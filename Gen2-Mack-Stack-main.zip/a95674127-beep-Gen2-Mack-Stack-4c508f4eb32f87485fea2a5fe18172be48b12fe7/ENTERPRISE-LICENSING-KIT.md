# AI INFINITY FORCE ONE — Enterprise Licensing Kit

**Master commercial document for Gen 2 Mack-Stack.**
Built 2026-11-19. Derived documents (listings, one-pager, outreach) follow
this file; where any derived copy disagrees with this file, this file wins.

**Status, stated plainly:** The strategy below is adopted. The BUSL license
is **not yet in force** — the code is private today, licenses are granted by
private agreement, and the BUSL parameters in §3 are a draft that requires
review by an intellectual-property attorney before activation. Prices are
asking prices. Sales to date: $0. No independent third-party review has been
completed yet; one has been requested.

---

## 1. Positioning

**Gen 2 Mack-Stack — Fail-closed Rust security. Evidence before promises.**

A security execution platform built around deterministic routing, isolated
worker processes, controlled execution lanes, and verifiable audit evidence.

What is sold is **verified security capability**, not ownership of the
source code. The five parts stay separate in every conversation:

- **Source code** lets a prospective customer inspect what was built.
- **Verification evidence** demonstrates what was actually tested.
- **Commercial licensing** gives the customer permission to deploy it.
- **Signed release attestations** establish exactly which build was evaluated.
- **Support and contractual commitments** give an enterprise someone accountable.

The owner (Allen Mack, sole proprietor) retains full intellectual-property
ownership under every license. Licenses are non-exclusive; the same work may
be licensed to multiple customers.

## 2. The product, described accurately

Gen 2 Mack-Stack, v0.14.2 — a 3-phase, 36-lane isolation sandbox:

- **Router:** 3-phase, 36 lanes (ingest → classify → route, one direction
  only). The lane count is a shipped, tested configuration —
  `LANE_COUNT = 36` in `infinity_mesh`, `dual_secret`, and `sibling_mesh`,
  exercised end to end by the `mack-mesh-demo` binary — not a marketing
  figure, and **not a pricing tier**: every license includes all 36 lanes.
- **Sessions:** dual-secret engine (partner-mask XOR over Shamir splitting)
  with honey termination, per-lane rate limiting, 8-second TTL, and keyed
  HMAC audit tags; InfinityMesh cover layer spreads shares across lanes
  with decoys, so a lost lane does not kill the session.
- **Egress:** fail-closed proxy — blind credential swap at the boundary,
  real HTTPS via CONNECT + split-TLS, child processes confined by
  **Landlock (filesystem + network) and seccomp**, with inherited-FD
  hygiene. There is no Wasmtime sandbox; wasmtime appears only as a
  transitive dependency of yara-x in the Gen 1 vault.
- **Proof:** hash-chained signed ledger with checkpoint anchoring, and a
  signed session receipt binding the version, confinement-policy digest,
  ledger head, and the measured SHA-256 of the proxy executable.
- **Stated limits:** single-process mesh model in this release; multi-device
  share transport is not built; chunked request bodies are refused;
  responses are relayed whole. **Not independently audited** — yet.

## 3. Licensing model (BUSL draft — attorney review required before use)

BUSL-1.1 is a source-available license, **not** an open-source license. Its
standard grant permits copying, modification, redistribution, and
non-production use; the production restriction lives in the parameters
below, which an IP attorney must draft into the actual license text before
this model is activated. Placing a file named LICENSE in the repository
does not by itself create these restrictions.

Draft parameters (from the 2026-11-19 licensing sketch, Allen's terms):

- **Licensor:** Allen Mack, sole proprietor (AI Infinity Force One)
- **Licensed Work:** Gen 2 Mack-Stack, per released version
- **Additional Use Grant:** read, copy, modify, run, and run the test suite
  for evaluation, research, and any non-production use; verify the signed
  attestation against the release
- **Use Limitation:** no production use; no offering the work or a
  derivative as a hosted or managed service to third parties; no embedding
  in a product offered to third parties
- **Change Date:** four (4) years after each version's first public release
  under the license (each version carries its own clock)
- **Change License:** Apache License 2.0

**Not covered by BUSL, ever:** Gen 1 MACK vault (its signed release record
stays frozen and untouched) and the MACK Verify GitHub Action (MIT, already
public, stays MIT).

**Trigger to activate:** a serious buyer or independent reviewer requires
source access. Until then, the current model — private code, license by
agreement — loses nothing.

## 4. Commercial tiers (Allen's live prices — unchanged)

| Tier | Price | What the customer gets |
| --- | --- | --- |
| Evaluation | $0 | Public starter kit (architecture), MACK Verify Action (MIT), published attestation + public key — verify the proof yourself |
| Pilot | $1,500 | Gen 2 pilot engagement, credited in full toward a license |
| Founder's | $5,000 | Non-exclusive license — first 3 only |
| Commercial | $19,900 | Standard non-exclusive license, production deployment rights |
| Complete Portfolio | $39,900 | Non-exclusive license to the full security portfolio (Gen 1, Gen 2, Gen 3, VaultLane, Stealth Core, Aegis-Seal, MACK Verify, starter kit, Smart-Flow) |
| OEM / Acquisition | Separate conversation | Embedding, redistribution, or ownership transfer — priced case by case, never from a rate card |

Pricing is based on verified functionality, deployment rights, evidence,
and support — **not** on lane count and not on seats. These are asking
prices, not established market values; the first pilot and the first
independent review are what turn an ask into a market signal.

## 5. Evidence standard — the evidence is the product

Every release ships a standardized evidence package. A buyer (or their
security team) can verify each item independently:

| Evidence | What the buyer can verify |
| --- | --- |
| Source commit | Exact source revision the results belong to |
| Test report | Test count and results, with the raw printout and its SHA-256 |
| CI results | Which automated checks passed, on whose runners |
| Fuzz report | Targets, executions, crashes |
| Security scan | Findings and exceptions, over the full git history |
| SBOM | Software dependencies (CycloneDX) |
| Binary SHA-256 | Exact tested artifact |
| Ed25519 signature | Authenticity and integrity of the signed statement |

**The honest distinction, printed in every package:** an owner-generated
Ed25519 signature proves *who signed the statement* and that it *has not
been altered*. It does not by itself prove the test results are true. That
is why the package carries raw printouts, hashes, and CI records that a
buyer can reproduce or re-run — independently reproducible evidence is the
differentiator, not a signature on a PDF.

Historical results are always labeled with the commit they belong to and
never presented as results for the current release. Current-release
results are stated only at the level actually observed.

**Never advertised:** zero vulnerabilities, zero bugs, or guaranteed
protection. Fail-closed is a design property, not a promise of perfection.

## 6. Terms kept in every deal

- License is per organization, non-transferable without written approval.
- The customer may not remove attestation material, license headers, or
  fail-closed checks.
- Support covers unmodified builds; modified builds receive best-effort only.
- Attestation is point-in-time verification of a specific build — not
  insurance against future attacks.
- No on-call incident response is promised unless a future Enterprise
  agreement says so in writing.
- An IP attorney reviews the BUSL parameters and the commercial agreement
  before the first sale under this model.

## 7. The remaining gap, and the plan for it

One gap outranks all others: **an independent third-party security review
of the current release.** Routes being pursued, in order:

1. A direct request to a qualified reviewer in the founder community
   (made 2026-11-19; awaiting reply).
2. University security research labs (one contacted 2026-11-12; a second
   identified with a verified contact, outreach prepared).
3. Any paid review becomes possible only after first revenue.

A completed review sells alongside the license and the evidence: the right
to use the technology, proof the release passed documented testing, and
access to the creator for integration and support.

---

*Built by Allen Mack — independent developer and system architect,
Williston, Florida. AI Infinity Force One.*
