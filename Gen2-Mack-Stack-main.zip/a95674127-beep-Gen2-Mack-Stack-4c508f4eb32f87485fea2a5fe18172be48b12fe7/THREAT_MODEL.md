# Threat Model — Gen 2 Mack-Stack

## Primary threat

**Secret exposure during execution.** Untrusted workloads, third-party
plugins, and autonomous agents are compromised or manipulated (including
by prompt injection) and exfiltrate the credentials they were given:
API keys, tokens, private keys, decrypted records.

## In scope

- A malicious or compromised workload inside a lane: it must find no raw
  secret in its memory, filesystem, or environment to steal.
- A single lost or stolen device: it holds only a key share; alone it can
  sign nothing and decrypt nothing.
- Tampering with the execution record: the hash chain and signed
  checkpoints make silent edits, truncation, and rollback detectable.
- Replay of a captured grant: leases are scoped, expiring, and bound to
  the checkpoint sequence.

## Out of scope — stated honestly

- **A compromised host kernel or root attacker on the same machine.**
  Pure software cannot shield memory from the kernel that owns it; this
  system's threshold design answers by ensuring no single machine holds
  a whole key, so one fully-owned device still cannot sign alone.
- Physical coercion of the owner.
- Availability attacks against the owner's own devices.

## Assumptions

- The cryptography is the published, audited kind (Argon2id,
  XChaCha20-Poly1305, Ed25519, RFC 9591 FROST) — implementation bugs are
  hunted with tests, not assumed away.
- Participants in key generation can authenticate each other's packages;
  the transport that carries shares between devices must provide that
  authentication and is part of this system's build.

## TLS transport (v0.9.0) — invariants

- Split-TLS is a deliberate trust decision: the proxy terminates
  the child's TLS so the credential swap can happen at the
  boundary. The proxy process therefore sees request plaintext.
  The alternatives are an opaque tunnel (no injection possible)
  or handing the child the real secret (no boundary at all).
- The session CA is generated per run, in memory only. Its
  private key is never written to disk, never logged, and dies
  with the process. Only the public certificate is written, at
  mode 0600 in a per-run file that is deleted at exit.
- A stray `no_proxy` in the child's inherited environment would
  silently bypass the boundary; TLS mode clears it for the child.
- Every request is authorized individually: sentinel verdict,
  then a scoped, expiring, single-use handle, burned before the
  vault is unsealed. Session continuity comes from successor
  mints, each one a signed-ledger entry — never from reusing a
  handle.
- Upstream trust is the Mozilla root store plus operator-added
  roots only (additive; `MACK_UPSTREAM_CA_PEM`). When
  `HTTPS_PROXY` is set, the upstream leg tunnels through it, but
  the tunnel does not decide trust — the root store does.
- TLS-path failures are logged to stderr with the host named.
  A proxy that fails silently teaches the child to route around
  it; this one fails loudly.
