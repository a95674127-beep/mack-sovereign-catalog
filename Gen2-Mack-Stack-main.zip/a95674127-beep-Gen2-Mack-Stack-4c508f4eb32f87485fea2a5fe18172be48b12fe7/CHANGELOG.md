# Changelog — Gen2-Mack-Stack (mack-security-runtime)

All versions are local-first: built, tested, and proven on the
operator's machine before any push. Test counts are `cargo test`
totals on this machine (rustc 1.99.1); CI verification on GitHub
Actions awaits the December 1, 2026 quota reset, like the rest of
the estate's private repos.

## Unreleased

## 0.16.0 — 2026-11-23

Performance release. No API, wire-format, on-disk-format, or
dependency changes; no security property weakened — every
change is the same computation with redundant work removed,
and the full suite (123 tests) passes unchanged.

- **Shamir reconstruction ~12–20× faster.** The Lagrange
  basis coefficients at x = 0 depend only on the share
  indices, but `reconstruct_secret` recomputed them —
  including a GF(256) inversion — for every byte of the
  secret. They are now computed once per call. Measured on
  the lab VM (release build, median of 3): 32-byte secret,
  k = 2: 14.1 µs → 1.16 µs per reconstruction; 256-byte
  secret, k = 3: 182.9 µs → 9.4 µs. Reconstructed values are
  bit-for-bit identical. This is the path the proxy runs at
  every credential injection.
- **Shamir splitting ~3–8× faster.** `split_secret` drew the
  per-byte polynomial coefficients with one CSPRNG call per
  byte; all coefficients are now drawn in a single call (the
  distribution is identical — independent uniform bytes).
  32-byte, k = 2, n = 3: 14.0 µs → 1.8 µs; 256-byte, k = 3,
  n = 5: 130.6 µs → 39.0 µs.
- **Mesh receive under load ~30× faster.** `receive` and
  `open_session` ran a full expiry sweep — a scan of every
  open session plus an allocation — on every call. Because
  all sessions share one TTL, a watermark on the oldest
  session's creation time now skips the sweep whenever
  nothing can have expired. Decoy receive with 500 sessions
  open: 3.74 µs → 0.12 µs. Expiry behavior is unchanged
  (the TTL test exercises the sweep path).

## 0.14.2 — 2026-11-18
Diagnostics + platform documentation, on the operator's
decision after the v0.12.0 Chromebook run diagnosed the
proxy-spawn failures to a kernel limit (that kernel does
not expose Landlock NET rules; FS Landlock works):

- **Documented platform limit.** Containerless ChromeOS
  Crostini is recorded in the README as unsupported for
  `mack-proxy`'s network-confined mode. The stack still
  fails closed there — it refuses to run a child without
  network confinement rather than weakening the guarantee.
  No FS-only fallback was adopted.
- **Startup confinement probe.** `LandlockSandbox` gains
  `probe_strict_isolation_with_network`: the exact
  enforcement ruleset built through a shared builder,
  without `restrict_self`. `mack-proxy` probes before
  spawning and, on an incapable kernel, exits at startup
  with the kernel's real reason (e.g.
  `NetworkConfinementUnsupported(...)`) instead of the
  run dying at child spawn behind a bare `EINVAL` — all
  that survives std's spawn error pipe from a `pre_exec`
  closure. A test asserts probe and enforcement agree.
- **pre_exec error reporting.** Every fallible `pre_exec`
  step (Landlock, rlimits, cgroup join, FD hygiene,
  seccomp) now writes its failure to the child's stderr
  before returning the error — the technique the FD audit
  already used for its own refusal — so the cause reaches
  the operator even though the errno cannot carry it.
- **Ledger e2e hang fixed.** The binary ledger test's
  upstream server used a blocking `accept()` joined before
  the output assert: when a child launch failed, no
  request ever arrived and the test hung instead of
  failing. The accept is now deadline-bounded (30s) and
  the proxy's outcome is asserted before the join.

## 0.14.1 — 2026-11-18
Hardening patch for the assembled mesh system, scoped
from an external review of the paste files — graded
against the shipped code first: the review's x == 0
share-forgery finding does NOT apply (the shipped
`secret_split` already rejects index 0), and four findings
did. All four are fixed here, in `dual_secret` only:

- **Lane state is engine-level.** The per-lane rate-limit
  state moved from `Session` to `Engine`, and the lane
  check now runs BEFORE the session lookup: a 30-second
  lane block genuinely outlives an 8-second session, and
  attempts against unknown session ids are throttled
  instead of free.
- **Payload integrity.** Each session stores a keyed
  payload commitment (HMAC-SHA-256, truncated, compared
  in constant time) taken at creation. A reconstruction
  that does not match fails with the new
  `DualError::IntegrityFailure` and the session SURVIVES —
  bogus or tampered shares no longer burn a session or
  return silent garbage.
- **Session hygiene.** Sessions are removed the moment
  they expire, trip honey, or complete;
  `Engine::purge_expired` (called on every
  `create_session`) sweeps abandoned ones. The audit log
  is capped at 1,024 tags, oldest dropped first.
- **Vestigial replay set removed.** The per-session
  used-share set could never trigger (it was populated
  only immediately before the session was deleted); the
  `Replay` error variant went with it. Replay defence is
  what it always actually was: the session is removed on
  success, so its id returns `UnknownSession` forever.
  `DualError::SessionTerminated` also removed — terminal
  sessions no longer exist in the registry to be reported.

## 0.14.0 — 2026-11-18
The Infinity paste set, assembled into one system at the
operator's order. The pastes were held verbatim and graded
as designs; what merged is a re-implementation on the
crate's existing primitives — no paste code was copied in,
and no new dependency was added.

- **Dual-secret engine** (`dual_secret`). Payload masked
  with a random partner; both halves split 3-of-5 on the
  SHIPPED `secret_split` (the paste set carried two more
  Shamir copies; both were dropped — one implementation to
  audit). Session discipline: 8-second TTL on caller
  Instants, honey x-coordinates (200/201) that terminate
  the session, per-lane rolling-window rate limiting with
  a 30-second block enforced before any reconstruction,
  single-completion sessions (replay-proof by removal),
  and a keyed audit log of 16-byte HMAC-SHA-256 tags
  (HMAC hand-rolled on the existing `sha2` dependency and
  pinned to the RFC 4231 vector in tests).
- **Sibling-mesh router** (`sibling_mesh`). Three phases
  in order — ingestion, classification (lane/kind/x only),
  deterministic routing into 36 per-lane FIFO queues —
  over the engine. Collection returns through the engine,
  so its checks are never bypassed.
- **Mesh transport** (`mesh_transport`). Shares in flight
  are XChaCha20-Poly1305-encrypted under per-share keys
  derived as SHA-256(master ‖ tag ‖ lane ‖ label ‖ x),
  with those fields also bound as AAD. The paste's AES-GCM
  stack and its unkeyed SHA-384 sidecar hash were NOT
  adopted (second cipher stack; AEAD already
  authenticates). End-to-end test: engine → transport →
  engine reconstructs.
- **`mack-mesh-demo` binary.** Runs the assembled system
  in a terminal against a one-lane observer and prints
  only numbers computed from the run (packets seen, real
  shares among them, decoys dropped, rebuild verdict);
  exit 0 on an exact rebuild.
- Honest scope, stated in the module docs: assembled from
  an unaudited external design, not itself independently
  audited; single-process; no network transport yet.

## 0.13.0 — 2026-11-18
One addition: the cover layer the v0.12.0 split was missing,
built from a lab-graded external design paste (graded
2026-11-18 in a scratch lab before any of it was merged; the
paste's split was NOT adopted — the shipped Shamir stays).

- **InfinityMesh cover layer** (`infinity_mesh`). A session's
  Shamir shares travel as opaque payloads on pre-spread lanes
  (of 36) under unrelated random tags, at staggered,
  jittered times, mixed with decoy shares that are identical
  in size, shape, and label distribution. The receiver's
  control map (tag → session) is the only place pairings
  exist and never travels; decoys and unknown tags drop
  silently. Sessions close the moment the Shamir threshold
  k is met — losing a lane no longer kills the session, the
  graded paste design's all-or-nothing flaw. Graded defects
  fixed on the way in: a valid tag with a wrong-length
  payload is dropped instead of panicking the receiver
  (regression-tested); collected payloads are zeroized when
  a session closes or expires; expiry is swept on every
  public entry point plus an explicit `purge_expired`.
  Honest scope, stated in the module docs: single-process
  model (sender session and receiver map in one object), no
  real network transport, lazy expiry with no background
  thread, TTL clock starts at session creation. 11 new tests
  including an end-to-end 2-of-3 rebuild with one lane lost.

## 0.12.0 — 2026-11-17
Five additions in the same spirit as 0.11.0: each takes a
mechanism an evaluator was asked to trust and gives it an
artifact or a refusal that can be exercised independently.

- **Inherited-FD hygiene in the confined-child pre_exec chain**
  (mack-proxy, between the cgroup join and seccomp). The
  child's stdio fds are audited with
  `getsockopt(SOL_SOCKET, SO_TYPE)`: a SOCK_DGRAM socket
  inherited on fd 0, 1, or 2 refuses the spawn — a pre-built
  datagram channel is the one UDP path the seccomp profile,
  which filters socket CREATION, cannot govern. Every other
  inherited descriptor (fd ≥ 3) is then closed with
  `close_range(3, u32::MAX)`; if the syscall is unavailable
  or fails, the spawn fails closed. The refusal is stated on
  the child's stderr before the spawn aborts (an io error
  returned from pre_exec crosses the spawn pipe as a bare
  errno). New suite `tests/fd_hygiene.rs` (2 tests:
  UDP-socket stdin refused with exit 3 and the child never
  runs; ordinary stdio as positive control), and the Escape
  Lab gains the same case asserted from the observed spawn
  result (`tests/adversarial_harness.rs`, now 14 cases).
- **External checkpoint anchoring** (`ledger::store` +
  `mack-ledger-verify`). A signed in-chain checkpoint can now
  be extracted into a sidecar JSON
  (`mack-ledger-verify <ledger> --extract-checkpoint <sidecar>`)
  — no private key involved; the sidecar copies the
  checkpoint's already-signed commitment (sequence, committed
  head, record count, signature). The verify mode
  `--against-checkpoint <sidecar>` checks the sidecar
  signature against the authority key it names, fully
  verifies the ledger chain, and then requires the file's
  head and record count to equal the checkpoint's: a file
  MISSING records the checkpoint commits to fails with a
  distinct `TailTruncation` error naming both counts — the
  one manipulation plain chain verification cannot see,
  because a truncated file is still a valid chain prefix —
  and extra records or a different head fail with
  `CheckpointMismatch`. Anchoring is an anti-rollback control
  for the checkpoint holder; it does not stop a checkpoint
  from being issued, it makes history older than the
  checkpoint unpresentable as complete. New suite
  `tests/checkpoint_anchoring.rs` (5 tests: roundtrip via
  library and CLI, truncated copy, extended copy, flipped
  signature byte, foreign ledger's sidecar).
- **Shamir split of the proxy-held secret** (`secret_split`,
  new). GF(256) Shamir by hand — no new dependencies — k=2
  of n=3, coefficients drawn from OsRng, shares zeroized on
  drop, reconstruction into a `Zeroizing` buffer. The proxy
  splits the secret at session start and drops the assembled
  buffer; on each injection it reconstructs transiently,
  builds the Authorization header, and lets the buffer
  zeroize on drop. The vault path is unchanged for
  vault-registered references. **Stated plainly: the three
  shares are co-located in the proxy process in this
  release.** The gain is narrow and real — the assembled
  secret exists only transiently during a burn — and it is
  NOT multi-party custody; distributing shares waits on the
  multi-device transport that also gates FROST-gated minting.
  6 unit tests: roundtrips at 1/2/16/32/64 bytes, every pair
  reconstructs, one share fails, a flipped share byte yields
  a wrong secret, duplicate/mismatched/zero-index shares and
  invalid parameters are refused.
- **Runtime session receipt** (`session_receipt`, new). At
  shutdown, after the final checkpoint, the proxy signs a
  receipt binding the crate version, a SHA-256 digest of a
  canonical summary of the confinement actually applied
  (Landlock ruleset inputs, the governor's rlimit values,
  the seccomp profile identifier, the FD-hygiene steps, and
  the cgroup outcome exactly as the run reported it), the
  ledger's final head hash and record count, the SHA-256 of
  the proxy executable measured from `current_exe()` at
  receipt time (never a placeholder — if the executable
  cannot be measured, no receipt is emitted and the failure
  is stated), and a Unix timestamp. The signing key is the
  same key that signed the session ledger; the receipt
  records its provenance (`authority` for a persistent
  ledger's operator key, `session-ephemeral` for the
  in-memory path, which is honestly worth less). The receipt
  prints as JSON to the proxy's stdout and, with a persistent
  ledger, is written to `<ledger>.receipt.json`. The demo
  script's new check 4c binds the receipt against the
  independently verified ledger and the binary on disk (demo
  now 10 checks). New suite `tests/session_receipt.rs`
  (2 tests) plus 3 unit tests (roundtrip, tamper-per-field,
  real executable measurement).
- **Handle table with loom models** (`handle_table`, new).
  The proxy's per-host handle tracking moved out of the
  binary into a library module with the standard loom/std
  sync shim; the binary resolves the current handle from it,
  records each burn after a successful egress (before minting
  the successor, which the table refuses otherwise), and
  closes the table at shutdown. `loom` is a dev-dependency
  only, behind `--cfg loom` with the cfg registered in
  Cargo.toml `[lints.rust]`, so normal builds are unchanged.
  Four models assert the strong properties: exactly one of
  two racing burns succeeds; a burn ordered after close
  completes always fails; a burn completed before close
  succeeds (ordering established with Release/Acquire atomic
  flags — loom 0.7's Barrier is an unimplemented stub — not
  an either-outcome assertion); a successor exists only after
  its predecessor burned. All 59 pre-existing tests pass
  unchanged (the proxy e2e suites are the regression proof);
  one visible consequence: on the loopback path a second
  request now fails handle resolution (the burned handle is
  gone) rather than replay detection — refused either way.

## 0.11.0 — 2026-11-17
The hardened release: five work items, one theme — every claim
the demo makes is now backed by a mechanism an evaluator can
exercise independently.

- **Persistent signed ledger** (`ledger::store`, new binary
  `mack-ledger-verify`). The `mack-proxy` session ledger can now
  be append-only on disk (`--ledger <path>`, env
  `MACK_LEDGER_PATH`): a JSON-lines file whose header binds it
  to one Ed25519 authority; every entry is written through and
  fsynced before it joins the in-memory chain, so the file is
  always a prefix of the chain. On open the chain is reloaded
  and fully re-verified; the crash rule is exact — a final line
  that fails to parse is a torn write, truncated with a signed
  `LEDGER_TORN_TAIL_RECOVERY` entry recording it, while anything
  parseable-but-wrong (altered, removed, or reordered entries,
  a foreign authority key) refuses the open. Signed checkpoints
  at shutdown commit to the pre-checkpoint tip; an export is the
  ledger file plus a manifest that `verify_export` cross-checks
  against the chain itself. `mack-ledger-verify` validates a
  file or an export directory end to end with no signing key
  and no live session. The authority seed lives in a key file
  (default `<ledger>.key`, created 0600). Without `--ledger`
  the ledger stays in-memory, as before. New suite
  `tests/ledger_persistence.rs` (8 tests): restart round-trip,
  foreign-authority refusal, tamper/removal/reorder detection,
  torn-tail recovery, export cross-check, and the binary path
  (proxy writes, verify tool confirms, second run continues
  the chain).
- **Seccomp workload profile for proxy children**
  (`SeccompEnforcer::build_workload_bpf`). Arbitrary child
  commands now run under a baseline denylist-over-default-allow
  profile (the worker lane's allowlist is unchanged): ptrace,
  mount, module loading, bpf, perf_event_open, io_uring,
  keyring syscalls, open_by_handle_at, swap, reboot, and setns
  fail with EPERM (never a kill, so probing runtimes can fall
  back); `unshare`/`clone` are denied when any `CLONE_NEW*`
  flag is set; and `socket()` argument filtering denies
  `AF_INET`/`AF_INET6` datagram sockets and raw sockets with
  EPERM — the mechanism that removes the child's direct UDP
  path, which Landlock's TCP-only rules never governed. The
  filter is built in the parent for the host architecture
  (x86_64 wired and test-proven here; aarch64 uses the same
  construction) and installed in `pre_exec`; any failure
  aborts the run or the spawn. Documented residuals: `clone3`
  flags sit behind a pointer seccomp cannot inspect and are
  not filtered (Landlock still binds such a child), and the
  profile is a denylist, not an allowlist. Both existing proxy
  e2e suites pass unchanged under it. New suite
  `tests/workload_seccomp.rs` (3 tests): UDP/UDP6/raw EPERM
  with a working TCP control, denied-syscall EPERM with a
  flagless-unshare control, and filter presence asserted via
  `/proc/self/status` (exactly one filter more than the test
  process carries).
- **Resource Governor v1** (`sandbox::resource_governor`).
  Every proxy child runs under rlimits set in `pre_exec` —
  `RLIMIT_AS` 512 MiB, `RLIMIT_CPU` 60 s, `RLIMIT_FSIZE`
  128 MiB, `RLIMIT_CORE` 0 by default, all flag/env
  configurable; a set failure aborts the spawn. A per-run
  cgroup v2 (`memory.max`, `cpu.max` = 100% of one CPU,
  `pids.max` 64) is created and joined in `pre_exec` where a
  delegated writable subtree exists. The run prints one report
  line naming exactly what was applied; process-count limiting
  is cgroup-only (`RLIMIT_NPROC` is per-UID and deliberately
  not used) and is reported as unenforced without the cgroup
  layer. In this build environment the cgroup root accepts
  directory creation but refuses control-file writes, so the
  layer is reported not applied here — the report, not the
  hope, is the feature. New suite `tests/resource_governor.rs`
  (3 tests): memory cap kills an over-allocating child, CPU
  cap kills a spinner, and the report line is checked against
  an independent delegation probe.
- **Escape Lab — adversarial harness extended**
  (`tests/adversarial_harness.rs`, 7 → 13 cases). New live
  cases, each asserting the denial from the child's observed
  result: direct TCP to a non-proxy port refused (EACCES)
  with a working proxied control; direct UDP refused (EPERM);
  child writes to the proxy's ledger file and file creation
  outside its grants refused (EACCES) with the ledger still
  verifying afterwards; memory exhaustion contained by the
  governor; a child that SIGKILLs itself after a successful
  request leaves a persistent ledger — checkpoint included —
  that `mack-ledger-verify` validates; and a fork attempt
  gated on the governor's cgroup layer being active in the
  environment (in this environment the case asserts the
  report's disclosure instead of forking). Burned-handle
  replay remains covered at the library level in
  `tests/policy_core.rs`.
- **Local release evidence**. `sbom.cdx.json` (repository
  root): a CycloneDX 1.5 SBOM generated from the locked
  dependency tree by `scripts/generate_sbom.py` — 180
  components with name, version, and license; dev-only
  packages are marked `scope: excluded`. `RELEASE_EVIDENCE.md`
  documents how to reproduce the release binaries' SHA-256
  hashes (and the two-clean-build reproducibility check) and
  states the deferral plainly: signed Sigstore/SLSA
  provenance via GitHub Actions waits for the 2026-12-01
  Actions quota reset and owner-placed workflow files, and
  is not claimed until then.
- Demo: `scripts/demo_live_api.sh` now runs the proxy with a
  per-run persistent ledger and verifies the file
  independently as a new check (9 checks, all passing in this
  environment, 2026-11-17); its confinement section names the
  seccomp profile and the governor, and its direct leg now
  observes the resolution-level failure the UDP denial
  produces, reported as observed. Full suite 59/59.

## 0.10.0 — 2026-11-17
- Network confinement for the `mack-proxy` child: the child's
  Landlock ruleset now also handles
  `LANDLOCK_ACCESS_NET_CONNECT_TCP` (Landlock ABI v4) with a
  single `NetPort` grant for the proxy's own port, so the
  kernel denies the child's outbound TCP connects to every
  other port at `connect()` time, before any traffic.
  Enforcement is a hard requirement — on a kernel without
  Landlock network rules (ABI < v4, kernel < 6.7) the spawn
  aborts instead of running the child without network
  confinement (fail-closed, no silent downgrade). New library
  entry point:
  `LandlockSandbox::enforce_strict_isolation_with_network`;
  the filesystem-only `enforce_strict_isolation` used by the
  in-process worker lane is unchanged. New tests
  (`tests/network_confinement.rs`, live-enforced on this
  kernel): a confined thread reaches the allowed port, is
  refused with EACCES on a different live loopback port, is
  refused with EACCES on a non-loopback TEST-NET address
  before any traffic, and reaches nothing with an empty
  allowed-port list. Stated limits, not hidden: Landlock
  network rules match ports, not addresses — a connect to
  any address on the allowed port passes the ruleset (the
  allowed port is the proxy's per-run ephemeral loopback
  port); only TCP connect is governed — UDP and other
  protocols are outside Landlock's network rules, and
  bind/listen is not restricted. Full suite 39/39.
- Demo correction (found by re-running the demo): the session
  token is NOT single-use — it is a session-scoped resolver the
  proxy swaps for the current per-host handle; the single-use
  layer is the per-host handles (burned at the boundary, successor
  minted per request). The demo's earlier check 7 asserted the
  wrong layer, and its header claimed the printed token was
  "already burned" — both corrected: the session token is now
  redacted like the key (new check 3b), and check 7 verifies
  rotation (a second use must authenticate through the successor;
  a refusal fails; a transport failure is inconclusive and fails
  the run). The earlier run's exit-52 reuse result was a dropped
  connection, not a refusal. The demo's Confinement section also
  now reports the host machine's network behavior as observed
  (conditional note) instead of describing one sandbox.
- Release-verification cleanup: the full eight-command checklist
  (fmt --check, test --locked --all-targets, clippy --locked
  --all-targets with -D warnings, release build, cargo audit,
  cargo deny check) now passes end to end. Clippy cleanup fixed
  twelve lints with no allow-suppressions: needless borrows in the
  hashers, `eq_ignore_ascii_case` for the proxy's host/action scope
  checks, `std::io::Error::other`, a redundant `trim_end`, a
  by-value `OsRng` for FROST DKG, `std::slice::from_ref` in tests,
  and `BuildProvenance::create_signed` now takes a single
  `ProvenanceInputs` parameter object instead of ten arguments.
  Added `deny.toml`: vulnerabilities fail the advisories check;
  licenses restricted to the permissive set present in the tree
  (incl. CDLA-Permissive-2.0 for webpki-roots); sources restricted
  to crates.io; the one unmaintained notice (atomic-polyfill,
  RUSTSEC-2023-0089 — the same advisory `cargo audit` allows) is
  ignored by ID with its reason recorded in the file.
- `scripts/demo_live_api.sh` — credential-injection demo against
  httpbin.org/bearer, a public echo service (not a provider API):
  a fresh demo key held only in the proxy's environment, injected
  at the boundary; the echoed token proves the swap. First live
  run 2026-11-16 passed its checks, with the proxy leg succeeding
  on a retry after a target hiccup (disclosed in the summary);
  full suite 37/37.
- Demo corrected the same day after an audit of the first version:
  (1) the token is no longer printed — only a truncated SHA-256
  (the first version printed it in full; with a real key that
  would publish it); (2) the child's direct-attempt leg now uses
  the system CA bundle — the first version let it inherit the
  session CA, so its TLS failure (curl exit 35) said nothing
  about the network; the leg now labels its failure level as
  observed (HTTP 401 = reached and refused; connect-level exit =
  network refused); (3) the ledger check now prints the proxy's
  "Run complete" line verbatim (entry count + tip hash) — the
  session ledger is in-memory and leaves no file;
  (4) the workload-environment evidence is printed names-only
  except proxy-relevant values — a full env dump can carry
  unrelated credentials; (5) the direct leg strips every proxy
  variable (including all_proxy). Audit outcome for the bypass
  question, both legs run 2026-11-16: with a network path the
  workload REACHES the endpoint and is refused with HTTP 401
  (credential isolation holds; network isolation absent); fully
  direct in this sandbox the attempt dies at TLS (curl exit 35)
  under both the system bundle and the sandbox egress bundle —
  the sandbox itself breaks direct egress, so the clean
  connection-level failure cannot be produced inside this VM.
- Second audit round, same day — evidence printed, not asserted:
  the outside control is printed in full (body, HTTP code, curl
  exit); the demo names the confinement in its output (Landlock
  filesystem ruleset; no network namespace, no network rules) and
  states that in this sandbox the direct leg measures the
  sandbox's own interception (the target resolves to a sinkhole
  address that answers a TLS ClientHello with non-TLS bytes —
  curl 'wrong version number', exit 35, identical inside and
  outside the workload, verified with curl -v); a handle-reuse
  leg proves the printed handle is burned (second use refused).
- `mack-proxy`: prints an explicit shutdown line —
  "Ledger verification: OK — signed chain valid (N entries,
  tip H)" — after `verify_chain()` succeeds. The session CA
  public PEM now lives in /dev/shm at mode 0444 per the design
  plan (public certificate only; /tmp fallback; deleted at
  exit); the TLS e2e assertion accepts either tmpfs location.
  Full suite 37/37 after the changes.

## 0.9.0 — 2026-11-15
- Real HTTPS transport for `mack-proxy` (`--tls`): CONNECT +
  split-TLS termination under the crate's existing foundations —
  the Landlock-confined child, the signed session ledger, the
  sentinel verdict, and vault unsealing all unchanged; the swap
  decision is the same `BlindEgressProxy::execute_egress`, now with
  the true scheme `https`. Design adopted from an externally
  proposed package after lab grading (grade file Part 13): its
  transport mechanism was proven live, its wholesale replacement
  of the proxy was rejected.
- Per-session in-memory CA (`proxy::tls::EphemeralSessionCa`,
  rcgen + rustls/ring): the CA private key never leaves the proxy
  process; only the public PEM is written (0600, deleted at exit)
  for the child to pin via the `SSL_CERT_FILE` family. The proxy
  therefore sees request plaintext at the boundary — inherent to
  credential injection, stated in THREAT_MODEL.md.
- Handles remain single-use; after each successful swap the
  session quorum mints a successor handle for that host (a
  signed-ledger entry per mint), so a session is multi-request
  while every request carries its own scoped, expiring handle.
- Upstream verification against the Mozilla root store
  (webpki-roots), plus additive operator roots via
  `MACK_UPSTREAM_CA_PEM`. The upstream leg honors `HTTPS_PROXY`
  (CONNECT tunnel) when set. TLS-mode errors are logged, never
  silent. Stated limits: request bodies need a Content-Length
  (chunked requests are refused); responses are relayed whole,
  not streamed.
- End-to-end test (`tests/proxy_tls_e2e.rs`): local HTTPS upstream
  under a test CA — injection verified at the upstream, second
  in-session request succeeds, forged handle denied, unlisted
  host refused at CONNECT, child environment secret-free.
  Verified live against https://example.com (two in-session
  requests, both 200, signed ledger verified at shutdown).
  37 tests passing, 0 failed; rustc warnings 0. Reproducible
  build re-verified 2026-11-15: two clean builds bit-identical
  (mack-security-runtime `f4fd4c78…`, mack-proxy `1b27ea6c…`).

## 0.8.0 — 2026-11-15
- Permanent adversarial harness (`tests/adversarial_harness.rs`):
  the strongest attack case per module in one suite, including the
  field-boundary collision regression. 7 cases, every attack fails.
- Reproducible-build verification (`scripts/verify_reproducible_build.sh`):
  two clean builds of both binaries are bit-identical (verified
  2026-11-15 on this machine; SHA-256 `c4273d2a…` / `e31d77b8…`).

## 0.7.0 — 2026-11-15
- Deterministic forensic replay (`forensic::replay`): real
  re-execution of a recorded workload, plain or inside the sandbox
  worker; digest mismatch is reported as a finding.
- CDR disarm-and-rebuild (`ContentDisarmEngine::disarm_text_payload`):
  script blocks removed, script URI schemes neutralized, NUL and
  ANSI stripped — cleaned bytes returned, not the original.

## 0.6.0 — 2026-11-15
- Capability leases (`proof_fabric::leases`): signed, scoped,
  expiring grants bound to one envelope, judged against a named
  `Clock` source; one-hour TTL cap.
- Seen-nonce replay store + `verify_envelope_once`: a captured
  envelope cannot be spent twice; forged envelopes cannot poison
  the store.

## 0.5.0 — 2026-11-15
- FROST threshold signatures (`threshold`): real RFC 9591
  `frost-ed25519` — dealerless DKG, quorum signing, aggregate
  signatures verifiable as ordinary Ed25519. Proven in the scratch
  lab before integration. Multi-device transport is NOT included
  and not claimed.

## 0.4.0 — 2026-11-15
- `mack-proxy` binary: blind-egress loopback proxy — fail-closed
  Landlock child, env-scrubbed secrets, per-host scoped handles,
  signed session ledger, live TCP end-to-end test. Loopback HTTP
  only, behind an explicit recorded `--insecure-loopback` flag;
  TLS/remote transport refused, not simulated.

## 0.3.0 — 2026-11-15
- Unification release: the verified policy core and an externally
  proposed design merged file-by-file under the crate's honesty
  rules (signed ledger mode, sealed envelopes, compound attestation,
  provenance records, CDR first step, Landlock+seccomp worker).
  Imported false labels were corrected in the code's own docs:
  multisig is not FROST, lane capacity records are not a mesh, and
  provenance records are not an SLSA level.

## 0.2.0 — 2026-11-15
- The policy core: vault (Argon2id + XChaCha20-Poly1305), egress
  sentinel, hash-chained proof ledger, multisig mint authority
  (named honestly as multisig), sandbox seams.

## 0.1.0 — 2026-11-14
- Initial crate: architecture and threat-model documents, module
  skeleton.
