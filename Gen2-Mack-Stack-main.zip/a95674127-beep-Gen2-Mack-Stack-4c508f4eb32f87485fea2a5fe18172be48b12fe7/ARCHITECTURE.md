# Architecture — Gen 2 Mack-Stack

## The problem

When untrusted code or an autonomous agent executes, platforms today hand
it the very secrets it might leak: API keys decrypted into its memory,
tokens sitting in its environment. One compromised dependency or one
prompt-injected agent, and the secret is gone.

## The shape

- **`vault`** — the at-rest core. Argon2id-derived keys seal payloads with
  XChaCha20-Poly1305; every seal writes a hash-chained audit entry. One
  envelope format lives here, and the rest of the system conforms to it —
  never a second divergent copy (the Generation 1 lesson).
- **`sandbox`** — execution lanes confined by Landlock (filesystem;
  TCP-connect rules for the proxy child) and
  seccomp (syscalls), on Generation 1's proven fail-closed patterns.
  The proxy child additionally runs under a baseline seccomp
  workload profile (dangerous syscalls denied; UDP and raw sockets
  denied by `socket()` argument filtering, so TCP to the proxy is
  its only network path) and the resource governor (per-child
  rlimits, plus cgroup v2 limits where a delegated subtree
  exists — reported as applied or not, never assumed).
  Since v0.12.0 the child's inherited descriptors are part of the
  confinement: a datagram socket inherited on stdio — a channel
  created before the seccomp filter existed — refuses the spawn,
  and every other inherited descriptor is closed before exec.
  Workloads run with the least execution they need and nothing more.
- **`proof_fabric`** — intent-bound envelopes and capability leases: work
  enters a lane only as a signed, scoped, expiring grant. Envelopes sign a
  domain-separated digest; replay protection binds to the checkpoint
  sequence; lease expiry names its clock source.
- **Threshold trust** — keys split across the owner's own devices with
  RFC 9591 FROST (`frost-ed25519`, proven in lab 2026-11-15): any 2 of 3
  devices can sign; no device holds the whole key; the output is an
  ordinary Ed25519 signature any existing verifier accepts. Placement in
  this tree is an open layout decision.
- **`cdr`** — documents are disarmed and reconstructed before a lane ever
  sees them.
- **`forensic`** — the flight recorder: a hash-chained record of what
  executed, extended toward per-decision attestation, so an incident can
  be replayed from evidence instead of argued from memory. Since
  v0.11.0 the record can be durable evidence rather than a
  shutdown printout: the signed ledger persists append-only to
  disk (write-through per entry, torn-tail crash recovery,
  signed checkpoints) and verifies independently of the process
  that wrote it (`mack-ledger-verify`). Since v0.12.0 the
  checkpoint is also an external anchor: extracted to a
  sidecar, it makes a tail-truncated ledger — otherwise a
  valid chain prefix — fail verification with a distinct
  error; and each proxy run closes with a signed session
  receipt binding the run's confinement policy digest, the
  ledger's final head and count, and the measured hash of the
  executable that ran.

## Dataflow thesis

A lane requests an action; the policy side checks the envelope and lease;
the secret — if one is needed at all — is injected only at the boundary
where the action leaves, and never becomes resident in the lane. What the
lane never holds, the lane cannot leak.

On the proxy's side of the boundary, residency is minimized too:
since v0.12.0 the proxy holds its secret as 2-of-3 Shamir shares
(`secret_split`, hand-rolled GF(256)) and reconstructs it only
transiently inside a burn. The shares are co-located in the proxy
process in this release — the assembled secret's residency window
shrinks to the burn, but custody is not distributed; that waits on
the multi-device transport named under Threshold trust.
