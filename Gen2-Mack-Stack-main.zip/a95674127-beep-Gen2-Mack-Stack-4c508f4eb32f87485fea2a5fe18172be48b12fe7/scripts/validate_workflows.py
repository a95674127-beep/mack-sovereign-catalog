#!/usr/bin/env python3
"""
MACK Security Runtime — Automated Workflow Concurrency & Release Safety Validator

Validates GitHub Actions workflows to guarantee:
1. Concurrency blocks exist and are strictly isolated by workflow namespace.
2. Concurrency expressions (${{ ... }}) are syntactically valid with balanced braces, parens, and quotes.
3. Invalid context accesses (e.g. matrix references at workflow level) are caught.
4. Release workflows and tag-triggered jobs are immune to accidental cancellation.
5. Simulated contextual evaluation verifies cancel-in-progress evaluates to FALSE under release tag events.
6. Reports the exact workflow file and line number for each failed concurrency invariant.
"""

import os
import sys
import re
import argparse

# Use PyYAML if available, with resilient fallback parser tailored for GHA structures
try:
    import yaml
    HAS_PYYAML = True
except ImportError:
    HAS_PYYAML = False


def extract_source_excerpt(content, target_line, context_lines=2):
    """
    Extracts a contextual source excerpt around target_line with gutter line numbers and pointer.
    Example:
         5 | concurrency:
         6 |   group: ${{ github.workflow }}-${{ github.ref }}
       > 7 |   cancel-in-progress: true
         8 | jobs:
    """
    if not content or target_line is None:
        return ""
    lines = content.splitlines()
    total = len(lines)
    if target_line < 1 or target_line > total:
        return ""

    start_line = max(1, target_line - context_lines)
    end_line = min(total, target_line + context_lines)

    max_width = len(str(end_line))
    excerpt_lines = []
    for num in range(start_line, end_line + 1):
        line_text = lines[num - 1]
        gutter = str(num).rjust(max_width)
        marker = ">" if num == target_line else " "
        excerpt_lines.append(f"     {marker} {gutter} | {line_text}")

    return "\n".join(excerpt_lines)


class ValidationError:
    def __init__(self, code, file, line, message=None, excerpt=None):
        if message is None:
            # Backwards compatibility: ValidationError(code, file, message)
            self.message = line
            self.line = 1
            self.excerpt = excerpt
        else:
            self.line = int(line) if line is not None else 1
            self.message = message
            self.excerpt = excerpt
        self.code = code
        self.file = file

    def format_detailed(self):
        loc = f"{self.file}:{self.line}" if self.line is not None else self.file
        header = f"[{self.code}] {loc}: {self.message}"
        if self.excerpt:
            return f"{header}\n{self.excerpt}"
        return header

    def __str__(self):
        return self.format_detailed()

    def __repr__(self):
        return f"ValidationError({self.code!r}, {self.file!r}, {self.line!r}, {self.message!r})"


def fallback_yaml_parse(text):
    """
    Fallback parser for GitHub Actions workflow structure when PyYAML is unavailable.
    Handles 'name', 'on', 'concurrency', and 'jobs'.
    """
    data = {}
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            i += 1
            continue

        m = re.match(r"^([a-zA-Z0-9_\-]+):\s*(.*)$", line)
        if m:
            key = m.group(1)
            val = m.group(2).strip()
            if key == "name":
                data["name"] = val.strip("'\"")
            elif key in ("on", "True"):  # Handle 'on' keyword
                on_data = {}
                i += 1
                while i < len(lines) and (lines[i].startswith("  ") or not lines[i].strip()):
                    subline = lines[i]
                    substripped = subline.strip()
                    if substripped and not substripped.startswith("#"):
                        subm = re.match(r"^  ([a-zA-Z0-9_\-]+):\s*(.*)$", subline)
                        if subm:
                            subkey = subm.group(1)
                            subval = subm.group(2).strip()
                            on_data[subkey] = subval or {}
                            j = i + 1
                            while j < len(lines) and (lines[j].startswith("    ") or not lines[j].strip()):
                                sub2line = lines[j]
                                sub2strip = sub2line.strip()
                                if sub2strip and not sub2strip.startswith("#"):
                                    sub2m = re.match(r"^    ([a-zA-Z0-9_\-]+):\s*(.*)$", sub2line)
                                    if sub2m:
                                        if isinstance(on_data[subkey], dict):
                                            on_data[subkey][sub2m.group(1)] = sub2m.group(2).strip()
                                j += 1
                    i += 1
                data["on"] = on_data
                continue
            elif key == "concurrency":
                conc_data = {}
                i += 1
                while i < len(lines) and (lines[i].startswith("  ") or not lines[i].strip()):
                    subline = lines[i]
                    substripped = subline.strip()
                    if substripped and not substripped.startswith("#"):
                        subm = re.match(r"^  ([a-zA-Z0-9_\-]+):\s*(.*)$", subline)
                        if subm:
                            ckey = subm.group(1)
                            cval = subm.group(2).strip()
                            if cval.lower() == "true":
                                conc_data[ckey] = True
                            elif cval.lower() == "false":
                                conc_data[ckey] = False
                            else:
                                conc_data[ckey] = cval
                    i += 1
                data["concurrency"] = conc_data
                continue
            elif key == "jobs":
                jobs_data = {}
                i += 1
                while i < len(lines) and (lines[i].startswith("  ") or not lines[i].strip()):
                    subline = lines[i]
                    substripped = subline.strip()
                    if substripped and not substripped.startswith("#"):
                        subm = re.match(r"^  ([a-zA-Z0-9_\-]+):\s*(.*)$", subline)
                        if subm:
                            job_name = subm.group(1)
                            job_info = {}
                            j = i + 1
                            while j < len(lines) and (lines[j].startswith("    ") or not lines[j].strip()):
                                jline = lines[j]
                                jstrip = jline.strip()
                                if jstrip and not jstrip.startswith("#"):
                                    jm = re.match(r"^    ([a-zA-Z0-9_\-]+):\s*(.*)$", jline)
                                    if jm:
                                        jkey = jm.group(1)
                                        jval = jm.group(2).strip()
                                        if jkey == "concurrency":
                                            job_conc = {}
                                            k = j + 1
                                            while k < len(lines) and (lines[k].startswith("      ") or not lines[k].strip()):
                                                kline = lines[k]
                                                kstrip = kline.strip()
                                                if kstrip and not kstrip.startswith("#"):
                                                    km = re.match(r"^      ([a-zA-Z0-9_\-]+):\s*(.*)$", kline)
                                                    if km:
                                                        kkey = km.group(1)
                                                        kval = km.group(2).strip()
                                                        if kval.lower() == "true":
                                                            job_conc[kkey] = True
                                                        elif kval.lower() == "false":
                                                            job_conc[kkey] = False
                                                        else:
                                                            job_conc[kkey] = kval
                                                k += 1
                                            job_info["concurrency"] = job_conc or jval
                                        else:
                                            job_info[jkey] = jval
                                j += 1
                            jobs_data[job_name] = job_info
                    i += 1
                data["jobs"] = jobs_data
                continue
            else:
                data[key] = val
        i += 1
    return data


def extract_line_map_yaml(content):
    """Builds a mapping from hierarchical key path to 1-based line number using PyYAML AST."""
    line_map = {}
    if not HAS_PYYAML or not content:
        return line_map

    try:
        loader = yaml.SafeLoader(content)
        node = loader.get_single_node()
    except Exception:
        return line_map

    if not node or not isinstance(node, yaml.MappingNode):
        return line_map

    def walk_mapping(mapping_node, prefix=""):
        for k_node, v_node in mapping_node.value:
            if not isinstance(k_node, yaml.ScalarNode):
                continue
            key_name = str(k_node.value)
            full_key = f"{prefix}.{key_name}" if prefix else key_name
            line_map[full_key] = k_node.start_mark.line + 1
            if isinstance(v_node, yaml.MappingNode):
                walk_mapping(v_node, full_key)

    walk_mapping(node)
    return line_map


def locate_line(content, scope="workflow", target="concurrency", line_map=None):
    """
    Locates the 1-based line number for a specific concurrency key or scope.
    Consults line_map if available, falling back to lexical line inspection.
    """
    if line_map:
        if scope == "workflow":
            if target == "concurrency" and "concurrency" in line_map:
                return line_map["concurrency"]
            if target == "group" and "concurrency.group" in line_map:
                return line_map["concurrency.group"]
            if target == "cancel-in-progress" and "concurrency.cancel-in-progress" in line_map:
                return line_map["concurrency.cancel-in-progress"]
            if target == "group" and "concurrency" in line_map:
                return line_map["concurrency"]
        elif scope.startswith("job:"):
            job_name = scope.split(":", 1)[1]
            prefix = f"jobs.{job_name}.concurrency"
            if target == "concurrency" and prefix in line_map:
                return line_map[prefix]
            if target == "group" and f"{prefix}.group" in line_map:
                return line_map[f"{prefix}.group"]
            if target == "cancel-in-progress" and f"{prefix}.cancel-in-progress" in line_map:
                return line_map[f"{prefix}.cancel-in-progress"]
            if target == "group" and prefix in line_map:
                return line_map[prefix]

    if not content:
        return 1

    lines = content.splitlines()

    if target == "root":
        for idx, line in enumerate(lines, 1):
            s = line.strip()
            if s and not s.startswith("#"):
                return idx
        return 1

    if scope == "workflow":
        in_concurrency = False
        concurrency_line = 1
        for idx, line in enumerate(lines, 1):
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            indent = len(line) - len(line.lstrip(" "))
            if indent == 0:
                if re.match(r"^concurrency\s*:", s):
                    concurrency_line = idx
                    if target == "concurrency":
                        return idx
                    after_colon = s.split(":", 1)[1].strip()
                    if after_colon and not after_colon.startswith("#"):
                        if target == "group":
                            return idx
                    in_concurrency = True
                    continue
                else:
                    in_concurrency = False
            elif in_concurrency:
                if indent == 0:
                    in_concurrency = False
                    continue
                if target == "group" and re.match(r"^group\s*:", s):
                    return idx
                if target == "cancel-in-progress" and re.match(r"^cancel-in-progress\s*:", s):
                    return idx
        return concurrency_line

    elif scope.startswith("job:"):
        job_name = scope.split(":", 1)[1]
        in_jobs = False
        in_target_job = False
        in_job_concurrency = False
        job_line = 1
        concurrency_line = 1

        for idx, line in enumerate(lines, 1):
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            indent = len(line) - len(line.lstrip(" "))
            if indent == 0:
                in_jobs = bool(re.match(r"^jobs\s*:", s))
                in_target_job = False
                in_job_concurrency = False
            elif in_jobs and indent == 2:
                if re.match(rf"^{re.escape(job_name)}\s*:", s):
                    in_target_job = True
                    job_line = idx
                else:
                    in_target_job = False
                in_job_concurrency = False
            elif in_target_job and indent == 4:
                if re.match(r"^concurrency\s*:", s):
                    in_job_concurrency = True
                    concurrency_line = idx
                    if target == "concurrency":
                        return idx
                    after_colon = s.split(":", 1)[1].strip()
                    if after_colon and not after_colon.startswith("#"):
                        if target == "group":
                            return idx
                else:
                    in_job_concurrency = False
            elif in_job_concurrency and indent > 4:
                if target == "group" and re.match(r"^group\s*:", s):
                    return idx
                if target == "cancel-in-progress" and re.match(r"^cancel-in-progress\s*:", s):
                    return idx

        return concurrency_line if concurrency_line != 1 else job_line

    return 1


def load_workflow_yaml(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    if HAS_PYYAML:
        try:
            return yaml.safe_load(content), content
        except Exception as e:
            err_line = 1
            if hasattr(e, "problem_mark") and e.problem_mark:
                err_line = e.problem_mark.line + 1
            raise ValueError(f"YAML Syntax Error at line {err_line}: {e}")
    else:
        return fallback_yaml_parse(content), content


def check_balanced_syntax(expr_str):
    """
    Checks that ${{ ... }} has balanced braces, parentheses, and quotes.
    Returns (is_valid, error_msg).
    """
    open_count = expr_str.count("${{")
    close_count = expr_str.count("}}")
    if open_count != close_count:
        return False, f"Unbalanced expression delimiters: found {open_count} '${{{{}}' and {close_count} '}}}}'"

    pattern = r"\$\{\{\s*(.*?)\s*\}\}"
    matches = re.findall(pattern, expr_str)
    for match in matches:
        in_single_quote = False
        in_double_quote = False
        paren_stack = []

        i = 0
        while i < len(match):
            char = match[i]
            if char == "'" and not in_double_quote:
                in_single_quote = not in_single_quote
            elif char == '"' and not in_single_quote:
                in_double_quote = not in_double_quote
            elif not in_single_quote and not in_double_quote:
                if char == '(':
                    paren_stack.append('(')
                elif char == ')':
                    if not paren_stack:
                        return False, f"Unmatched closing parenthesis ')' in expression: '{match}'"
                    paren_stack.pop()
            i += 1

        if in_single_quote:
            return False, f"Unclosed single quote in expression: '{match}'"
        if in_double_quote:
            return False, f"Unclosed double quote in expression: '{match}'"
        if paren_stack:
            return False, f"Unclosed opening parenthesis '(' in expression: '{match}'"

    return True, None


def split_top_level(s, sep):
    """Splits a string by a separator only when outside quotes or parentheses."""
    parts = []
    current = []
    paren_depth = 0
    in_quote = False
    quote_char = None

    i = 0
    sep_len = len(sep)
    while i < len(s):
        c = s[i]
        if c in ("'", '"'):
            if not in_quote:
                in_quote = True
                quote_char = c
            elif quote_char == c:
                in_quote = False
                quote_char = None
            current.append(c)
            i += 1
        elif in_quote:
            current.append(c)
            i += 1
        elif c == '(':
            paren_depth += 1
            current.append(c)
            i += 1
        elif c == ')':
            paren_depth -= 1
            current.append(c)
            i += 1
        elif paren_depth == 0 and s[i:i+sep_len] == sep:
            parts.append("".join(current).strip())
            current = []
            i += sep_len
        else:
            current.append(c)
            i += 1

    parts.append("".join(current).strip())
    return parts


def evaluate_expression(expr_str, context):
    """
    Safely evaluates a GitHub Actions expression against a simulated context dictionary.
    Supports !, ||, &&, ==, !=, startsWith, endsWith, contains, and context lookups.
    """
    s = expr_str.strip()
    if s.startswith("${{") and s.endswith("}}"):
        s = s[3:-2].strip()

    def eval_node(sub):
        sub = sub.strip()
        if not sub:
            return ""

        # Logical NOT
        if sub.startswith("!"):
            return not eval_node(sub[1:])

        # startsWith function
        m_start = re.match(r"^startsWith\(\s*(.*?)\s*,\s*(.*?)\s*\)$", sub)
        if m_start:
            arg1 = eval_node(m_start.group(1))
            arg2 = eval_node(m_start.group(2))
            return str(arg1).startswith(str(arg2))

        # endsWith function
        m_end = re.match(r"^endsWith\(\s*(.*?)\s*,\s*(.*?)\s*\)$", sub)
        if m_end:
            arg1 = eval_node(m_end.group(1))
            arg2 = eval_node(m_end.group(2))
            return str(arg1).endswith(str(arg2))

        # contains function
        m_cont = re.match(r"^contains\(\s*(.*?)\s*,\s*(.*?)\s*\)$", sub)
        if m_cont:
            arg1 = eval_node(m_cont.group(1))
            arg2 = eval_node(m_cont.group(2))
            return str(arg2) in str(arg1)

        # Logical OR (||)
        parts_or = split_top_level(sub, "||")
        if len(parts_or) > 1:
            val = eval_node(parts_or[0])
            if val:
                return val
            return eval_node(parts_or[1])

        # Logical AND (&&)
        parts_and = split_top_level(sub, "&&")
        if len(parts_and) > 1:
            return bool(eval_node(parts_and[0]) and eval_node(parts_and[1]))

        # Equality ==
        parts_eq = split_top_level(sub, "==")
        if len(parts_eq) > 1:
            return eval_node(parts_eq[0]) == eval_node(parts_eq[1])

        # Inequality !=
        parts_neq = split_top_level(sub, "!=")
        if len(parts_neq) > 1:
            return eval_node(parts_neq[0]) != eval_node(parts_neq[1])

        # String literals
        if (sub.startswith("'") and sub.endswith("'")) or (sub.startswith('"') and sub.endswith('"')):
            return sub[1:-1]

        # Booleans
        if sub.lower() == "true":
            return True
        if sub.lower() == "false":
            return False

        # Context lookups
        parts = sub.split(".")
        curr = context
        for p in parts:
            if isinstance(curr, dict) and p in curr:
                curr = curr[p]
            else:
                return ""
        return curr

    return eval_node(s)


def validate_workflow(filepath, content=None, data=None):
    errors = []
    filename = os.path.basename(filepath)

    def add_error(code, line, msg):
        exc = extract_source_excerpt(content, line)
        errors.append(ValidationError(code, filename, line, msg, excerpt=exc))

    if data is None:
        if content is not None:
            try:
                if HAS_PYYAML:
                    data = yaml.safe_load(content)
                else:
                    data = fallback_yaml_parse(content)
            except Exception as e:
                err_line = 1
                if hasattr(e, "problem_mark") and e.problem_mark:
                    err_line = e.problem_mark.line + 1
                return [ValidationError("YAML_PARSE_ERROR", filename, err_line, str(e), excerpt=extract_source_excerpt(content, err_line))]
        else:
            try:
                data, content = load_workflow_yaml(filepath)
            except Exception as e:
                return [ValidationError("YAML_PARSE_ERROR", filename, 1, str(e), excerpt=extract_source_excerpt(content, 1))]

    if not isinstance(data, dict):
        return [ValidationError("INVALID_FORMAT", filename, 1, "Workflow YAML must be a mapping", excerpt=extract_source_excerpt(content, 1))]

    # Build line map if PyYAML is active
    line_map = extract_line_map_yaml(content) if content else {}

    # 1. Determine triggers and workflow purpose
    # Note: In PyYAML 1.1, unquoted 'on:' key is parsed as boolean True
    on_triggers = data.get("on") if "on" in data else data.get(True, {})

    triggers_tags = False
    triggers_release = False
    is_dedicated_release = False

    if isinstance(on_triggers, dict):
        if "push" in on_triggers:
            push_trig = on_triggers["push"]
            if isinstance(push_trig, dict) and ("tags" in push_trig or "tags-ignore" in push_trig):
                triggers_tags = True
        if "release" in on_triggers:
            triggers_release = True
    elif isinstance(on_triggers, list):
        if "release" in on_triggers:
            triggers_release = True
    elif isinstance(on_triggers, str):
        if on_triggers == "release":
            triggers_release = True

    if "release" in filename.lower() or "publish" in filename.lower():
        is_dedicated_release = True
    if triggers_release:
        is_dedicated_release = True

    # 2. Concurrency Block Validation
    concurrency = data.get("concurrency")
    if concurrency is None:
        jobs = data.get("jobs", {})
        if not jobs or not all(isinstance(j, dict) and "concurrency" in j for j in jobs.values()):
            root_line = locate_line(content, "workflow", "root", line_map)
            add_error(
                "CONCURRENCY_MISSING",
                root_line,
                "Workflow lacks a concurrency configuration. Outdated runs cannot be cancelled and jobs may race."
            )
            return errors
        concurrency_blocks = [(f"job:{jname}", j["concurrency"]) for jname, j in jobs.items()]
    else:
        concurrency_blocks = [("workflow", concurrency)]

    for scope, conc in concurrency_blocks:
        conc_line = locate_line(content, scope, "concurrency", line_map)

        if isinstance(conc, str):
            group = conc
            cancel_in_progress = False
        elif isinstance(conc, dict):
            group = conc.get("group")
            cancel_in_progress = conc.get("cancel-in-progress")
        else:
            add_error(
                "CONCURRENCY_INVALID_TYPE",
                conc_line,
                f"Concurrency configuration in {scope} must be a mapping or string, got {type(conc).__name__}"
            )
            continue

        group_line = locate_line(content, scope, "group", line_map)

        if not group or not str(group).strip():
            add_error(
                "CONCURRENCY_GROUP_EMPTY",
                group_line,
                f"Concurrency group in {scope} is missing or empty."
            )
            continue

        group_str = str(group)

        # Check expression delimiter and syntax
        valid_syntax, err_msg = check_balanced_syntax(group_str)
        if not valid_syntax:
            add_error(
                "CONCURRENCY_GROUP_SYNTAX_ERROR",
                group_line,
                f"Invalid concurrency group expression in {scope}: {err_msg}"
            )

        # Check for invalid context access at workflow level
        if scope == "workflow":
            if "matrix." in group_str:
                add_error(
                    "CONCURRENCY_INVALID_CONTEXT",
                    group_line,
                    "Workflow-level concurrency group references 'matrix.*', which is undefined at workflow scope."
                )

        # Workflow Namespace Isolation:
        # Group MUST incorporate github.workflow or explicit workflow filename to prevent cross-workflow run cancellation
        if "${{ github.workflow }}" not in group_str and "github.workflow" not in group_str:
            stem = os.path.splitext(filename)[0]
            if stem not in group_str and data.get("name", "") not in group_str:
                add_error(
                    "CONCURRENCY_NAMESPACE_COLLISION_RISK",
                    group_line,
                    f"Concurrency group '{group_str}' in {scope} lacks '${{{{ github.workflow }}}}' namespace isolation. Multiple distinct workflows on the same ref will cancel each other."
                )

        # Cancel-in-progress validation
        cancel_line = locate_line(content, scope, "cancel-in-progress", line_map)

        if cancel_in_progress is None:
            pass  # GitHub Actions defaults to false
        elif isinstance(cancel_in_progress, str):
            if cancel_in_progress.lower() in ("true", "false", "'true'", '"true"', "'false'", '"false"'):
                add_error(
                    "CONCURRENCY_TYPE_STRING_BOOLEAN",
                    cancel_line,
                    f"cancel-in-progress in {scope} is string '{cancel_in_progress}'. Must be literal boolean or ${{ ... }} expression."
                )
            else:
                valid_syntax, err_msg = check_balanced_syntax(cancel_in_progress)
                if not valid_syntax:
                    add_error(
                        "CONCURRENCY_CANCEL_SYNTAX_ERROR",
                        cancel_line,
                        f"Invalid cancel-in-progress expression in {scope}: {err_msg}"
                    )
                if scope == "workflow" and "matrix." in cancel_in_progress:
                    add_error(
                        "CONCURRENCY_INVALID_CONTEXT",
                        cancel_line,
                        "Workflow-level cancel-in-progress references 'matrix.*', which is undefined at workflow scope."
                    )
        elif not isinstance(cancel_in_progress, bool):
            add_error(
                "CONCURRENCY_CANCEL_INVALID_TYPE",
                cancel_line,
                f"cancel-in-progress in {scope} must be boolean or expression, got {type(cancel_in_progress).__name__}"
            )

        # 3. ACCIDENTAL CANCELLATION OF RELEASE WORKFLOWS SAFEGUARD
        # Rule: Dedicated release workflows MUST NOT cancel in progress
        if is_dedicated_release:
            if cancel_in_progress is True:
                add_error(
                    "RELEASE_ACCIDENTAL_CANCELLATION_RISK",
                    cancel_line,
                    "Dedicated release workflow has 'cancel-in-progress: true'. Packaging and artifact publishing runs MUST NOT be cancelled in progress."
                )
            elif isinstance(cancel_in_progress, str):
                tag_context = {
                    "github": {
                        "ref": "refs/tags/v1.0.0",
                        "head_ref": "",
                        "workflow": data.get("name", filename),
                        "event_name": "push"
                    }
                }
                res = evaluate_expression(cancel_in_progress, tag_context)
                if res is True:
                    add_error(
                        "RELEASE_ACCIDENTAL_CANCELLATION_RISK",
                        cancel_line,
                        f"Release workflow cancel expression '{cancel_in_progress}' evaluates to TRUE on tag events, risking accidental release aborts."
                    )

        # Rule: Workflows triggering on tags (e.g. CI matrix on tags) MUST NOT cancel on tag runs
        elif triggers_tags:
            if cancel_in_progress is True:
                add_error(
                    "TAG_ACCIDENTAL_CANCELLATION_RISK",
                    cancel_line,
                    "Workflow triggers on tags but has unconditional 'cancel-in-progress: true'. Tag releases would be cancelled mid-flight."
                )
            elif isinstance(cancel_in_progress, str):
                tag_context = {
                    "github": {
                        "ref": "refs/tags/v1.0.0",
                        "head_ref": "",
                        "workflow": data.get("name", filename),
                        "event_name": "push"
                    }
                }
                tag_res = evaluate_expression(cancel_in_progress, tag_context)
                if tag_res is True:
                    add_error(
                        "TAG_ACCIDENTAL_CANCELLATION_RISK",
                        cancel_line,
                        f"cancel-in-progress expression '{cancel_in_progress}' evaluates to TRUE on tag push (refs/tags/v1.0.0). Tag runs would not be protected from cancellation."
                    )

    return errors


def run_self_tests():
    """Executes a suite of synthetic positive, negative, and edge test fixtures with line-number verification."""
    print("[*] Running Workflow Validator Self-Tests (with Line Number Verification)...")

    fixtures = [
        # 1. Valid CI with tag protection guard
        {
            "name": "valid_ci_guarded.yml",
            "content": """name: CI
on:
  push:
    branches: [main]
    tags: ['v*']
  pull_request:
    branches: [main]
concurrency:
  group: ${{ github.workflow }}-${{ github.head_ref || github.ref }}
  cancel-in-progress: ${{ !startsWith(github.ref, 'refs/tags/') }}
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: echo ok
""",
            "expect_errors": 0,
            "test_desc": "Valid CI workflow with tag guard"
        },
        # 2. Valid release workflow with cancel-in-progress: false
        {
            "name": "release.yml",
            "content": """name: Release
on:
  push:
    tags: ['v*']
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: false
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - run: echo ok
""",
            "expect_errors": 0,
            "test_desc": "Valid dedicated release with cancel-in-progress: false"
        },
        # 3. Invalid release workflow with cancel-in-progress: true (line 7)
        {
            "name": "release.yml",
            "content": """name: Release
on:
  push:
    tags: ['v*']
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - run: echo ok
""",
            "expect_errors": 1,
            "expected_code": "RELEASE_ACCIDENTAL_CANCELLATION_RISK",
            "expected_line": 7,
            "test_desc": "Reject dedicated release with cancel-in-progress: true at line 7"
        },
        # 4. Invalid tag-triggered workflow with unconditional cancel-in-progress: true (line 8)
        {
            "name": "ci_bad_tag.yml",
            "content": """name: CI Bad Tag
on:
  push:
    branches: [main]
    tags: ['v*']
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: echo ok
""",
            "expect_errors": 1,
            "expected_code": "TAG_ACCIDENTAL_CANCELLATION_RISK",
            "expected_line": 8,
            "test_desc": "Reject tag trigger with cancel-in-progress: true at line 8"
        },
        # 5. Invalid tag-triggered workflow with flawed expression that cancels tags (line 8)
        {
            "name": "ci_flawed_expr.yml",
            "content": """name: CI Flawed
on:
  push:
    branches: [main]
    tags: ['v*']
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: ${{ startsWith(github.ref, 'refs/tags/') }}
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: echo ok
""",
            "expect_errors": 1,
            "expected_code": "TAG_ACCIDENTAL_CANCELLATION_RISK",
            "expected_line": 8,
            "test_desc": "Reject inverted tag expression at line 8"
        },
        # 6. Invalid concurrency group syntax (unbalanced parentheses) (line 6)
        {
            "name": "ci_unbalanced_paren.yml",
            "content": """name: CI Bad Paren
on:
  push:
    branches: [main]
concurrency:
  group: ${{ github.workflow }}-${{ !startsWith(github.ref, 'refs/tags/' }}
  cancel-in-progress: true
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: echo ok
""",
            "expect_errors": 1,
            "expected_code": "CONCURRENCY_GROUP_SYNTAX_ERROR",
            "expected_line": 6,
            "test_desc": "Reject unbalanced parentheses in group at line 6"
        },
        # 7. Missing workflow namespace isolation (line 6)
        {
            "name": "ci_no_namespace.yml",
            "content": """name: CI No Namespace
on:
  push:
    branches: [main]
concurrency:
  group: ${{ github.ref }}
  cancel-in-progress: true
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: echo ok
""",
            "expect_errors": 1,
            "expected_code": "CONCURRENCY_NAMESPACE_COLLISION_RISK",
            "expected_line": 6,
            "test_desc": "Reject group lacking namespace isolation at line 6"
        },
        # 8. Quoted string boolean instead of literal/expression (line 7)
        {
            "name": "ci_string_boolean.yml",
            "content": """name: CI String Bool
on:
  push:
    branches: [main]
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: "true"
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: echo ok
""",
            "expect_errors": 1,
            "expected_code": "CONCURRENCY_TYPE_STRING_BOOLEAN",
            "expected_line": 7,
            "test_desc": "Reject quoted string boolean at line 7"
        },
        # 9. Invalid context access (matrix at workflow level) (line 6)
        {
            "name": "ci_invalid_matrix_context.yml",
            "content": """name: CI Invalid Matrix Context
on:
  push:
    branches: [main]
concurrency:
  group: ${{ github.workflow }}-${{ matrix.os }}
  cancel-in-progress: true
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: echo ok
""",
            "expect_errors": 1,
            "expected_code": "CONCURRENCY_INVALID_CONTEXT",
            "expected_line": 6,
            "test_desc": "Reject matrix context in workflow group at line 6"
        },
        # 10. Missing concurrency block entirely (line 1)
        {
            "name": "ci_missing_concurrency.yml",
            "content": """name: CI Missing Concurrency
on:
  push:
    branches: [main]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: echo ok
""",
            "expect_errors": 1,
            "expected_code": "CONCURRENCY_MISSING",
            "expected_line": 1,
            "test_desc": "Reject missing concurrency block reporting line 1"
        },
    ]

    failed_tests = 0
    for idx, f in enumerate(fixtures, 1):
        errs = validate_workflow(f["name"], content=f["content"])
        expected_cnt = f["expect_errors"]
        if len(errs) != expected_cnt:
            print(f"  [FAIL] Test {idx} ({f['test_desc']}): Expected {expected_cnt} errors, got {len(errs)}: {errs}")
            failed_tests += 1
            continue

        if "expected_code" in f:
            matching_errors = [e for e in errs if e.code == f["expected_code"]]
            if not matching_errors:
                print(f"  [FAIL] Test {idx} ({f['test_desc']}): Expected error code {f['expected_code']}, got: {[e.code for e in errs]}")
                failed_tests += 1
                continue

            if "expected_line" in f:
                matching_lines = [e for e in matching_errors if e.line == f["expected_line"]]
                if not matching_lines:
                    print(f"  [FAIL] Test {idx} ({f['test_desc']}): Expected line {f['expected_line']}, got: {[e.line for e in matching_errors]}")
                    failed_tests += 1
                    continue
                for e in matching_lines:
                    if not e.excerpt or ">" not in e.excerpt:
                        print(f"  [FAIL] Test {idx} ({f['test_desc']}): Expected source excerpt with gutter pointer '>'")
                        failed_tests += 1
                        continue

        print(f"  [PASS] Test {idx}: {f['test_desc']}")

    if failed_tests > 0:
        print(f"[!] {failed_tests} self-test(s) failed.")
        return False
    print("[+] All self-tests passed successfully with accurate line-number reporting!")
    return True


def main():
    parser = argparse.ArgumentParser(description="Validate GitHub Actions workflow concurrency and release safety.")
    parser.add_argument("--workflows-dir", default=".github/workflows", help="Path to workflows directory")
    parser.add_argument("--self-test", action="store_true", help="Run internal self-tests covering edge and negative cases")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose diagnostic output")
    args = parser.parse_args()

    if args.self_test:
        success = run_self_tests()
        sys.exit(0 if success else 1)

    if not os.path.isdir(args.workflows_dir):
        print(f"[-] Workflows directory not found: {args.workflows_dir}", file=sys.stderr)
        sys.exit(1)

    yaml_files = [
        os.path.join(args.workflows_dir, f)
        for f in os.listdir(args.workflows_dir)
        if f.endswith((".yml", ".yaml"))
    ]

    if not yaml_files:
        print(f"[-] No workflow files found in {args.workflows_dir}", file=sys.stderr)
        sys.exit(1)

    print(f"[*] Validating {len(yaml_files)} workflow(s) in {args.workflows_dir}...")
    total_errors = 0

    for wf_path in sorted(yaml_files):
        errs = validate_workflow(wf_path)
        if errs:
            total_errors += len(errs)
            print(f"\n[FAIL] {os.path.basename(wf_path)}:")
            for err in errs:
                print(f"  • {err}")
                if os.environ.get("GITHUB_ACTIONS") == "true":
                    print(f"::error file={wf_path},line={err.line},title={err.code}::{err.message}")
        else:
            if args.verbose:
                print(f"[PASS] {os.path.basename(wf_path)}: Concurrency & release safety verified.")

    if total_errors > 0:
        print(f"\n[!] Validation FAILED with {total_errors} error(s).", file=sys.stderr)
        sys.exit(1)

    print("\n[+] SUCCESS: All workflows passed concurrency validation and release safety verification.")
    sys.exit(0)


if __name__ == "__main__":
    main()
