#!/usr/bin/env bash
# demo_live_api.sh — credential-injection demo for mack-proxy.
#
# What this proves, stated precisely:
#
#   A workload that does NOT hold an API key can call a key-gated
#   HTTPS endpoint through mack-proxy, because the proxy holds the
#   key and injects it at the boundary. A caller without the proxy
#   has no key, and the endpoint refuses it.
#
#   The default target is httpbin.org/bearer — a public ECHO
#   service, not a provider API. It is used because it answers 401
#   without an Authorization header and echoes the received token
#   with one, which makes the injection observable. The echo proves
#   the mechanism; it is not a call against a real provider. To run
#   the same path against a real provider endpoint, set
#   DEMO_TARGET_URL and DEMO_TARGET_HOST (the key then goes in
#   MACK_REAL_SECRET the same way, in the proxy's environment only).
#
# What this does NOT prove:
#
#   * Anything beyond that boundary. The child is confined by
#     Landlock FILESYSTEM rules and Landlock NETWORK rules
#     (fail-closed): its outbound TCP connects are limited to
#     the proxy's own port, so the direct attempt below is
#     denied by the kernel at connect time for any other port.
#     The network rules match ports, not addresses, and govern
#     TCP connect only. Since v0.11.0 the child also runs under
#     a baseline seccomp workload profile (dangerous syscalls
#     fail with EPERM; socket() filtering denies UDP and raw
#     sockets, so the child has no direct datagram path — its
#     own name resolution included) and resource-governor
#     rlimits. Since v0.12.0 the child's inherited descriptors
#     are audited before exec: a datagram socket inherited on
#     stdio refuses the spawn, and every other inherited
#     descriptor is closed. Bind/listen is not restricted, and
#     no network namespace is applied. What the direct leg
#     observes is reported at the level observed, never
#     rounded up.
#   * Anything about a real provider's key: the demo key is
#     generated fresh per run and is worthless outside it.
#
# Output hygiene:
#
#   The demo key is NEVER printed. Where the echo service returns
#   it, the output shows a truncated SHA-256 of the token instead.
#   (An earlier version of this script printed the token in full —
#   with a real key that would publish it. Fixed 2026-11-16.)
#
# Two handle layers, stated precisely (an earlier version of this
# script conflated them — corrected 2026-11-16):
#   * Per-host handles are single-use: each is burned at the egress
#     boundary, where the secret is reconstructed from its 2-of-3
#     Shamir shares (v0.12.0 — the shares are co-located in the
#     proxy process, so the assembled secret exists only
#     transiently inside a burn; this is not multi-party custody),
#     and the session quorum mints a successor per request (each
#     mint a signed-ledger entry). A replayed per-host handle is
#     refused.
#   * The token in the workload's environment (MACK_TOKEN_HANDLE)
#     is the SESSION token: a session-scoped resolver that the
#     proxy swaps for the current per-host handle. It is NOT
#     single-use and stays live for the whole session, so this
#     script redacts it exactly like the key (truncated hash only).
#     The demo's second call with the same session token is
#     expected to succeed — through the ROTATED per-host handle —
#     and check 7 verifies that rotation happened.
#
# Ledger:
#
#   This script runs the proxy with --ledger, so the session
#   ledger is PERSISTENT (v0.11.0): an append-only file, written
#   through per entry. At shutdown the proxy appends a signed
#   checkpoint, verifies the signed chain, and, only if
#   verification passes, prints
#     [mack-proxy] Ledger verification: OK — signed chain valid (N entries, tip H)
#     [mack-proxy] Run complete. Signed ledger entries: N | Tip hash: H
#   to stderr (a failed verification panics before those lines).
#   This script prints both lines verbatim, and then verifies
#   the ledger FILE independently with mack-ledger-verify — no
#   proxy, no signing key — as a separate check.
#   At shutdown the proxy also emits a signed session receipt
#   (v0.12.0): printed as JSON to its stdout and written to
#   <ledger>.receipt.json. The receipt binds the crate version,
#   a digest of the confinement policy actually applied, the
#   ledger's final head hash and record count, and the SHA-256
#   of the proxy executable measured at receipt time — signed
#   with the same authority key that signed the ledger. Check
#   4c binds the receipt against the independently verified
#   ledger and the binary on disk.
#
# Usage:  scripts/demo_live_api.sh
# Exit:   0 = every check passed, 1 = a check failed.
# Needs:  cargo, curl, sha256sum, outbound HTTPS for the proxy's
#         upstream leg (HTTPS_PROXY is honored if set).

set -u
cd "$(dirname "$0")/.."

API_URL="${DEMO_TARGET_URL:-https://httpbin.org/bearer}"
API_HOST="${DEMO_TARGET_HOST:-httpbin.org}"
ECHO_MODE=1
[ "$API_URL" = "https://httpbin.org/bearer" ] || ECHO_MODE=0

# System CA bundle for the child's direct attempt — deliberately
# NOT the proxy's session CA. (The proxy sets SSL_CERT_FILE,
# CURL_CA_BUNDLE and REQUESTS_CA_BUNDLE to its session CA for the
# child; a direct attempt inheriting those fails TLS against any
# real endpoint, which would say nothing about the network.)
SYSTEM_CA=""
for c in /etc/ssl/certs/ca-certificates.crt /etc/pki/tls/certs/ca-bundle.crt /etc/ssl/cert.pem; do
    [ -f "$c" ] && { SYSTEM_CA="$c"; break; }
done
[ -n "$SYSTEM_CA" ] || { echo "FAIL: no system CA bundle found"; exit 1; }

echo "== Building mack-proxy =="
cargo build --bin mack-proxy --bin mack-ledger-verify 2>&1 | tail -2
BIN="target/debug/mack-proxy"
VBIN="target/debug/mack-ledger-verify"
[ -x "$BIN" ] || { echo "FAIL: mack-proxy binary not found"; exit 1; }
[ -x "$VBIN" ] || { echo "FAIL: mack-ledger-verify binary not found"; exit 1; }

# Per-run persistent ledger for this demo run (the authority key
# is created beside it, 0600, by the proxy itself).
LEDGER_DIR="$(mktemp -d)"
LEDGER_PATH="$LEDGER_DIR/session.ledger.jsonl"

# Fresh demo key, known only to this script and the proxy process.
DEMO_KEY="mack-demo-key-$(head -c 12 /dev/urandom | od -An -tx1 | tr -d ' \n')"
KEY_HASH="sha256:$(printf '%s' "$DEMO_KEY" | sha256sum | cut -c1-16)"

CHILD_SCRIPT="
export http_proxy=\"\$HTTP_PROXY\" https_proxy=\"\$HTTPS_PROXY\" no_proxy=\"\" NO_PROXY=\"\"
echo \"CHILD_ENV_BEGIN\"
env | sort
echo \"CHILD_ENV_END\"
echo \"PROXY_CALL_BEGIN\"
curl -s --max-time 60 -H \"X-Mack-Handle: \$MACK_TOKEN_HANDLE\" $API_URL
echo
echo \"PROXY_CALL_END\"
echo \"REUSE_CALL_BEGIN\"
curl -s --max-time 30 -w \"\nREUSE_HTTP_CODE=%{http_code}\n\" -H \"X-Mack-Handle: \$MACK_TOKEN_HANDLE\" $API_URL || echo \"REUSE_CURL_EXIT=\$?\"
echo \"REUSE_CALL_END\"
echo \"DIRECT_CALL_BEGIN\"
env -u http_proxy -u https_proxy -u HTTP_PROXY -u HTTPS_PROXY -u all_proxy -u ALL_PROXY \
    SSL_CERT_FILE=$SYSTEM_CA CURL_CA_BUNDLE=$SYSTEM_CA REQUESTS_CA_BUNDLE=$SYSTEM_CA \
  curl -s --max-time 30 --cacert $SYSTEM_CA -w \"\nDIRECT_HTTP_CODE=%{http_code}\n\" $API_URL \
  || echo \"DIRECT_CURL_EXIT=\$?\"
echo \"DIRECT_CALL_END\"
"

section() { printf '%s' "$3" | sed -n "/$1/,/$2/p"; }
redact() {
    if [ -n "${SESSION_TOKEN:-}" ]; then
        sed -e "s/$DEMO_KEY/<redacted $KEY_HASH>/g" \
            -e "s|$SESSION_TOKEN|<redacted session token $SESSION_TOKEN_HASH>|g"
    else
        sed "s/$DEMO_KEY/<redacted $KEY_HASH>/g"
    fi
}

PASS=0; FAIL=0
check() { if [ "$2" -eq 0 ]; then echo "PASS: $1"; PASS=$((PASS+1));
          else echo "FAIL: $1"; FAIL=$((FAIL+1)); fi }

OUT=""; LEDGER_LINE=""; LEDGER_OK_LINE=""; ATTEMPT=0
while [ $ATTEMPT -lt 2 ]; do
    ATTEMPT=$((ATTEMPT+1))
    echo "== Run through mack-proxy (attempt $ATTEMPT) =="
    ERRFILE="$(mktemp)"
    OUT="$(MACK_REAL_SECRET="$DEMO_KEY" "$BIN" run --tls --allow "$API_HOST" \
            --ledger "$LEDGER_PATH" \
            -- sh -c "$CHILD_SCRIPT" 2>"$ERRFILE")"
    LEDGER_LINE="$(grep 'Run complete. Signed ledger entries:' "$ERRFILE" || true)"
    LEDGER_OK_LINE="$(grep 'Ledger verification: OK' "$ERRFILE" || true)"
    rm -f "$ERRFILE"
    PROXY_SECTION="$(section PROXY_CALL_BEGIN PROXY_CALL_END "$OUT")"
    if [ $ECHO_MODE -eq 1 ]; then
        printf '%s' "$PROXY_SECTION" | grep -q '"authenticated": true' && break
    else
        printf '%s' "$PROXY_SECTION" | grep -q . && break
    fi
    echo "(proxy leg did not complete; retrying once in case the target hiccuped)"
done

ENV_SECTION="$(section CHILD_ENV_BEGIN CHILD_ENV_END "$OUT")"
SESSION_TOKEN="$(printf '%s' "$ENV_SECTION" | sed -n 's/^MACK_TOKEN_HANDLE=//p' | head -1)"
SESSION_TOKEN_HASH=""
[ -n "$SESSION_TOKEN" ] && SESSION_TOKEN_HASH="sha256:$(printf '%s' "$SESSION_TOKEN" | sha256sum | cut -c1-16)"
REUSE_SECTION="$(section REUSE_CALL_BEGIN REUSE_CALL_END "$OUT")"
DIRECT_SECTION="$(section DIRECT_CALL_BEGIN DIRECT_CALL_END "$OUT")"

# Outside control, run here in the open so its evidence can be
# printed in full: same URL, no proxy, no key.
OUTSIDE_RAW="$(curl -s --max-time 60 -w "
OUTSIDE_HTTP_CODE=%{http_code}" "$API_URL")"
OUTSIDE_EXIT=$?
OUTSIDE_CODE="$(printf '%s' "$OUTSIDE_RAW" | sed -n 's/.*OUTSIDE_HTTP_CODE=\([0-9]*\).*/\1/p' | tail -1)"
OUTSIDE_BODY="$(printf '%s' "$OUTSIDE_RAW" | sed 's/OUTSIDE_HTTP_CODE=[0-9]*//')"

echo
echo "== What the target received through the proxy (key redacted) =="
printf '%s' "$PROXY_SECTION" | redact; echo
echo "== The workload's environment (names only, except proxy-relevant values) =="
# The full env is captured for the key-absence check but NOT printed
# in full: on a real machine it can hold unrelated credentials.
printf '%s' "$ENV_SECTION" | redact | sed -E \
  '/^(HTTP_PROXY|HTTPS_PROXY|http_proxy|https_proxy|MACK_TOKEN_HANDLE|SSL_CERT_FILE|CURL_CA_BUNDLE|REQUESTS_CA_BUNDLE|NODE_EXTRA_CA_CERTS)=/!s/=.*$/=<value not printed>/'; echo
echo "== Second use of the session token (per-host handle rotation) =="
printf '%s' "$REUSE_SECTION" | redact; echo
echo "== Confinement, named =="
echo "Applied to the workload by mack-proxy: Landlock FILESYSTEM ruleset (fail-closed); Landlock"
echo "NETWORK rules — outbound TCP connect allowed only to this proxy's port, every other port"
echo "denied by the kernel at connect time; a baseline SECCOMP workload profile — dangerous"
echo "syscalls fail with EPERM, namespace creation is denied, and socket() filtering denies UDP"
echo "and raw sockets outright (the child has no direct datagram path, its own name resolution"
echo "included); and resource-governor RLIMITS (address space, CPU time, file size, no core"
echo "dumps); and inherited-descriptor hygiene — the child's stdio is audited for inherited"
echo "datagram sockets (one refuses the spawn outright) and every other inherited descriptor"
echo "is closed before exec (v0.12.0). At shutdown the proxy emits a signed session receipt"
echo "binding this policy, the ledger's final head and count, and the measured SHA-256 of the"
echo "proxy executable — check 4c verifies it below. The proxy address is supplied through"
echo "environment variables. NOT applied: network"
echo "namespace, or per-address rules (Landlock matches ports, not addresses). Bind/listen is"
echo "not restricted."
if printf '%s' "$DIRECT_SECTION" | grep -q 'DIRECT_CURL_EXIT=35'; then
    echo "Environment note: on THIS machine, direct egress is intercepted before TLS — the target"
    echo "name resolves to a sinkhole address that answers a TLS ClientHello with non-TLS bytes"
    echo "(curl: 'wrong version number', exit 35), identically inside and outside the workload."
    echo "The direct leg below therefore measures this machine's network interception, not the"
    echo "proxy. Where an ordinary network path exists, the same keyless attempt reaches the"
    echo "target and is refused (HTTP 401, observed 2026-11-16 with the system CA bundle via an"
    echo "egress proxy)."
elif printf '%s' "$DIRECT_SECTION" | grep -q 'DIRECT_HTTP_CODE=401'; then
    echo "Environment note: on THIS machine the direct leg ran over an ordinary network path —"
    echo "TLS completed against the system CA bundle and the target itself answered. The result"
    echo "below is the target's own refusal of a keyless call, observed directly, not through"
    echo "any intermediary."
else
    echo "Environment note: the direct leg's outcome below is reported exactly as observed on"
    echo "this machine (the HTTP code and curl exit are printed with it); no environment"
    echo "behavior is assumed in either direction."
fi
echo "== The workload's direct attempt, system CA bundle, no proxy =="
printf '%s' "$DIRECT_SECTION" | redact; echo
echo "== Outside control: same URL, no proxy, no key (printed in full) =="
printf 'response body: %s\n' "$(printf '%s' "$OUTSIDE_BODY" | tr '\n' ' ')"
printf 'OUTSIDE_HTTP_CODE=%s\nOUTSIDE_CURL_EXIT=%s\n' "$OUTSIDE_CODE" "$OUTSIDE_EXIT"
echo "== Ledger evidence (proxy stderr, verbatim) =="
if [ -n "$LEDGER_OK_LINE" ]; then printf '%s\n' "$LEDGER_OK_LINE"; else echo "(no Ledger verification line — the verify call's result is not in the log)"; fi
if [ -n "$LEDGER_LINE" ]; then printf '%s\n' "$LEDGER_LINE"; else echo "(no Run complete line — verification did not pass or the run failed)"; fi
echo "Ledger file: $LEDGER_PATH — persistent and append-only. Independent verification of the"
echo "file itself (mack-ledger-verify; no proxy, no signing key):"
VERIFY_OUT="$("$VBIN" "$LEDGER_PATH" 2>&1)"
VERIFY_EXIT=$?
printf '%s\n' "$VERIFY_OUT"
echo
echo "== Checks =="

# 1. Through the proxy, the target accepted the call and (in echo
#    mode) received exactly the key only the proxy held.
if [ $ECHO_MODE -eq 1 ]; then
    if printf '%s' "$PROXY_SECTION" | grep -q '"authenticated": true' \
       && printf '%s' "$PROXY_SECTION" | grep -q "\"token\": \"$DEMO_KEY\""; then
        check "echo service accepted the call through the proxy and received exactly the proxy-held key (token shown as $KEY_HASH)" 0
    else
        check "echo service accepted the call through the proxy and received exactly the proxy-held key" 1
    fi
else
    echo "NOTE: custom target — automated token comparison runs only in echo mode; verify the response above manually."
fi

# 2. Key hygiene: the key never appears in the workload's env.
if printf '%s' "$ENV_SECTION" | grep -q "$DEMO_KEY"; then
    check "demo key absent from the workload's environment" 1
else
    check "demo key absent from the workload's environment" 0
fi

# 3. Output hygiene: nothing this script printed contains the key.
if printf '%s' "$PROXY_SECTION" | redact | grep -q "$DEMO_KEY"; then
    check "printed output redacts the key" 1
else
    check "printed output redacts the key (only its truncated hash is shown)" 0
fi

# 3b. Output hygiene, session token: the session token is a live
#     session-scoped capability (see header), so nothing printed
#     may contain it in full either.
if [ -n "$SESSION_TOKEN" ] && printf '%s' "$ENV_SECTION" | redact | grep -q "$SESSION_TOKEN"; then
    check "printed output redacts the session token" 1
else
    check "printed output redacts the session token (only its truncated hash is shown)" 0
fi

# 4. Ledger: the proxy's own verification line, printed by
#    mack-proxy after verify_chain() succeeds at shutdown (a failed
#    verification panics before either line is printed).
if [ -n "$LEDGER_OK_LINE" ] && [ -n "$LEDGER_LINE" ]; then
    check "signed ledger verified at shutdown — the proxy's 'Ledger verification: OK' line is printed above with entry count and tip hash" 0
else
    check "signed ledger verified at shutdown" 1
fi

# 4b. Ledger persistence: the file the proxy wrote now verifies
#     INDEPENDENTLY — full chain, signatures, and the shutdown
#     checkpoint — from the artifact alone, with no live session
#     and no signing key (mack-ledger-verify, run above).
if [ "$VERIFY_EXIT" -eq 0 ] && printf '%s' "$VERIFY_OUT" | grep -q 'LEDGER VERIFICATION: OK'; then
    check "ledger file verifies independently (mack-ledger-verify) — the session's signed evidence persists on disk, checkpoint included" 0
else
    check "ledger file verifies independently (mack-ledger-verify)" 1
fi

# 4c. Session receipt (v0.12.0): the receipt file the proxy
#     wrote beside the ledger must bind THIS ledger's head and
#     count as independently verified above, and the SHA-256 of
#     the proxy binary on disk as measured here — the receipt's
#     claims are checked against artifacts, not trusted.
RECEIPT_PATH="$LEDGER_PATH.receipt.json"
if [ -f "$RECEIPT_PATH" ]; then
    R_HEAD="$(sed -n 's/.*"ledger_head_hash": "\([0-9a-f]*\)".*/\1/p' "$RECEIPT_PATH" | head -1)"
    R_COUNT="$(sed -n 's/.*"ledger_record_count": \([0-9]*\).*/\1/p' "$RECEIPT_PATH" | head -1)"
    R_BIN="$(sed -n 's/.*"proxy_binary_sha256": "\([0-9a-f]*\)".*/\1/p' "$RECEIPT_PATH" | head -1)"
    V_TIP="$(printf '%s' "$VERIFY_OUT" | sed -n 's/.*Tip hash: \([0-9a-f]*\).*/\1/p' | head -1)"
    V_COUNT="$(printf '%s' "$VERIFY_OUT" | sed -n 's/.*Entries verified: \([0-9]*\).*/\1/p' | head -1)"
    BIN_HASH="$(sha256sum "$BIN" | cut -d' ' -f1)"
    if [ -n "$R_HEAD" ] && [ "$R_HEAD" = "$V_TIP" ] && [ "$R_COUNT" = "$V_COUNT" ] && [ "$R_BIN" = "$BIN_HASH" ]; then
        check "session receipt binds the independently verified ledger head and count, and the measured SHA-256 of the proxy binary (receipt, mack-ledger-verify, and sha256sum all agree)" 0
    else
        check "session receipt binds the verified ledger head/count and the proxy binary's SHA-256 (receipt head ${R_HEAD:0:16}..., count $R_COUNT, binary ${R_BIN:0:16}...; verified tip ${V_TIP:0:16}..., count $V_COUNT)" 1
    fi
else
    check "session receipt file written beside the ledger ($RECEIPT_PATH)" 1
fi

# 5. Outside control: same URL, no proxy, no key — printed in full
#    above (body, HTTP code, curl exit). The transport must work
#    and the target must refuse (401 in echo mode), proving the
#    endpoint is reachable and key-gated from outside, so an inside
#    failure is attributable to the inside.
if [ $ECHO_MODE -eq 1 ] && [ "$OUTSIDE_CODE" = "401" ]; then
    check "outside control: no proxy and no key is refused by the target (HTTP 401, curl exit $OUTSIDE_EXIT — printed in full above): transport works, key is demanded" 0
elif [ $ECHO_MODE -eq 0 ] && [ "$OUTSIDE_CODE" != "000" ] && [ -n "$OUTSIDE_CODE" ]; then
    check "outside control: target reachable without the proxy (HTTP $OUTSIDE_CODE, printed above)" 0
else
    check "outside control: no proxy and no key is refused by the target (expected HTTP 401 in echo mode; got HTTP $OUTSIDE_CODE, curl exit $OUTSIDE_EXIT)" 1
fi

# 6. The workload's direct attempt, with the system CA bundle so
#    TLS trust is not the variable. It must not authenticate. The
#    failure LEVEL is reported as observed, never rounded up:
#    a resolution-level exit (6) is the child's direct DNS dying
#    on the seccomp profile's UDP denial (since v0.11.0); a
#    connect-level exit (7/28) on the target's port is the
#    Landlock network ruleset denying the connect at the kernel
#    level (since v0.10.0); an HTTP 401 means the endpoint was
#    REACHED, which the ruleset must prevent for any non-proxy
#    port, so it fails the run; a TLS-level exit (35) on an
#    intercepting network measures that interception, not the
#    proxy — see the Confinement section above, which reports
#    this machine's behavior as observed, either way.
DIRECT_CODE="$(printf '%s' "$DIRECT_SECTION" | sed -n 's/.*DIRECT_HTTP_CODE=\([0-9]*\).*/\1/p' | tail -1)"
DIRECT_EXIT="$(printf '%s' "$DIRECT_SECTION" | sed -n 's/.*DIRECT_CURL_EXIT=\([0-9]*\).*/\1/p' | tail -1)"
if printf '%s' "$DIRECT_SECTION" | grep -q '"authenticated": true'; then
    check "workload direct attempt — BYPASS EXISTS: the workload reached the target authenticated without the proxy" 1
elif [ "$DIRECT_CODE" = "401" ]; then
    check "workload direct attempt REACHED the target and was refused without the key (HTTP 401) — credential isolation held, but the Landlock network ruleset did NOT block this connect, which it must for any non-proxy port" 1
elif [ -n "$DIRECT_EXIT" ]; then
    check "workload direct attempt failed at the connection/TLS level from inside (curl exit $DIRECT_EXIT, HTTP $DIRECT_CODE) with the system CA bundle — not authenticated; a resolution-level exit is the seccomp profile's UDP denial, a connect-level exit on a non-proxy port is the Landlock network ruleset itself, and the level is reported as observed (see Confinement)" 0
else
    check "workload direct attempt did not authenticate (HTTP $DIRECT_CODE)" 0
fi

# 7. Session-token rotation: the second call presents the SAME
#    session token. By design it must authenticate — the proxy
#    resolves the session token to the CURRENT per-host handle,
#    which is the freshly minted successor (the first per-host
#    handle was burned by call 1; replaying IT would be refused,
#    but the workload never sees per-host handles). A refusal here
#    means rotation is broken. A transport failure with no HTTP
#    response is inconclusive and fails the run rather than
#    passing on no evidence. (An earlier version of this check
#    asserted the session token itself was single-use; it is not —
#    see the header.)
REUSE_CODE="$(printf '%s' "$REUSE_SECTION" | sed -n 's/.*REUSE_HTTP_CODE=\([0-9]*\).*/\1/p' | tail -1)"
if printf '%s' "$REUSE_SECTION" | grep -q '"authenticated": true'; then
    check "session token resolved a second time — per-host handle rotated (successor minted and ledgered; the burned first handle cannot be replayed); the session token is a session-scoped resolver, redacted above like the key" 0
elif [ "$REUSE_CODE" = "401" ] || [ "$REUSE_CODE" = "403" ]; then
    check "session token's second use was REFUSED by the proxy (HTTP $REUSE_CODE) — successor rotation is broken: the design says it must resolve to the freshly minted per-host handle" 1
else
    check "session token's second use produced no HTTP response (HTTP $REUSE_CODE) — rotation UNPROVEN on this run; the run fails rather than passing on no evidence" 1
fi

echo
if [ $ATTEMPT -gt 1 ]; then
    echo "== $PASS passed, $FAIL failed — NOTE: the proxy leg passed only on attempt $ATTEMPT of 2 (the target hiccuped on attempt 1; the retry is disclosed, not hidden) =="
else
    echo "== $PASS passed, $FAIL failed (proxy leg passed on attempt 1) =="
fi
[ "$FAIL" -eq 0 ]
