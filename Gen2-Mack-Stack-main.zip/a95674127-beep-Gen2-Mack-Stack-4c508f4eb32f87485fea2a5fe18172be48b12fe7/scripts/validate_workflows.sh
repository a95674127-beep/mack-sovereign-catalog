#!/usr/bin/env bash
set -euo pipefail

echo "================================================================="
echo " MACK Security Runtime — Workflow Concurrency & Release Safety   "
echo "================================================================="

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Ensure Python 3 is available
if ! command -v python3 &>/dev/null; then
    echo "[-] ERROR: python3 is required for workflow validation."
    exit 1
fi

echo "[*] Step 1: Running validator regression and edge-case test suite..."
python3 "${SCRIPT_DIR}/validate_workflows.py" --self-test

echo "[*] Step 2: Validating active repository workflows in .github/workflows..."
python3 "${SCRIPT_DIR}/validate_workflows.py" --workflows-dir "${ROOT_DIR}/.github/workflows" --verbose

echo "[+] All workflow concurrency and release protections confirmed."
