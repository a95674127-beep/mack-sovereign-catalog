#!/usr/bin/env bash
# Reproducible-build verification (v0.8.0): builds both binaries
# twice from clean with a pinned SOURCE_DATE_EPOCH and compares
# SHA-256 digests. Same source + same toolchain must produce
# bit-identical binaries; a mismatch is reported, never papered over.
set -euo pipefail
cd "$(dirname "$0")/.."
export SOURCE_DATE_EPOCH=1700000000
export CARGO_INCREMENTAL=0
export PATH="$HOME/.cargo/bin:$PATH"

build_and_hash() {
    cargo clean -q
    cargo build --bins -q
    sha256sum target/debug/mack-security-runtime target/debug/mack-proxy | awk '{print $1}' | tr '\n' ' '
    echo
}

A=$(build_and_hash)
B=$(build_and_hash)
echo "build 1: $A"
echo "build 2: $B"
if [ "$A" = "$B" ]; then
    echo "REPRODUCIBLE: both clean builds are bit-identical"
else
    echo "MISMATCH: clean builds differ"
    exit 1
fi
