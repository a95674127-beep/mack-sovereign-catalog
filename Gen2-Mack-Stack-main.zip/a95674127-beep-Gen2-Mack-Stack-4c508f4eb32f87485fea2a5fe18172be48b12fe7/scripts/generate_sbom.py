#!/usr/bin/env python3
"""Generate a CycloneDX 1.5 SBOM from the locked dependency tree.

Reads `cargo metadata --locked` and writes `sbom.cdx.json` at the
repository root. Every package in the resolve graph appears once,
with its name, version, and license as cargo metadata reports
them. Packages reachable from the root package through normal or
build edges are scope "required"; packages reachable only through
dev-dependency edges (test/bench tooling that never ships) are
scope "excluded".

The output is deterministic (no timestamp, no serial number,
components sorted) so regenerating it at release time diffs
cleanly against the committed copy.

Usage: python3 scripts/generate_sbom.py [output-path]
"""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def purl(name: str, version: str) -> str:
    return f"pkg:cargo/{name}@{version}"


def licenses_for(pkg: dict) -> list:
    license_expr = pkg.get("license")
    if license_expr:
        return [{"expression": license_expr}]
    license_file = pkg.get("license_file")
    if license_file:
        return [{"license": {"name": f"See license file: {license_file}"}}]
    return []


def main() -> int:
    out_path = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "sbom.cdx.json"
    raw = subprocess.run(
        ["cargo", "metadata", "--locked", "--format-version", "1"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=True,
    ).stdout
    metadata = json.loads(raw)

    packages = {pkg["id"]: pkg for pkg in metadata["packages"]}
    workspace_ids = set(metadata["workspace_members"])
    root_ids = [
        node["id"] for node in metadata["resolve"]["nodes"] if node["id"] in workspace_ids
    ]
    nodes = {node["id"]: node for node in metadata["resolve"]["nodes"]}

    # Breadth-first reachability from the root package(s) over
    # non-dev edges, to classify each package's scope.
    required = set(root_ids)
    frontier = list(root_ids)
    while frontier:
        current = frontier.pop()
        for dep in nodes.get(current, {}).get("deps", []):
            kinds = {dk.get("kind") for dk in dep.get("dep_kinds", [])}
            if "dev" in kinds and len(kinds) == 1:
                continue
            target = dep["pkg"]
            if target not in required:
                required.add(target)
                frontier.append(target)

    def component(pkg: dict, scope: str, ctype: str) -> dict:
        comp = {
            "type": ctype,
            "bom-ref": purl(pkg["name"], pkg["version"]),
            "name": pkg["name"],
            "version": pkg["version"],
            "purl": purl(pkg["name"], pkg["version"]),
        }
        if scope:
            comp["scope"] = scope
        lic = licenses_for(pkg)
        if lic:
            comp["licenses"] = lic
        return comp

    roots = [packages[pid] for pid in root_ids]
    if len(roots) != 1:
        raise SystemExit(f"expected exactly one workspace root package, got {len(roots)}")
    root_pkg = roots[0]

    components = []
    for pid, pkg in packages.items():
        if pid in workspace_ids:
            continue
        scope = "required" if pid in required else "excluded"
        components.append(component(pkg, scope, "library"))
    components.sort(key=lambda c: (c["name"], c["version"]))

    bom = {
        "bomFormat": "CycloneDX",
        "specVersion": "1.5",
        "version": 1,
        "metadata": {
            "tools": [
                {
                    "vendor": "Gen2-Mack-Stack",
                    "name": "scripts/generate_sbom.py",
                    "version": "1.0",
                }
            ],
            "component": component(root_pkg, "", "application"),
        },
        "components": components,
    }
    out_path.write_text(json.dumps(bom, indent=2) + "\n")
    print(f"wrote {out_path} ({len(components)} components)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
