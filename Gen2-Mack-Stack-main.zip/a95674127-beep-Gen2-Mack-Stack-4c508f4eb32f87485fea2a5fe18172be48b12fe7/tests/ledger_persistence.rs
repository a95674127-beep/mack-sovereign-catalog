//! Persistence tests for the signed proof ledger (v0.11.0,
//! `ledger::store`): round-trip across restarts, authority
//! binding, tamper/removal/reorder detection, the torn-tail
//! crash-recovery rule, export + manifest cross-checking, and the
//! binary-level path — `mack-proxy --ledger` writing a file that
//! `mack-ledger-verify` validates independently.

use ed25519_dalek::SigningKey;
use mack_security_runtime::ledger::store::{self, LedgerStoreError};
use mack_security_runtime::ledger::ProofLedger;
use rand_core::OsRng;
use std::io::{Read, Write};
use std::net::TcpListener;
use std::path::PathBuf;
use std::process::Command;
use std::thread;

fn fresh_dir(tag: &str) -> PathBuf {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let dir = std::env::temp_dir().join(format!(
        "mack-ledger-test-{tag}-{}-{nanos}",
        std::process::id()
    ));
    std::fs::create_dir_all(&dir).unwrap();
    dir
}

/// Builds a persistent ledger with two entries and a checkpoint
/// (3 entries total) and returns the tip after the first two.
fn build_ledger(path: &std::path::Path, key: &SigningKey) -> String {
    let (mut ledger, report) = ProofLedger::open_persistent(path, key.clone()).unwrap();
    assert_eq!(report.loaded_entries, 0);
    ledger.append("RUN_START", "lane-1", b"one", None);
    ledger.append("EGRESS_DECISION", "lane-1", b"two", None);
    let tip_after_two = ledger.tip_hash().to_string();
    ledger.append_checkpoint("lane-1");
    tip_after_two
}

#[test]
fn persistent_ledger_round_trip_across_restarts() {
    let dir = fresh_dir("roundtrip");
    let path = dir.join("ledger.jsonl");
    let key = SigningKey::generate(&mut OsRng);
    let tip_after_two = build_ledger(&path, &key);

    // Restart under the same authority: the chain is loaded,
    // re-verified, and continues where it left off.
    let (mut ledger, report) = ProofLedger::open_persistent(&path, key.clone()).unwrap();
    assert_eq!(report.loaded_entries, 3);
    assert_eq!(report.recovered_torn_bytes, 0);
    ledger.verify_chain().unwrap();
    let resumed = ledger.append("RUN_RESUMED", "lane-1", b"three", None);
    assert_eq!(resumed.sequence, 4);
    ledger.verify_chain().unwrap();

    // Independent verification from the file alone.
    let summary = store::verify_file(&path).unwrap();
    assert_eq!(summary.entry_count, 4);
    assert_eq!(summary.tip_hash, ledger.tip_hash());
    assert_eq!(summary.last_checkpoint_sequence, Some(3));
    assert_eq!(
        summary.last_checkpoint_committed_tip.as_deref(),
        Some(tip_after_two.as_str()),
        "the checkpoint must commit to the tip that preceded it"
    );
    assert_eq!(
        summary.authority_verifying_key,
        hex::encode(key.verifying_key().to_bytes())
    );
}

#[test]
fn persistent_ledger_refuses_a_different_authority() {
    let dir = fresh_dir("authority");
    let path = dir.join("ledger.jsonl");
    let key_a = SigningKey::generate(&mut OsRng);
    let key_b = SigningKey::generate(&mut OsRng);
    build_ledger(&path, &key_a);
    let err = ProofLedger::open_persistent(&path, key_b).unwrap_err();
    assert!(
        matches!(err, LedgerStoreError::AuthorityMismatch(_)),
        "a ledger file must refuse a foreign authority, got: {err}"
    );
}

#[test]
fn tampered_entry_fails_verification_and_open() {
    let dir = fresh_dir("tamper");
    let path = dir.join("ledger.jsonl");
    let key = SigningKey::generate(&mut OsRng);
    build_ledger(&path, &key);

    // Flip one hex digit inside the second entry's payload_hash:
    // the JSON stays parseable, so this is tampering, not a tear.
    let text = std::fs::read_to_string(&path).unwrap();
    let mut lines: Vec<String> = text.lines().map(|l| l.to_string()).collect();
    let marker = "\"payload_hash\":\"";
    let pos = lines[2].find(marker).unwrap() + marker.len();
    let original = lines[2].as_bytes()[pos];
    let flipped = if original == b'a' { 'b' } else { 'a' };
    lines[2].replace_range(pos..pos + 1, &flipped.to_string());
    std::fs::write(&path, lines.join("\n") + "\n").unwrap();

    let err = store::verify_file(&path).unwrap_err();
    assert!(
        matches!(err, LedgerStoreError::ChainInvalid(_)),
        "tampered entry must fail chain verification, got: {err}"
    );
    let err = ProofLedger::open_persistent(&path, key).unwrap_err();
    assert!(
        matches!(err, LedgerStoreError::ChainInvalid(_)),
        "open must refuse a tampered chain, got: {err}"
    );
}

#[test]
fn removed_entry_fails_verification() {
    let dir = fresh_dir("removal");
    let path = dir.join("ledger.jsonl");
    let key = SigningKey::generate(&mut OsRng);
    build_ledger(&path, &key);
    let text = std::fs::read_to_string(&path).unwrap();
    let mut lines: Vec<&str> = text.lines().collect();
    lines.remove(2); // drop the second entry line entirely
    std::fs::write(&path, lines.join("\n") + "\n").unwrap();
    let err = store::verify_file(&path).unwrap_err();
    assert!(
        matches!(err, LedgerStoreError::ChainInvalid(_)),
        "a removed entry must break the chain, got: {err}"
    );
}

#[test]
fn reordered_entries_fail_verification() {
    let dir = fresh_dir("reorder");
    let path = dir.join("ledger.jsonl");
    let key = SigningKey::generate(&mut OsRng);
    build_ledger(&path, &key);
    let text = std::fs::read_to_string(&path).unwrap();
    let mut lines: Vec<&str> = text.lines().collect();
    lines.swap(1, 2); // swap the two entry lines
    std::fs::write(&path, lines.join("\n") + "\n").unwrap();
    let err = store::verify_file(&path).unwrap_err();
    assert!(
        matches!(err, LedgerStoreError::ChainInvalid(_)),
        "reordered entries must break the chain, got: {err}"
    );
}

#[test]
fn torn_tail_is_recovered_at_open_and_recorded() {
    let dir = fresh_dir("torn");
    let path = dir.join("ledger.jsonl");
    let key = SigningKey::generate(&mut OsRng);
    build_ledger(&path, &key);

    // Simulate a crash mid-append: a partial JSON line, no newline.
    let torn = "{\"sequence\":4,\"prev_hash\":\"deadbeef";
    {
        let mut f = std::fs::OpenOptions::new()
            .append(true)
            .open(&path)
            .unwrap();
        f.write_all(torn.as_bytes()).unwrap();
        f.sync_all().unwrap();
    }
    // The strict verifier judges the artifact as-is: torn = corrupt.
    let err = store::verify_file(&path).unwrap_err();
    assert!(
        matches!(err, LedgerStoreError::Corrupt(_)),
        "strict verification must report the torn tail, got: {err}"
    );

    // Open applies the documented recovery: truncate the torn
    // tail, keep the verified prefix, and record the truncation
    // as a signed entry.
    let (ledger, report) = ProofLedger::open_persistent(&path, key).unwrap();
    assert_eq!(report.loaded_entries, 3);
    assert_eq!(report.recovered_torn_bytes, torn.len());
    assert_eq!(ledger.entries().len(), 4);
    assert_eq!(
        ledger.entries()[3].event_type,
        store::RECOVERY_EVENT,
        "the recovery must be recorded in the chain itself"
    );
    ledger.verify_chain().unwrap();
    // After recovery the file verifies independently again.
    let summary = store::verify_file(&path).unwrap();
    assert_eq!(summary.entry_count, 4);
}

#[test]
fn export_verifies_and_manifest_cross_checks() {
    let dir = fresh_dir("export");
    let path = dir.join("ledger.jsonl");
    let key = SigningKey::generate(&mut OsRng);
    build_ledger(&path, &key);

    let export_dir = dir.join("exported");
    let manifest = store::export(&path, &export_dir).unwrap();
    assert_eq!(manifest.entry_count, 3);
    let summary = store::verify_export(&export_dir).unwrap();
    assert_eq!(summary.tip_hash, manifest.tip_hash);
    assert_eq!(summary.last_checkpoint_sequence, Some(3));

    // Tamper with the EXPORTED copy: manifest and chain now
    // disagree with the entry hashes, and verification fails.
    let exported = export_dir.join(&manifest.ledger_file);
    let text = std::fs::read_to_string(&exported).unwrap();
    let mut lines: Vec<String> = text.lines().map(|l| l.to_string()).collect();
    let marker = "\"event_type\":\"";
    let pos = lines[1].find(marker).unwrap() + marker.len();
    lines[1].replace_range(pos..pos + 1, "X");
    std::fs::write(&exported, lines.join("\n") + "\n").unwrap();
    assert!(
        store::verify_export(&export_dir).is_err(),
        "a tampered export must fail verification"
    );
}

#[test]
fn binary_persists_ledger_and_verify_tool_confirms() {
    let dir = fresh_dir("binary");
    let ledger_path = dir.join("session.ledger.jsonl");
    let key_path = dir.join("authority.key");

    // A real upstream + a child that makes one proxied request,
    // mirroring tests/proxy_cli_e2e.rs.
    let upstream = TcpListener::bind("127.0.0.1:0").unwrap();
    let upstream_port = upstream.local_addr().unwrap().port();
    let server = thread::spawn(move || {
        // Bounded accept (v0.14.2): a plain blocking accept()
        // here hung this test forever when the proxy's child
        // failed to launch (diagnosed 2026-11-17 on a kernel
        // without Landlock NET rules — no request ever
        // arrived, and the join below blocked on a thread
        // that could never proceed). Poll with a deadline
        // and fail with the reason instead.
        upstream.set_nonblocking(true).unwrap();
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(30);
        let (mut conn, _) = loop {
            match upstream.accept() {
                Ok(pair) => break pair,
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                    assert!(
                        std::time::Instant::now() < deadline,
                        "upstream received no connection within 30s — the proxied run failed before any request"
                    );
                    thread::sleep(std::time::Duration::from_millis(25));
                }
                Err(e) => panic!("upstream accept failed: {e}"),
            }
        };
        let mut buf = [0u8; 4096];
        let _ = conn.read(&mut buf).unwrap();
        let resp = "HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK";
        conn.write_all(resp.as_bytes()).unwrap();
    });
    let child_script = format!(
        r#"
import os, socket
proxy = os.environ["HTTP_PROXY"].replace("http://", "")
phost, pport = proxy.split(":")
s = socket.create_connection((phost, int(pport)), timeout=5)
req = (
    "GET http://127.0.0.1:{p}/v1/test HTTP/1.1\r\n"
    "Host: 127.0.0.1:{p}\r\n"
    "Authorization: Bearer " + os.environ["MACK_TOKEN_HANDLE"] + "\r\n"
    "Connection: close\r\n\r\n"
)
s.sendall(req.encode())
data = s.recv(4096).decode()
s.close()
assert "200 OK" in data, data
print("CHILD_REQUEST_OK")
"#,
        p = upstream_port
    );
    let proxy_bin = env!("CARGO_BIN_EXE_mack-proxy");
    let output = Command::new(proxy_bin)
        .env("MACK_REAL_SECRET", "ledger-e2e-secret")
        .args([
            "run",
            "--allow",
            "127.0.0.1",
            "--method",
            "GET",
            "--insecure-loopback",
            "--ledger",
            ledger_path.to_str().unwrap(),
            "--ledger-key",
            key_path.to_str().unwrap(),
            "--",
            "python3",
            "-c",
            &child_script,
        ])
        .output()
        .expect("failed to run mack-proxy");
    // Assert on the proxy's own outcome BEFORE joining the
    // upstream thread (v0.14.2): if the run failed, this
    // fails fast with the proxy's stderr in the message
    // instead of blocking on a server that may never see a
    // connection.
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        output.status.success() && stdout.contains("CHILD_REQUEST_OK"),
        "proxied run must succeed.\nstdout: {stdout}\nstderr: {stderr}"
    );
    server.join().unwrap();
    assert!(
        stderr.contains("Session ledger: persistent at"),
        "the run must report persistent mode.\nstderr: {stderr}"
    );
    assert!(
        stderr.contains("Ledger checkpoint: sequence"),
        "the run must checkpoint at shutdown.\nstderr: {stderr}"
    );

    // Independent verification with the standalone tool.
    let verify_bin = env!("CARGO_BIN_EXE_mack-ledger-verify");
    let vout = Command::new(verify_bin)
        .arg(&ledger_path)
        .output()
        .expect("failed to run mack-ledger-verify");
    let vtext = String::from_utf8_lossy(&vout.stdout);
    assert!(
        vout.status.success() && vtext.contains("LEDGER VERIFICATION: OK"),
        "standalone verification must pass.\nstdout: {vtext}\nstderr: {}",
        String::from_utf8_lossy(&vout.stderr)
    );
    let first_count = store::verify_file(&ledger_path).unwrap().entry_count;
    assert!(
        first_count >= 4,
        "expected several entries, got {first_count}"
    );

    // A second run under the same ledger + key continues the chain.
    let output2 = Command::new(proxy_bin)
        .env("MACK_REAL_SECRET", "ledger-e2e-secret")
        .args([
            "run",
            "--allow",
            "127.0.0.1",
            "--ledger",
            ledger_path.to_str().unwrap(),
            "--ledger-key",
            key_path.to_str().unwrap(),
            "--",
            "sh",
            "-c",
            "exit 0",
        ])
        .output()
        .expect("failed to rerun mack-proxy");
    assert!(
        output2.status.success(),
        "second run must succeed.\nstderr: {}",
        String::from_utf8_lossy(&output2.stderr)
    );
    let second_count = store::verify_file(&ledger_path).unwrap().entry_count;
    assert!(
        second_count > first_count,
        "the chain must grow across runs ({first_count} -> {second_count})"
    );
}
