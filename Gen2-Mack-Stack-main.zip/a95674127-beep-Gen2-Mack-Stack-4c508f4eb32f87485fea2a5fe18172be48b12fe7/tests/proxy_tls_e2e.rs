//! End-to-end test of the v0.9.0 TLS transport in `mack-proxy`:
//! a local HTTPS upstream (own test CA), a confined child (curl),
//! and the full path — CONNECT, split-TLS termination, sentinel +
//! handle checks, vault unsealing, secret injection on the upstream
//! leg only, response relay.
//!
//! What this proves that the graded external package's test did not:
//! a REAL HTTPS request completes through the tunnel, the upstream
//! sees the real secret while the child never does, a SECOND request
//! in the same session also succeeds (successor handles are minted
//! per request — handles stay single-use without bricking the
//! session), a forged handle is denied, and a non-allowlisted host
//! is refused at CONNECT.

use rcgen::{BasicConstraints, CertificateParams, DistinguishedName, DnType, IsCa, KeyPair};
use std::io::{Read, Write};
use std::net::TcpListener;
use std::process::Command;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

fn build_upstream() -> (u16, std::path::PathBuf, Arc<AtomicBool>) {
    let _ = rustls::crypto::ring::default_provider().install_default();

    // Test CA.
    let mut ca_params = CertificateParams::default();
    ca_params.is_ca = IsCa::Ca(BasicConstraints::Unconstrained);
    let mut dn = DistinguishedName::new();
    dn.push(DnType::CommonName, "mack-proxy TLS e2e test CA");
    ca_params.distinguished_name = dn;
    let ca_key = KeyPair::generate().unwrap();
    let ca_cert = ca_params.self_signed(&ca_key).unwrap();
    let ca_pem = ca_cert.pem();

    // Server leaf for "localhost".
    let mut leaf_params = CertificateParams::new(vec!["localhost".to_string()]).unwrap();
    let mut ldn = DistinguishedName::new();
    ldn.push(DnType::CommonName, "localhost");
    leaf_params.distinguished_name = ldn;
    let leaf_key = KeyPair::generate().unwrap();
    let leaf_cert = leaf_params.signed_by(&leaf_key, &ca_cert, &ca_key).unwrap();
    let server_cfg = rustls::ServerConfig::builder()
        .with_no_client_auth()
        .with_single_cert(
            vec![leaf_cert.der().clone()],
            rustls::pki_types::PrivateKeyDer::Pkcs8(rustls::pki_types::PrivatePkcs8KeyDer::from(
                leaf_key.serialize_der(),
            )),
        )
        .unwrap();

    let ca_path = std::env::temp_dir().join(format!("mack-tls-e2e-ca-{}.pem", std::process::id()));
    std::fs::write(&ca_path, &ca_pem).unwrap();

    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let port = listener.local_addr().unwrap().port();
    let stop = Arc::new(AtomicBool::new(false));
    let stop_thread = Arc::clone(&stop);
    std::thread::spawn(move || {
        listener.set_nonblocking(true).unwrap();
        while !stop_thread.load(Ordering::Relaxed) {
            match listener.accept() {
                Ok((stream, _)) => {
                    let cfg = Arc::new(server_cfg.clone());
                    std::thread::spawn(move || {
                        let conn = match rustls::ServerConnection::new(cfg) {
                            Ok(c) => c,
                            Err(_) => return,
                        };
                        let mut tls = rustls::StreamOwned::new(conn, stream);
                        // GET requests only: read byte-wise until the
                        // header block ends (no body follows).
                        let mut buf: Vec<u8> = Vec::new();
                        let mut byte = [0u8; 1];
                        let mut auth = String::new();
                        loop {
                            match tls.read(&mut byte) {
                                Ok(0) => break,
                                Ok(_) => {
                                    buf.push(byte[0]);
                                    if buf.ends_with(b"\r\n\r\n") {
                                        break;
                                    }
                                }
                                Err(_) => return,
                            }
                        }
                        let text = String::from_utf8_lossy(&buf);
                        for line in text.lines() {
                            if let Some((k, v)) = line.split_once(':') {
                                if k.trim().eq_ignore_ascii_case("authorization") {
                                    auth = v.trim().to_string();
                                }
                            }
                        }
                        let body = format!("AUTH:{auth}");
                        let resp = format!(
                            "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                            body.len(),
                            body
                        );
                        let _ = tls.write_all(resp.as_bytes());
                        let _ = tls.flush();
                    });
                }
                Err(_) => std::thread::sleep(std::time::Duration::from_millis(25)),
            }
        }
    });
    (port, ca_path, stop)
}

#[test]
fn tls_mode_end_to_end() {
    let (port, ca_path, stop) = build_upstream();
    let bin = env!("CARGO_BIN_EXE_mack-proxy");
    let script = format!(
        r#"export http_proxy="$HTTP_PROXY" https_proxy="$HTTPS_PROXY" no_proxy="" NO_PROXY=""
echo "ENV_SECRET_COUNT=$(env | grep -c tls-e2e-secret-42 || true)"
echo "R1=$(curl -s --max-time 20 -H "X-Mack-Handle: $MACK_TOKEN_HANDLE" https://localhost:{port}/echo)"
echo "R2=$(curl -s --max-time 20 -H "X-Mack-Handle: $MACK_TOKEN_HANDLE" https://localhost:{port}/echo)"
echo "FORGED_OUT=$(curl -s -i --max-time 20 -H "X-Mack-Handle: MACK_HANDLE_forged" https://localhost:{port}/echo)"
UNLISTED=$(curl -s --max-time 10 https://example.com/ 2>&1); echo "UNLISTED_EXIT=$?"
echo "CAFILE=$SSL_CERT_FILE""#
    );
    let output = Command::new(bin)
        .env("MACK_REAL_SECRET", "tls-e2e-secret-42")
        .env("MACK_UPSTREAM_CA_PEM", &ca_path)
        .args([
            "run",
            "--tls",
            "--allow",
            "localhost",
            "--",
            "sh",
            "-c",
            &script,
        ])
        .output()
        .expect("failed to run mack-proxy");
    stop.store(true, Ordering::Relaxed);
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);

    assert!(
        stdout.contains("R1=AUTH:Bearer tls-e2e-secret-42"),
        "first request: upstream should echo the injected secret.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("R2=AUTH:Bearer tls-e2e-secret-42"),
        "second request in the same session must also succeed (successor handle).\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("FORGED_OUT=") && stdout.contains("403 Forbidden"),
        "forged handle must be denied inside the tunnel.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        !stdout.contains("UNLISTED_EXIT=0"),
        "non-allowlisted host must fail.\nstdout: {stdout}"
    );
    assert!(
        stdout.contains("ENV_SECRET_COUNT=0"),
        "child environment must never contain the raw secret.\nstdout: {stdout}"
    );
    assert!(
        stdout.contains("CAFILE=/dev/shm/mack_session_ca_")
            || stdout.contains("CAFILE=/tmp/mack_session_ca_"),
        "child must receive the session CA path.\nstdout: {stdout}"
    );
    assert!(
        stderr.contains("Run complete. Signed ledger entries:"),
        "signed ledger must verify at shutdown.\nstderr: {stderr}"
    );
    let _ = std::fs::remove_file(&ca_path);
}
