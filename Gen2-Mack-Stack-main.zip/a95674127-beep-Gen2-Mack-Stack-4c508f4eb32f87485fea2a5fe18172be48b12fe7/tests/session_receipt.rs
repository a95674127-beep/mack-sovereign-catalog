//! Session receipt integration tests (v0.12.0): a real
//! `mack-proxy` run emits a signed receipt at shutdown; the
//! receipt must verify against the same key that signed the
//! session ledger, and its bound ledger head/count and binary
//! hash must match the artifacts on disk — measured, never
//! asserted.

use ed25519_dalek::{SigningKey, VerifyingKey};
use mack_security_runtime::ledger::store;
use mack_security_runtime::session_receipt::{
    SessionReceipt, KEY_PROVENANCE_AUTHORITY, KEY_PROVENANCE_SESSION,
};
use sha2::{Digest, Sha256};
use std::path::PathBuf;
use std::process::Command;

fn fresh_dir(tag: &str) -> PathBuf {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let dir = std::env::temp_dir().join(format!(
        "mack-receipt-test-{tag}-{}-{nanos}",
        std::process::id()
    ));
    std::fs::create_dir_all(&dir).unwrap();
    dir
}

/// Extracts the receipt JSON from a proxy run's stdout: the
/// receipt is the only JSON object the proxy prints there.
fn receipt_from_stdout(stdout: &str) -> SessionReceipt {
    let start = stdout
        .find("{\n  \"version\"")
        .expect("proxy stdout must contain the session receipt JSON");
    serde_json::from_str(&stdout[start..]).expect("receipt JSON must parse")
}

fn sha256_hex_of(path: &std::path::Path) -> String {
    let bytes = std::fs::read(path).unwrap();
    format!("{:x}", Sha256::digest(&bytes))
}

#[test]
fn persistent_run_receipt_binds_ledger_and_binary() {
    let dir = fresh_dir("persistent");
    let ledger_path = dir.join("session.ledger.jsonl");
    let key_path = dir.join("authority.key");
    let proxy_bin = env!("CARGO_BIN_EXE_mack-proxy");

    let output = Command::new(proxy_bin)
        .env("MACK_REAL_SECRET", "receipt-test-secret")
        .args([
            "run",
            "--allow",
            "127.0.0.1",
            "--ledger",
            ledger_path.to_str().unwrap(),
            "--ledger-key",
            key_path.to_str().unwrap(),
            "--",
            "sh",
            "-c",
            "exit 0",
        ])
        .output()
        .expect("failed to run mack-proxy");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        output.status.success(),
        "run must succeed.\nstdout: {stdout}\nstderr: {stderr}"
    );

    let receipt = receipt_from_stdout(&stdout);
    assert_eq!(receipt.version, env!("CARGO_PKG_VERSION"));
    assert_eq!(receipt.key_provenance, KEY_PROVENANCE_AUTHORITY);

    // The receipt verifies against the authority key that
    // signed the ledger (the key file the proxy created).
    let seed = std::fs::read(&key_path).unwrap();
    let seed_arr: [u8; 32] = seed.as_slice().try_into().unwrap();
    let authority = SigningKey::from_bytes(&seed_arr);
    receipt
        .verify(&authority.verifying_key())
        .expect("receipt must verify against the ledger authority key");

    // Its bound head/count equal the ledger file's verified
    // final state (after the shutdown checkpoint).
    let summary = store::verify_file(&ledger_path).unwrap();
    assert_eq!(receipt.ledger_record_count, summary.entry_count as u64);
    assert_eq!(receipt.ledger_head_hash, summary.tip_hash);

    // Its binary hash is the measured hash of the very binary
    // that ran.
    assert_eq!(
        receipt.proxy_binary_sha256,
        sha256_hex_of(std::path::Path::new(proxy_bin)),
        "the receipt must bind the measured hash of the running proxy binary"
    );

    // The sidecar receipt file beside the ledger carries the
    // same receipt.
    let mut os = ledger_path.clone().into_os_string();
    os.push(".receipt.json");
    let receipt_path = PathBuf::from(os);
    let on_disk: SessionReceipt =
        serde_json::from_str(&std::fs::read_to_string(&receipt_path).unwrap())
            .expect("receipt file must parse");
    assert_eq!(on_disk, receipt);
}

#[test]
fn in_memory_run_receipt_is_labeled_session_ephemeral() {
    let proxy_bin = env!("CARGO_BIN_EXE_mack-proxy");
    let output = Command::new(proxy_bin)
        .env("MACK_REAL_SECRET", "receipt-test-secret")
        .args(["run", "--allow", "127.0.0.1", "--", "sh", "-c", "exit 0"])
        .output()
        .expect("failed to run mack-proxy");
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        output.status.success(),
        "run must succeed.\nstdout: {stdout}\nstderr: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    let receipt = receipt_from_stdout(&stdout);
    assert_eq!(receipt.key_provenance, KEY_PROVENANCE_SESSION);
    // An ephemeral receipt verifies against the key it names —
    // and only that key (which is exactly why it proves less
    // than an authority-signed one).
    let vk_bytes = hex::decode(&receipt.authority_verifying_key).unwrap();
    let vk_arr: [u8; 32] = vk_bytes.as_slice().try_into().unwrap();
    let vk = VerifyingKey::from_bytes(&vk_arr).unwrap();
    receipt.verify(&vk).unwrap();
    assert!(receipt.ledger_record_count >= 2);
}
