//! Live-enforcement tests for Landlock network confinement
//! (`enforce_strict_isolation_with_network`), in their own test
//! binary: Landlock restriction is per-thread and irreversible, so
//! the confined connects run on a dedicated thread, mirroring
//! `tests/worker_sandbox.rs`.
//!
//! Pass conditions (the worker_sandbox pattern):
//! - enforcement succeeds on this kernel and the connect assertions
//!   below hold, or
//! - enforcement fails (e.g. the host kernel predates Landlock
//!   network rules, ABI v4 / 6.7) and the workload is aborted —
//!   the fail-closed path. The connects are never run unconfined.
//!
//! What is asserted, and what deliberately is NOT:
//! - A confined thread CAN connect to the one allowed port (the
//!   proxy port in production).
//! - A confined thread is REFUSED (EACCES / PermissionDenied) when
//!   connecting to a different loopback port with a live listener,
//!   and when connecting to a non-loopback address on a
//!   non-allowed port — refused by Landlock at `connect()` time,
//!   before any traffic.
//! - NOT asserted: refusal on a non-loopback address at the
//!   ALLOWED port. Landlock network rules match ports, not
//!   addresses, so that connect passes the ruleset. That is the
//!   documented limit of the mechanism (see the enforcer's doc
//!   comment), and these tests do not claim otherwise.

use mack_security_runtime::sandbox::landlock_enforcer::LandlockSandbox;
use std::io;
use std::net::{SocketAddr, TcpListener, TcpStream};
use std::thread;
use std::time::Duration;

const CONNECT_TIMEOUT: Duration = Duration::from_secs(5);

fn attempt(addr: &str, port: u16) -> io::Result<()> {
    let sa: SocketAddr = format!("{addr}:{port}")
        .parse()
        .expect("IP-literal socket address");
    TcpStream::connect_timeout(&sa, CONNECT_TIMEOUT).map(|_| ())
}

enum Outcome {
    Enforced {
        allowed: io::Result<()>,
        other_loopback: io::Result<()>,
        non_loopback: io::Result<()>,
    },
    FailedClosed(String),
}

#[test]
fn network_confined_child_reaches_only_the_allowed_port() {
    // Two live loopback listeners: the "proxy" port (allowed) and
    // an unrelated port (must be refused despite a listener
    // actively accepting there).
    let allowed_listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let allowed_port = allowed_listener.local_addr().unwrap().port();
    let other_listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let other_port = other_listener.local_addr().unwrap().port();
    assert_ne!(allowed_port, other_port);
    // The non-loopback attempt below uses port 443; the allowed
    // port is an ephemeral listener port, never 443.
    assert_ne!(allowed_port, 443);

    let spool = std::env::temp_dir();
    let handle = thread::spawn(move || {
        match LandlockSandbox::enforce_strict_isolation_with_network(
            &[spool.as_path()],
            &[allowed_port],
        ) {
            Ok(_) => Outcome::Enforced {
                allowed: attempt("127.0.0.1", allowed_port),
                other_loopback: attempt("127.0.0.1", other_port),
                // RFC 5737 TEST-NET-1, unroutable by design. An
                // unconfined connect to it would block, time out,
                // or fail with a routing error — never an instant
                // PermissionDenied. The assertion below therefore
                // proves the refusal happened at the Landlock
                // layer, before any traffic.
                non_loopback: attempt("192.0.2.1", 443),
            },
            Err(e) => Outcome::FailedClosed(e.to_string()),
        }
    });

    match handle.join().expect("network confinement test thread died") {
        Outcome::FailedClosed(msg) => {
            assert!(
                msg.contains("Landlock"),
                "abort must come from Landlock enforcement, got: {msg}"
            );
        }
        Outcome::Enforced {
            allowed,
            other_loopback,
            non_loopback,
        } => {
            eprintln!("network confinement enforced on this kernel; assertions are live");
            allowed.expect("confined child must reach the allowed (proxy) port");
            let other = other_loopback
                .expect_err("confined child must be refused on a different loopback port");
            assert_eq!(
                other.kind(),
                io::ErrorKind::PermissionDenied,
                "refusal must be Landlock EACCES at connect() time, got: {other}"
            );
            let remote =
                non_loopback.expect_err("confined child must be refused on a non-loopback address");
            assert_eq!(
                remote.kind(),
                io::ErrorKind::PermissionDenied,
                "refusal must be Landlock EACCES before any traffic, got: {remote}"
            );
        }
    }
}

#[test]
fn network_confined_child_with_no_allowed_ports_reaches_nothing() {
    // Handled-but-never-granted means deny-all: with an empty
    // allowed-port list, even a live loopback listener is refused.
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let port = listener.local_addr().unwrap().port();

    let spool = std::env::temp_dir();
    let handle =
        thread::spawn(move || {
            match LandlockSandbox::enforce_strict_isolation_with_network(&[spool.as_path()], &[]) {
                Ok(_) => Outcome::Enforced {
                    allowed: attempt("127.0.0.1", port),
                    other_loopback: Ok(()),
                    non_loopback: Ok(()),
                },
                Err(e) => Outcome::FailedClosed(e.to_string()),
            }
        });

    match handle.join().expect("network confinement test thread died") {
        Outcome::FailedClosed(msg) => {
            assert!(
                msg.contains("Landlock"),
                "abort must come from Landlock enforcement, got: {msg}"
            );
        }
        Outcome::Enforced { allowed, .. } => {
            let err =
                allowed.expect_err("with no allowed ports, a confined child must reach nothing");
            assert_eq!(
                err.kind(),
                io::ErrorKind::PermissionDenied,
                "refusal must be Landlock EACCES at connect() time, got: {err}"
            );
        }
    }
}

/// v0.14.2: the startup probe must agree with real
/// enforcement. The probe builds the identical ruleset
/// without restricting its caller, so it is safe on the
/// test's main thread; enforcement runs on a dedicated
/// thread (Landlock is per-thread and irreversible), as in
/// the tests above. On a kernel with Landlock NET both
/// succeed; on one without, both fail — and the probe's
/// error must name Landlock, because `mack-proxy` prints
/// it verbatim as the refusal reason.
#[test]
fn probe_agrees_with_enforcement() {
    let spool = std::env::temp_dir();
    let probe = LandlockSandbox::probe_strict_isolation_with_network(&[spool.as_path()], &[9]);
    let spool2 = spool.clone();
    let handle = thread::spawn(move || {
        LandlockSandbox::enforce_strict_isolation_with_network(&[spool2.as_path()], &[9])
    });
    let enforced = handle.join().expect("enforcement thread died");
    match (&probe, &enforced) {
        (Ok(()), Ok(_)) => {}
        (Err(pe), Err(ee)) => {
            assert!(
                pe.to_string().contains("Landlock"),
                "probe error must name Landlock, got: {pe}"
            );
            assert!(
                ee.to_string().contains("Landlock"),
                "enforcement error must name Landlock, got: {ee}"
            );
        }
        _ => panic!("probe and enforcement disagree: probe={probe:?} enforced={enforced:?}"),
    }
}
