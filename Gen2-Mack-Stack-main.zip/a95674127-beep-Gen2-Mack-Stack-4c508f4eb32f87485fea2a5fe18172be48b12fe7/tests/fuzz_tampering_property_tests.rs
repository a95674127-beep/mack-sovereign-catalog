//! Property-based adversarial fuzzing, tampering verification, and concurrency stress test suite.
//!
//! Uses proptest to systematically generate pseudo-random byte sequences, bit-flip mutations,
//! malformed envelopes, and corrupted ciphertexts to verify that:
//! 1. Content Disarm and Reconstruction (CDR) never panics and sanitizes prohibited payloads.
//! 2. Arbitrary garbage input to envelope deserialization and signature verification fails safely.
//! 3. Tampered ciphertexts and invalid passphrases strictly fail unsealing without panics or memory leaks.
//! 4. Concurrent multi-threaded vault operations maintain thread safety, isolation, and data integrity.

use ed25519_dalek::SigningKey;
use proptest::prelude::*;
use rand_core::OsRng;
use std::thread;

use mack_security_runtime::cdr::content_disarm::ContentDisarmEngine;
use mack_security_runtime::proof_fabric::execution_envelope::IntentBoundEnvelope;
use mack_security_runtime::vault::MackVaultEngine;

proptest! {
    #![proptest_config(ProptestConfig::with_cases(200))]

    /// Property 1: CDR never panics on arbitrary raw byte streams and eliminates script tags.
    #[test]
    fn prop_cdr_never_panics_on_arbitrary_bytes(bytes in proptest::collection::vec(any::<u8>(), 0..4096)) {
        let result = ContentDisarmEngine::sanitize_and_reconstruct(&bytes);
        if let Ok(sanitized) = result {
            if let Ok(sanitized_str) = std::str::from_utf8(&sanitized) {
                let lower = sanitized_str.to_lowercase();
                prop_assert!(!lower.contains("<script"));
                prop_assert!(!lower.contains("javascript:"));
            }
        }
    }

    /// Property 2: Ingress envelope deserialization and signature verification never panic on arbitrary input.
    #[test]
    fn prop_envelope_ingress_never_panics_on_fuzzed_data(bytes in proptest::collection::vec(any::<u8>(), 0..2048)) {
        if let Ok(envelope) = bincode::deserialize::<IntentBoundEnvelope>(&bytes) {
            let dummy_key = SigningKey::generate(&mut OsRng).verifying_key();
            let _ = envelope.verify(&bytes, &dummy_key);
        }
    }
}

proptest! {
    // Argon2id key derivation uses 64MB memory / 3 iterations per seal/unseal call.
    // 4 property cases perform 8 high-memory KDF derivations in debug mode.
    #![proptest_config(ProptestConfig::with_cases(4))]

    /// Property 3: Flipped bit in sealed ciphertext strictly fails unseal and never panics.
    #[test]
    fn prop_vault_ciphertext_bitflip_tampering_detected(
        secret in proptest::collection::vec(any::<u8>(), 1..64),
        passphrase in "[a-zA-Z0-9!@#$%^&*()_+]{8,24}",
        flip_byte_idx in 0usize..512usize,
        flip_bit in 0u8..8u8
    ) {
        let sealed = MackVaultEngine::seal(passphrase.as_bytes(), &secret, "PROP_TEST_LANE")
            .expect("Sealing should succeed");

        let mut tampered = sealed.clone();
        if !tampered.ciphertext.is_empty() {
            let target_idx = flip_byte_idx % tampered.ciphertext.len();
            tampered.ciphertext[target_idx] ^= 1 << (flip_bit % 8);

            // Tampered ciphertext MUST fail unseal
            let unseal_res = MackVaultEngine::unseal(passphrase.as_bytes(), &tampered);
            prop_assert!(unseal_res.is_err(), "Tampered ciphertext must fail unseal");
        }
    }

    /// Property 4: Wrong passphrase strictly fails unseal across random string inputs.
    #[test]
    fn prop_vault_wrong_passphrase_strictly_fails(
        secret in proptest::collection::vec(any::<u8>(), 1..64),
        passphrase in "[a-zA-Z0-9]{8,16}",
        wrong_pass in "[a-zA-Z0-9]{8,16}"
    ) {
        prop_assume!(passphrase != wrong_pass);
        let sealed = MackVaultEngine::seal(passphrase.as_bytes(), &secret, "PROP_TEST_PASS")
            .expect("Sealing should succeed");

        let unseal_res = MackVaultEngine::unseal(wrong_pass.as_bytes(), &sealed);
        prop_assert!(unseal_res.is_err(), "Wrong passphrase must fail unseal");
    }
}

/// Concurrency & Thread-Safety Stress Test:
/// Exercises concurrent sealing and unsealing across multiple worker threads to verify thread safety and absence of race conditions.
#[test]
fn test_concurrent_vault_multithreading_stress() {
    let mut handles = Vec::new();

    for thread_idx in 0..4 {
        let handle = thread::spawn(move || {
            let secret = format!("thread_secret_payload_worker_{}", thread_idx).into_bytes();
            let pass = format!("thread_pass_{}_secure_test", thread_idx);

            // Seal secret
            let sealed =
                MackVaultEngine::seal(pass.as_bytes(), &secret, &format!("LANE_{}", thread_idx))
                    .expect("Thread seal failed");

            // Unseal and verify exact roundtrip
            let unsealed =
                MackVaultEngine::unseal(pass.as_bytes(), &sealed).expect("Thread unseal failed");
            assert_eq!(unsealed, secret);

            // Verify wrong passphrase in thread fails
            assert!(MackVaultEngine::unseal(b"completely_wrong_thread_pass", &sealed).is_err());
        });
        handles.push(handle);
    }

    for h in handles {
        h.join()
            .expect("Worker thread panicked during concurrent stress test");
    }
}
