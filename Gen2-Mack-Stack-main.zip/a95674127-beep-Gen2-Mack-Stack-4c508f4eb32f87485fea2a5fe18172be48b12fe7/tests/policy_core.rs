//! Policy-core integration tests, ported from the graded 7-pillar
//! package's adversarial harness and adapted to this crate: Allen Mack's
//! own vault core, the canonicalization-fixed ledger, deterministic keys.

use ed25519_dalek::SigningKey;
use mack_security_runtime::{
    auth::{MintRequest, QuorumAuthority},
    egress::{EgressSentinel, EgressVerdict},
    ledger::ProofLedger,
    proxy::{BlindEgressProxy, OutboundRequest},
    vault::MackVaultEngine,
};

#[test]
fn ledger_field_boundary_collision_is_fixed() {
    // Regression test for the defect proven against the as-received
    // package: ("AB","C") and ("A","BC") hashed identically there.
    let mut a = ProofLedger::new();
    let mut b = ProofLedger::new();
    let ea = a.append("AB", "C", b"same-payload", None);
    let eb = b.append("A", "BC", b"same-payload", None);
    assert_ne!(ea.entry_hash, eb.entry_hash);
    assert!(a.verify_chain().is_ok());
    assert!(b.verify_chain().is_ok());
}

#[test]
fn policy_core_end_to_end_and_adversarial() {
    let mut ledger = ProofLedger::new();
    let master_pass = b"mack-stack-gen2-root-passphrase";

    // Vault: seal a stand-in API key with the owner's own vault core.
    let sealed = MackVaultEngine::seal(
        master_pass,
        b"sk-live-SUPER-SECRET-TOKEN-998877",
        ledger.tip_hash(),
    )
    .expect("vault seal");

    // Egress sentinel: metadata blackhole + default-deny.
    let mut sentinel = EgressSentinel::new();
    assert!(sentinel.allow_host("169.254.169.254").is_err());
    sentinel.allow_host("api.datavendor.ai").unwrap();
    assert_eq!(
        sentinel.evaluate_request("lane-1", "http", "169.254.169.254", &mut ledger),
        EgressVerdict::DeniedMetadataBlackhole
    );
    assert_eq!(
        sentinel.evaluate_request("lane-1", "https", "evil-exfil.attacker.io", &mut ledger),
        EgressVerdict::DeniedNotAllowlisted
    );

    // Quorum minting (multisig 2-of-3): one signature fails, two succeed.
    let dev1 = SigningKey::from_bytes(&[1u8; 32]);
    let dev2 = SigningKey::from_bytes(&[2u8; 32]);
    let dev3 = SigningKey::from_bytes(&[3u8; 32]);
    let quorum = QuorumAuthority::new(
        2,
        vec![
            dev1.verifying_key(),
            dev2.verifying_key(),
            dev3.verifying_key(),
        ],
    )
    .unwrap();
    let mint_req = MintRequest {
        run_id: "run-2026-11-15-alpha".into(),
        lane_id: "lane-1".into(),
        target_host: "api.datavendor.ai".into(),
        allowed_action: "POST".into(),
        expires_at_epoch: 2_000_000_000,
        secret_ref_id: "datavendor_prod_key".into(),
    };
    let sig1 = QuorumAuthority::sign_request(&dev1, &mint_req);
    assert!(quorum
        .mint_scoped_handle(
            mint_req.clone(),
            std::slice::from_ref(&sig1),
            1_900_000_000,
            &mut ledger
        )
        .is_err());
    let sig2 = QuorumAuthority::sign_request(&dev2, &mint_req);
    let handle = quorum
        .mint_scoped_handle(mint_req, &[sig1, sig2], 1_900_000_000, &mut ledger)
        .expect("2-of-3 mint");
    assert!(handle.opaque_handle.starts_with("MACK_HANDLE_"));
    assert!(!handle.opaque_handle.contains("SUPER-SECRET"));

    // Blind proxy: wrong host blocked, valid request injects, replay blocked.
    let mut proxy = BlindEgressProxy::new();
    proxy.register_sealed_secret("datavendor_prod_key", sealed);
    proxy.register_handle(handle.clone());

    let bad = OutboundRequest {
        run_id: "run-2026-11-15-alpha".into(),
        lane_id: "lane-1".into(),
        scheme: "https".into(),
        host: "evil-exfil.attacker.io".into(),
        action: "POST".into(),
        handle_token: handle.opaque_handle.clone(),
    };
    assert!(proxy
        .execute_egress(&bad, &sentinel, master_pass, 1_900_000_010, &mut ledger)
        .is_err());

    let valid = OutboundRequest {
        host: "api.datavendor.ai".into(),
        ..bad.clone()
    };
    let dispatched = proxy
        .execute_egress(&valid, &sentinel, master_pass, 1_900_000_020, &mut ledger)
        .expect("valid scoped egress");
    assert_eq!(
        dispatched.injected_auth_header,
        "Bearer sk-live-SUPER-SECRET-TOKEN-998877"
    );
    assert!(proxy
        .execute_egress(&valid, &sentinel, master_pass, 1_900_000_025, &mut ledger)
        .is_err());

    // Delegation binding + full chain verification.
    let parent = ledger.append("LANE_EXEC", "lane-1", b"phase-1", None);
    ledger.append(
        "LANE_EXEC",
        "lane-2",
        b"phase-2",
        Some(parent.entry_hash.clone()),
    );
    assert_eq!(
        ledger.entries().last().unwrap().parent_delegation_hash,
        Some(parent.entry_hash)
    );
    assert!(ledger.verify_chain().is_ok());
}
