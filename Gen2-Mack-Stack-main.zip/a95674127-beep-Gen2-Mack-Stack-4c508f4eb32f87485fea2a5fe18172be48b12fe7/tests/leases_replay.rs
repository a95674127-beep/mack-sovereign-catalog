//! Capability leases + seen-nonce replay guard tests (v0.6.0).

use ed25519_dalek::SigningKey;
use mack_security_runtime::proof_fabric::execution_envelope::IntentBoundEnvelope;
use mack_security_runtime::proof_fabric::leases::{
    verify_envelope_once, CapabilityLease, Clock, LeaseError, ManualClock, SeenNonceStore,
    SystemClock, MAX_LEASE_TTL_SECS,
};
use rand_core::OsRng;

fn envelope(key: &SigningKey, principal: &str, nonce: u64, payload: &[u8]) -> IntentBoundEnvelope {
    IntentBoundEnvelope::sign_new(principal, "chain-tip-x", payload, nonce, key)
        .expect("sign envelope")
}

#[test]
fn lease_issues_verifies_and_authorizes_its_envelope() {
    let authority = SigningKey::generate(&mut OsRng);
    let clock = ManualClock::new(1_000);
    let env = envelope(&authority, "lane-1", 42, b"payload");
    let lease = CapabilityLease::issue(
        &authority,
        "lane-1",
        "egress:api.example.com:POST",
        42,
        &clock,
        600,
    )
    .expect("issue lease");
    lease
        .verify(&authority.verifying_key(), &clock)
        .expect("verify");
    lease
        .authorize(&authority.verifying_key(), &env, &clock)
        .expect("authorize matching envelope");
}

#[test]
fn lease_expiry_is_judged_by_the_named_clock() {
    let authority = SigningKey::generate(&mut OsRng);
    let mut clock = ManualClock::new(1_000);
    let lease = CapabilityLease::issue(&authority, "lane-1", "cap", 7, &clock, 60).unwrap();
    clock.advance(59);
    assert!(lease.verify(&authority.verifying_key(), &clock).is_ok());
    clock.advance(1); // now == expires_at
    match lease.verify(&authority.verifying_key(), &clock) {
        Err(LeaseError::Expired { .. }) => {}
        other => panic!("expected Expired, got {other:?}"),
    }
}

#[test]
fn lease_rejects_forgery_scope_mismatch_and_long_ttl() {
    let authority = SigningKey::generate(&mut OsRng);
    let other = SigningKey::generate(&mut OsRng);
    let clock = ManualClock::new(5_000);
    let lease = CapabilityLease::issue(&authority, "lane-1", "cap", 9, &clock, 60).unwrap();
    // Wrong authority key.
    assert!(lease.verify(&other.verifying_key(), &clock).is_err());
    // Wrong principal.
    let env_other = envelope(&authority, "lane-2", 9, b"p");
    match lease.authorize(&authority.verifying_key(), &env_other, &clock) {
        Err(LeaseError::ScopeMismatch(_)) => {}
        other => panic!("expected ScopeMismatch (principal), got {other:?}"),
    }
    // Wrong envelope nonce.
    let env_nonce = envelope(&authority, "lane-1", 10, b"p");
    match lease.authorize(&authority.verifying_key(), &env_nonce, &clock) {
        Err(LeaseError::ScopeMismatch(_)) => {}
        other => panic!("expected ScopeMismatch (nonce), got {other:?}"),
    }
    // TTL above the cap.
    assert!(matches!(
        CapabilityLease::issue(
            &authority,
            "lane-1",
            "cap",
            1,
            &clock,
            MAX_LEASE_TTL_SECS + 1
        ),
        Err(LeaseError::TtlTooLong { .. })
    ));
}

#[test]
fn replayed_envelope_is_rejected_and_forgery_does_not_poison_the_store() {
    let authority = SigningKey::generate(&mut OsRng);
    let vk = authority.verifying_key();
    let mut store = SeenNonceStore::new();
    let payload = b"sensitive payload";
    let env = envelope(&authority, "lane-1", 77, payload);

    verify_envelope_once(&mut store, &env, payload, &vk).expect("first presentation");
    match verify_envelope_once(&mut store, &env, payload, &vk) {
        Err(LeaseError::ReplayDetected) => {}
        other => panic!("expected ReplayDetected, got {other:?}"),
    }

    // A forged envelope (bad payload digest) with a FRESH nonce fails
    // verification and must not spend that nonce: the genuine envelope
    // carrying it is still accepted afterwards, exactly once.
    let genuine = envelope(&authority, "lane-1", 78, payload);
    let mut forged = genuine.clone();
    forged.payload_sha256 = "0".repeat(64);
    assert!(verify_envelope_once(&mut store, &forged, payload, &vk).is_err());
    verify_envelope_once(&mut store, &genuine, payload, &vk)
        .expect("genuine envelope still accepted after forgery attempt");
    assert_eq!(store.spent_count(), 2);

    // A different nonce from the same principal is a different spend.
    let env2 = envelope(&authority, "lane-1", 79, payload);
    verify_envelope_once(&mut store, &env2, payload, &vk).expect("fresh nonce ok");
    // The system clock path also runs.
    assert!(SystemClock.now_epoch() > 0);
}
