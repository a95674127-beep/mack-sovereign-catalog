//! Live-enforcement test for the pinned worker, in its own test binary:
//! the worker applies a KillProcess seccomp filter to its thread, so it
//! is isolated from the main suites on purpose.
//!
//! Pass conditions (either proves the enforcement wiring):
//! - the workload runs to completion under Landlock + seccomp, or
//! - enforcement fails (e.g. the host kernel lacks Landlock) and the
//!   workload is aborted — the fail-closed path.

use mack_security_runtime::sandbox::worker_runner::PinnedWorkerRunner;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

#[test]
fn pinned_worker_enforces_or_fails_closed() {
    let ran = Arc::new(AtomicBool::new(false));
    let flag = Arc::clone(&ran);
    let spool = std::env::temp_dir();
    let handle = PinnedWorkerRunner::new(spool).spawn_pinned_worker(move || {
        flag.store(true, Ordering::SeqCst);
        Ok(())
    });
    match handle.join() {
        Ok(Ok(())) => {
            assert!(ran.load(Ordering::SeqCst), "workload must have run");
        }
        Ok(Err(e)) => {
            assert!(
                e.contains("Landlock") || e.contains("Seccomp"),
                "abort must come from enforcement, got: {e}"
            );
            assert!(
                !ran.load(Ordering::SeqCst),
                "workload must NOT run when enforcement fails"
            );
        }
        Err(_) => panic!("worker thread died unexpectedly (possible seccomp process-kill)"),
    }
}
