//! FROST threshold integration tests (v0.5.0): real RFC 9591 DKG and
//! quorum signing, with the aggregate checked under plain Ed25519.

use ed25519_dalek::Verifier;
use mack_security_runtime::auth::MintRequest;
use mack_security_runtime::threshold::{run_dkg, sign_message};

#[test]
fn dkg_two_of_three_quorums_sign_and_verify_as_plain_ed25519() {
    let (participants, group) = run_dkg(&[1, 2, 3], 2).expect("DKG");
    let vk = group.verifying_key().expect("group key");
    let msg = b"threshold integration: mint approval payload";

    // Quorum {1,3}.
    let sig_a =
        sign_message(&group, &[&participants[0], &participants[2]], msg).expect("sign {1,3}");
    assert!(vk.verify_strict(msg, &sig_a).is_ok());
    group.verify(msg, &sig_a).expect("group verify {1,3}");

    // Quorum {2,3} — any 2 of 3.
    let sig_b =
        sign_message(&group, &[&participants[1], &participants[2]], msg).expect("sign {2,3}");
    assert!(vk.verify_strict(msg, &sig_b).is_ok());

    // Tampered message fails.
    assert!(vk
        .verify_strict(b"threshold integration: mint approval payload!", &sig_a)
        .is_err());
}

#[test]
fn dkg_rejects_duplicate_participant_ids() {
    // Regression for the 2026-11-19 review finding: run_dkg
    // accepted duplicate identifiers, letting one identity
    // occupy two seats of the ceremony.
    let dup = run_dkg(&[1, 2, 2], 2);
    assert!(dup.is_err(), "duplicate participant IDs must be rejected");
}

#[test]
fn lone_signer_cannot_produce_a_signature() {
    let (participants, group) = run_dkg(&[1, 2, 3], 2).expect("DKG");
    let lone = sign_message(&group, &[&participants[0]], b"anything");
    assert!(lone.is_err(), "1-of-3 must fail below threshold");
}

#[test]
fn participant_share_survives_serialization_round_trip() {
    let (participants, group) = run_dkg(&[1, 2, 3], 2).expect("DKG");
    let bytes = participants[2].to_bytes().expect("serialize share");
    let restored = mack_security_runtime::threshold::ThresholdParticipant::from_bytes(3, &bytes)
        .expect("restore share");
    let msg = b"restored share still signs";
    let sig =
        sign_message(&group, &[&participants[0], &restored], msg).expect("sign with restored");
    group.verify(msg, &sig).expect("verify");
}

#[test]
fn threshold_signature_authorizes_a_mint_request_payload() {
    // The integration shape that matters: a MintRequest's canonical
    // bytes are the payload; a FROST quorum's signature over them
    // verifies under the group key with the crate's ordinary verifier.
    let (participants, group) = run_dkg(&[1, 2, 3], 2).expect("DKG");
    let req = MintRequest {
        run_id: "run-threshold-1".into(),
        lane_id: "lane-1".into(),
        target_host: "api.example.com".into(),
        allowed_action: "POST".into(),
        expires_at_epoch: 2_000_000_000,
        secret_ref_id: "prod_key".into(),
    };
    let payload = req.canonical_bytes();
    let sig = sign_message(&group, &[&participants[1], &participants[2]], &payload)
        .expect("quorum signs the mint payload");
    let vk = group.verifying_key().expect("group key");
    assert!(vk.verify(&payload, &sig).is_ok());
}
