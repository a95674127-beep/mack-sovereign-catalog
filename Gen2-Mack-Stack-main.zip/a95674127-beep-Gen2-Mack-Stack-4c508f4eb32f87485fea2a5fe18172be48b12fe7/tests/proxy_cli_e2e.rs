//! End-to-end test for the `mack-proxy` binary (v0.4.0): a real local
//! upstream, the compiled binary wrapping a child process, Landlock
//! confinement fail-closed, env scrubbing, blind credential injection
//! over live TCP, and a sentinel denial for a non-allowlisted host.
//!
//! Adapted from the externally proposed harness (lab-graded
//! 2026-11-15) to this crate's binary and its explicit
//! `--insecure-loopback` operator flag.

use std::{
    io::{Read, Write},
    net::TcpListener,
    process::Command,
    thread,
};

#[test]
fn test_mack_proxy_binary_blind_proxy_tcp_e2e() {
    let upstream = TcpListener::bind("127.0.0.1:0").unwrap();
    let upstream_port = upstream.local_addr().unwrap().port();
    let server_thread = thread::spawn(move || {
        let (mut conn, _) = upstream.accept().unwrap();
        let mut buf = [0u8; 4096];
        let n = conn.read(&mut buf).unwrap();
        let received = String::from_utf8_lossy(&buf[..n]).to_string();
        let resp = "HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK";
        conn.write_all(resp.as_bytes()).unwrap();
        received
    });
    let bin_path = env!("CARGO_BIN_EXE_mack-proxy");
    // Child: (1) the real secret must NOT be in its environment;
    // (2) a request to the allowlisted loopback host succeeds and the
    //     upstream receives the injected credential;
    // (3) a request to a non-allowlisted host is denied (403).
    let child_script = format!(
        r#"
if [ -n "$MACK_REAL_SECRET" ]; then exit 99; fi
python3 -c '
import os, socket
proxy = os.environ["HTTP_PROXY"].replace("http://", "")
phost, pport = proxy.split(":")
def via_proxy(host_header, target):
    s = socket.create_connection((phost, int(pport)), timeout=5)
    req = (
        "GET " + target + " HTTP/1.1\r\n"
        "Host: " + host_header + "\r\n"
        "Authorization: Bearer " + os.environ["MACK_TOKEN_HANDLE"] + "\r\n"
        "Connection: close\r\n\r\n"
    )
    s.sendall(req.encode())
    data = s.recv(4096).decode()
    s.close()
    return data
ok = via_proxy("127.0.0.1:{p}", "http://127.0.0.1:{p}/v1/test")
assert "200 OK" in ok, ok
denied = via_proxy("localhost:{p}", "http://localhost:{p}/v1/test")
assert "403" in denied, denied
'
"#,
        p = upstream_port
    );
    let output = Command::new(bin_path)
        .env("MACK_REAL_SECRET", "sk-live-TCP-BOUNDARY-REAL-SECRET-777")
        .args([
            "run",
            "--allow",
            "127.0.0.1",
            "--method",
            "GET",
            "--insecure-loopback",
            "--",
            "sh",
            "-c",
            &child_script,
        ])
        .output()
        .expect("Failed to execute mack-proxy binary");
    assert!(
        output.status.success(),
        "mack-proxy CLI run exited with failure: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    let upstream_received = server_thread.join().unwrap();
    assert!(
        upstream_received.contains("Authorization: Bearer sk-live-TCP-BOUNDARY-REAL-SECRET-777"),
        "Upstream server must receive the blind-injected real credential, got:\n{}",
        upstream_received
    );
    assert!(
        upstream_received.contains("X-Mack-Ledger-Receipt:"),
        "Upstream request must carry the ledger receipt header"
    );
}
