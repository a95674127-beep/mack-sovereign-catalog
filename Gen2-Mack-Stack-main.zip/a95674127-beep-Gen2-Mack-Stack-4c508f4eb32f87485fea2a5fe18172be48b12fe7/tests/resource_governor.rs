//! Live-enforcement tests for the resource governor (v0.11.0) as
//! applied by `mack-proxy`: the rlimit layer is proven by a child
//! that dies against the memory cap and a child that dies against
//! the CPU cap, and the governor's own report line is checked
//! against an independent probe of this environment — if no
//! delegated cgroup v2 subtree exists here, the report must say
//! the cgroup layer was not applied and process-count limiting is
//! unenforced; if one exists, it must claim the cgroup and its
//! limits. The report is never taken on faith.

use std::process::Command;
use std::time::Instant;

fn run_proxy(extra_args: &[&str], child: &[&str]) -> (String, String, Option<i32>, u128) {
    let bin = env!("CARGO_BIN_EXE_mack-proxy");
    let started = Instant::now();
    let mut cmd = Command::new(bin);
    cmd.env("MACK_REAL_SECRET", "governor-test-secret")
        .arg("run")
        .arg("--allow")
        .arg("127.0.0.1")
        .args(extra_args)
        .arg("--")
        .args(child);
    let output = cmd.output().expect("failed to run mack-proxy");
    (
        String::from_utf8_lossy(&output.stdout).into_owned(),
        String::from_utf8_lossy(&output.stderr).into_owned(),
        output.status.code(),
        started.elapsed().as_millis(),
    )
}

/// Independent probe of the same delegation question the
/// governor's cgroup layer answers for itself: can THIS process
/// create a cgroup AND write its control files? (Some sandboxes
/// allow the mkdir but refuse the writes — creation alone does
/// not prove delegation, as this repository's own test history
/// shows.)
fn cgroup_delegation_available() -> bool {
    let probe = std::path::Path::new("/sys/fs/cgroup")
        .join(format!("mack-gov-probe-{}", std::process::id()));
    if std::fs::create_dir(&probe).is_err() {
        return false;
    }
    let writable = std::fs::write(probe.join("memory.max"), "536870912").is_ok();
    let _ = std::fs::remove_dir(&probe);
    writable
}

#[test]
fn governor_memory_cap_stops_overallocating_child() {
    let (stdout, stderr, code, _ms) = run_proxy(
        &["--limit-as-mib", "128"],
        &[
            "python3",
            "-c",
            "x = bytearray(512 * 1024 * 1024)\nprint('ALLOC_SURVIVED')",
        ],
    );
    assert!(
        !stdout.contains("ALLOC_SURVIVED"),
        "a 512 MiB allocation must not survive a 128 MiB address-space cap.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert_ne!(
        code,
        Some(0),
        "the over-allocating child must fail (MemoryError), not exit cleanly"
    );
    assert!(
        stderr.contains("Resource governor: rlimits applied")
            && stderr.contains("RLIMIT_AS=128 MiB"),
        "the run must report the applied rlimits.\nstderr: {stderr}"
    );
}

#[test]
fn governor_cpu_cap_kills_spinner() {
    let (stdout, stderr, code, elapsed_ms) = run_proxy(
        &["--limit-cpu-secs", "1"],
        &["python3", "-c", "while True: pass"],
    );
    assert_ne!(
        code,
        Some(0),
        "the spinning child must be killed by the CPU cap, not exit cleanly.\nstdout: {stdout}"
    );
    assert!(
        elapsed_ms < 30_000,
        "the CPU cap must stop the spinner promptly (run took {elapsed_ms} ms)"
    );
    assert!(
        stderr.contains("RLIMIT_CPU=1 s"),
        "the run must report the applied CPU limit.\nstderr: {stderr}"
    );
}

#[test]
fn governor_report_matches_this_environment() {
    let (_stdout, stderr, code, _ms) = run_proxy(
        &[
            "--limit-as-mib",
            "512",
            "--limit-cpu-secs",
            "60",
            "--limit-fsize-mib",
            "128",
        ],
        &["sh", "-c", "exit 0"],
    );
    assert_eq!(
        code,
        Some(0),
        "trivial child must succeed.\nstderr: {stderr}"
    );
    let line = stderr
        .lines()
        .find(|l| l.contains("Resource governor:"))
        .expect("the run must print a resource governor report line");
    assert!(
        line.contains("rlimits applied (RLIMIT_AS=512 MiB, RLIMIT_CPU=60 s, RLIMIT_FSIZE=128 MiB, RLIMIT_CORE=0)"),
        "report must name the applied rlimits.\nline: {line}"
    );
    if cgroup_delegation_available() {
        assert!(
            line.contains("cgroup v2 applied") && line.contains("pids.max=64"),
            "with delegation available the report must claim the applied cgroup.\nline: {line}"
        );
    } else {
        assert!(
            line.contains("cgroup v2 not applied")
                && line.contains("process-count limit not enforced"),
            "without delegation the report must disclose the missing layer.\nline: {line}"
        );
    }
}
