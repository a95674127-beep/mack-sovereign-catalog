//! External checkpoint anchoring tests (v0.12.0,
//! `ledger::store` + `mack-ledger-verify` modes): an extracted
//! signed checkpoint sidecar anchors a ledger file against
//! TAIL truncation — the one manipulation plain chain
//! verification cannot see, because a shortened file is still
//! a valid chain prefix.

use ed25519_dalek::SigningKey;
use mack_security_runtime::ledger::store::{self, LedgerStoreError};
use mack_security_runtime::ledger::ProofLedger;
use rand_core::OsRng;
use std::path::PathBuf;
use std::process::Command;

fn fresh_dir(tag: &str) -> PathBuf {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let dir = std::env::temp_dir().join(format!(
        "mack-anchor-test-{tag}-{}-{nanos}",
        std::process::id()
    ));
    std::fs::create_dir_all(&dir).unwrap();
    dir
}

/// A persistent ledger with two entries and a checkpoint
/// (3 records total), under `key`.
fn build_ledger(path: &std::path::Path, key: &SigningKey) {
    let (mut ledger, _) = ProofLedger::open_persistent(path, key.clone()).unwrap();
    ledger.append("RUN_START", "lane-1", b"one", None);
    ledger.append("EGRESS_DECISION", "lane-1", b"two", None);
    ledger.append_checkpoint("lane-1");
}

fn read_sidecar(path: &std::path::Path) -> store::CheckpointSidecar {
    serde_json::from_str(&std::fs::read_to_string(path).unwrap()).unwrap()
}

#[test]
fn extract_and_verify_roundtrip_library_and_binary() {
    let dir = fresh_dir("roundtrip");
    let path = dir.join("ledger.jsonl");
    let key = SigningKey::generate(&mut OsRng);
    build_ledger(&path, &key);

    // Library path: extract, verify against the anchor.
    let sidecar = store::extract_checkpoint(&path).unwrap();
    assert_eq!(sidecar.checkpoint_sequence, 3);
    assert_eq!(sidecar.committed_sequence, 2);
    assert_eq!(sidecar.record_count, 3);
    assert_eq!(
        sidecar.authority_verifying_key,
        hex::encode(key.verifying_key().to_bytes())
    );
    let summary = store::verify_against_checkpoint(&path, &sidecar).unwrap();
    assert_eq!(summary.entry_count, 3);
    assert_eq!(summary.tip_hash, sidecar.head_hash);

    // Binary path: the same round trip through the CLI modes.
    let sidecar_path = dir.join("checkpoint.json");
    let verify_bin = env!("CARGO_BIN_EXE_mack-ledger-verify");
    let out = Command::new(verify_bin)
        .arg(&path)
        .arg("--extract-checkpoint")
        .arg(&sidecar_path)
        .output()
        .expect("failed to run mack-ledger-verify --extract-checkpoint");
    assert!(
        out.status.success(),
        "extraction must succeed.\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&out.stdout),
        String::from_utf8_lossy(&out.stderr)
    );
    let from_cli = read_sidecar(&sidecar_path);
    assert_eq!(from_cli, sidecar, "CLI and library extraction must agree");
    let out = Command::new(verify_bin)
        .arg(&path)
        .arg("--against-checkpoint")
        .arg(&sidecar_path)
        .output()
        .expect("failed to run mack-ledger-verify --against-checkpoint");
    assert!(
        out.status.success()
            && String::from_utf8_lossy(&out.stdout).contains("LEDGER VERIFICATION: OK"),
        "anchored verification must pass.\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&out.stdout),
        String::from_utf8_lossy(&out.stderr)
    );
}

#[test]
fn truncated_tail_is_detected_with_both_counts() {
    let dir = fresh_dir("truncated");
    let path = dir.join("ledger.jsonl");
    let key = SigningKey::generate(&mut OsRng);
    build_ledger(&path, &key);
    let sidecar = store::extract_checkpoint(&path).unwrap();

    // Truncate the tail: drop the checkpoint line itself. What
    // remains is a perfectly valid 2-entry chain — plain
    // verification accepts it, which is the entire reason the
    // anchor exists.
    let text = std::fs::read_to_string(&path).unwrap();
    let lines: Vec<&str> = text.lines().collect();
    assert_eq!(lines.len(), 4); // header + 3 entries
    std::fs::write(&path, lines[..3].join("\n") + "\n").unwrap();
    store::verify_file(&path)
        .expect("the truncated prefix still verifies as a chain — the anchor must catch it");

    let err = store::verify_against_checkpoint(&path, &sidecar).unwrap_err();
    match &err {
        LedgerStoreError::TailTruncation(msg) => {
            assert!(
                msg.contains("holds 2 records") && msg.contains("commits to 3"),
                "the error must name both counts, got: {msg}"
            );
        }
        other => panic!("expected TailTruncation, got: {other:?}"),
    }
}

#[test]
fn extended_ledger_is_a_checkpoint_mismatch() {
    let dir = fresh_dir("extended");
    let path = dir.join("ledger.jsonl");
    let key = SigningKey::generate(&mut OsRng);
    build_ledger(&path, &key);
    let sidecar = store::extract_checkpoint(&path).unwrap();

    // A later run under the same authority appends past the
    // checkpoint: the chain is valid and longer than the anchor
    // commits to.
    let (mut ledger, _) = ProofLedger::open_persistent(&path, key).unwrap();
    ledger.append("RUN_RESUMED", "lane-1", b"three", None);
    drop(ledger);
    store::verify_file(&path).expect("the extended chain still verifies on its own");

    let err = store::verify_against_checkpoint(&path, &sidecar).unwrap_err();
    assert!(
        matches!(err, LedgerStoreError::CheckpointMismatch(_)),
        "an extended ledger must be a checkpoint mismatch, got: {err}"
    );
}

#[test]
fn flipped_sidecar_signature_byte_fails_signature_verification() {
    let dir = fresh_dir("sigflip");
    let path = dir.join("ledger.jsonl");
    let key = SigningKey::generate(&mut OsRng);
    build_ledger(&path, &key);
    let mut sidecar = store::extract_checkpoint(&path).unwrap();

    // Flip the first hex digit of the copied signature.
    let mut sig = sidecar.authority_signature.clone();
    let first = sig.remove(0);
    sig.insert(0, if first == 'a' { 'b' } else { 'a' });
    sidecar.authority_signature = sig;

    let err = store::verify_against_checkpoint(&path, &sidecar).unwrap_err();
    assert!(
        matches!(err, LedgerStoreError::CheckpointSignature(_)),
        "a flipped signature byte must fail signature verification, got: {err}"
    );
}

#[test]
fn sidecar_from_a_different_ledger_is_a_mismatch() {
    let dir = fresh_dir("foreign");
    let path_a = dir.join("ledger-a.jsonl");
    let path_b = dir.join("ledger-b.jsonl");
    let key_a = SigningKey::generate(&mut OsRng);
    let key_b = SigningKey::generate(&mut OsRng);
    build_ledger(&path_a, &key_a);
    build_ledger(&path_b, &key_b);

    // Ledger A's anchor presented against ledger B (different
    // authority, different chain).
    let sidecar_a = store::extract_checkpoint(&path_a).unwrap();
    let err = store::verify_against_checkpoint(&path_b, &sidecar_a).unwrap_err();
    assert!(
        matches!(err, LedgerStoreError::CheckpointMismatch(_)),
        "a foreign ledger's sidecar must mismatch, got: {err}"
    );
}
