//! Unified-core tests for the modules adopted at the 2026-11-15
//! unification (v0.3.0): signed ledger mode, execution envelopes,
//! compound attestation, envelope sealing, CDR filter, build
//! provenance, and seccomp filter construction.

use ed25519_dalek::{Signature, Signer, SigningKey, Verifier};
use mack_security_runtime::cdr::content_disarm::ContentDisarmEngine;
use mack_security_runtime::forensic::build_provenance::{BuildProvenance, ProvenanceInputs};
use mack_security_runtime::ledger::ProofLedger;
use mack_security_runtime::proof_fabric::compound_attestation::CompoundAttestationChain;
use mack_security_runtime::proof_fabric::execution_envelope::IntentBoundEnvelope;
use mack_security_runtime::sandbox::seccomp_filter::SeccompEnforcer;
use mack_security_runtime::vault::envelope_crypto::EnvelopeVaultCrypto;
use rand_core::OsRng;
use std::collections::HashMap;
use zeroize::Zeroizing;

#[test]
fn signed_ledger_signs_entries_and_verifies() {
    let key = SigningKey::generate(&mut OsRng);
    let vk = key.verifying_key();
    let mut ledger = ProofLedger::with_authority(key);
    let e1 = ledger.append("GENESIS", "lane-0", b"one", None);
    let e2 = ledger.append("EGRESS_VERDICT", "lane-0", b"two", None);
    assert_eq!(e1.authority_signature.len(), 64);
    assert_eq!(e2.authority_signature.len(), 64);
    ledger.verify_chain().expect("signed chain must verify");

    // The stored signature verifies under the authority key...
    let sig = Signature::from_bytes(e1.authority_signature.as_slice().try_into().unwrap());
    assert!(vk.verify(e1.entry_hash.as_bytes(), &sig).is_ok());
    // ...and NOT under a different key.
    let other = SigningKey::generate(&mut OsRng).verifying_key();
    assert!(other.verify(e1.entry_hash.as_bytes(), &sig).is_err());

    // Unsigned mode still works and carries no signatures.
    let mut plain = ProofLedger::new();
    let p = plain.append("GENESIS", "lane-0", b"x", None);
    assert!(p.authority_signature.is_empty());
    plain.verify_chain().expect("unsigned chain must verify");
}

#[test]
fn envelope_signs_verifies_and_rejects_tampering() {
    let key = SigningKey::generate(&mut OsRng);
    let vk = key.verifying_key();
    let env = IntentBoundEnvelope::sign_new("agent-1", "root-hash", b"payload-bytes", 7, &key)
        .expect("signing must succeed");
    env.verify(b"payload-bytes", &vk)
        .expect("valid envelope must verify");
    assert!(env.verify(b"tampered-bytes", &vk).is_err());
    let other = SigningKey::generate(&mut OsRng).verifying_key();
    assert!(env.verify(b"payload-bytes", &other).is_err());
}

#[test]
fn compound_attestation_chain_verifies_and_breaks_on_edit() {
    let key_a = SigningKey::generate(&mut OsRng);
    let key_b = SigningKey::generate(&mut OsRng);
    let mut keys = HashMap::new();
    keys.insert("agent-a".to_string(), key_a.verifying_key());
    keys.insert("agent-b".to_string(), key_b.verifying_key());

    let mut chain = CompoundAttestationChain::new("root-envelope-hash".to_string());
    chain
        .append_delegation("agent-a", "agent-b", "intent-1", &key_a)
        .expect("first link");
    chain
        .append_delegation("agent-b", "agent-c", "intent-2", &key_b)
        .expect("second link");
    chain
        .verify_continuity(&keys)
        .expect("intact chain must verify");

    let mut broken = chain.clone();
    broken.links[0].recipient_agent_id = "agent-x".to_string();
    assert!(broken.verify_continuity(&keys).is_err());
}

#[test]
fn envelope_crypto_roundtrip_and_aad_binding() {
    let sealed = EnvelopeVaultCrypto::seal(
        b"passphrase",
        b"aad-context",
        Zeroizing::new(b"secret payload".to_vec()),
    )
    .expect("seal");
    let opened = EnvelopeVaultCrypto::open(b"passphrase", b"aad-context", &sealed).expect("open");
    assert_eq!(opened.as_slice(), b"secret payload");
    assert!(EnvelopeVaultCrypto::open(b"passphrase", b"other-aad", &sealed).is_err());
    assert!(EnvelopeVaultCrypto::open(b"wrong-pass", b"aad-context", &sealed).is_err());
}

#[test]
fn cdr_rejects_executables_and_scripts_passes_text() {
    assert!(ContentDisarmEngine::sanitize_and_reconstruct(b"\x7fELF\x02\x01").is_err());
    assert!(ContentDisarmEngine::sanitize_and_reconstruct(b"MZ\x90\x00").is_err());
    assert!(
        ContentDisarmEngine::sanitize_and_reconstruct(b"hi <script>alert(1)</script>").is_err()
    );
    let clean = ContentDisarmEngine::sanitize_and_reconstruct(b"plain record text")
        .expect("clean text must pass");
    assert_eq!(clean.as_slice(), b"plain record text");
}

#[test]
fn build_provenance_signs_verifies_and_detects_tampering() {
    let key = SigningKey::generate(&mut OsRng);
    let vk = key.verifying_key();
    let files: Vec<(String, &[u8])> = vec![
        ("src/lib.rs".to_string(), b"lib bytes" as &[u8]),
        ("src/main.rs".to_string(), b"main bytes" as &[u8]),
    ];
    let lock: &[u8] = b"lockfile bytes";
    let bin: &[u8] = b"binary bytes";
    let prov = BuildProvenance::create_signed(
        ProvenanceInputs {
            build_id: "build-1".to_string(),
            target_triple: "x86_64-unknown-linux-gnu".to_string(),
            rustc_version: "rustc 1.99.1".to_string(),
            source_date_epoch: 1_773_532_800,
            files: &files,
            cargo_lock: lock,
            compiler_flags: vec!["--remap-path-prefix=/src=/build".to_string()],
            binary_bytes: bin,
            release_key_id: "release-key-1".to_string(),
        },
        &key,
    )
    .expect("create provenance");
    prov.verify(&vk, &files, lock, bin).expect("verify ok");
    assert!(prov.verify(&vk, &files, lock, b"tampered binary").is_err());
}

#[test]
fn seccomp_filter_builds() {
    let bpf = SeccompEnforcer::build_worker_bpf().expect("BPF program must build");
    assert!(!bpf.is_empty());
}

#[test]
fn signer_trait_in_scope() {
    // Guards the Signer import used above (dalek sign API smoke check).
    let key = SigningKey::generate(&mut OsRng);
    let sig = key.sign(b"smoke");
    assert!(key.verifying_key().verify(b"smoke", &sig).is_ok());
}
