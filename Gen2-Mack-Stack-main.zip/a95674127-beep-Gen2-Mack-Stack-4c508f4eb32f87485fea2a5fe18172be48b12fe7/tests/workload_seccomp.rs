//! Live-enforcement tests for the seccomp workload profile
//! (v0.11.0, `SeccompEnforcer::build_workload_bpf`) as installed
//! by `mack-proxy` on its child.
//!
//! The profile is proven behaviorally, from inside the confined
//! child: UDP and raw socket creation fail with EPERM, a denied
//! syscall (`ptrace`) fails with EPERM, a namespace `unshare`
//! fails with EPERM while a flagless `unshare(0)` succeeds (the
//! arg filter is precise, not a blanket syscall ban), a TCP
//! connection to the proxy succeeds, and `/proc/self/status`
//! shows exactly one more seccomp filter than the test process
//! itself carries — the installation is asserted, not assumed.
//! (EPERM alone could in principle come from a host filter; the
//! filter-count assertion plus the fail-closed `pre_exec` — the
//! child cannot run at all if installation fails — pins the
//! result to this profile.)

use std::process::Command;

fn run_python_child(script: &str) -> (String, String, bool) {
    let bin = env!("CARGO_BIN_EXE_mack-proxy");
    let output = Command::new(bin)
        .env("MACK_REAL_SECRET", "seccomp-test-secret")
        .args([
            "run",
            "--allow",
            "127.0.0.1",
            "--insecure-loopback",
            "--",
            "python3",
            "-c",
            script,
        ])
        .output()
        .expect("failed to run mack-proxy");
    (
        String::from_utf8_lossy(&output.stdout).into_owned(),
        String::from_utf8_lossy(&output.stderr).into_owned(),
        output.status.success(),
    )
}

fn own_seccomp_filters() -> u32 {
    let status = std::fs::read_to_string("/proc/self/status").unwrap();
    status
        .lines()
        .find_map(|l| l.strip_prefix("Seccomp_filters:"))
        .and_then(|v| v.trim().parse().ok())
        .expect("test process must report Seccomp_filters")
}

#[test]
fn workload_udp_and_raw_sockets_denied_tcp_allowed() {
    let script = r#"
import os, socket
out = []
# TCP stream socket to the proxy itself: the one permitted path.
proxy = os.environ["HTTP_PROXY"].replace("http://", "")
phost, pport = proxy.split(":")
s = socket.create_connection((phost, int(pport)), timeout=5)
s.close()
out.append("TCP_OK")
for family, typ, label in [
    (socket.AF_INET, socket.SOCK_DGRAM, "UDP4"),
    (socket.AF_INET6, socket.SOCK_DGRAM, "UDP6"),
    (socket.AF_INET, socket.SOCK_RAW, "RAW4"),
]:
    try:
        bad = socket.socket(family, typ)
        bad.close()
        out.append(label + "_ALLOWED")
    except PermissionError:
        out.append(label + "_EPERM")
    except OSError as e:
        out.append(label + "_ERRNO_" + str(e.errno))
print(" ".join(out))
"#;
    let (stdout, stderr, success) = run_python_child(script);
    assert!(
        success,
        "child run failed.\nstdout: {stdout}\nstderr: {stderr}"
    );
    for marker in ["TCP_OK", "UDP4_EPERM", "UDP6_EPERM", "RAW4_EPERM"] {
        assert!(
            stdout.contains(marker),
            "expected {marker} in child output.\nstdout: {stdout}\nstderr: {stderr}"
        );
    }
}

#[test]
fn workload_denied_syscalls_return_eperm_not_death() {
    // Syscall numbers come from the same libc constants the
    // profile is built from, so the test tracks the profile.
    let script = format!(
        r#"
import ctypes
libc = ctypes.CDLL("libc.so.6", use_errno=True)
def call(nr, a1):
    ctypes.set_errno(0)
    r = libc.syscall(nr, a1)
    return r, ctypes.get_errno()
r, e = call({ptrace}, 0)
print("PTRACE_EPERM" if (r == -1 and e == 1) else "PTRACE_OTHER_%d_%d" % (r, e))
r, e = call({unshare}, {clone_newnet})
print("UNSHARE_NET_EPERM" if (r == -1 and e == 1) else "UNSHARE_NET_OTHER_%d_%d" % (r, e))
r, e = call({unshare}, 0)
print("UNSHARE_PLAIN_OK" if r == 0 else "UNSHARE_PLAIN_OTHER_%d_%d" % (r, e))
"#,
        ptrace = libc::SYS_ptrace,
        unshare = libc::SYS_unshare,
        clone_newnet = libc::CLONE_NEWNET,
    );
    let (stdout, stderr, success) = run_python_child(&script);
    assert!(
        success,
        "child run failed.\nstdout: {stdout}\nstderr: {stderr}"
    );
    for marker in ["PTRACE_EPERM", "UNSHARE_NET_EPERM", "UNSHARE_PLAIN_OK"] {
        assert!(
            stdout.contains(marker),
            "expected {marker} in child output.\nstdout: {stdout}\nstderr: {stderr}"
        );
    }
}

#[test]
fn workload_filter_presence_is_asserted() {
    let script = r#"
for line in open("/proc/self/status"):
    if line.startswith("Seccomp:"):
        print("SECCOMP_MODE=" + line.split(":")[1].strip())
    if line.startswith("Seccomp_filters:"):
        print("FILTERS=" + line.split(":")[1].strip())
"#;
    let (stdout, stderr, success) = run_python_child(script);
    assert!(
        success,
        "child run failed.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("SECCOMP_MODE=2"),
        "child must be in seccomp filter mode.\nstdout: {stdout}"
    );
    let child_filters: u32 = stdout
        .lines()
        .find_map(|l| l.strip_prefix("FILTERS="))
        .and_then(|v| v.trim().parse().ok())
        .expect("child must report its filter count");
    assert_eq!(
        child_filters,
        own_seccomp_filters() + 1,
        "the child must carry exactly one filter more than the test process: the workload profile"
    );
}
