//! Integration test: the vault core through the public API only.

use mack_security_runtime::vault::MackVaultEngine;

#[test]
fn seal_unseal_roundtrip_and_wrong_passphrase_fails() {
    let sealed =
        MackVaultEngine::seal(b"correct-passphrase", b"roundtrip-vector", "GENESIS").expect("seal");
    let opened = MackVaultEngine::unseal(b"correct-passphrase", &sealed).expect("unseal");
    assert_eq!(opened, b"roundtrip-vector");
    assert!(MackVaultEngine::unseal(b"wrong-passphrase", &sealed).is_err());
}
