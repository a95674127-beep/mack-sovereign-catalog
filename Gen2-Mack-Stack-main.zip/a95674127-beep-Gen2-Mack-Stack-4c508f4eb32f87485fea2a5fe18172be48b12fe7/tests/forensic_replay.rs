//! Deterministic forensic replay tests (v0.7.0): real re-execution,
//! plain and inside the sandbox worker.

use mack_security_runtime::forensic::replay::{record_run, replay_run, replay_run_confined};

/// A pure, deterministic workload: byte-wise transform + fold.
fn workload(input: &[u8]) -> Vec<u8> {
    input
        .iter()
        .map(|b| b.wrapping_mul(31).wrapping_add(7))
        .collect()
}

#[test]
fn replay_of_a_faithful_record_matches() {
    let input = b"lane input: transfer 50 credits";
    let record = record_run(input, &workload(input), "ledger-tip-abc");
    let report = replay_run(&record, workload);
    assert!(report.digest_matches);
    assert!(!report.confined);
    assert_eq!(
        report.recomputed_output_sha256,
        record.expected_output_sha256
    );
}

#[test]
fn replay_detects_tampered_record_and_tampered_input() {
    let input = b"original input";
    let mut record = record_run(input, &workload(input), "tip");
    record.expected_output_sha256 = "0".repeat(64);
    assert!(!replay_run(&record, workload).digest_matches);

    let mut record2 = record_run(input, &workload(input), "tip");
    record2.input = b"swapped input".to_vec();
    assert!(!replay_run(&record2, workload).digest_matches);
}

#[test]
fn confined_replay_matches_or_fails_closed() {
    let input = b"confined replay input";
    let record = record_run(input, &workload(input), "tip");
    match replay_run_confined(&record, std::env::temp_dir(), workload) {
        Ok(report) => {
            assert!(report.confined);
            assert!(
                report.digest_matches,
                "confined replay must reproduce the digest"
            );
        }
        Err(e) => {
            // Fail-closed is an acceptable outcome on a host without
            // enforcement support; a silent unconfined fallback is not
            // (it would have returned Ok with confined == true and no
            // error, or worse, run the workload anyway).
            assert!(
                e.contains("Landlock") || e.contains("Seccomp") || e.contains("enforc"),
                "abort must come from enforcement, got: {e}"
            );
        }
    }
}
