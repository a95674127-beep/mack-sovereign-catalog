//! Inherited-FD hygiene tests (v0.12.0, `mack-proxy` pre_exec):
//! a UDP datagram socket inherited as the child's stdin must
//! refuse the spawn — the seccomp profile filters socket
//! CREATION, so an inherited datagram socket is the one UDP
//! channel that would otherwise slip past it. The refusal is
//! asserted from the observed spawn result: `mack-proxy` exits
//! with its launch-failure code and the child never runs.

use std::net::UdpSocket;
use std::os::unix::io::{FromRawFd, IntoRawFd};
use std::process::{Command, Stdio};

fn proxy_command() -> Command {
    let mut cmd = Command::new(env!("CARGO_BIN_EXE_mack-proxy"));
    cmd.env("MACK_REAL_SECRET", "fd-hygiene-secret").args([
        "run",
        "--allow",
        "127.0.0.1",
        "--",
        "sh",
        "-c",
        "echo CHILD_RAN",
    ]);
    cmd
}

#[test]
fn inherited_udp_socket_as_stdin_refuses_the_spawn() {
    // Hand mack-proxy a live UDP socket as its stdin; the
    // confined child would inherit it as fd 0.
    let sock = UdpSocket::bind("127.0.0.1:0").expect("bind UDP socket");
    let fd = sock.into_raw_fd();
    // SAFETY: the raw fd is owned by this Stdio from here on;
    // it is the socket created just above and used nowhere else.
    let stdio = unsafe { Stdio::from_raw_fd(fd) };
    let output = proxy_command()
        .stdin(stdio)
        .output()
        .expect("failed to run mack-proxy");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_eq!(
        output.status.code(),
        Some(3),
        "mack-proxy must refuse the run (exit 3).\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stderr.contains("Failed to launch confined child process"),
        "the refusal must surface as a spawn failure.\nstderr: {stderr}"
    );
    assert!(
        stderr.contains("inherited UDP datagram socket on fd 0"),
        "the refusal must name the FD audit.\nstderr: {stderr}"
    );
    assert!(
        !stdout.contains("CHILD_RAN"),
        "the child must never run.\nstdout: {stdout}"
    );
}

#[test]
fn ordinary_stdio_spawns_the_child_normally() {
    // Positive control: with ordinary (null) stdin the same
    // run spawns the child, which runs and exits cleanly — the
    // refusal above is about the datagram socket, not the
    // harness.
    let output = proxy_command()
        .stdin(Stdio::null())
        .output()
        .expect("failed to run mack-proxy");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        output.status.success(),
        "ordinary run must succeed.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("CHILD_RAN"),
        "the child must run under ordinary stdio.\nstdout: {stdout}\nstderr: {stderr}"
    );
}
