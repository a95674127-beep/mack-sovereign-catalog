//! Defensive verification suite for GitHub Actions workflow concurrency and release protections.
//!
//! Enforces:
//! 1. All workflows maintain top-level concurrency groups isolated by `${{ github.workflow }}` namespace.
//! 2. Release workflows strictly prohibit cancellation (`cancel-in-progress: false`).
//! 3. CI workflows with tag triggers protect release builds via `${{ !startsWith(github.ref, 'refs/tags/') }}`.
//! 4. Automated Python workflow validation harness executes without errors across both active workflows
//!    and edge-case synthetic test suites.
//! 5. Validator precisely reports workflow filename and line number for each failed concurrency invariant.

use std::fs;
use std::path::Path;
use std::process::Command;

#[test]
fn test_workflow_validator_script_active_and_self_test() {
    let script_path = Path::new("scripts/validate_workflows.py");
    assert!(
        script_path.exists(),
        "scripts/validate_workflows.py must exist in the repository root"
    );

    // 1. Run internal self-tests (negative & edge cases with line number assertions)
    let self_test_res = Command::new("python3")
        .arg("scripts/validate_workflows.py")
        .arg("--self-test")
        .output();

    if let Ok(output) = self_test_res {
        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);
        assert!(
            output.status.success(),
            "Workflow validator self-test failed!\nSTDOUT:\n{}\nSTDERR:\n{}",
            stdout,
            stderr
        );
    }

    // 2. Run validator against .github/workflows
    let val_res = Command::new("python3")
        .arg("scripts/validate_workflows.py")
        .arg("--workflows-dir")
        .arg(".github/workflows")
        .output();

    if let Ok(output) = val_res {
        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);
        assert!(
            output.status.success(),
            "Active workflow validation failed!\nSTDOUT:\n{}\nSTDERR:\n{}",
            stdout,
            stderr
        );
    }
}

#[test]
fn test_workflow_validator_reports_file_and_line_numbers_for_invariants() {
    let temp_dir = std::env::temp_dir().join(format!("mack_wf_line_test_{}", std::process::id()));
    fs::create_dir_all(&temp_dir).expect("Failed to create temporary directory for line tests");

    // Case 1: Accidental release cancellation at line 7
    let bad_release_path = temp_dir.join("bad_release.yml");
    let bad_release_content = "name: Bad Release\non:\n  push:\n    tags: ['v*']\nconcurrency:\n  group: ${{ github.workflow }}-${{ github.ref }}\n  cancel-in-progress: true\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo ok\n";
    fs::write(&bad_release_path, bad_release_content).expect("Failed to write bad_release.yml");

    // Case 2: Missing namespace isolation at line 6
    let bad_namespace_path = temp_dir.join("bad_namespace.yml");
    let bad_namespace_content = "name: Bad Namespace\non:\n  push:\n    branches: [main]\nconcurrency:\n  group: ${{ github.ref }}\n  cancel-in-progress: true\njobs:\n  test:\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo ok\n";
    fs::write(&bad_namespace_path, bad_namespace_content)
        .expect("Failed to write bad_namespace.yml");

    // Case 3: Missing concurrency block entirely at line 1
    let missing_conc_path = temp_dir.join("missing_conc.yml");
    let missing_conc_content = "name: Missing Concurrency\non:\n  push:\n    branches: [main]\njobs:\n  test:\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo ok\n";
    fs::write(&missing_conc_path, missing_conc_content).expect("Failed to write missing_conc.yml");

    let val_res = Command::new("python3")
        .arg("scripts/validate_workflows.py")
        .arg("--workflows-dir")
        .arg(&temp_dir)
        .output()
        .expect("Failed to execute validator on temporary directory");

    let stdout = String::from_utf8_lossy(&val_res.stdout);
    let stderr = String::from_utf8_lossy(&val_res.stderr);

    // Clean up
    let _ = fs::remove_dir_all(&temp_dir);

    assert!(
        !val_res.status.success(),
        "Validator should have rejected workflows with concurrency violations"
    );

    // Verify Case 1 line number reporting and contextual excerpt
    assert!(
        stdout.contains("bad_release.yml:7"),
        "Validator must report 'bad_release.yml:7' for cancel-in-progress violation!\nSTDOUT:\n{}\nSTDERR:\n{}",
        stdout, stderr
    );
    assert!(
        stdout.contains("RELEASE_ACCIDENTAL_CANCELLATION_RISK"),
        "Validator must report RELEASE_ACCIDENTAL_CANCELLATION_RISK"
    );
    assert!(
        stdout.contains("> 7 |   cancel-in-progress: true"),
        "Validator must include contextual source excerpt for line 7!\nSTDOUT:\n{}\nSTDERR:\n{}",
        stdout,
        stderr
    );

    // Verify Case 2 line number reporting and contextual excerpt
    assert!(
        stdout.contains("bad_namespace.yml:6"),
        "Validator must report 'bad_namespace.yml:6' for namespace violation!\nSTDOUT:\n{}\nSTDERR:\n{}",
        stdout, stderr
    );
    assert!(
        stdout.contains("CONCURRENCY_NAMESPACE_COLLISION_RISK"),
        "Validator must report CONCURRENCY_NAMESPACE_COLLISION_RISK"
    );
    assert!(
        stdout.contains("> 6 |   group: ${{ github.ref }}"),
        "Validator must include contextual source excerpt for line 6!\nSTDOUT:\n{}\nSTDERR:\n{}",
        stdout,
        stderr
    );

    // Verify Case 3 line number reporting and contextual excerpt
    assert!(
        stdout.contains("missing_conc.yml:1"),
        "Validator must report 'missing_conc.yml:1' for missing concurrency violation!\nSTDOUT:\n{}\nSTDERR:\n{}",
        stdout, stderr
    );
    assert!(
        stdout.contains("CONCURRENCY_MISSING"),
        "Validator must report CONCURRENCY_MISSING"
    );
    assert!(
        stdout.contains("> 1 | name: Missing Concurrency"),
        "Validator must include contextual source excerpt for line 1!\nSTDOUT:\n{}\nSTDERR:\n{}",
        stdout,
        stderr
    );
}

#[test]
fn test_release_workflow_cancellation_immunity_invariant() {
    let release_path = Path::new(".github/workflows/release.yml");
    assert!(
        release_path.exists(),
        ".github/workflows/release.yml must exist"
    );

    let content =
        fs::read_to_string(release_path).expect("Failed to read release.yml workflow file");

    // Concurrency group isolation
    assert!(
        content.contains("${{ github.workflow }}"),
        "release.yml concurrency group must be isolated with github.workflow namespace"
    );

    // Explicit cancel-in-progress: false
    assert!(
        content.contains("cancel-in-progress: false"),
        "release.yml MUST have cancel-in-progress explicitly set to false to protect releases"
    );

    // Reject any dangerous cancel-in-progress: true
    assert!(
        !content.contains("cancel-in-progress: true"),
        "release.yml MUST NOT have cancel-in-progress set to true"
    );
}

#[test]
fn test_ci_workflow_tag_cancellation_immunity_invariant() {
    let ci_path = Path::new(".github/workflows/ci.yml");
    assert!(ci_path.exists(), ".github/workflows/ci.yml must exist");

    let content = fs::read_to_string(ci_path).expect("Failed to read ci.yml workflow file");

    assert!(
        content.contains("${{ github.workflow }}"),
        "ci.yml concurrency group must be isolated with github.workflow namespace"
    );

    // Must protect tags from cancellation
    assert!(
        content.contains("!startsWith(github.ref, 'refs/tags/')"),
        "ci.yml must protect tag runs from cancellation via !startsWith(github.ref, 'refs/tags/')"
    );

    // Must not have unconditional cancel-in-progress: true
    assert!(
        !content.contains("cancel-in-progress: true"),
        "ci.yml triggers on tags and must not have unconditional cancel-in-progress: true"
    );
}

#[test]
fn test_gitleaks_workflow_namespace_isolation() {
    let gitleaks_path = Path::new(".github/workflows/gitleaks.yml");
    assert!(
        gitleaks_path.exists(),
        ".github/workflows/gitleaks.yml must exist"
    );

    let content =
        fs::read_to_string(gitleaks_path).expect("Failed to read gitleaks.yml workflow file");

    assert!(
        content.contains("${{ github.workflow }}"),
        "gitleaks.yml concurrency group must be isolated with github.workflow namespace"
    );
}
