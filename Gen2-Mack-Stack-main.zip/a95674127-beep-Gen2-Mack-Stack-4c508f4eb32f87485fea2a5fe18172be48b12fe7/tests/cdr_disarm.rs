//! CDR disarm-and-rebuild tests (v0.7.0): the rebuilt bytes, not the
//! originals, are what come back.

use mack_security_runtime::cdr::content_disarm::ContentDisarmEngine;

#[test]
fn script_blocks_are_removed_and_text_is_rebuilt() {
    let dirty = b"<p>hello</p><script type='x'>steal()</script><p>world</p>";
    let out = ContentDisarmEngine::disarm_text_payload(dirty).expect("disarm");
    assert_eq!(&*out.bytes, b"<p>hello</p><p>world</p>");
    assert!(out.changed);
    assert!(out.removed.contains(&"script-block"));
}

#[test]
fn schemes_nuls_and_ansi_are_stripped() {
    let dirty = b"<a href='JAVASCRIPT:evil()'>x</a>\x00\x1b[31mred\x1b[0m";
    let out = ContentDisarmEngine::disarm_text_payload(dirty).expect("disarm");
    let text = String::from_utf8_lossy(&out.bytes).to_string();
    assert!(!text.to_ascii_lowercase().contains("javascript:"));
    assert!(text.contains("blocked:"));
    assert!(!out.bytes.contains(&0));
    assert!(!out.bytes.contains(&0x1b));
    assert!(out.removed.contains(&"javascript-scheme"));
    assert!(out.removed.contains(&"nul-bytes"));
    assert!(out.removed.contains(&"ansi-escapes"));
}

#[test]
fn clean_text_passes_byte_identical_and_disarm_is_idempotent() {
    let clean = b"Quarterly report: all figures nominal.";
    let out = ContentDisarmEngine::disarm_text_payload(clean).expect("disarm clean");
    assert_eq!(&*out.bytes, clean);
    assert!(!out.changed);
    assert!(out.removed.is_empty());

    let dirty = b"a<script>x()</script>b";
    let once = ContentDisarmEngine::disarm_text_payload(dirty).expect("once");
    let twice = ContentDisarmEngine::disarm_text_payload(&once.bytes).expect("twice");
    assert_eq!(&*twice.bytes, &*once.bytes);
    assert!(!twice.changed);
}

#[test]
fn payload_that_rebuilds_to_nothing_is_an_error() {
    assert!(ContentDisarmEngine::disarm_text_payload(b"<script>only()</script>").is_err());
    assert!(ContentDisarmEngine::disarm_text_payload(b"").is_err());
}
