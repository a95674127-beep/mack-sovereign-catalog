//! Adversarial harness (v0.8.0) — the permanent attack suite.
//! The release documentation calls this suite the **Escape Lab**;
//! it is the same harness, extended — not a separate subsystem.
//!
//! One home for the strongest attack case against each module,
//! including the regressions for defects this crate's lineage
//! actually shipped and fixed: the ledger field-boundary hash
//! collision (proven by test against an external design on
//! 2026-11-15) and envelope replay (open until the v0.6.0 store).
//! Every case asserts the attack FAILS. If one of these ever passes
//! its attack, that is a release-blocking regression.
//!
//! v0.11.0 extension: escape cases against the assembled
//! `mack-proxy` child confinement — direct TCP and UDP egress,
//! writes to proxy state, memory exhaustion under the resource
//! governor, abrupt child death vs. the persistent ledger, and a
//! fork attempt gated on the governor's cgroup layer being active
//! in the environment running the test. (Burned-handle replay is
//! covered at the library level in `tests/policy_core.rs` and is
//! not duplicated here.)
//!
//! v0.12.0 extension: an inherited datagram socket on the
//! child's stdio — a pre-built UDP channel that the seccomp
//! socket-CREATION filter cannot govern — is refused at spawn
//! by the pre_exec FD audit.

use ed25519_dalek::SigningKey;
use mack_security_runtime::cdr::content_disarm::ContentDisarmEngine;
use mack_security_runtime::ledger::ProofLedger;
use mack_security_runtime::proof_fabric::compound_attestation::CompoundAttestationChain;
use mack_security_runtime::proof_fabric::execution_envelope::IntentBoundEnvelope;
use mack_security_runtime::proof_fabric::leases::{
    verify_envelope_once, CapabilityLease, LeaseError, ManualClock, SeenNonceStore,
};
use mack_security_runtime::threshold::{run_dkg, sign_message};
use mack_security_runtime::vault::MackVaultEngine;
use rand_core::OsRng;
use std::collections::HashMap;
use std::io::{Read, Write};
use std::net::{TcpListener, UdpSocket};
use std::os::unix::io::{FromRawFd, IntoRawFd};
use std::process::{Command, Stdio};
use std::thread;

#[test]
fn attack_vault_wrong_passphrase_and_tampered_ciphertext() {
    let sealed = MackVaultEngine::seal(b"correct horse", b"top secret", "tip0").expect("seal");
    assert!(MackVaultEngine::unseal(b"wrong horse", &sealed).is_err());
    let mut tampered = sealed.clone();
    tampered.ciphertext[0] ^= 0xff;
    assert!(MackVaultEngine::unseal(b"correct horse", &tampered).is_err());
}

#[test]
fn attack_envelope_payload_swap_and_wrong_authority() {
    let authority = SigningKey::generate(&mut OsRng);
    let impostor = SigningKey::generate(&mut OsRng);
    let env = IntentBoundEnvelope::sign_new("lane-1", "tip", b"real payload", 1, &authority)
        .expect("sign");
    // Payload swapped after sealing.
    assert!(env
        .verify(b"swapped payload", &authority.verifying_key())
        .is_err());
    // Genuine envelope, wrong verifying authority.
    assert!(env
        .verify(b"real payload", &impostor.verifying_key())
        .is_err());
}

#[test]
fn attack_attestation_link_tampered_after_signing() {
    let alice = SigningKey::generate(&mut OsRng);
    let mut keys = HashMap::new();
    keys.insert("alice".to_string(), alice.verifying_key());
    let mut chain = CompoundAttestationChain::new("root-hash".to_string());
    chain
        .append_delegation("alice", "bob", "intent-1", &alice)
        .expect("append");
    chain
        .verify_continuity(&keys)
        .expect("honest chain verifies");
    chain.links[0].task_intent_hash = "intent-EVIL".to_string();
    assert!(
        chain.verify_continuity(&keys).is_err(),
        "tampered link must break the chain"
    );
}

#[test]
fn attack_threshold_signature_from_a_foreign_group() {
    let (_victims, victim_group) = run_dkg(&[1, 2, 3], 2).expect("victim DKG");
    let (attackers, attacker_group) = run_dkg(&[1, 2, 3], 2).expect("attacker DKG");
    let msg = b"mint 1,000,000 to attacker";
    let forged = sign_message(&attacker_group, &[&attackers[0], &attackers[1]], msg)
        .expect("attacker quorum signs under its own group");
    assert!(
        victim_group.verify(msg, &forged).is_err(),
        "a foreign group's signature must not verify under the victim group key"
    );
}

#[test]
fn attack_lease_cross_envelope_and_replay_after_authorization() {
    let authority = SigningKey::generate(&mut OsRng);
    let vk = authority.verifying_key();
    let clock = ManualClock::new(10_000);
    let env_a =
        IntentBoundEnvelope::sign_new("lane-1", "tip", b"payload", 100, &authority).expect("env A");
    let env_b =
        IntentBoundEnvelope::sign_new("lane-1", "tip", b"payload", 200, &authority).expect("env B");
    let lease = CapabilityLease::issue(&authority, "lane-1", "egress:x:POST", 100, &clock, 300)
        .expect("lease for A");
    // Lease minted for envelope A presented against envelope B.
    match lease.authorize(&vk, &env_b, &clock) {
        Err(LeaseError::ScopeMismatch(_)) => {}
        other => panic!("expected ScopeMismatch, got {other:?}"),
    }
    // Authorized once, then the same envelope replayed.
    lease.authorize(&vk, &env_a, &clock).expect("authorize A");
    let mut store = SeenNonceStore::new();
    verify_envelope_once(&mut store, &env_a, b"payload", &vk).expect("first use");
    match verify_envelope_once(&mut store, &env_a, b"payload", &vk) {
        Err(LeaseError::ReplayDetected) => {}
        other => panic!("expected ReplayDetected, got {other:?}"),
    }
}

#[test]
fn regression_ledger_field_boundary_collision() {
    // The proven 2026-11-15 defect class: naive concatenation made
    // ("AB","C") and ("A","BC") hash identically. The length-prefixed
    // digest must keep them distinct.
    let mut a = ProofLedger::new();
    a.append("AB", "C", b"payload", None);
    let mut b = ProofLedger::new();
    b.append("A", "BC", b"payload", None);
    assert_ne!(
        a.tip_hash(),
        b.tip_hash(),
        "field-boundary collision regression"
    );
    a.verify_chain().expect("chain A verifies");
    b.verify_chain().expect("chain B verifies");
}

#[test]
fn attack_cdr_executable_rejected_and_script_neutralized() {
    // Strict engine: an ELF payload is refused outright.
    let elf = b"\x7fELF\x02\x01\x01\x00malice";
    assert!(ContentDisarmEngine::sanitize_and_reconstruct(elf).is_err());
    // Rebuild engine: script content does not survive into the output.
    let html = b"keep<script>exfiltrate()</script>keep";
    let out = ContentDisarmEngine::disarm_text_payload(html).expect("disarm");
    let text = String::from_utf8_lossy(&out.bytes).to_string();
    assert!(!text.contains("exfiltrate"));
    assert_eq!(text, "keepkeep");
}

// ---------------------------------------------------------------------
// Escape Lab (v0.11.0): attacks from inside a live mack-proxy child.
// Each case asserts the denial from the child's own observed result.
// ---------------------------------------------------------------------

/// Spawns `mack-proxy` with the given extra args and child command;
/// returns (stdout, stderr, exit code).
fn run_proxy(extra_args: &[&str], child: &[&str]) -> (String, String, Option<i32>) {
    let bin = env!("CARGO_BIN_EXE_mack-proxy");
    let output = Command::new(bin)
        .env("MACK_REAL_SECRET", "escape-lab-secret")
        .arg("run")
        .args(extra_args)
        .arg("--")
        .args(child)
        .output()
        .expect("failed to run mack-proxy");
    (
        String::from_utf8_lossy(&output.stdout).into_owned(),
        String::from_utf8_lossy(&output.stderr).into_owned(),
        output.status.code(),
    )
}

/// A one-shot loopback upstream that answers a single request with
/// 200 OK. Returns its port.
fn one_shot_upstream() -> u16 {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let port = listener.local_addr().unwrap().port();
    thread::spawn(move || {
        if let Ok((mut conn, _)) = listener.accept() {
            let mut buf = [0u8; 4096];
            let _ = conn.read(&mut buf);
            let _ = conn
                .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK");
        }
    });
    port
}

/// Child script: one request through the proxy (control), then a
/// direct TCP connect to the same upstream port (attack).
fn via_proxy_then_direct_script(port: u16) -> String {
    format!(
        r#"
import os, socket
proxy = os.environ["HTTP_PROXY"].replace("http://", "")
phost, pport = proxy.split(":")
s = socket.create_connection((phost, int(pport)), timeout=30)
req = (
    "GET http://127.0.0.1:{p}/ HTTP/1.1\r\n"
    "Host: 127.0.0.1:{p}\r\n"
    "Authorization: Bearer " + os.environ["MACK_TOKEN_HANDLE"] + "\r\n"
    "Connection: close\r\n\r\n"
)
s.sendall(req.encode())
data = s.recv(4096).decode()
s.close()
print("VIA_PROXY_OK" if "200 OK" in data else "VIA_PROXY_FAIL")
try:
    d = socket.create_connection(("127.0.0.1", {p}), timeout=30)
    d.close()
    print("DIRECT_TCP_ALLOWED")
except PermissionError:
    print("DIRECT_TCP_EACCES")
except OSError as e:
    print("DIRECT_TCP_ERRNO_%d" % e.errno)
"#,
        p = port
    )
}

#[test]
fn attack_direct_tcp_to_non_proxy_port_is_denied() {
    let port = one_shot_upstream();
    let script = via_proxy_then_direct_script(port);
    let (stdout, stderr, code) = run_proxy(
        &["--allow", "127.0.0.1", "--insecure-loopback"],
        &["python3", "-c", &script],
    );
    assert_eq!(
        code,
        Some(0),
        "child run failed.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("VIA_PROXY_OK"),
        "control: the proxied request must succeed.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("DIRECT_TCP_EACCES"),
        "attack: a direct connect to a non-proxy port must be refused by the kernel (Landlock EACCES).\nstdout: {stdout}\nstderr: {stderr}"
    );
}

#[test]
fn attack_direct_udp_is_denied_from_child() {
    let script = r#"
import socket
try:
    u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    u.sendto(b"escape", ("192.0.2.1", 53))
    u.close()
    print("UDP_ALLOWED")
except PermissionError:
    print("UDP_EPERM")
except OSError as e:
    print("UDP_ERRNO_%d" % e.errno)
"#;
    let (stdout, stderr, code) = run_proxy(
        &["--allow", "127.0.0.1", "--insecure-loopback"],
        &["python3", "-c", script],
    );
    assert_eq!(
        code,
        Some(0),
        "child run failed.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("UDP_EPERM"),
        "attack: direct UDP must be denied at socket creation (seccomp EPERM).\nstdout: {stdout}\nstderr: {stderr}"
    );
}

#[test]
fn attack_child_cannot_write_proxy_state_files() {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let dir = std::env::temp_dir().join(format!("mack-escape-{}-{nanos}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let ledger_path = dir.join("state.ledger.jsonl");
    let script = r#"
import os
target = os.environ["ATTACK_LEDGER_PATH"]
try:
    with open(target, "a") as f:
        f.write("{\"sequence\":99,\"forged\":true}\n")
    print("LEDGER_WRITE_ALLOWED")
except PermissionError:
    print("LEDGER_WRITE_EACCES")
marker = "/tmp/mack-escape-marker-%d" % os.getpid()
try:
    with open(marker, "w") as f:
        f.write("x")
    print("TMP_CREATE_ALLOWED")
except PermissionError:
    print("TMP_CREATE_EACCES")
"#;
    let bin = env!("CARGO_BIN_EXE_mack-proxy");
    let output = Command::new(bin)
        .env("MACK_REAL_SECRET", "escape-lab-secret")
        .env("ATTACK_LEDGER_PATH", &ledger_path)
        .args([
            "run",
            "--allow",
            "127.0.0.1",
            "--insecure-loopback",
            "--ledger",
            ledger_path.to_str().unwrap(),
            "--",
            "python3",
            "-c",
            script,
        ])
        .output()
        .expect("failed to run mack-proxy");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        output.status.success(),
        "child run failed.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("LEDGER_WRITE_EACCES"),
        "attack: the child must not append to the proxy's ledger file (read-only Landlock grant).\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("TMP_CREATE_EACCES"),
        "attack: the child must not create files outside its grants.\nstdout: {stdout}\nstderr: {stderr}"
    );
    // And the ledger the child tried to forge still verifies.
    mack_security_runtime::ledger::store::verify_file(&ledger_path)
        .expect("the ledger must survive the child's forgery attempt untouched");
}

#[test]
fn attack_memory_exhaustion_is_contained_by_governor() {
    let (stdout, stderr, code) = run_proxy(
        &["--allow", "127.0.0.1", "--limit-as-mib", "128"],
        &[
            "python3",
            "-c",
            "x = bytearray(512 * 1024 * 1024)\nprint('ALLOC_SURVIVED')",
        ],
    );
    assert!(
        !stdout.contains("ALLOC_SURVIVED") && code != Some(0),
        "attack: memory exhaustion must be contained by the governor (child dies against the cap; the host and this test are unaffected).\nstdout: {stdout}\nstderr: {stderr}"
    );
}

#[test]
fn attack_abrupt_child_death_leaves_verifiable_ledger() {
    let port = one_shot_upstream();
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let dir =
        std::env::temp_dir().join(format!("mack-escape-death-{}-{nanos}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let ledger_path = dir.join("session.ledger.jsonl");
    let script = format!(
        r#"
import os, signal, socket, sys
proxy = os.environ["HTTP_PROXY"].replace("http://", "")
phost, pport = proxy.split(":")
s = socket.create_connection((phost, int(pport)), timeout=30)
req = (
    "GET http://127.0.0.1:{p}/ HTTP/1.1\r\n"
    "Host: 127.0.0.1:{p}\r\n"
    "Authorization: Bearer " + os.environ["MACK_TOKEN_HANDLE"] + "\r\n"
    "Connection: close\r\n\r\n"
)
s.sendall(req.encode())
data = s.recv(4096).decode()
s.close()
assert "200 OK" in data, data
print("REQUEST_OK")
sys.stdout.flush()
os.kill(os.getpid(), signal.SIGKILL)
"#,
        p = port
    );
    let (stdout, stderr, code) = run_proxy(
        &[
            "--allow",
            "127.0.0.1",
            "--insecure-loopback",
            "--ledger",
            ledger_path.to_str().unwrap(),
        ],
        &["python3", "-c", &script],
    );
    assert!(
        stdout.contains("REQUEST_OK"),
        "the request must complete before the child dies.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert_ne!(
        code,
        Some(0),
        "a SIGKILLed child must surface as a failed run.\nstderr: {stderr}"
    );
    // The evidence survives the workload: the ledger on disk —
    // including the shutdown checkpoint the proxy appended after
    // the child's death — verifies independently.
    let verify = Command::new(env!("CARGO_BIN_EXE_mack-ledger-verify"))
        .arg(&ledger_path)
        .output()
        .expect("failed to run mack-ledger-verify");
    assert!(
        verify.status.success()
            && String::from_utf8_lossy(&verify.stdout).contains("LEDGER VERIFICATION: OK"),
        "the persistent ledger must verify after abrupt child death.\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&verify.stdout),
        String::from_utf8_lossy(&verify.stderr)
    );
    let text = std::fs::read_to_string(&ledger_path).unwrap();
    assert!(
        text.contains("LEDGER_CHECKPOINT"),
        "the shutdown checkpoint must be in the persisted chain"
    );
}

#[test]
fn attack_inherited_udp_socket_on_stdio_is_refused_at_spawn() {
    // The smuggle: hand the proxy a live UDP socket as its
    // stdin, so the confined child would inherit a ready-made
    // datagram channel as fd 0 — created BEFORE the seccomp
    // profile existed, so the socket() filter never sees it.
    // The pre_exec FD audit (v0.12.0) must refuse the spawn:
    // mack-proxy exits with its launch-failure code and the
    // child never runs.
    let sock = UdpSocket::bind("127.0.0.1:0").expect("bind UDP socket");
    let fd = sock.into_raw_fd();
    // SAFETY: the raw fd is owned by this Stdio from here on;
    // it is the socket created just above and used nowhere else.
    let stdio = unsafe { Stdio::from_raw_fd(fd) };
    let output = Command::new(env!("CARGO_BIN_EXE_mack-proxy"))
        .env("MACK_REAL_SECRET", "escape-lab-secret")
        .stdin(stdio)
        .args([
            "run",
            "--allow",
            "127.0.0.1",
            "--",
            "sh",
            "-c",
            "echo CHILD_RAN",
        ])
        .output()
        .expect("failed to run mack-proxy");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_eq!(
        output.status.code(),
        Some(3),
        "attack: a child inheriting a UDP socket on stdio must be refused at spawn.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stderr.contains("inherited UDP datagram socket on fd 0"),
        "the refusal must come from the FD audit.\nstderr: {stderr}"
    );
    assert!(
        !stdout.contains("CHILD_RAN"),
        "the child must never run.\nstdout: {stdout}"
    );
}

#[test]
fn attack_fork_attempt_bounded_only_where_governor_is_active() {
    // Gate: this case runs the fork attempt ONLY when the run's
    // own governor report says the cgroup layer (the layer that
    // carries pids.max) was actually applied in this environment.
    // Otherwise the case asserts the report discloses the gap and
    // does not destabilize the host with an unbounded attempt.
    let (_stdout, stderr, code) = run_proxy(&["--allow", "127.0.0.1"], &["sh", "-c", "exit 0"]);
    assert_eq!(code, Some(0), "probe run failed.\nstderr: {stderr}");
    let line = stderr
        .lines()
        .find(|l| l.contains("Resource governor:"))
        .expect("probe run must print the governor report");
    if !line.contains("cgroup v2 applied") {
        assert!(
            line.contains("process-count limit not enforced"),
            "without the cgroup layer the report must disclose that process count is unenforced.\nline: {line}"
        );
        return;
    }
    let script = r#"
import os, time
pids = []
try:
    for _ in range(128):
        pid = os.fork()
        if pid == 0:
            time.sleep(10)
            os._exit(0)
        pids.append(pid)
    print("FORK_UNBOUNDED")
except OSError:
    print("FORK_LIMITED_AFTER_%d" % len(pids))
for pid in pids:
    try:
        os.kill(pid, 9)
    except OSError:
        pass
for pid in pids:
    try:
        os.waitpid(pid, 0)
    except OSError:
        pass
"#;
    let (stdout, stderr, code) = run_proxy(&["--allow", "127.0.0.1"], &["python3", "-c", script]);
    assert_eq!(
        code,
        Some(0),
        "fork-attempt run failed.\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("FORK_LIMITED_AFTER_"),
        "attack: with pids.max applied, the fork attempt must hit the limit.\nstdout: {stdout}\nstderr: {stderr}"
    );
}
