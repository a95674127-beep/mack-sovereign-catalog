# Security Policy

## Posture

This is a security system; its claims discipline is part of the design:

- **Fail closed.** When a confinement or verification step cannot be
  established, the operation does not proceed.
- **Established cryptography only.** No invented primitives. Sealing is
  Argon2id + XChaCha20-Poly1305; signatures are Ed25519; threshold signing,
  when integrated, is RFC 9591 FROST via the audited ZF FROST crates.
- **Secrets are zeroized** on drop wherever they are held, and are never
  logged, never written to disk in plaintext, and never sent anywhere by
  this code. Since v0.12.0 the proxy holds its secret as 2-of-3 Shamir
  shares (zeroized on drop; reconstruction lands in a zeroizing buffer),
  so the assembled secret exists only transiently during an injection.
  The shares are co-located in the proxy process: this narrows the
  residency window and is **not** multi-party custody — distributed
  custody waits on multi-device share transport.
- **Inherited descriptors are untrusted input.** Since v0.12.0 the
  confined child's stdio is audited before exec (a datagram socket
  there refuses the spawn — it would bypass the seccomp profile's
  socket-creation filter) and every other inherited descriptor is
  closed; failure of either step fails the spawn.
- **A valid chain is not proof of completeness.** Since v0.12.0 a
  ledger can be verified against an extracted signed checkpoint
  (`mack-ledger-verify --against-checkpoint`): records the
  checkpoint commits to but the file lacks fail as `TailTruncation`.
  Whoever holds a checkpoint can detect a rolled-back tail; the
  session receipt the proxy signs at shutdown binds the run to
  that same final head and count, plus the measured hash of the
  executable that produced it.
- **Operator-provisioned keys are the operator's.** The one key material
  this code writes to disk is the persistent ledger's authority seed,
  and only when the operator enables it (`mack-proxy --ledger`): it is
  created mode 0600 at the operator-chosen path (default
  `<ledger>.key`) — the same trust class as an SSH private key.
  Workload secrets are never in that category.
- **Claims match the code.** A module marked design-stage is not a feature.
  Public claims wait for built, tested, verified code.

## Reporting

This is a private development repository. Security concerns go to the
repository owner directly. There is no bug bounty and no public disclosure
process at this stage.
