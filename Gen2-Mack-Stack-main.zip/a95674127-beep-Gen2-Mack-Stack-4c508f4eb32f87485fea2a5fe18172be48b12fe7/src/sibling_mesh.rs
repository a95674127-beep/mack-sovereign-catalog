//! Sibling-mesh router (v0.14.0) — the 3-phase, 36-lane
//! pipeline over the [`crate::dual_secret`] engine.
//! Assembled from the lab-held Infinity paste set at the
//! operator's order. The router does no cryptography
//! itself; crypto lives in [`crate::dual_secret`] and
//! [`crate::secret_split`].
//!
//! Phases, in order, one direction only:
//! 1. **Ingestion** — validate and create the dual-secret
//!    session. Never classifies, never routes.
//! 2. **Classification** — lane, kind, and x only. Never
//!    reads share bytes, never reconstructs.
//! 3. **Routing** — deterministic placement into per-lane
//!    FIFO queues. Never re-randomizes a lane, never
//!    reorders within a lane.
//!
//! [`SiblingMeshRouter::ingest`] runs the three phases in
//! order. The phase functions are also public so callers
//! can stage them explicitly; the ordering guarantee holds
//! for `ingest`, and a caller staging phases by hand owns
//! the order they choose. Collection goes back through the
//! engine's `attempt_reconstruct`, so expiry, honey
//! termination, replay, and rate limiting are enforced on
//! the way in — the router never bypasses them.
//!
//! HONEST SCOPE: same as the engine — a single-process
//! model, no network transport. Shares "leave" the router
//! only when a lane is drained; what carries them after
//! that is the caller's transport (see
//! [`crate::mesh_transport`] for the encrypted form).

use std::collections::VecDeque;
use std::time::Instant;

use zeroize::Zeroizing;

use crate::dual_secret::{DualError, Engine, ScheduledShare, Share};

/// Lanes the router places shares into (matches
/// [`crate::dual_secret::LANE_COUNT`]).
pub const LANE_COUNT: usize = crate::dual_secret::LANE_COUNT;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum RouterError {
    Dual(DualError),
    BadLane,
    EmptyPayload,
}

impl From<DualError> for RouterError {
    fn from(e: DualError) -> Self {
        // The engine's own empty-payload error surfaces as
        // the router's, so callers see one spelling.
        if e == DualError::EmptyPayload {
            return RouterError::EmptyPayload;
        }
        RouterError::Dual(e)
    }
}

/// Phase 1 output. Ingestion never inspects payload bytes
/// beyond length.
pub struct Ingested {
    pub session_id: [u8; 16],
    pub scheduled: Vec<ScheduledShare>,
    pub created: Instant,
}

/// Phase 2's per-share classification: lane, jitter, kind,
/// and x — nothing about the share's bytes.
#[derive(Debug, Clone)]
pub struct ClassifiedItem {
    pub lane: usize,
    pub jitter_ms: u64,
    pub kind_is_b: bool,
    pub x: u8,
}

/// Phase 2 output: the classification plus the scheduled
/// shares it was derived from, carried to Phase 3.
pub struct Classified {
    pub session_id: [u8; 16],
    pub items: Vec<ClassifiedItem>,
    pub scheduled: Vec<ScheduledShare>,
}

/// Phase 3 output: how many shares were placed into lanes.
#[derive(Debug)]
pub struct Routed {
    pub session_id: [u8; 16],
    pub placed: usize,
}

pub struct SiblingMeshRouter {
    engine: Engine,
    lanes: Vec<VecDeque<ScheduledShare>>,
}

impl SiblingMeshRouter {
    pub fn new(audit_key: [u8; 32]) -> Self {
        Self {
            engine: Engine::new(audit_key),
            lanes: (0..LANE_COUNT).map(|_| VecDeque::new()).collect(),
        }
    }

    /// The full pipeline in correct order: ingestion, then
    /// classification, then routing. Never skips a phase.
    pub fn ingest(&mut self, payload: &[u8], now: Instant) -> Result<Routed, RouterError> {
        let ingested = self.phase_ingest(payload, now)?;
        let classified = self.phase_classify(ingested);
        Ok(self.phase_route(classified))
    }

    /// Phase 1: Ingestion. Creates the dual-secret session
    /// (which splits A and B). No classification, no
    /// routing, no payload inspection here.
    pub fn phase_ingest(&mut self, payload: &[u8], now: Instant) -> Result<Ingested, RouterError> {
        if payload.is_empty() {
            return Err(RouterError::EmptyPayload);
        }
        let (session_id, scheduled) = self.engine.create_session(payload, now)?;
        Ok(Ingested {
            session_id,
            scheduled,
            created: now,
        })
    }

    /// Phase 2: Classification. Derives lane, jitter, kind,
    /// and x from the scheduled shares. Does not read share
    /// bytes, does not reconstruct, does not decrypt.
    pub fn phase_classify(&self, ingested: Ingested) -> Classified {
        let items: Vec<ClassifiedItem> = ingested
            .scheduled
            .iter()
            .map(|s| ClassifiedItem {
                lane: s.lane,
                jitter_ms: s.jitter_ms,
                kind_is_b: matches!(s.share.kind, crate::dual_secret::SecretKind::B),
                x: s.share.x,
            })
            .collect();
        Classified {
            session_id: ingested.session_id,
            items,
            scheduled: ingested.scheduled,
        }
    }

    /// Phase 3: Deterministic routing. Each share goes to
    /// the lane Phase 2 recorded for it, in order. The
    /// router never re-randomizes a lane; jitter is
    /// preserved for the sender to apply, not applied here.
    pub fn phase_route(&mut self, classified: Classified) -> Routed {
        let mut placed = 0;
        for item in classified.scheduled {
            let lane = item.lane;
            if lane < LANE_COUNT {
                self.lanes[lane].push_back(item);
                placed += 1;
            }
        }
        Routed {
            session_id: classified.session_id,
            placed,
        }
    }

    /// Drains one lane for sending. The caller applies each
    /// share's `jitter_ms` before sending it. This is the
    /// only way shares leave the router — one lane at a
    /// time, in placement order.
    pub fn drain_lane(&mut self, lane: usize) -> Result<Vec<ScheduledShare>, RouterError> {
        if lane >= LANE_COUNT {
            return Err(RouterError::BadLane);
        }
        let mut out = Vec::new();
        while let Some(s) = self.lanes[lane].pop_front() {
            out.push(s);
        }
        Ok(out)
    }

    pub fn lane_len(&self, lane: usize) -> usize {
        if lane >= LANE_COUNT {
            return 0;
        }
        self.lanes[lane].len()
    }

    pub fn total_queued(&self) -> usize {
        self.lanes.iter().map(|q| q.len()).sum()
    }

    /// Collection path. Goes back through the engine, which
    /// enforces expiry, honey termination, replay, and rate
    /// limiting. The router does not bypass engine checks.
    pub fn submit(
        &mut self,
        session_id: &[u8; 16],
        shares: Vec<Share>,
        arrival_lane: usize,
        now: Instant,
    ) -> Result<Zeroizing<Vec<u8>>, RouterError> {
        if arrival_lane >= LANE_COUNT {
            return Err(RouterError::BadLane);
        }
        Ok(self
            .engine
            .attempt_reconstruct(session_id, shares, arrival_lane, now)?)
    }

    pub fn audit_count(&self) -> usize {
        self.engine.audit_tags.len()
    }

    pub fn session_count(&self) -> usize {
        self.engine.session_count()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dual_secret::{SecretKind, Share as DualShare};
    use std::time::Duration;
    use zeroize::Zeroizing;

    fn router() -> SiblingMeshRouter {
        SiblingMeshRouter::new([7u8; 32])
    }

    fn clone_share(s: &DualShare) -> DualShare {
        DualShare {
            x: s.x,
            y: Zeroizing::new(s.y.to_vec()),
            kind: s.kind,
        }
    }

    fn collect_all(r: &mut SiblingMeshRouter) -> Vec<DualShare> {
        let mut collected = Vec::new();
        for lane in 0..LANE_COUNT {
            for s in r.drain_lane(lane).unwrap() {
                collected.push(clone_share(&s.share));
            }
        }
        collected
    }

    fn subset(collected: &[DualShare], a_n: usize, b_n: usize) -> Vec<DualShare> {
        let mut out = Vec::new();
        let (mut a, mut b) = (0, 0);
        for s in collected {
            match s.kind {
                SecretKind::A if a < a_n => {
                    out.push(clone_share(s));
                    a += 1;
                }
                SecretKind::B if b < b_n => {
                    out.push(clone_share(s));
                    b += 1;
                }
                _ => {}
            }
        }
        out
    }

    #[test]
    fn pipeline_roundtrip() {
        let mut r = router();
        let now = Instant::now();
        let payload = b"sibling mesh pipeline test";
        let routed = r.ingest(payload, now).unwrap();
        assert_eq!(routed.placed, 10);
        assert_eq!(r.total_queued(), 10);
        let collected = collect_all(&mut r);
        let out = r
            .submit(&routed.session_id, subset(&collected, 3, 3), 0, now)
            .unwrap();
        assert_eq!(&*out, payload);
    }

    #[test]
    fn phases_stay_separated() {
        let mut r = router();
        let now = Instant::now();
        let ingested = r.phase_ingest(b"phase separation", now).unwrap();
        assert_eq!(ingested.scheduled.len(), 10);
        let classified = r.phase_classify(ingested);
        assert_eq!(classified.items.len(), 10);
        for it in &classified.items {
            assert!(it.lane < LANE_COUNT);
        }
        let routed = r.phase_route(classified);
        assert_eq!(routed.placed, 10);
    }

    #[test]
    fn honey_via_router_terminates() {
        let mut r = router();
        let now = Instant::now();
        let routed = r.ingest(b"honey via router test", now).unwrap();
        let honey = DualShare {
            x: crate::dual_secret::HONEY_X[0],
            y: Zeroizing::new(vec![9u8; 10]),
            kind: SecretKind::A,
        };
        let res = r.submit(&routed.session_id, vec![honey], 1, now);
        assert!(matches!(
            res,
            Err(RouterError::Dual(DualError::HoneyTriggered))
        ));
    }

    #[test]
    fn empty_payload_rejected_in_ingestion() {
        let mut r = router();
        assert!(matches!(
            r.ingest(b"", Instant::now()),
            Err(RouterError::EmptyPayload)
        ));
    }

    #[test]
    fn bad_lane_rejected() {
        let mut r = router();
        assert!(matches!(r.drain_lane(36), Err(RouterError::BadLane)));
    }

    #[test]
    fn expiry_enforced_on_submit() {
        let mut r = router();
        let now = Instant::now();
        let routed = r.ingest(b"expiry via router 123", now).unwrap();
        let collected = collect_all(&mut r);
        let late = now + Duration::from_secs(9);
        let res = r.submit(&routed.session_id, collected, 0, late);
        assert!(matches!(
            res,
            Err(RouterError::Dual(DualError::SessionExpired))
        ));
    }
}
