//! Proof ledger — SHA-256 hash-chained record of runtime events.
//!
//! Merged 2026-11-15 from the graded 7-pillar package, with one defect
//! fixed during the merge: fields are now hashed length-prefixed (and the
//! optional parent link carries a presence tag), so two different entries
//! can no longer collide into one hash — the as-received version hashed
//! raw concatenated bytes, and ("AB","C") vs ("A","BC") provably produced
//! identical entry hashes.
//!
//! STATUS: a hash chain proves internal consistency. Since v0.3.0 a
//! ledger can also run in signed mode (ProofLedger::with_authority):
//! every entry then carries an Ed25519 signature over its entry hash,
//! and verify_chain enforces it — the signed-entry design adopted from
//! the graded external tree, kept on this ledger's length-prefixed
//! encoding instead of its bincode one. The parent_delegation_hash
//! field remains the seed for compound attestation across delegated
//! work.
//!
//! Since v0.11.0 a ledger can also be PERSISTENT: see
//! [`store`](crate::ledger::store). A persistent ledger is an
//! append-only JSON-lines file (header line naming the format
//! version and the authority verifying key, then one JSON object
//! per entry). Every append is written through and fsynced before
//! the entry joins the in-memory chain, so the file on disk is
//! always a prefix of the chain — which is what makes the crash
//! rule decidable: on open, a final line that fails to parse is a
//! torn write (crash mid-append) and is truncated, with a signed
//! recovery entry recording the truncation; a line that parses but
//! fails verification is tampering, and the open refuses. A ledger
//! with no store attached remains in-memory only, exactly as
//! before.

pub mod store;

use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

pub const GENESIS_HASH: &str = "GENESIS_EVT_1041";

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LedgerEntry {
    pub sequence: u64,
    pub prev_hash: String,
    pub event_type: String,
    pub actor_lane: String,
    pub payload_hash: String,
    /// Parent entry hash when one lane delegates work to another.
    pub parent_delegation_hash: Option<String>,
    pub entry_hash: String,
    /// Ed25519 signature over entry_hash by the ledger authority, when
    /// the ledger runs in signed mode. Empty in unsigned mode.
    pub authority_signature: Vec<u8>,
}

fn push_field(hasher: &mut Sha256, bytes: &[u8]) {
    hasher.update((bytes.len() as u64).to_be_bytes());
    hasher.update(bytes);
}

fn entry_digest(
    sequence: u64,
    prev_hash: &str,
    event_type: &str,
    actor_lane: &str,
    payload_hash: &str,
    parent: &Option<String>,
) -> String {
    let mut h = Sha256::new();
    h.update(sequence.to_be_bytes());
    push_field(&mut h, prev_hash.as_bytes());
    push_field(&mut h, event_type.as_bytes());
    push_field(&mut h, actor_lane.as_bytes());
    push_field(&mut h, payload_hash.as_bytes());
    match parent {
        Some(p) => {
            h.update([1u8]);
            push_field(&mut h, p.as_bytes());
        }
        None => {
            h.update([0u8]);
        }
    }
    format!("{:x}", h.finalize())
}

#[derive(Debug)]
pub struct ProofLedger {
    entries: Vec<LedgerEntry>,
    authority: Option<SigningKey>,
    /// Verify-only key, set when the ledger was rebuilt from stored
    /// entries for verification (no signing authority held).
    verify_key: Option<VerifyingKey>,
    /// Attached append-only persistence (v0.11.0). When present,
    /// every append is written through to the ledger file and
    /// fsynced before the entry joins the chain.
    store: Option<store::LedgerStore>,
}

impl Clone for ProofLedger {
    /// Cloning produces an in-memory snapshot: the clone does NOT
    /// carry the persistence store (a ledger file has one writer).
    fn clone(&self) -> Self {
        Self {
            entries: self.entries.clone(),
            authority: self.authority.clone(),
            verify_key: self.verify_key,
            store: None,
        }
    }
}

impl Default for ProofLedger {
    fn default() -> Self {
        Self::new()
    }
}

impl ProofLedger {
    pub fn new() -> Self {
        Self {
            entries: Vec::new(),
            authority: None,
            verify_key: None,
            store: None,
        }
    }

    /// Signed mode: every appended entry carries an Ed25519 signature
    /// over its entry hash, and verify_chain enforces those signatures.
    pub fn with_authority(authority: SigningKey) -> Self {
        Self {
            entries: Vec::new(),
            authority: Some(authority),
            verify_key: None,
            store: None,
        }
    }

    /// Rebuilds a ledger from existing entries after verifying the
    /// full chain (sequence, hash links, entry hashes, and — when a
    /// signing or verifying key is supplied — authority signatures).
    /// This is the load path for persistent ledgers and for
    /// independent verification: nothing is trusted until the whole
    /// chain re-verifies from genesis.
    pub fn from_verified_entries(
        entries: Vec<LedgerEntry>,
        authority: Option<SigningKey>,
        verify_key: Option<VerifyingKey>,
    ) -> Result<Self, String> {
        let ledger = Self {
            entries,
            authority,
            verify_key,
            store: None,
        };
        ledger.verify_chain()?;
        Ok(ledger)
    }

    /// Opens (or creates) a persistent ledger at `path`, signed by
    /// `authority`. See [`store`] for the on-disk format, the
    /// torn-tail crash-recovery rule, and the refusal conditions.
    pub fn open_persistent(
        path: &std::path::Path,
        authority: SigningKey,
    ) -> Result<(Self, store::OpenReport), store::LedgerStoreError> {
        store::open(path, authority)
    }

    /// The path of the attached ledger file, when persistent.
    pub fn persistence_path(&self) -> Option<&std::path::Path> {
        self.store.as_ref().map(|s| s.path())
    }

    fn effective_verifying_key(&self) -> Option<VerifyingKey> {
        self.authority
            .as_ref()
            .map(|k| k.verifying_key())
            .or(self.verify_key)
    }

    pub fn authority_verifying_key(&self) -> Option<VerifyingKey> {
        self.effective_verifying_key()
    }

    pub fn tip_hash(&self) -> &str {
        self.entries
            .last()
            .map(|e| e.entry_hash.as_str())
            .unwrap_or(GENESIS_HASH)
    }

    pub fn append(
        &mut self,
        event_type: &str,
        actor_lane: &str,
        payload: &[u8],
        parent_delegation_hash: Option<String>,
    ) -> LedgerEntry {
        let sequence = (self.entries.len() as u64) + 1;
        let prev_hash = self.tip_hash().to_string();

        let mut p_hasher = Sha256::new();
        p_hasher.update(payload);
        let payload_hash = format!("{:x}", p_hasher.finalize());

        let entry_hash = entry_digest(
            sequence,
            &prev_hash,
            event_type,
            actor_lane,
            &payload_hash,
            &parent_delegation_hash,
        );

        let authority_signature = match &self.authority {
            Some(key) => key.sign(entry_hash.as_bytes()).to_vec(),
            None => Vec::new(),
        };

        let entry = LedgerEntry {
            sequence,
            prev_hash,
            event_type: event_type.to_string(),
            actor_lane: actor_lane.to_string(),
            payload_hash,
            parent_delegation_hash,
            entry_hash,
            authority_signature,
        };

        // Write-through (v0.11.0): with a store attached, the entry
        // is durable on disk BEFORE it joins the in-memory chain, so
        // the file is always a prefix of the chain. A persistence
        // failure is fatal by design (fail-closed): a run whose
        // audit log cannot be written must not continue unaudited.
        if let Some(store) = &mut self.store {
            store.write_entry(&entry).unwrap_or_else(|e| {
                panic!("AUDIT LEDGER PERSISTENCE FAILURE (fail-closed, run aborted): {e}")
            });
        }

        self.entries.push(entry.clone());
        entry
    }

    /// Appends a signed checkpoint entry. The checkpoint commits to
    /// the chain state BEFORE itself: its `prev_hash` is the tip it
    /// checkpoints and its sequence minus one is the entry count it
    /// checkpoints, so an independent verifier can confirm exactly
    /// which prefix of the chain the authority attested, from the
    /// stored fields alone. The entry carries the authority
    /// signature like every other entry in signed mode.
    pub fn append_checkpoint(&mut self, actor_lane: &str) -> LedgerEntry {
        let committed_tip = self.tip_hash().to_string();
        let committed_seq = self.entries.len() as u64;
        let payload = format!(
            "checkpoint: authority attests chain complete through sequence {committed_seq}, tip {committed_tip}"
        );
        self.append(
            store::CHECKPOINT_EVENT,
            actor_lane,
            payload.as_bytes(),
            None,
        )
    }

    /// Deterministic verification of the entire hash chain from genesis to tip.
    pub fn verify_chain(&self) -> Result<(), String> {
        let mut expected_prev = GENESIS_HASH.to_string();

        for (idx, entry) in self.entries.iter().enumerate() {
            let expected_seq = (idx as u64) + 1;
            if entry.sequence != expected_seq {
                return Err(format!("Sequence mismatch at index {}", idx));
            }
            if entry.prev_hash != expected_prev {
                return Err(format!("Broken hash chain at sequence {}", entry.sequence));
            }
            let recomputed = entry_digest(
                entry.sequence,
                &entry.prev_hash,
                &entry.event_type,
                &entry.actor_lane,
                &entry.payload_hash,
                &entry.parent_delegation_hash,
            );
            if recomputed != entry.entry_hash {
                return Err(format!(
                    "Tampered entry hash at sequence {}",
                    entry.sequence
                ));
            }
            if let Some(vk) = self.effective_verifying_key() {
                let sig_bytes: [u8; 64] =
                    entry
                        .authority_signature
                        .as_slice()
                        .try_into()
                        .map_err(|_| {
                            format!("Missing authority signature at sequence {}", entry.sequence)
                        })?;
                let sig = Signature::from_bytes(&sig_bytes);
                vk.verify(entry.entry_hash.as_bytes(), &sig).map_err(|_| {
                    format!("Invalid authority signature at sequence {}", entry.sequence)
                })?;
            }
            expected_prev = entry.entry_hash.clone();
        }
        Ok(())
    }

    pub fn entries(&self) -> &[LedgerEntry] {
        &self.entries
    }
}
