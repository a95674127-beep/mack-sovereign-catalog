//! Append-only persistent storage for the proof ledger (v0.11.0).
//!
//! On-disk format (JSON lines, one object per line):
//! - Line 1 is a header: `{"format":"mack-proof-ledger","version":1,
//!   "authority_verifying_key":"<hex>"}`. The header binds the file
//!   to one ledger authority; a file written under a different key
//!   is refused at open, never merged.
//! - Each following line is one [`LedgerEntry`] serialized as JSON.
//!
//! Durability rule: every entry is written and fsynced BEFORE it
//! joins the in-memory chain (see `ProofLedger::append`), so after
//! a crash the file holds a prefix of the chain plus at most one
//! torn final line.
//!
//! Crash-recovery rule (the only recovery this module performs):
//! on open, a FINAL line that fails to parse as an entry is a torn
//! write. It is truncated from the file, the verified prefix is
//! loaded, and a signed [`RECOVERY_EVENT`] entry recording the
//! truncation is appended before the ledger is used. Anything else
//! wrong — an unparseable line anywhere else, a header mismatch, a
//! chain that fails verification (altered, removed, or reordered
//! entries, including a parseable-but-tampered final entry) — is
//! tampering or corruption, and the open REFUSES. A broken chain is
//! never silently accepted.
//!
//! Independent verification ([`verify_file`], and the
//! `mack-ledger-verify` binary) needs no signing key and no live
//! session: it re-verifies the whole chain from the file alone,
//! using the verifying key named in the file's own header. An
//! export ([`export`]) is the ledger file copied beside a manifest
//! that restates the tip, entry count, and last checkpoint, so a
//! recipient can cross-check the manifest against the chain itself
//! ([`verify_export`]).
//!
//! External checkpoint anchoring (v0.12.0): chain verification
//! alone cannot detect TAIL truncation — a shortened file is
//! still a perfectly valid chain prefix. [`extract_checkpoint`]
//! copies the latest signed checkpoint entry out of a verified
//! ledger into a sidecar ([`CheckpointSidecar`]) that an
//! operator can keep somewhere else; [`verify_against_checkpoint`]
//! later re-verifies a ledger file against that anchor and
//! refuses a file with fewer records
//! ([`LedgerStoreError::TailTruncation`]), more records, or a
//! different head ([`LedgerStoreError::CheckpointMismatch`]).
//! The sidecar needs no private key: it copies the checkpoint
//! entry's already-signed fields.

use super::{LedgerEntry, ProofLedger};
use ed25519_dalek::{SigningKey, VerifyingKey};
use serde::{Deserialize, Serialize};
use std::fmt;
use std::fs::{File, OpenOptions};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};

pub const LEDGER_FORMAT_NAME: &str = "mack-proof-ledger";
pub const LEDGER_FORMAT_VERSION: u32 = 1;
pub const EXPORT_FORMAT_NAME: &str = "mack-proof-ledger-export";
pub const CHECKPOINT_EVENT: &str = "LEDGER_CHECKPOINT";
pub const RECOVERY_EVENT: &str = "LEDGER_TORN_TAIL_RECOVERY";

#[derive(Debug)]
pub enum LedgerStoreError {
    /// Filesystem failure (create/read/write/fsync).
    Io(String),
    /// The file is not a well-formed ledger (bad header, unparseable
    /// non-final line, torn tail handed to the strict verifier).
    Corrupt(String),
    /// The file was written under a different authority key.
    AuthorityMismatch(String),
    /// The parsed chain failed cryptographic verification
    /// (alteration, removal, or reordering).
    ChainInvalid(String),
    /// Checkpoint anchoring: the ledger file holds FEWER
    /// records than the extracted checkpoint commits to — the
    /// tail was truncated after the checkpoint was taken.
    TailTruncation(String),
    /// Checkpoint anchoring: the ledger file does not match
    /// the extracted checkpoint (more records than committed,
    /// a different head, a different authority, or a different
    /// checkpoint entry than the sidecar carries).
    CheckpointMismatch(String),
    /// Checkpoint anchoring: the sidecar's copied checkpoint
    /// signature does not verify under the authority key.
    CheckpointSignature(String),
}

impl fmt::Display for LedgerStoreError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Io(e) => write!(f, "ledger store I/O failure: {e}"),
            Self::Corrupt(e) => write!(f, "ledger file corrupt: {e}"),
            Self::AuthorityMismatch(e) => write!(f, "ledger authority mismatch: {e}"),
            Self::ChainInvalid(e) => write!(f, "ledger chain verification failed: {e}"),
            Self::TailTruncation(e) => write!(f, "ledger tail truncation detected: {e}"),
            Self::CheckpointMismatch(e) => write!(f, "ledger checkpoint mismatch: {e}"),
            Self::CheckpointSignature(e) => {
                write!(f, "checkpoint signature verification failed: {e}")
            }
        }
    }
}

impl std::error::Error for LedgerStoreError {}

fn io_err(e: std::io::Error) -> LedgerStoreError {
    LedgerStoreError::Io(e.to_string())
}

#[derive(Serialize, Deserialize)]
struct FileHeader {
    format: String,
    version: u32,
    authority_verifying_key: String,
}

/// What an [`open`] did, reported so callers can surface recovery
/// instead of hiding it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OpenReport {
    /// Entries loaded from disk (0 for a freshly created file).
    pub loaded_entries: usize,
    /// Bytes truncated as a torn final line (0 when the file was
    /// intact or new). When non-zero, a signed recovery entry was
    /// appended recording the truncation.
    pub recovered_torn_bytes: usize,
}

/// The write side of a persistent ledger: an append-mode file
/// handle owned by exactly one [`ProofLedger`].
pub struct LedgerStore {
    file: File,
    path: PathBuf,
    /// Set when the loaded file's last entry line had no trailing
    /// newline (a complete write whose newline never landed — the
    /// entry parsed and verified, so it was kept). The next append
    /// must terminate that line before writing its own.
    needs_leading_newline: bool,
}

impl fmt::Debug for LedgerStore {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("LedgerStore")
            .field("path", &self.path)
            .field("needs_leading_newline", &self.needs_leading_newline)
            .finish_non_exhaustive()
    }
}

impl LedgerStore {
    pub fn path(&self) -> &Path {
        &self.path
    }

    /// Serializes one entry as a JSON line, writes it, and fsyncs.
    /// Called by `ProofLedger::append` before the entry joins the
    /// in-memory chain.
    pub fn write_entry(&mut self, entry: &LedgerEntry) -> Result<(), LedgerStoreError> {
        let mut line = if self.needs_leading_newline {
            self.needs_leading_newline = false;
            "\n".to_string()
        } else {
            String::new()
        };
        line.push_str(
            &serde_json::to_string(entry)
                .map_err(|e| LedgerStoreError::Io(format!("entry serialization failed: {e}")))?,
        );
        line.push('\n');
        self.file.write_all(line.as_bytes()).map_err(io_err)?;
        // File is unbuffered in std, so write_all is the write;
        // sync_all is the durability barrier.
        self.file.sync_all().map_err(io_err)?;
        Ok(())
    }
}

struct ParsedFile {
    header: FileHeader,
    entries: Vec<LedgerEntry>,
    /// Byte length of the torn final line, when the strictness
    /// rules identify one (parse failure on the last line only).
    torn_tail_bytes: usize,
    /// Byte offset at which the valid prefix ends (== file length
    /// when nothing is torn).
    valid_prefix_len: usize,
    /// True when the file's final entry line lacks a trailing
    /// newline but parsed and is otherwise complete.
    last_line_unterminated: bool,
}

/// Splits raw file bytes into (header, entries), applying the
/// torn-tail rule. `strict` is for independent verification: a torn
/// tail is reported as corruption there instead of being measured
/// for truncation, because verification judges the artifact as-is.
fn parse_file(bytes: &[u8], strict: bool) -> Result<ParsedFile, LedgerStoreError> {
    let text = String::from_utf8(bytes.to_vec())
        .map_err(|_| LedgerStoreError::Corrupt("file is not valid UTF-8".into()))?;
    // Segment start offsets, splitting on '\n'. A trailing '\n'
    // yields a final empty segment, which is not a line.
    let mut segments: Vec<(usize, &str)> = Vec::new();
    let mut start = 0usize;
    for (i, b) in text.bytes().enumerate() {
        if b == b'\n' {
            segments.push((start, &text[start..i]));
            start = i + 1;
        }
    }
    let ends_with_newline = text.ends_with('\n') || text.is_empty();
    if start < text.len() {
        segments.push((start, &text[start..]));
    }
    if segments.is_empty() {
        return Err(LedgerStoreError::Corrupt("file is empty".into()));
    }
    let header: FileHeader = serde_json::from_str(segments[0].1)
        .map_err(|e| LedgerStoreError::Corrupt(format!("bad header line: {e}")))?;
    if header.format != LEDGER_FORMAT_NAME {
        return Err(LedgerStoreError::Corrupt(format!(
            "not a {LEDGER_FORMAT_NAME} file (format field is {:?})",
            header.format
        )));
    }
    if header.version != LEDGER_FORMAT_VERSION {
        return Err(LedgerStoreError::Corrupt(format!(
            "unsupported ledger format version {} (this build reads {})",
            header.version, LEDGER_FORMAT_VERSION
        )));
    }

    let mut entries = Vec::new();
    let mut torn_tail_bytes = 0usize;
    let mut valid_prefix_len = text.len();
    let entry_segments = &segments[1..];
    for (idx, (seg_start, seg)) in entry_segments.iter().enumerate() {
        let is_last = idx + 1 == entry_segments.len();
        if seg.is_empty() {
            return Err(LedgerStoreError::Corrupt(format!(
                "empty line at entry position {}",
                idx + 1
            )));
        }
        match serde_json::from_str::<LedgerEntry>(seg) {
            Ok(entry) => entries.push(entry),
            Err(e) => {
                if is_last && !strict {
                    // Torn write: a crash interrupted this append.
                    // Everything from this segment's start to EOF
                    // is the torn remainder.
                    torn_tail_bytes = text.len() - seg_start;
                    valid_prefix_len = *seg_start;
                    break;
                }
                if is_last {
                    return Err(LedgerStoreError::Corrupt(format!(
                        "final line does not parse as an entry (torn or tampered tail): {e}"
                    )));
                }
                return Err(LedgerStoreError::Corrupt(format!(
                    "entry line {} does not parse: {e}",
                    idx + 1
                )));
            }
        }
    }
    // Any non-empty file not ending in '\n' has an unterminated
    // last line (header-only files included): if it parsed, it is
    // kept, and the next append must terminate it first.
    let last_line_unterminated = torn_tail_bytes == 0 && !ends_with_newline;
    Ok(ParsedFile {
        header,
        entries,
        torn_tail_bytes,
        valid_prefix_len,
        last_line_unterminated,
    })
}

fn verifying_key_from_hex(hex_str: &str) -> Result<VerifyingKey, LedgerStoreError> {
    let bytes = hex::decode(hex_str)
        .map_err(|e| LedgerStoreError::Corrupt(format!("header verifying key is not hex: {e}")))?;
    let arr: [u8; 32] = bytes
        .as_slice()
        .try_into()
        .map_err(|_| LedgerStoreError::Corrupt("header verifying key is not 32 bytes".into()))?;
    VerifyingKey::from_bytes(&arr)
        .map_err(|e| LedgerStoreError::Corrupt(format!("header verifying key is invalid: {e}")))
}

/// Opens (or creates) the persistent ledger at `path` under
/// `authority`, applying the crash-recovery rule documented at the
/// top of this module. Returns the ready-to-use ledger (store
/// attached) and a report of what was loaded or recovered.
pub fn open(
    path: &Path,
    authority: SigningKey,
) -> Result<(ProofLedger, OpenReport), LedgerStoreError> {
    let expected_vk_hex = hex::encode(authority.verifying_key().to_bytes());

    let existing = if path.exists() {
        let mut buf = Vec::new();
        File::open(path)
            .and_then(|mut f| f.read_to_end(&mut buf))
            .map_err(io_err)?;
        if buf.is_empty() {
            None
        } else {
            Some(buf)
        }
    } else {
        None
    };

    let Some(bytes) = existing else {
        // Fresh ledger: header first, fsynced, then the store.
        let header = FileHeader {
            format: LEDGER_FORMAT_NAME.to_string(),
            version: LEDGER_FORMAT_VERSION,
            authority_verifying_key: expected_vk_hex,
        };
        let mut file = File::create(path).map_err(io_err)?;
        let line = serde_json::to_string(&header)
            .map_err(|e| LedgerStoreError::Io(format!("header serialization failed: {e}")))?;
        file.write_all(line.as_bytes()).map_err(io_err)?;
        file.write_all(b"\n").map_err(io_err)?;
        file.sync_all().map_err(io_err)?;
        drop(file);
        // Best-effort directory fsync so the creation itself is
        // durable; filesystems that refuse it are not fatal here.
        if let Some(parent) = path.parent() {
            if let Ok(dir) = File::open(parent) {
                let _ = dir.sync_all();
            }
        }
        let append_file = OpenOptions::new().append(true).open(path).map_err(io_err)?;
        let mut ledger = ProofLedger::with_authority(authority);
        ledger.store = Some(LedgerStore {
            file: append_file,
            path: path.to_path_buf(),
            needs_leading_newline: false,
        });
        return Ok((
            ledger,
            OpenReport {
                loaded_entries: 0,
                recovered_torn_bytes: 0,
            },
        ));
    };

    let parsed = parse_file(&bytes, false)?;
    if parsed.header.authority_verifying_key != expected_vk_hex {
        return Err(LedgerStoreError::AuthorityMismatch(format!(
            "file at {} belongs to authority {}, not the supplied key {}",
            path.display(),
            parsed.header.authority_verifying_key,
            expected_vk_hex
        )));
    }
    let loaded_entries = parsed.entries.len();
    // Nothing is trusted until the whole loaded prefix re-verifies.
    // A parseable-but-tampered entry (including the final one) fails
    // here and refuses the open — only UNPARSEABLE tails are torn.
    let mut ledger = ProofLedger::from_verified_entries(parsed.entries, Some(authority), None)
        .map_err(LedgerStoreError::ChainInvalid)?;

    if parsed.torn_tail_bytes > 0 {
        let file = OpenOptions::new().write(true).open(path).map_err(io_err)?;
        file.set_len(parsed.valid_prefix_len as u64)
            .map_err(io_err)?;
        file.sync_all().map_err(io_err)?;
        drop(file);
    }
    let append_file = OpenOptions::new().append(true).open(path).map_err(io_err)?;
    ledger.store = Some(LedgerStore {
        file: append_file,
        path: path.to_path_buf(),
        needs_leading_newline: parsed.last_line_unterminated,
    });

    let report = OpenReport {
        loaded_entries,
        recovered_torn_bytes: parsed.torn_tail_bytes,
    };
    if parsed.torn_tail_bytes > 0 {
        // The recovery itself is part of the record: a signed entry
        // states what was truncated and what prefix survived.
        let payload = format!(
            "torn tail truncated at open: {} bytes removed; verified prefix of {} entries recovered, tip {}",
            parsed.torn_tail_bytes,
            loaded_entries,
            ledger.tip_hash()
        );
        ledger.append(RECOVERY_EVENT, "ledger-store", payload.as_bytes(), None);
    }
    Ok((ledger, report))
}

/// The result of independently verifying a ledger file.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LedgerFileSummary {
    pub authority_verifying_key: String,
    pub entry_count: usize,
    pub tip_hash: String,
    pub last_checkpoint_sequence: Option<u64>,
    /// The tip the last checkpoint commits to (its `prev_hash`).
    pub last_checkpoint_committed_tip: Option<String>,
}

fn summarize(entries: &[LedgerEntry], vk_hex: &str) -> LedgerFileSummary {
    let mut last_checkpoint_sequence = None;
    let mut last_checkpoint_committed_tip = None;
    for e in entries {
        if e.event_type == CHECKPOINT_EVENT {
            last_checkpoint_sequence = Some(e.sequence);
            last_checkpoint_committed_tip = Some(e.prev_hash.clone());
        }
    }
    LedgerFileSummary {
        authority_verifying_key: vk_hex.to_string(),
        entry_count: entries.len(),
        tip_hash: entries
            .last()
            .map(|e| e.entry_hash.clone())
            .unwrap_or_else(|| super::GENESIS_HASH.to_string()),
        last_checkpoint_sequence,
        last_checkpoint_committed_tip,
    }
}

/// Independently verifies a ledger file end to end: header,
/// per-entry hashes, chain links, sequence, and every authority
/// signature, using only the verifying key in the file's header.
/// Detects alteration (hash/signature failure), removal and
/// reordering (sequence/link failure). Needs no signing key and no
/// live session.
pub fn verify_file(path: &Path) -> Result<LedgerFileSummary, LedgerStoreError> {
    let mut buf = Vec::new();
    File::open(path)
        .and_then(|mut f| f.read_to_end(&mut buf))
        .map_err(io_err)?;
    let parsed = parse_file(&buf, true)?;
    let vk = verifying_key_from_hex(&parsed.header.authority_verifying_key)?;
    let ledger = ProofLedger::from_verified_entries(parsed.entries, None, Some(vk))
        .map_err(LedgerStoreError::ChainInvalid)?;
    Ok(summarize(
        ledger.entries(),
        &parsed.header.authority_verifying_key,
    ))
}

/// The manifest written beside an exported ledger file. It restates
/// facts the chain itself proves, so a recipient can cross-check
/// the manifest against [`verify_file`] output instead of trusting
/// either one alone.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LedgerManifest {
    pub format: String,
    pub format_version: u32,
    /// File name of the ledger inside the export directory.
    pub ledger_file: String,
    pub authority_verifying_key: String,
    pub entry_count: usize,
    pub tip_hash: String,
    pub last_checkpoint_sequence: Option<u64>,
    pub last_checkpoint_committed_tip: Option<String>,
}

/// Exports a ledger: verifies the source file, copies it into
/// `export_dir`, and writes `manifest.json` beside it.
pub fn export(ledger_path: &Path, export_dir: &Path) -> Result<LedgerManifest, LedgerStoreError> {
    let summary = verify_file(ledger_path)?;
    std::fs::create_dir_all(export_dir).map_err(io_err)?;
    let file_name = ledger_path
        .file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_else(|| "ledger.jsonl".to_string());
    let dest = export_dir.join(&file_name);
    std::fs::copy(ledger_path, &dest).map_err(io_err)?;
    let manifest = LedgerManifest {
        format: EXPORT_FORMAT_NAME.to_string(),
        format_version: LEDGER_FORMAT_VERSION,
        ledger_file: file_name,
        authority_verifying_key: summary.authority_verifying_key.clone(),
        entry_count: summary.entry_count,
        tip_hash: summary.tip_hash.clone(),
        last_checkpoint_sequence: summary.last_checkpoint_sequence,
        last_checkpoint_committed_tip: summary.last_checkpoint_committed_tip.clone(),
    };
    let manifest_json = serde_json::to_string_pretty(&manifest)
        .map_err(|e| LedgerStoreError::Io(format!("manifest serialization failed: {e}")))?;
    let mut mf = File::create(export_dir.join("manifest.json")).map_err(io_err)?;
    mf.write_all(manifest_json.as_bytes()).map_err(io_err)?;
    mf.write_all(b"\n").map_err(io_err)?;
    mf.sync_all().map_err(io_err)?;
    Ok(manifest)
}

/// Verifies an export directory: the ledger file inside is verified
/// on its own, then every manifest field is cross-checked against
/// the verified summary. A manifest that disagrees with its chain
/// fails.
pub fn verify_export(export_dir: &Path) -> Result<LedgerFileSummary, LedgerStoreError> {
    let manifest_text = std::fs::read_to_string(export_dir.join("manifest.json"))
        .map_err(|e| LedgerStoreError::Corrupt(format!("cannot read manifest.json: {e}")))?;
    let manifest: LedgerManifest = serde_json::from_str(&manifest_text)
        .map_err(|e| LedgerStoreError::Corrupt(format!("bad manifest.json: {e}")))?;
    if manifest.format != EXPORT_FORMAT_NAME {
        return Err(LedgerStoreError::Corrupt(format!(
            "not a {EXPORT_FORMAT_NAME} manifest (format field is {:?})",
            manifest.format
        )));
    }
    let summary = verify_file(&export_dir.join(&manifest.ledger_file))?;
    let agrees = summary.authority_verifying_key == manifest.authority_verifying_key
        && summary.entry_count == manifest.entry_count
        && summary.tip_hash == manifest.tip_hash
        && summary.last_checkpoint_sequence == manifest.last_checkpoint_sequence
        && summary.last_checkpoint_committed_tip == manifest.last_checkpoint_committed_tip;
    if !agrees {
        return Err(LedgerStoreError::ChainInvalid(
            "manifest disagrees with the verified chain (tip, count, or checkpoint mismatch)"
                .into(),
        ));
    }
    Ok(summary)
}

pub const CHECKPOINT_SIDECAR_FORMAT: &str = "mack-proof-ledger-checkpoint";

/// An extracted signed checkpoint, kept apart from the ledger
/// file as an external anchor (v0.12.0). Every field is copied
/// from the checkpoint entry as it stands in the verified
/// ledger — including the authority's signature over that
/// entry — so producing one needs no private key, and checking
/// one needs only the authority's public key.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CheckpointSidecar {
    pub format: String,
    pub format_version: u32,
    /// Hex Ed25519 verifying key of the ledger authority.
    pub authority_verifying_key: String,
    /// Sequence of the checkpoint entry itself.
    pub checkpoint_sequence: u64,
    /// The entry count the checkpoint commits to (its sequence
    /// minus one: the chain state BEFORE the checkpoint entry).
    pub committed_sequence: u64,
    /// The head hash the checkpoint commits to (the checkpoint
    /// entry's `prev_hash`).
    pub committed_tip_hash: String,
    /// The ledger head THROUGH the checkpoint: the checkpoint
    /// entry's own `entry_hash`. A ledger anchored by this
    /// sidecar must end exactly here.
    pub head_hash: String,
    /// Record count through the checkpoint (== checkpoint
    /// sequence; sequences are 1-based and contiguous).
    pub record_count: u64,
    /// Hex Ed25519 signature of the checkpoint entry, copied
    /// from the entry itself.
    pub authority_signature: String,
}

/// Loads a ledger file and fully re-verifies its chain,
/// returning the header's authority key (hex) and the verified
/// entries. Shared by the anchoring operations.
fn load_verified(path: &Path) -> Result<(String, Vec<LedgerEntry>), LedgerStoreError> {
    let mut buf = Vec::new();
    File::open(path)
        .and_then(|mut f| f.read_to_end(&mut buf))
        .map_err(io_err)?;
    let parsed = parse_file(&buf, true)?;
    let vk = verifying_key_from_hex(&parsed.header.authority_verifying_key)?;
    let ledger = ProofLedger::from_verified_entries(parsed.entries, None, Some(vk))
        .map_err(LedgerStoreError::ChainInvalid)?;
    Ok((
        parsed.header.authority_verifying_key,
        ledger.entries().to_vec(),
    ))
}

/// Extracts the latest signed checkpoint entry from a verified
/// ledger file into a [`CheckpointSidecar`]. The file is fully
/// verified first; a ledger with no checkpoint entry is
/// refused.
pub fn extract_checkpoint(path: &Path) -> Result<CheckpointSidecar, LedgerStoreError> {
    let (vk_hex, entries) = load_verified(path)?;
    let checkpoint = entries
        .iter()
        .rev()
        .find(|e| e.event_type == CHECKPOINT_EVENT)
        .ok_or_else(|| {
            LedgerStoreError::Corrupt("ledger contains no checkpoint entry to extract".to_string())
        })?;
    if checkpoint.authority_signature.is_empty() {
        return Err(LedgerStoreError::Corrupt(
            "checkpoint entry carries no authority signature (unsigned ledger)".to_string(),
        ));
    }
    Ok(CheckpointSidecar {
        format: CHECKPOINT_SIDECAR_FORMAT.to_string(),
        format_version: LEDGER_FORMAT_VERSION,
        authority_verifying_key: vk_hex,
        checkpoint_sequence: checkpoint.sequence,
        committed_sequence: checkpoint.sequence - 1,
        committed_tip_hash: checkpoint.prev_hash.clone(),
        head_hash: checkpoint.entry_hash.clone(),
        record_count: checkpoint.sequence,
        authority_signature: hex::encode(&checkpoint.authority_signature),
    })
}

/// Verifies a ledger file against an extracted checkpoint
/// sidecar. Steps, in order: the sidecar's signature is
/// verified against the authority key it names; the ledger
/// file's chain is fully re-verified; the file's authority
/// must be the sidecar's authority; and the file must end
/// EXACTLY at the checkpoint — fewer records is
/// [`LedgerStoreError::TailTruncation`] (naming both counts),
/// more records or a different head is
/// [`LedgerStoreError::CheckpointMismatch`], as is a file
/// whose checkpoint entry is not the entry the sidecar
/// carries.
pub fn verify_against_checkpoint(
    path: &Path,
    sidecar: &CheckpointSidecar,
) -> Result<LedgerFileSummary, LedgerStoreError> {
    use ed25519_dalek::{Signature, Verifier};
    if sidecar.format != CHECKPOINT_SIDECAR_FORMAT {
        return Err(LedgerStoreError::CheckpointMismatch(format!(
            "not a {CHECKPOINT_SIDECAR_FORMAT} sidecar (format field is {:?})",
            sidecar.format
        )));
    }
    // The sidecar's own signature first: it must be a genuine
    // authority signature over the checkpoint entry hash it
    // carries, under the authority key it names.
    let vk = verifying_key_from_hex(&sidecar.authority_verifying_key)?;
    let sig_bytes = hex::decode(&sidecar.authority_signature).map_err(|e| {
        LedgerStoreError::CheckpointSignature(format!("sidecar signature is not hex: {e}"))
    })?;
    let sig_arr: [u8; 64] = sig_bytes.as_slice().try_into().map_err(|_| {
        LedgerStoreError::CheckpointSignature("sidecar signature is not 64 bytes".to_string())
    })?;
    vk.verify(
        sidecar.head_hash.as_bytes(),
        &Signature::from_bytes(&sig_arr),
    )
    .map_err(|_| {
        LedgerStoreError::CheckpointSignature(
            "sidecar signature does not verify under the authority key it names".to_string(),
        )
    })?;

    let (vk_hex, entries) = load_verified(path)?;
    if vk_hex != sidecar.authority_verifying_key {
        return Err(LedgerStoreError::CheckpointMismatch(format!(
            "ledger belongs to authority {vk_hex}, sidecar to {}",
            sidecar.authority_verifying_key
        )));
    }
    let file_count = entries.len() as u64;
    if file_count < sidecar.record_count {
        return Err(LedgerStoreError::TailTruncation(format!(
            "ledger file holds {file_count} records; the checkpoint commits to {} \
             ({} record(s) missing from the tail)",
            sidecar.record_count,
            sidecar.record_count - file_count
        )));
    }
    if file_count > sidecar.record_count {
        return Err(LedgerStoreError::CheckpointMismatch(format!(
            "ledger file holds {file_count} records; the checkpoint commits to {} \
             (the file extends past the checkpoint)",
            sidecar.record_count
        )));
    }
    let summary = summarize(&entries, &vk_hex);
    if summary.tip_hash != sidecar.head_hash {
        return Err(LedgerStoreError::CheckpointMismatch(format!(
            "ledger head {} does not equal the checkpoint head {}",
            summary.tip_hash, sidecar.head_hash
        )));
    }
    // The checkpoint entry in the file must be the very entry
    // the sidecar carries (same sequence, same signature).
    let entry = entries
        .iter()
        .find(|e| e.sequence == sidecar.checkpoint_sequence)
        .ok_or_else(|| {
            LedgerStoreError::CheckpointMismatch(
                "checkpoint entry absent despite a matching record count".to_string(),
            )
        })?;
    if entry.event_type != CHECKPOINT_EVENT
        || hex::encode(&entry.authority_signature) != sidecar.authority_signature
    {
        return Err(LedgerStoreError::CheckpointMismatch(
            "the file's checkpoint entry is not the entry the sidecar carries".to_string(),
        ));
    }
    Ok(summary)
}
