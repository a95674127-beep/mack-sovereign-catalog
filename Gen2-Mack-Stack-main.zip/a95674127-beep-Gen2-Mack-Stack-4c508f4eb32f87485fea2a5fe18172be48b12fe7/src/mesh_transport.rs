//! Mesh transport encryption (v0.14.0) — the encrypted
//! form a share travels in. Assembled from the lab-held
//! Infinity paste set at the operator's order, rebuilt on
//! the crate's existing AEAD instead of adding a second
//! cipher stack: the paste used AES-256-GCM; this module
//! uses XChaCha20-Poly1305, the crate's standard AEAD
//! (see [`crate::vault::envelope_crypto`]), and no new
//! dependency was added.
//!
//! Each share is encrypted under its own key, derived with
//! HKDF-SHA256 (RFC 5869) from the master key, the share's
//! tag as extract salt, and lane/label/index bound in the
//! expand info — with the same four fields bound again as
//! AEAD associated data, so a ciphertext cannot be moved to
//! another lane, label, or share index without failing
//! authentication. The nonce is a fresh random 24 bytes per
//! share.
//!
//! Two paste choices were deliberately NOT carried over:
//! - The separate unkeyed SHA-384 "hash" field. AEAD
//!   already authenticates the ciphertext and the bound
//!   fields; an unkeyed hash checked before decryption
//!   adds no security property and invites treating it as
//!   one. Authentication failure here is the AEAD's verdict
//!   and nothing else's.
//! - `/dev/urandom` reads. Randomness comes from `OsRng`,
//!   the crate's standard source.
//!
//! HONEST SCOPE: the master key is the caller's problem —
//! in production it must come from a real key exchange,
//! never be hardcoded, and be zeroized after use
//! ([`zeroize_key`]). This module authenticates shares in
//! flight; it does not decide which shares are real (that
//! is the receiver's session state) and it does not hide
//! traffic shape — that is the cover layer's job
//! ([`crate::infinity_mesh`]).

use chacha20poly1305::aead::{Aead, KeyInit, Payload};
use chacha20poly1305::{XChaCha20Poly1305, XNonce};
use hkdf::Hkdf;
use rand::rngs::OsRng;
use rand::RngCore;
use sha2::Sha256;
use zeroize::{Zeroize, Zeroizing};

/// One share in encrypted flight form.
#[derive(Clone)]
pub struct EncryptedShare {
    pub tag: [u8; 16],
    pub lane: u8,
    pub label: u8,
    pub x: u8,
    pub nonce: [u8; 24],
    pub ciphertext: Vec<u8>,
}

fn derive_key(
    master: &[u8; 32],
    tag: &[u8; 16],
    lane: u8,
    label: u8,
    x: u8,
) -> Zeroizing<[u8; 32]> {
    // Review finding (2026-11-19): the v0.14.2 derivation was a
    // raw SHA-256 over master || tag || lane || label || x — a
    // bare hash concatenation, not a KDF. Replaced with
    // HKDF-SHA256 (RFC 5869): the tag is the extract salt, the
    // master is the input keying material, and lane/label/x are
    // bound in the expand `info` under a module domain string.
    // The same four fields remain bound a second time as AEAD
    // associated data (see `aad_for`).
    //
    // Second review finding (2026-11-19): the derived key was a
    // plain `[u8; 32]` that lingered in memory after use. It is
    // now returned in a `Zeroizing` wrapper and wiped on drop at
    // both call sites.
    let hk = Hkdf::<Sha256>::new(Some(tag.as_slice()), master.as_slice());
    let mut info = Vec::with_capacity(28);
    info.extend_from_slice(b"mack-gen2/mesh-transport/v1");
    info.extend_from_slice(&[lane, label, x]);
    let mut key = Zeroizing::new([0u8; 32]);
    hk.expand(&info, key.as_mut())
        .expect("32 bytes is a valid HKDF-SHA256 output length");
    key
}

fn aad_for(tag: &[u8; 16], lane: u8, label: u8, x: u8) -> [u8; 19] {
    let mut aad = [0u8; 19];
    aad[..16].copy_from_slice(tag);
    aad[16] = lane;
    aad[17] = label;
    aad[18] = x;
    aad
}

/// Encrypts one share's plaintext under its per-share key.
/// The plaintext is typically a share encoding whose first
/// byte(s) the receiver interprets after decryption.
pub fn encrypt_share(
    master: &[u8; 32],
    tag: [u8; 16],
    lane: u8,
    label: u8,
    x: u8,
    plaintext: &[u8],
) -> EncryptedShare {
    let key_bytes = derive_key(master, &tag, lane, label, x);
    let cipher = XChaCha20Poly1305::new_from_slice(&*key_bytes)
        .expect("32-byte key is a valid XChaCha20-Poly1305 key");
    let mut nonce = [0u8; 24];
    OsRng.fill_bytes(&mut nonce);
    let aad = aad_for(&tag, lane, label, x);
    let ciphertext = cipher
        .encrypt(
            XNonce::from_slice(&nonce),
            Payload {
                msg: plaintext,
                aad: &aad,
            },
        )
        .expect("XChaCha20-Poly1305 encryption does not fail on in-memory input");
    EncryptedShare {
        tag,
        lane,
        label,
        x,
        nonce,
        ciphertext,
    }
}

/// Decrypts a share. Returns `None` on any authentication
/// failure — tampered ciphertext, wrong master key, or a
/// share moved to a different lane, label, or index than
/// it was encrypted for. The caller drops `None` silently.
///
/// Review finding (2026-11-19): the plaintext came back as a
/// plain `Vec<u8>` that lingered in memory after use. It is
/// now returned in a `Zeroizing` wrapper and wiped on drop.
pub fn decrypt_share(master: &[u8; 32], enc: &EncryptedShare) -> Option<Zeroizing<Vec<u8>>> {
    let key_bytes = derive_key(master, &enc.tag, enc.lane, enc.label, enc.x);
    let cipher = XChaCha20Poly1305::new_from_slice(&*key_bytes).ok()?;
    let aad = aad_for(&enc.tag, enc.lane, enc.label, enc.x);
    cipher
        .decrypt(
            XNonce::from_slice(&enc.nonce),
            Payload {
                msg: &enc.ciphertext,
                aad: &aad,
            },
        )
        .ok()
        .map(Zeroizing::new)
}

/// Zeroizes a master key in place after use.
pub fn zeroize_key(key: &mut [u8; 32]) {
    key.zeroize();
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dual_secret::{Engine, SecretKind, Share};
    use std::time::Instant;
    use zeroize::Zeroizing;

    fn master() -> [u8; 32] {
        let mut m = [0u8; 32];
        OsRng.fill_bytes(&mut m);
        m
    }

    #[test]
    fn roundtrip() {
        let m = master();
        let enc = encrypt_share(&m, [3u8; 16], 7, 2, 4, b"share-payload-bytes");
        let dec = decrypt_share(&m, &enc).expect("own share must decrypt");
        assert_eq!(&dec[..], b"share-payload-bytes");
    }

    #[test]
    fn tampered_ciphertext_fails() {
        let m = master();
        let mut enc = encrypt_share(&m, [3u8; 16], 7, 2, 4, b"share-payload-bytes");
        enc.ciphertext[0] ^= 0xff;
        assert!(decrypt_share(&m, &enc).is_none());
    }

    #[test]
    fn wrong_master_fails() {
        let m = master();
        let enc = encrypt_share(&m, [3u8; 16], 7, 2, 4, b"share-payload-bytes");
        let other = master();
        assert!(decrypt_share(&other, &enc).is_none());
    }

    #[test]
    fn moved_lane_fails_aad_binding() {
        let m = master();
        let mut enc = encrypt_share(&m, [3u8; 16], 7, 2, 4, b"share-payload-bytes");
        enc.lane = 8;
        assert!(decrypt_share(&m, &enc).is_none());
        let mut enc2 = encrypt_share(&m, [3u8; 16], 7, 2, 4, b"share-payload-bytes");
        enc2.x = 5;
        assert!(decrypt_share(&m, &enc2).is_none());
    }

    #[test]
    fn nonce_is_fresh_per_share() {
        let m = master();
        let a = encrypt_share(&m, [3u8; 16], 7, 2, 4, b"same-plaintext");
        let b = encrypt_share(&m, [3u8; 16], 7, 2, 4, b"same-plaintext");
        assert_ne!(a.nonce, b.nonce);
        assert_ne!(a.ciphertext, b.ciphertext);
    }

    #[test]
    fn end_to_end_engine_over_transport() {
        // The assembled path: engine splits, transport
        // encrypts every share, receiver decrypts and the
        // engine reconstructs the payload.
        let m = master();
        let mut engine = Engine::new([9u8; 32]);
        let now = Instant::now();
        let payload = b"assembled-system-end-to-end";
        let (sid, scheduled) = engine.create_session(payload, now).unwrap();
        let mut collected: Vec<Share> = Vec::new();
        for s in &scheduled {
            // Plaintext form: [kind_byte || y...]; kind byte
            // 0 = A, 1 = B.
            let mut plain = Vec::with_capacity(1 + s.share.y.len());
            plain.push(if s.share.kind == SecretKind::B { 1 } else { 0 });
            plain.extend_from_slice(&s.share.y);
            let enc = encrypt_share(&m, [1u8; 16], s.lane as u8, 0, s.share.x, &plain);
            let dec = decrypt_share(&m, &enc).expect("own share must decrypt");
            let kind = if dec[0] == 1 {
                SecretKind::B
            } else {
                SecretKind::A
            };
            collected.push(Share {
                x: s.share.x,
                y: Zeroizing::new(dec[1..].to_vec()),
                kind,
            });
        }
        let subset: Vec<Share> = collected
            .iter()
            .filter(|s| s.kind == SecretKind::A)
            .take(3)
            .chain(collected.iter().filter(|s| s.kind == SecretKind::B).take(3))
            .map(|s| Share {
                x: s.x,
                y: Zeroizing::new(s.y.to_vec()),
                kind: s.kind,
            })
            .collect();
        let out = engine.attempt_reconstruct(&sid, subset, 0, now).unwrap();
        assert_eq!(&*out, payload);
    }
}
