//! Per-host handle table (v0.12.0) — the `mack-proxy` binary's
//! source of truth for which handle is current for each allowed
//! host, whether it has burned, and whether the session is
//! closed.
//!
//! Before v0.12.0 this state was a bare `HashMap<String, String>`
//! in the proxy binary, and the burn/successor invariants lived
//! only in handler code order. The table makes them structural:
//!
//! - A handle burns exactly once: [`HandleTable::burn`] succeeds
//!   for a given token only on the first call, however many
//!   callers race it (the check-and-mark happens under one lock).
//! - A successor exists only after its predecessor burned:
//!   [`HandleTable::install_current`] refuses to install a new
//!   current handle for a host while the existing one is
//!   unburned — for the initial mint (no current exists) and for
//!   successors alike; one rule, both cases.
//! - Session close is final: after [`HandleTable::close`], burns
//!   fail with [`BurnError::Closed`] and no token resolves. A
//!   burn that completed before the close stands; the ordering
//!   is decided by the lock, not by timing luck.
//!
//! The burn the table records mirrors the authoritative burn
//! inside `BlindEgressProxy::execute_egress` (the scoped
//! handle's `consumed` flag, checked against sentinel verdict,
//! scope, and expiry under the session-state lock). Handlers
//! call [`HandleTable::burn`] only after a successful swap, so
//! the two records cannot disagree about a completed request:
//! resolution reads this table, the swap burns there first, and
//! this table is marked before any successor is minted.
//!
//! Concurrency: the table is internally synchronized and cheap
//! to clone (an `Arc` around the state). Its synchronization
//! primitives come through the standard loom shim —
//! `loom::sync` under `--cfg loom`, `std::sync` otherwise — so
//! the state machine is model-checked by the loom tests at the
//! bottom of this file (dev-dependency only; run with
//! `RUSTFLAGS="--cfg loom" cargo test --lib handle_table`).
//! Normal builds use the std primitives and behave exactly as a
//! plain mutex-guarded map.

#[cfg(loom)]
use loom::sync::{Arc, Mutex};
#[cfg(not(loom))]
use std::sync::{Arc, Mutex};

use std::collections::HashMap;
use std::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BurnError {
    /// No handle was ever installed for this host.
    UnknownHost,
    /// The presented token is not the host's current handle.
    TokenMismatch,
    /// The current handle has already burned (single-use).
    AlreadyBurned,
    /// The session is closed; no further burns are possible.
    Closed,
}

impl fmt::Display for BurnError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnknownHost => write!(f, "no handle installed for this host"),
            Self::TokenMismatch => write!(f, "token is not the host's current handle"),
            Self::AlreadyBurned => write!(f, "handle already burned (single-use)"),
            Self::Closed => write!(f, "session is closed"),
        }
    }
}

impl std::error::Error for BurnError {}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InstallError {
    /// A current handle exists for this host and has not burned
    /// yet; a successor may only follow a burn.
    UnburnedCurrentExists,
    /// The session is closed; no new handles are installed.
    Closed,
}

impl fmt::Display for InstallError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnburnedCurrentExists => {
                write!(f, "an unburned current handle already exists for this host")
            }
            Self::Closed => write!(f, "session is closed"),
        }
    }
}

impl std::error::Error for InstallError {}

#[derive(Debug)]
struct HandleRecord {
    token: String,
    burned: bool,
}

#[derive(Debug, Default)]
struct Inner {
    current: HashMap<String, HandleRecord>,
    closed: bool,
}

/// The per-host handle state for one proxy session. See the
/// module documentation for the invariants.
#[derive(Debug, Clone, Default)]
pub struct HandleTable {
    inner: Arc<Mutex<Inner>>,
}

impl HandleTable {
    pub fn new() -> Self {
        Self::default()
    }

    /// Installs `token` as the current handle for `host`. Used
    /// for the initial per-host mint and for successors alike:
    /// it succeeds only when the host has no current handle or
    /// its current handle has burned.
    pub fn install_current(&self, host: &str, token: String) -> Result<(), InstallError> {
        let mut inner = self.inner.lock().unwrap();
        if inner.closed {
            return Err(InstallError::Closed);
        }
        if let Some(rec) = inner.current.get(host) {
            if !rec.burned {
                return Err(InstallError::UnburnedCurrentExists);
            }
        }
        inner.current.insert(
            host.to_string(),
            HandleRecord {
                token,
                burned: false,
            },
        );
        Ok(())
    }

    /// The token a presented session token resolves to for
    /// `host`: the current handle, if one is installed, unburned,
    /// and the session is open.
    pub fn current_token(&self, host: &str) -> Option<String> {
        let inner = self.inner.lock().unwrap();
        if inner.closed {
            return None;
        }
        inner
            .current
            .get(host)
            .filter(|rec| !rec.burned)
            .map(|rec| rec.token.clone())
    }

    /// Marks the host's current handle burned. Succeeds exactly
    /// once per installed handle: the token must be the current
    /// one, it must not have burned before, and the session must
    /// be open.
    pub fn burn(&self, host: &str, token: &str) -> Result<(), BurnError> {
        let mut inner = self.inner.lock().unwrap();
        if inner.closed {
            return Err(BurnError::Closed);
        }
        let rec = inner.current.get_mut(host).ok_or(BurnError::UnknownHost)?;
        if rec.token != token {
            return Err(BurnError::TokenMismatch);
        }
        if rec.burned {
            return Err(BurnError::AlreadyBurned);
        }
        rec.burned = true;
        Ok(())
    }

    /// Closes the session: no further burns, installs, or
    /// resolutions. Idempotent.
    pub fn close(&self) {
        self.inner.lock().unwrap().closed = true;
    }

    pub fn is_closed(&self) -> bool {
        self.inner.lock().unwrap().closed
    }
}

/// Plain unit tests — std builds only. Under `--cfg loom` the
/// table's primitives are loom's, which panic outside a
/// `loom::model` execution; the loom models below cover the
/// same flows there.
#[cfg(all(test, not(loom)))]
mod tests {
    use super::*;

    #[test]
    fn install_resolve_burn_successor_flow() {
        let table = HandleTable::new();
        assert_eq!(table.current_token("example.com"), None);
        table
            .install_current("example.com", "tok-1".to_string())
            .unwrap();
        assert_eq!(table.current_token("example.com").as_deref(), Some("tok-1"));
        // A successor cannot be installed while tok-1 is unburned.
        assert_eq!(
            table.install_current("example.com", "tok-2".to_string()),
            Err(InstallError::UnburnedCurrentExists)
        );
        // Wrong token cannot burn; the right one burns exactly once.
        assert_eq!(
            table.burn("example.com", "forged"),
            Err(BurnError::TokenMismatch)
        );
        table.burn("example.com", "tok-1").unwrap();
        assert_eq!(
            table.burn("example.com", "tok-1"),
            Err(BurnError::AlreadyBurned)
        );
        assert_eq!(table.current_token("example.com"), None);
        // After the burn, the successor installs and resolves.
        table
            .install_current("example.com", "tok-2".to_string())
            .unwrap();
        assert_eq!(table.current_token("example.com").as_deref(), Some("tok-2"));
        // Hosts are independent.
        assert_eq!(
            table.burn("other.example", "tok-2"),
            Err(BurnError::UnknownHost)
        );
    }

    #[test]
    fn close_is_final_for_burns_installs_and_resolution() {
        let table = HandleTable::new();
        table.install_current("h", "tok".to_string()).unwrap();
        assert!(!table.is_closed());
        table.close();
        assert!(table.is_closed());
        assert_eq!(table.burn("h", "tok"), Err(BurnError::Closed));
        assert_eq!(table.current_token("h"), None);
        assert_eq!(
            table.install_current("h", "tok-2".to_string()),
            Err(InstallError::Closed)
        );
        table.close(); // idempotent
    }
}

/// Loom concurrency models. These compile and run ONLY under
/// `--cfg loom` (`RUSTFLAGS="--cfg loom" cargo test --lib
/// handle_table`); normal builds never see them. Each model
/// asserts the strong form of its property — where ordering
/// matters, the model itself establishes the order with a
/// Release/Acquire atomic flag (loom 0.7's `Barrier` is an
/// unimplemented stub that panics, so it cannot be used)
/// instead of accepting either outcome.
#[cfg(all(test, loom))]
mod loom_models {
    use super::*;
    use loom::sync::atomic::{AtomicBool, Ordering};

    /// Spins until `flag` is set. The flag's Release store /
    /// Acquire load pair is the happens-before edge that orders
    /// the two sides of models (b1) and (b2).
    fn wait_for(flag: &AtomicBool) {
        while !flag.load(Ordering::Acquire) {
            loom::thread::yield_now();
        }
    }

    /// (a) Two racing burns of the same handle: exactly one
    /// succeeds; the loser observes AlreadyBurned.
    #[test]
    fn racing_burns_exactly_one_succeeds() {
        loom::model(|| {
            let table = HandleTable::new();
            table.install_current("h", "tok".to_string()).unwrap();
            let t1 = table.clone();
            let t2 = table.clone();
            let h1 = loom::thread::spawn(move || t1.burn("h", "tok"));
            let h2 = loom::thread::spawn(move || t2.burn("h", "tok"));
            let r1 = h1.join().unwrap();
            let r2 = h2.join().unwrap();
            let oks = [&r1, &r2].iter().filter(|r| r.is_ok()).count();
            assert_eq!(oks, 1, "exactly one racing burn may succeed: {r1:?} {r2:?}");
            let loser = if r1.is_err() { &r1 } else { &r2 };
            assert_eq!(loser.as_ref().unwrap_err(), &BurnError::AlreadyBurned);
        });
    }

    /// (b1) A burn ordered strictly AFTER a completed close
    /// fails with Closed. The atomic flag orders the
    /// operations: the burner attempts its burn only after
    /// observing the flag the closer sets once `close()` has
    /// returned, so the burn is ordered after the close by a
    /// real happens-before edge — never by timing luck.
    #[test]
    fn burn_ordered_after_close_fails() {
        loom::model(|| {
            let table = HandleTable::new();
            table.install_current("h", "tok".to_string()).unwrap();
            let closed_flag = Arc::new(AtomicBool::new(false));
            let t_close = table.clone();
            let f_close = closed_flag.clone();
            let closer = loom::thread::spawn(move || {
                t_close.close();
                f_close.store(true, Ordering::Release);
            });
            let t_burn = table.clone();
            let burner = loom::thread::spawn(move || {
                wait_for(&closed_flag);
                t_burn.burn("h", "tok")
            });
            closer.join().unwrap();
            let result = burner.join().unwrap();
            assert_eq!(
                result,
                Err(BurnError::Closed),
                "no burn may succeed once close has completed"
            );
        });
    }

    /// (b2) The complementary order: a burn that completes
    /// BEFORE close begins succeeds — close is final only for
    /// what follows it. The closer waits for the flag the
    /// burner sets after its burn has returned.
    #[test]
    fn burn_completed_before_close_succeeds() {
        loom::model(|| {
            let table = HandleTable::new();
            table.install_current("h", "tok".to_string()).unwrap();
            let burned_flag = Arc::new(AtomicBool::new(false));
            let t_burn = table.clone();
            let f_burn = burned_flag.clone();
            let burner = loom::thread::spawn(move || {
                let r = t_burn.burn("h", "tok");
                f_burn.store(true, Ordering::Release);
                r
            });
            let t_close = table.clone();
            let closer = loom::thread::spawn(move || {
                wait_for(&burned_flag);
                t_close.close();
            });
            let result = burner.join().unwrap();
            closer.join().unwrap();
            assert_eq!(result, Ok(()), "a burn completed before close must stand");
            assert!(table.is_closed());
        });
    }

    /// (c) Successor installation racing the predecessor's
    /// burn: the install may succeed ONLY if the burn did —
    /// a successor can never exist ahead of its predecessor's
    /// burn. (The serial orderings are covered by the unit
    /// tests above; this model checks the racing case.)
    #[test]
    fn successor_install_never_precedes_burn() {
        loom::model(|| {
            let table = HandleTable::new();
            table.install_current("h", "tok-1".to_string()).unwrap();
            let t_burn = table.clone();
            let t_install = table.clone();
            let burner = loom::thread::spawn(move || t_burn.burn("h", "tok-1"));
            let installer =
                loom::thread::spawn(move || t_install.install_current("h", "tok-2".to_string()));
            let burn_result = burner.join().unwrap();
            let install_result = installer.join().unwrap();
            if install_result.is_ok() {
                assert_eq!(
                    burn_result,
                    Ok(()),
                    "a successor was installed but its predecessor never burned"
                );
                assert_eq!(table.current_token("h").as_deref(), Some("tok-2"));
            } else {
                assert_eq!(
                    install_result,
                    Err(InstallError::UnburnedCurrentExists),
                    "the only lawful refusal is an unburned predecessor"
                );
            }
        });
    }
}
