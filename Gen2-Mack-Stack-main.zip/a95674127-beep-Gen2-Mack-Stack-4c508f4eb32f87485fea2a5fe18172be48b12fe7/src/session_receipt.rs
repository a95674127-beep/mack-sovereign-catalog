//! Runtime session receipt (v0.12.0) — a signed statement the
//! `mack-proxy` emits at shutdown, binding the run's evidence
//! together: the crate version, a digest of the confinement
//! policy actually applied to the child, the session ledger's
//! final head hash and record count, and a real SHA-256 of the
//! proxy executable that ran. It is signed with the same key
//! that signed the session ledger, and the receipt records
//! which key that was ([`KEY_PROVENANCE_AUTHORITY`] when the
//! operator's persistent-ledger authority key signed, or
//! [`KEY_PROVENANCE_SESSION`] for an in-memory session's
//! ephemeral key — in which case the receipt is verifiable
//! only against the verifying key printed in the receipt
//! itself, and proves correspondingly less).
//!
//! The binary hash is MEASURED at receipt time by hashing
//! `std::env::current_exe()`; it is never a placeholder and
//! never a constant. The policy digest is a SHA-256 over a
//! canonical string the caller builds from the actual
//! confinement values used for the child (see
//! [`ConfinementPolicySummary`]) — the receipt binds the
//! claim, and the claim is assembled from the run's real
//! configuration, so a receipt cannot quietly describe a
//! different run.

use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::io::Read;

/// `key_provenance` value when the ledger authority key (the
/// operator-custodied key file of a persistent ledger) signed.
pub const KEY_PROVENANCE_AUTHORITY: &str = "authority";
/// `key_provenance` value when a per-session ephemeral key
/// (in-memory ledger) signed.
pub const KEY_PROVENANCE_SESSION: &str = "session-ephemeral";

/// The confinement values a session actually ran under, as
/// labeled strings assembled by the caller from its real
/// configuration and run report. [`policy_digest`] hashes the
/// canonical form; the receipt binds that digest.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ConfinementPolicySummary {
    /// Landlock ruleset summary (filesystem grants, network
    /// port grants, compatibility posture).
    pub landlock: String,
    /// Resource-governor rlimit values applied in pre_exec.
    pub rlimits: String,
    /// Seccomp workload-profile identifier.
    pub seccomp_profile: String,
    /// Inherited-FD hygiene steps applied in pre_exec.
    pub fd_hygiene: String,
    /// Cgroup layer outcome, exactly as the run reported it
    /// (applied with its limits, or not applied with the
    /// reason).
    pub cgroup: String,
}

impl ConfinementPolicySummary {
    /// Canonical single-string form, one labeled line per
    /// layer, in a fixed order. The digest binds this string.
    pub fn canonical(&self) -> String {
        format!(
            "landlock: {}\nrlimits: {}\nseccomp: {}\nfd-hygiene: {}\ncgroup: {}",
            self.landlock, self.rlimits, self.seccomp_profile, self.fd_hygiene, self.cgroup
        )
    }
}

/// SHA-256 (hex) of the summary's canonical form.
pub fn policy_digest(summary: &ConfinementPolicySummary) -> String {
    format!("{:x}", Sha256::digest(summary.canonical().as_bytes()))
}

/// Measures the running executable: streams
/// `std::env::current_exe()` through SHA-256 and returns the
/// hex digest. This is the value the receipt binds as
/// `proxy_binary_sha256` — measured, never asserted.
pub fn current_exe_sha256() -> Result<String, String> {
    let exe = std::env::current_exe()
        .map_err(|e| format!("cannot locate the running executable: {e}"))?;
    let mut file =
        std::fs::File::open(&exe).map_err(|e| format!("cannot open {}: {e}", exe.display()))?;
    let mut hasher = Sha256::new();
    let mut buf = [0u8; 8192];
    loop {
        let n = file
            .read(&mut buf)
            .map_err(|e| format!("cannot read {}: {e}", exe.display()))?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
    }
    Ok(format!("{:x}", hasher.finalize()))
}

fn push_field(hasher: &mut Sha256, bytes: &[u8]) {
    hasher.update((bytes.len() as u64).to_be_bytes());
    hasher.update(bytes);
}

/// The signed digest of a receipt's bound fields:
/// domain-tagged, length-prefixed, in a fixed order (the same
/// anti-collision encoding discipline as the ledger's entry
/// digest). Defined on the receipt itself so signing and
/// verification can never drift apart.
fn receipt_digest(receipt: &SessionReceipt) -> [u8; 32] {
    let mut h = Sha256::new();
    h.update(b"mack-session-receipt/v1");
    push_field(&mut h, receipt.version.as_bytes());
    push_field(&mut h, receipt.policy_digest.as_bytes());
    push_field(&mut h, receipt.ledger_head_hash.as_bytes());
    push_field(&mut h, &receipt.ledger_record_count.to_be_bytes());
    push_field(&mut h, receipt.proxy_binary_sha256.as_bytes());
    push_field(&mut h, &receipt.unix_timestamp.to_be_bytes());
    push_field(&mut h, receipt.key_provenance.as_bytes());
    push_field(&mut h, receipt.authority_verifying_key.as_bytes());
    h.finalize().into()
}

/// A signed session receipt. Serialized as JSON by the proxy
/// (stdout, and `<ledger path>.receipt.json` for persistent
/// sessions). Verify with [`SessionReceipt::verify`] against
/// the ledger authority's verifying key.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SessionReceipt {
    /// Crate version of the proxy that ran the session.
    pub version: String,
    /// [`policy_digest`] of the confinement actually applied.
    pub policy_digest: String,
    /// The session ledger's tip hash after its final
    /// checkpoint.
    pub ledger_head_hash: String,
    /// The session ledger's entry count after its final
    /// checkpoint.
    pub ledger_record_count: u64,
    /// Measured SHA-256 of the proxy executable (see
    /// [`current_exe_sha256`]).
    pub proxy_binary_sha256: String,
    /// Receipt issuance time (seconds since the Unix epoch).
    pub unix_timestamp: u64,
    /// Which key signed: [`KEY_PROVENANCE_AUTHORITY`] or
    /// [`KEY_PROVENANCE_SESSION`].
    pub key_provenance: String,
    /// Hex Ed25519 verifying key of the signing key (the same
    /// key that signed the session ledger).
    pub authority_verifying_key: String,
    /// Hex Ed25519 signature over the receipt digest.
    pub signature: String,
}

impl SessionReceipt {
    /// Builds and signs a receipt. `key` must be the key that
    /// signed the session ledger; `key_provenance` records its
    /// custody class (see the module constants). The bound
    /// version is this crate's own version — a receipt cannot
    /// claim a version the signing binary is not.
    pub fn sign(
        policy_digest: &str,
        ledger_head_hash: &str,
        ledger_record_count: u64,
        proxy_binary_sha256: &str,
        unix_timestamp: u64,
        key_provenance: &str,
        key: &SigningKey,
    ) -> SessionReceipt {
        let mut receipt = SessionReceipt {
            version: env!("CARGO_PKG_VERSION").to_string(),
            policy_digest: policy_digest.to_string(),
            ledger_head_hash: ledger_head_hash.to_string(),
            ledger_record_count,
            proxy_binary_sha256: proxy_binary_sha256.to_string(),
            unix_timestamp,
            key_provenance: key_provenance.to_string(),
            authority_verifying_key: hex::encode(key.verifying_key().to_bytes()),
            signature: String::new(),
        };
        let signature = key.sign(&receipt_digest(&receipt));
        receipt.signature = hex::encode(signature.to_bytes());
        receipt
    }

    /// Verifies the receipt: the supplied verifying key must be
    /// the key the receipt names, and the signature must cover
    /// every bound field exactly as recorded. Any tampered
    /// field — version, policy digest, ledger head or count,
    /// binary hash, timestamp, provenance — fails.
    pub fn verify(&self, verifying_key: &VerifyingKey) -> Result<(), String> {
        if hex::encode(verifying_key.to_bytes()) != self.authority_verifying_key {
            return Err(
                "receipt names a different authority key than the one supplied".to_string(),
            );
        }
        let digest = receipt_digest(self);
        let sig_bytes = hex::decode(&self.signature)
            .map_err(|e| format!("receipt signature is not hex: {e}"))?;
        let sig_arr: [u8; 64] = sig_bytes
            .as_slice()
            .try_into()
            .map_err(|_| "receipt signature is not 64 bytes".to_string())?;
        let signature = Signature::from_bytes(&sig_arr);
        verifying_key
            .verify(&digest, &signature)
            .map_err(|_| "receipt signature verification failed".to_string())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand_core::OsRng;

    fn sample_receipt(key: &SigningKey) -> SessionReceipt {
        let summary = ConfinementPolicySummary {
            landlock: "fs-read-only[8 paths]; net-connect-tcp[4242]; hard-requirement".into(),
            rlimits: "RLIMIT_AS=512 MiB, RLIMIT_CPU=60 s, RLIMIT_FSIZE=128 MiB, RLIMIT_CORE=0"
                .into(),
            seccomp_profile: "workload-denylist-v1".into(),
            fd_hygiene: "audit-stdio-dgram; close-range>=3".into(),
            cgroup: "cgroup v2 not applied (test) — process-count limit not enforced".into(),
        };
        SessionReceipt::sign(
            &policy_digest(&summary),
            "deadbeefcafe",
            7,
            &"ab".repeat(32),
            1_700_000_000,
            KEY_PROVENANCE_AUTHORITY,
            key,
        )
    }

    #[test]
    fn receipt_sign_verify_roundtrip() {
        let key = SigningKey::generate(&mut OsRng);
        let receipt = sample_receipt(&key);
        receipt.verify(&key.verifying_key()).unwrap();
        // JSON round-trip preserves verifiability (the form the
        // proxy writes to disk).
        let json = serde_json::to_string(&receipt).unwrap();
        let parsed: SessionReceipt = serde_json::from_str(&json).unwrap();
        parsed.verify(&key.verifying_key()).unwrap();
    }

    #[test]
    fn tampering_with_any_bound_field_fails_verification() {
        let key = SigningKey::generate(&mut OsRng);
        let vk = key.verifying_key();
        let base = sample_receipt(&key);
        let mut variants: Vec<SessionReceipt> = Vec::new();
        let mut v = base.clone();
        v.version = "9.9.9".into();
        variants.push(v);
        let mut v = base.clone();
        v.policy_digest = "00".repeat(32);
        variants.push(v);
        let mut v = base.clone();
        v.ledger_head_hash = "feedface".into();
        variants.push(v);
        let mut v = base.clone();
        v.ledger_record_count += 1;
        variants.push(v);
        let mut v = base.clone();
        v.proxy_binary_sha256 = "cd".repeat(32);
        variants.push(v);
        let mut v = base.clone();
        v.unix_timestamp += 1;
        variants.push(v);
        let mut v = base.clone();
        v.key_provenance = KEY_PROVENANCE_SESSION.into();
        variants.push(v);
        for variant in &variants {
            assert!(
                variant.verify(&vk).is_err(),
                "tampered receipt must not verify: {variant:?}"
            );
        }
        // A different key never verifies an honest receipt.
        let other = SigningKey::generate(&mut OsRng);
        assert!(base.verify(&other.verifying_key()).is_err());
    }

    #[test]
    fn current_exe_hash_is_a_real_measurement() {
        let h1 = current_exe_sha256().unwrap();
        let h2 = current_exe_sha256().unwrap();
        assert_eq!(h1, h2, "the same executable must hash identically");
        assert_eq!(h1.len(), 64);
        assert!(h1.chars().all(|c| c.is_ascii_hexdigit()));
    }
}
