//! Dual-secret session engine (v0.14.0; hardened in
//! v0.14.1) — assembled from the lab-held Infinity paste
//! set at the operator's order, with the paste's duplicate
//! Shamir implementations REMOVED: all splitting and
//! reconstruction here runs on the shipped
//! [`crate::secret_split`] (GF(256), Lagrange at x = 0), so
//! there is exactly one Shamir implementation in the crate
//! to audit.
//!
//! Design: the payload is masked with an independent random
//! partner of the same length. Secret A = payload XOR
//! partner, Secret B = partner. Each is split 3-of-5 with
//! [`crate::secret_split`]; the payload exists only as
//! A XOR B, so both reconstructions must succeed and be the
//! right ones.
//!
//! Session discipline enforced by the engine (all on
//! caller-supplied `Instant`s, never wall clock, so behaviour
//! is deterministic under test):
//! - 8-second session TTL from creation.
//! - Honey shares: x-coordinates 200 and 201 are reserved
//!   and never issued. Presenting one terminates THIS
//!   session immediately and invalidates its shares.
//! - Per-lane rate limiting, held at ENGINE level (v0.14.1):
//!   at most [`RATE_MAX_IN_WINDOW`] reconstruction attempts
//!   per lane in a rolling [`RATE_WINDOW`]; the attempt that
//!   crosses the limit blocks the lane for [`LANE_BLOCK`].
//!   The lane check runs before the session lookup, so a
//!   block outlives any single 8-second session and attempts
//!   against unknown session ids are throttled too.
//! - Payload integrity (v0.14.1): each session stores a
//!   keyed commitment (HMAC-SHA-256 over the payload,
//!   truncated) taken at creation. A reconstruction whose
//!   XOR result does not match the commitment fails with
//!   [`DualError::IntegrityFailure`] and the session
//!   SURVIVES — bogus or tampered shares can no longer
//!   burn a session or yield silent garbage.
//! - Replay: a session completes exactly once and is then
//!   removed; its id can never be reused. (That removal is
//!   the whole replay defence; v0.14.1 deleted a vestigial
//!   per-session used-share set that could never trigger.)
//! - Hygiene (v0.14.1): sessions are removed the moment
//!   they expire, trip honey, or complete, and
//!   [`Engine::purge_expired`] — called on every
//!   `create_session` — sweeps anything stale. The audit
//!   log is capped at [`AUDIT_TAG_CAP`] tags, oldest first.
//! - Audit: every lifecycle event appends a 16-byte keyed
//!   tag (HMAC-SHA-256 over the session id and event name,
//!   truncated) to [`Engine::audit_tags`]. The log holds no
//!   session ids and no payload material. HMAC is built on
//!   the crate's existing `sha2` dependency and is pinned to
//!   the RFC 4231 test vector in this module's tests.
//!
//! HONEST SCOPE: assembled from an unaudited external
//! design and NOT itself independently audited. The GF(256)
//! code it reuses is not constant-time. This is a
//! single-process engine: no network, no persistence, and
//! no cross-process replay protection. `Zeroizing` is
//! best-effort heap cleanup, not proof of erasure.

use std::collections::{HashMap, HashSet, VecDeque};
use std::time::{Duration, Instant};

use rand::rngs::OsRng;
use rand::RngCore;
use sha2::{Digest, Sha256};
use zeroize::{Zeroize, Zeroizing};

use crate::secret_split::{reconstruct_secret, split_secret, SecretShare, SplitError};

/// Shares of EACH secret (A and B) required to reconstruct.
pub const THRESHOLD: usize = 3;
/// Shares of EACH secret issued per session.
pub const TOTAL_SHARES: usize = 5;
/// Session lifetime from creation.
pub const SESSION_TTL: Duration = Duration::from_secs(8);
/// Rolling rate-limit window per lane.
pub const RATE_WINDOW: Duration = Duration::from_secs(5);
/// Attempts allowed per lane inside the window.
pub const RATE_MAX_IN_WINDOW: usize = 5;
/// How long a lane stays blocked after crossing the limit.
pub const LANE_BLOCK: Duration = Duration::from_secs(30);
/// Lanes shares are scheduled across (matches
/// [`crate::infinity_mesh::LANE_COUNT`]).
pub const LANE_COUNT: usize = 36;
/// Reserved honey x-coordinates; never issued as real shares.
pub const HONEY_X: [u8; 2] = [200, 201];
/// Maximum audit tags retained; the oldest are dropped
/// first. Bounds the audit log's memory (v0.14.1).
pub const AUDIT_TAG_CAP: usize = 1024;

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub enum SecretKind {
    A,
    B,
}

/// One share of one half (A or B) of a dual-secret session.
#[derive(Clone)]
pub struct Share {
    pub x: u8,
    pub y: Zeroizing<Vec<u8>>,
    pub kind: SecretKind,
}

impl Share {
    fn from_secret_share(mut s: SecretShare, kind: SecretKind) -> Self {
        Share {
            x: s.index,
            y: Zeroizing::new(std::mem::take(&mut s.data)),
            kind,
        }
    }

    fn to_secret_share(&self) -> SecretShare {
        SecretShare {
            index: self.x,
            data: self.y.to_vec(),
        }
    }
}

/// A share plus its assigned lane and send jitter, as
/// scheduled by [`Engine::create_session`].
#[derive(Clone)]
pub struct ScheduledShare {
    pub lane: usize,
    pub jitter_ms: u64,
    pub share: Share,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum DualError {
    InsufficientShares,
    DuplicateShare,
    MismatchedShares,
    IntegrityFailure,
    HoneyTriggered,
    SessionExpired,
    RateLimited,
    LaneBlocked,
    UnknownSession,
    BadLane,
    EmptyPayload,
}

impl From<SplitError> for DualError {
    fn from(e: SplitError) -> Self {
        match e {
            SplitError::InsufficientShares => DualError::InsufficientShares,
            SplitError::DuplicateShareIndex => DualError::DuplicateShare,
            _ => DualError::MismatchedShares,
        }
    }
}

#[derive(Debug, Default)]
struct LaneState {
    attempts: VecDeque<Instant>,
    blocked_until: Option<Instant>,
}

impl LaneState {
    /// Enforces the rolling window and the block. This is
    /// enforcement, not counting: a blocked lane rejects
    /// before any reconstruction work happens.
    fn check_and_record(&mut self, now: Instant) -> Result<(), DualError> {
        if let Some(until) = self.blocked_until {
            if now < until {
                return Err(DualError::LaneBlocked);
            }
            self.blocked_until = None;
        }
        while let Some(front) = self.attempts.front() {
            if now.duration_since(*front) > RATE_WINDOW {
                self.attempts.pop_front();
            } else {
                break;
            }
        }
        if self.attempts.len() >= RATE_MAX_IN_WINDOW {
            self.blocked_until = Some(now + LANE_BLOCK);
            return Err(DualError::RateLimited);
        }
        self.attempts.push_back(now);
        Ok(())
    }
}

/// A live session. The registry only ever holds live
/// sessions: expiry, honey, and completion all remove the
/// entry at the moment they happen (v0.14.1).
#[derive(Debug)]
struct Session {
    created: Instant,
    /// Keyed commitment to the payload, taken at creation;
    /// a reconstruction must match it or fail with
    /// [`DualError::IntegrityFailure`].
    commit: [u8; 16],
}

/// HMAC-SHA-256 (RFC 2104) over the concatenation of
/// `parts`, built on the crate's `sha2`. Pinned to the
/// RFC 4231 test vectors in this module's tests.
fn hmac_sha256(key: &[u8], parts: &[&[u8]]) -> [u8; 32] {
    const BLOCK: usize = 64;
    let mut key_block = [0u8; BLOCK];
    if key.len() > BLOCK {
        let hashed = Sha256::digest(key);
        key_block[..32].copy_from_slice(&hashed);
    } else {
        key_block[..key.len()].copy_from_slice(key);
    }
    let mut ipad = [0x36u8; BLOCK];
    let mut opad = [0x5cu8; BLOCK];
    for i in 0..BLOCK {
        ipad[i] ^= key_block[i];
        opad[i] ^= key_block[i];
    }
    let mut inner = Sha256::new();
    inner.update(ipad);
    for part in parts {
        inner.update(part);
    }
    let inner_hash = inner.finalize();
    let mut outer = Sha256::new();
    outer.update(opad);
    outer.update(inner_hash);
    let mut out = [0u8; 32];
    out.copy_from_slice(&outer.finalize());
    out
}

/// Constant-time equality for 16-byte tags: no early exit,
/// so a commitment comparison does not leak how many bytes
/// matched.
fn ct_eq16(a: &[u8; 16], b: &[u8; 16]) -> bool {
    let mut diff = 0u8;
    for i in 0..16 {
        diff |= a[i] ^ b[i];
    }
    diff == 0
}

/// The dual-secret engine: session registry, honey and
/// rate-limit enforcement, and the keyed audit log.
/// Rate-limit state lives HERE, not in sessions (v0.14.1),
/// so lane blocks outlive individual sessions.
#[derive(Debug)]
pub struct Engine {
    audit_key: [u8; 32],
    sessions: HashMap<[u8; 16], Session>,
    lanes: Vec<LaneState>,
    /// Privacy-preserving audit log: only 16-byte keyed
    /// tags, never a raw payload or session id. Capped at
    /// [`AUDIT_TAG_CAP`] entries, oldest dropped first.
    pub audit_tags: Vec<[u8; 16]>,
}

impl Engine {
    pub fn new(audit_key: [u8; 32]) -> Self {
        Self {
            audit_key,
            sessions: HashMap::new(),
            lanes: (0..LANE_COUNT).map(|_| LaneState::default()).collect(),
            audit_tags: Vec::new(),
        }
    }

    /// The 16-byte keyed audit tag for an event on a
    /// session: HMAC-SHA-256(audit_key, session_id || event),
    /// truncated. Keyed, so tags cannot be forged or
    /// correlated without the audit key.
    pub fn audit_tag(&self, session_id: &[u8; 16], event: &str) -> [u8; 16] {
        let mac = hmac_sha256(&self.audit_key, &[session_id, event.as_bytes()]);
        let mut tag = [0u8; 16];
        tag.copy_from_slice(&mac[..16]);
        tag
    }

    fn audit(&mut self, session_id: &[u8; 16], event: &str) {
        let tag = self.audit_tag(session_id, event);
        if self.audit_tags.len() >= AUDIT_TAG_CAP {
            self.audit_tags.remove(0);
        }
        self.audit_tags.push(tag);
    }

    /// The keyed payload commitment stored at session
    /// creation: HMAC-SHA-256(audit_key, "payload-commit" ||
    /// payload), truncated to 16 bytes.
    fn payload_commit(&self, payload: &[u8]) -> [u8; 16] {
        let mac = hmac_sha256(&self.audit_key, &[b"payload-commit", payload]);
        let mut tag = [0u8; 16];
        tag.copy_from_slice(&mac[..16]);
        tag
    }

    /// Removes every session whose TTL has passed at `now`.
    /// Called on each `create_session`; sessions that hit a
    /// terminal event are already removed at that moment,
    /// so this sweeps only the abandoned ones.
    pub fn purge_expired(&mut self, now: Instant) {
        self.sessions
            .retain(|_, s| now.duration_since(s.created) <= SESSION_TTL);
    }

    /// Creates a session: masks the payload with a fresh
    /// partner, splits both halves 3-of-5 on
    /// [`crate::secret_split`], and schedules the ten shares
    /// across the lanes. Partner (B) shares are offset by 18
    /// lanes so A and B for the same x never share a lane.
    /// Each share gets independent jitter (0–199 ms).
    pub fn create_session(
        &mut self,
        payload: &[u8],
        now: Instant,
    ) -> Result<([u8; 16], Vec<ScheduledShare>), DualError> {
        if payload.is_empty() {
            return Err(DualError::EmptyPayload);
        }
        self.purge_expired(now);
        let mut rng = OsRng;
        let mut session_id = [0u8; 16];
        rng.fill_bytes(&mut session_id);

        let mut partner = Zeroizing::new(vec![0u8; payload.len()]);
        rng.fill_bytes(&mut partner);
        let mut secret_a = Zeroizing::new(vec![0u8; payload.len()]);
        for i in 0..payload.len() {
            secret_a[i] = payload[i] ^ partner[i];
        }

        let shares_a = split_secret(&secret_a, THRESHOLD as u8, TOTAL_SHARES as u8)?;
        let shares_b = split_secret(&partner, THRESHOLD as u8, TOTAL_SHARES as u8)?;

        let session = Session {
            created: now,
            commit: self.payload_commit(payload),
        };
        self.sessions.insert(session_id, session);
        self.audit(&session_id, "session_created");

        let mut scheduled = Vec::with_capacity(2 * TOTAL_SHARES);
        for (kind, shares) in [(SecretKind::A, shares_a), (SecretKind::B, shares_b)] {
            for s in shares {
                let share = Share::from_secret_share(s, kind);
                let base = share.x as usize * 7 + session_id[0] as usize;
                let offset = if kind == SecretKind::B { 18 } else { 0 };
                let lane = (base + offset) % LANE_COUNT;
                let jitter_ms = rng.next_u64() % 200;
                scheduled.push(ScheduledShare {
                    lane,
                    jitter_ms,
                    share,
                });
            }
        }
        Ok((session_id, scheduled))
    }

    /// Attempts reconstruction of a session's payload from
    /// collected shares arriving on `lane` at `now`.
    /// Enforces, in order: the engine-level per-lane rate
    /// limit (before any session lookup, so unknown ids are
    /// throttled too), known session, TTL, honey
    /// termination, per-kind thresholds, and the payload
    /// integrity commitment. Expiry and honey remove the
    /// session at once; an integrity failure leaves it
    /// alive for the real shares. On success the session is
    /// completed and removed — its id can never be reused.
    pub fn attempt_reconstruct(
        &mut self,
        session_id: &[u8; 16],
        shares: Vec<Share>,
        lane: usize,
        now: Instant,
    ) -> Result<Zeroizing<Vec<u8>>, DualError> {
        if lane >= LANE_COUNT {
            return Err(DualError::BadLane);
        }
        // Engine-level lane enforcement FIRST (v0.14.1):
        // the block outlives any session, and brute-forcing
        // unknown session ids is throttled like anything
        // else on the lane.
        self.lanes[lane].check_and_record(now)?;

        let (created, commit) = {
            let session = self
                .sessions
                .get(session_id)
                .ok_or(DualError::UnknownSession)?;
            (session.created, session.commit)
        };
        if now.duration_since(created) > SESSION_TTL {
            self.audit(session_id, "session_expired");
            self.sessions.remove(session_id);
            return Err(DualError::SessionExpired);
        }
        if shares.iter().any(|s| HONEY_X.contains(&s.x)) {
            self.audit(session_id, "honey_triggered");
            self.sessions.remove(session_id);
            return Err(DualError::HoneyTriggered);
        }

        let mut a_shares: Vec<Share> = Vec::new();
        let mut b_shares: Vec<Share> = Vec::new();
        let mut seen: HashSet<(SecretKind, u8)> = HashSet::new();
        for s in shares {
            if !seen.insert((s.kind, s.x)) {
                return Err(DualError::DuplicateShare);
            }
            match s.kind {
                SecretKind::A => a_shares.push(s),
                SecretKind::B => b_shares.push(s),
            }
        }
        if a_shares.len() < THRESHOLD || b_shares.len() < THRESHOLD {
            self.audit(session_id, "insufficient_shares");
            return Err(DualError::InsufficientShares);
        }

        let a_secret: Vec<SecretShare> = a_shares.iter().map(Share::to_secret_share).collect();
        let b_secret: Vec<SecretShare> = b_shares.iter().map(Share::to_secret_share).collect();
        let mut rec_a = reconstruct_secret(&a_secret, THRESHOLD as u8)?;
        let rec_b = reconstruct_secret(&b_secret, THRESHOLD as u8)?;
        if rec_a.len() != rec_b.len() {
            rec_a.zeroize();
            return Err(DualError::MismatchedShares);
        }
        let mut payload = Zeroizing::new(vec![0u8; rec_a.len()]);
        for i in 0..payload.len() {
            payload[i] = rec_a[i] ^ rec_b[i];
        }
        rec_a.zeroize();
        // rec_b drops here; Zeroizing clears it.

        // Integrity (v0.14.1): the XOR result must match the
        // commitment taken at creation. Bogus or tampered
        // shares fail HERE — no silent garbage, and the
        // session survives for the legitimate shares.
        if !ct_eq16(&self.payload_commit(&payload), &commit) {
            self.audit(session_id, "integrity_failure");
            return Err(DualError::IntegrityFailure);
        }

        self.audit(session_id, "reconstructed");
        // Remove so the id cannot be replayed even if the
        // caller retries. This removal is the replay defence.
        self.sessions.remove(session_id);
        Ok(payload)
    }

    pub fn session_count(&self) -> usize {
        self.sessions.len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn engine() -> Engine {
        Engine::new([7u8; 32])
    }

    fn clone_share(s: &Share) -> Share {
        Share {
            x: s.x,
            y: Zeroizing::new(s.y.to_vec()),
            kind: s.kind,
        }
    }

    fn take(scheduled: &[ScheduledShare], kind: SecretKind, n: usize) -> Vec<Share> {
        scheduled
            .iter()
            .filter(|s| s.share.kind == kind)
            .take(n)
            .map(|s| clone_share(&s.share))
            .collect()
    }

    #[test]
    fn hmac_matches_rfc4231_case_1() {
        // RFC 4231 Test Case 1: key = 0x0b x 20, data = "Hi There".
        let key = [0x0bu8; 20];
        let mac = hmac_sha256(&key, &[b"Hi There"]);
        let expected: [u8; 32] = [
            0xb0, 0x34, 0x4c, 0x61, 0xd8, 0xdb, 0x38, 0x53, 0x5c, 0xa8, 0xaf, 0xce, 0xaf, 0x0b,
            0xf1, 0x2b, 0x88, 0x1d, 0xc2, 0x00, 0xc9, 0x83, 0x3d, 0xa7, 0x26, 0xe9, 0x37, 0x6c,
            0x2e, 0x32, 0xcf, 0xf7,
        ];
        assert_eq!(mac, expected);
    }

    #[test]
    fn dual_recovers_payload() {
        let mut e = engine();
        let now = Instant::now();
        let payload = b"partner riding shotgun secret";
        let (sid, scheduled) = e.create_session(payload, now).unwrap();
        let mut shares = take(&scheduled, SecretKind::A, 3);
        shares.extend(take(&scheduled, SecretKind::B, 3));
        let out = e.attempt_reconstruct(&sid, shares, 0, now).unwrap();
        assert_eq!(&*out, payload);
        assert_eq!(e.session_count(), 0);
    }

    #[test]
    fn two_of_one_kind_do_not_recover() {
        let mut e = engine();
        let now = Instant::now();
        let (sid, scheduled) = e.create_session(b"12345678", now).unwrap();
        let mut shares = take(&scheduled, SecretKind::A, 2);
        shares.extend(take(&scheduled, SecretKind::B, 3));
        assert!(matches!(
            e.attempt_reconstruct(&sid, shares, 0, now),
            Err(DualError::InsufficientShares)
        ));
    }

    #[test]
    fn honey_terminates_session_and_invalidates() {
        let mut e = engine();
        let now = Instant::now();
        let (sid, scheduled) = e.create_session(b"secret1234", now).unwrap();
        let honey = Share {
            x: HONEY_X[0],
            y: Zeroizing::new(vec![9u8; 10]),
            kind: SecretKind::A,
        };
        assert!(matches!(
            e.attempt_reconstruct(&sid, vec![honey], 1, now),
            Err(DualError::HoneyTriggered)
        ));
        let mut valid = take(&scheduled, SecretKind::A, 3);
        valid.extend(take(&scheduled, SecretKind::B, 3));
        // v0.14.1: the honeyed session is removed at once,
        // so the follow-up attempt sees an unknown session.
        assert!(matches!(
            e.attempt_reconstruct(&sid, valid, 1, now),
            Err(DualError::UnknownSession)
        ));
        assert_eq!(e.session_count(), 0);
    }

    #[test]
    fn replay_after_success_is_rejected() {
        let mut e = engine();
        let now = Instant::now();
        let (sid, scheduled) = e.create_session(b"replay-test-payload!", now).unwrap();
        let mk = || {
            let mut v = take(&scheduled, SecretKind::A, 5);
            v.extend(take(&scheduled, SecretKind::B, 5));
            v
        };
        assert!(e.attempt_reconstruct(&sid, mk(), 2, now).is_ok());
        assert!(e.attempt_reconstruct(&sid, mk(), 2, now).is_err());
    }

    #[test]
    fn rate_limit_blocks_lane() {
        let mut e = engine();
        let now = Instant::now();
        let (sid, _) = e.create_session(b"rate-limit-payload!!", now).unwrap();
        let mut saw_limit = false;
        for _ in 0..6 {
            let r = e.attempt_reconstruct(&sid, vec![], 3, now);
            if matches!(r, Err(DualError::RateLimited) | Err(DualError::LaneBlocked)) {
                saw_limit = true;
            }
        }
        assert!(saw_limit);
        // Lane stays blocked for 30s: an attempt at +4s
        // (inside the block, and still inside the 8s
        // session TTL) is refused at the lane check. The
        // paste's own version of this test asserted the
        // block at +10s, past its own 8s expiry — it could
        // never have passed against the paste's code.
        // v0.14.1: lane state is engine-level, so the block
        // now genuinely outlives the session (proven by
        // lane_block_outlives_session below).
        let later = now + Duration::from_secs(4);
        let r = e.attempt_reconstruct(&sid, vec![], 3, later);
        assert!(matches!(
            r,
            Err(DualError::LaneBlocked) | Err(DualError::RateLimited)
        ));
    }

    #[test]
    fn expiry_8s() {
        let mut e = engine();
        let now = Instant::now();
        let (sid, scheduled) = e.create_session(b"expiry-payload-1234", now).unwrap();
        let mut shares = take(&scheduled, SecretKind::A, 5);
        shares.extend(take(&scheduled, SecretKind::B, 5));
        let late = now + Duration::from_secs(9);
        assert!(matches!(
            e.attempt_reconstruct(&sid, shares, 0, late),
            Err(DualError::SessionExpired)
        ));
    }

    #[test]
    fn audit_tag_is_16_bytes_keyed() {
        let e = engine();
        let tag = e.audit_tag(&[1u8; 16], "test");
        assert_eq!(tag.len(), 16);
        let tag2 = Engine::new([8u8; 32]).audit_tag(&[1u8; 16], "test");
        assert_ne!(tag, tag2);
        // Events are audited: session creation appends a tag.
        let mut e2 = engine();
        let now = Instant::now();
        let _ = e2.create_session(b"audit-count-check", now).unwrap();
        assert_eq!(e2.audit_tags.len(), 1);
    }

    #[test]
    fn lane_scheduling_spreads_partner() {
        let mut e = engine();
        let now = Instant::now();
        let (_, scheduled) = e.create_session(b"scheduling-check-123", now).unwrap();
        assert_eq!(scheduled.len(), 2 * TOTAL_SHARES);
        let lanes_a: HashSet<usize> = scheduled
            .iter()
            .filter(|s| s.share.kind == SecretKind::A)
            .map(|s| s.lane)
            .collect();
        let lanes_b: HashSet<usize> = scheduled
            .iter()
            .filter(|s| s.share.kind == SecretKind::B)
            .map(|s| s.lane)
            .collect();
        assert!(lanes_a.len() > 1);
        assert!(lanes_b.len() > 1);
        // The 18-lane partner offset means A and B for the
        // same x never share a lane.
        for s in scheduled.iter().filter(|s| s.share.kind == SecretKind::A) {
            let b_lane = scheduled
                .iter()
                .find(|t| t.share.kind == SecretKind::B && t.share.x == s.share.x)
                .map(|t| t.lane)
                .unwrap();
            assert_ne!(s.lane, b_lane);
        }
    }

    #[test]
    fn empty_payload_rejected() {
        let mut e = engine();
        let now = Instant::now();
        assert!(matches!(
            e.create_session(b"", now),
            Err(DualError::EmptyPayload)
        ));
    }

    // ---- v0.14.1 hardening tests ----

    #[test]
    fn lane_block_outlives_session() {
        let mut e = engine();
        let now = Instant::now();
        let (sid1, _) = e.create_session(b"first-session-payload", now).unwrap();
        // Burn lane 5 with rapid failed attempts until it
        // blocks.
        for _ in 0..6 {
            let _ = e.attempt_reconstruct(&sid1, vec![], 5, now);
        }
        // A brand-new session inherits the block: lane state
        // is the engine's, not the session's.
        let (sid2, _) = e.create_session(b"second-session-payload", now).unwrap();
        assert!(matches!(
            e.attempt_reconstruct(&sid2, vec![], 5, now),
            Err(DualError::LaneBlocked) | Err(DualError::RateLimited)
        ));
    }

    #[test]
    fn unknown_session_attempts_are_throttled() {
        let mut e = engine();
        let now = Instant::now();
        let bogus = [42u8; 16];
        let mut saw_limit = false;
        for _ in 0..6 {
            match e.attempt_reconstruct(&bogus, vec![], 7, now) {
                Err(DualError::UnknownSession) => {}
                Err(DualError::RateLimited) | Err(DualError::LaneBlocked) => {
                    saw_limit = true;
                }
                _ => panic!("unexpected result"),
            }
        }
        assert!(saw_limit);
    }

    #[test]
    fn bogus_shares_fail_integrity_and_session_survives() {
        let mut e = engine();
        let now = Instant::now();
        let payload = b"integrity-protected-payload";
        let (sid, scheduled) = e.create_session(payload, now).unwrap();
        // Fabricated shares: valid x values, payload-length
        // bodies, wrong data. They reconstruct fine as math
        // and must fail at the commitment instead.
        let bogus: Vec<Share> = (1u8..=3)
            .flat_map(|x| {
                [
                    Share {
                        x,
                        y: Zeroizing::new(vec![0xa5u8; payload.len()]),
                        kind: SecretKind::A,
                    },
                    Share {
                        x,
                        y: Zeroizing::new(vec![0x3cu8; payload.len()]),
                        kind: SecretKind::B,
                    },
                ]
            })
            .collect();
        assert!(matches!(
            e.attempt_reconstruct(&sid, bogus, 0, now),
            Err(DualError::IntegrityFailure)
        ));
        // The session was NOT burned: the real shares still
        // reconstruct it.
        assert_eq!(e.session_count(), 1);
        let mut real = take(&scheduled, SecretKind::A, 3);
        real.extend(take(&scheduled, SecretKind::B, 3));
        let out = e.attempt_reconstruct(&sid, real, 0, now).unwrap();
        assert_eq!(&*out, payload);
    }

    #[test]
    fn tampered_share_fails_integrity() {
        let mut e = engine();
        let now = Instant::now();
        let (sid, scheduled) = e.create_session(b"tamper-evident-payload!", now).unwrap();
        let mut shares = take(&scheduled, SecretKind::A, 3);
        shares.extend(take(&scheduled, SecretKind::B, 3));
        shares[0].y[0] ^= 0xff;
        assert!(matches!(
            e.attempt_reconstruct(&sid, shares, 0, now),
            Err(DualError::IntegrityFailure)
        ));
        assert_eq!(e.session_count(), 1);
    }

    #[test]
    fn expired_session_is_removed() {
        let mut e = engine();
        let now = Instant::now();
        let (sid, scheduled) = e.create_session(b"short-lived-payload-1", now).unwrap();
        assert_eq!(e.session_count(), 1);
        let mut shares = take(&scheduled, SecretKind::A, 3);
        shares.extend(take(&scheduled, SecretKind::B, 3));
        let late = now + Duration::from_secs(9);
        assert!(matches!(
            e.attempt_reconstruct(&sid, shares, 0, late),
            Err(DualError::SessionExpired)
        ));
        assert_eq!(e.session_count(), 0);
    }

    #[test]
    fn create_session_sweeps_stale_sessions() {
        let mut e = engine();
        let now = Instant::now();
        let _ = e.create_session(b"abandoned-payload-123", now).unwrap();
        assert_eq!(e.session_count(), 1);
        // Nine seconds later a new session is created; the
        // abandoned one is swept by the create path.
        let later = now + Duration::from_secs(9);
        let _ = e.create_session(b"fresh-payload-1234567", later).unwrap();
        assert_eq!(e.session_count(), 1);
    }

    #[test]
    fn audit_log_is_capped() {
        let mut e = engine();
        let now = Instant::now();
        for _ in 0..(AUDIT_TAG_CAP + 10) {
            let _ = e.create_session(b"cap-check-payload", now).unwrap();
        }
        assert!(e.audit_tags.len() <= AUDIT_TAG_CAP);
    }
}
