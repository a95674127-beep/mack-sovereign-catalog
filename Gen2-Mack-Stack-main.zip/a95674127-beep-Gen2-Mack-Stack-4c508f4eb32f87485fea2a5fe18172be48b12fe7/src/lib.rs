#![forbid(unsafe_code)]

//! mack-security-runtime — Gen 2 Mack-Stack.
//!
//! The generational successor to AI Infinity Force One (Generation 1),
//! built beside the original, which stays frozen and untouched.
//! Design record: aifo-next-generation-design-note-2026-11-14.
//!
//! Module status at v0.14.2:
//! - `vault` — IMPLEMENTED (Allen Mack's vault core, with tests), plus
//!   AAD-bound envelope sealing in `vault::envelope_crypto`.
//! - `ledger` — IMPLEMENTED: hash-chained proof ledger with an optional
//!   signed mode (Ed25519 authority signature per entry) and, since
//!   v0.11.0, optional append-only persistence with torn-tail crash
//!   recovery, signed checkpoints, and independent verification
//!   (`ledger::store`, `mack-ledger-verify`). Since v0.12.0 the
//!   verifier also anchors a ledger file to an extracted signed
//!   checkpoint sidecar, detecting tail truncation and extension
//!   against the checkpoint (`ledger::store::CheckpointSidecar`).
//! - `secret_split` — IMPLEMENTED (v0.12.0): hand-rolled GF(256)
//!   Shamir splitting (2-of-3 for the proxy session secret);
//!   shares are co-located in the proxy process in this release —
//!   in-process hygiene, not multi-party custody.
//! - `dual_secret`, `sibling_mesh`, `mesh_transport` —
//!   IMPLEMENTED (v0.14.0, hardened v0.14.1): the assembled mesh system, built
//!   from a lab-held external design at the operator's
//!   order. A dual-secret session engine (partner-mask XOR
//!   over the shipped `secret_split` — no duplicate Shamir;
//!   honey termination, per-lane rate limiting, 8-second
//!   TTL, keyed HMAC audit tags), a 3-phase 36-lane router
//!   (ingest → classify → route, one direction only), and
//!   transport encryption for shares in flight
//!   (XChaCha20-Poly1305, per-share derived keys, AAD-bound
//!   lane/label/index). Exercised end to end by the
//!   `mack-mesh-demo` binary. NOT independently audited.
//! - `infinity_mesh` — IMPLEMENTED (v0.13.0): the InfinityMesh
//!   cover layer over `secret_split` — lane-spread, decoyed,
//!   short-TTL transport sessions that close at the Shamir
//!   threshold, so a lost lane no longer kills the session.
//!   Single-process model in this release; the multi-device
//!   transport it disciplines remains unbuilt.
//! - `handle_table` — IMPLEMENTED (v0.12.0): the proxy binary's
//!   per-host handle state (current handle, burn, successor,
//!   session close) with structural single-burn and
//!   successor-after-burn invariants; loom models under
//!   `--cfg loom` (dev-only).
//! - `session_receipt` — IMPLEMENTED (v0.12.0): the signed
//!   runtime session receipt binding version, confinement-policy
//!   digest, ledger head/count, and the measured SHA-256 of the
//!   proxy executable, signed with the session ledger's key.
//! - `egress` — IMPLEMENTED: default-deny destination policy (decision
//!   layer; enforcement belongs to callers).
//! - `auth` — IMPLEMENTED: quorum-gated scoped minting, MULTISIG form.
//!   FROST threshold signing is implemented in `threshold` (v0.5.0);
//!   multi-device share transport is not built.
//! - `proxy` — IMPLEMENTED: blind credential swap logic at the egress
//!   boundary, plus the `mack-proxy` binary: real loopback HTTP and
//!   (v0.9.0) real HTTPS via CONNECT + split-TLS; a child confined by
//!   Landlock (filesystem + TCP-connect rules), a baseline seccomp
//!   workload profile, inherited-FD hygiene (v0.12.0), and the
//!   resource governor; a signed session ledger (persistent on
//!   request since v0.11.0); per-host scoped handles; the session
//!   secret held as Shamir shares and reconstructed per burn
//!   (v0.12.0); and a signed session receipt at shutdown
//!   (v0.12.0).
//! - `proof_fabric` — IMPLEMENTED: signed execution envelopes and
//!   signed compound-attestation delegation chains. Capability leases
//!   and the seen-nonce replay store are implemented (v0.6.0); the
//!   lease store is in-memory (see `proof_fabric::leases`).
//! - `sandbox` — IMPLEMENTED (Tier 1): Landlock (fail-closed) and
//!   seccomp enforcers, a pinned worker thread, the workload seccomp
//!   profile for arbitrary children, and the resource governor
//!   (rlimits; cgroup v2 where delegated). Tier 2 (Firecracker
//!   microVM) is dispatch policy/configuration only; no VM is created.
//! - `cdr` — IMPLEMENTED (first step): executable-header rejection and
//!   script-pattern detection; no document parsing/rebuild yet.
//! - `forensic` — IMPLEMENTED: signed build-provenance records and the
//!   evidence chamber.

pub mod auth;
pub mod cdr;
pub mod dual_secret;
pub mod egress;
pub mod forensic;
pub mod handle_table;
pub mod infinity_mesh;
pub mod ledger;
pub mod mesh_transport;
pub mod proof_fabric;
pub mod proxy;
pub mod sandbox;
pub mod secret_split;
pub mod session_receipt;
pub mod sibling_mesh;
pub mod threshold;
pub mod vault;
