//! Quorum-gated minting of per-run scoped credential handles.
//!
//! Merged 2026-11-15 from the graded 7-pillar package, with the canonical
//! request encoding changed to length-prefixed fields (the as-received
//! "|"-joined form had the same field-boundary ambiguity proven against
//! the ledger).
//!
//! HONEST LABEL: this quorum is MULTISIG — each device signs independently
//! with its own full Ed25519 key, and the authority counts distinct valid
//! signers. It is NOT FROST threshold signing: there is no distributed key
//! generation and no split key. FROST (frost-ed25519, RFC 9591) remains
//! the adopted threshold design — proven in the lab 2026-11-15 — and its
//! integration will replace or sit behind this module's interface.
//! Expiry is checked against a caller-supplied epoch: the clock source is
//! the caller's, named here rather than hidden.

use crate::ledger::ProofLedger;
use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use sha2::{Digest, Sha256};
use std::collections::HashSet;

#[derive(Debug, Clone)]
pub struct MintRequest {
    pub run_id: String,
    pub lane_id: String,
    pub target_host: String,
    pub allowed_action: String,
    pub expires_at_epoch: u64,
    pub secret_ref_id: String,
}

impl MintRequest {
    /// Domain-tagged, length-prefixed canonical encoding for signing.
    pub fn canonical_bytes(&self) -> Vec<u8> {
        let host = self.target_host.to_ascii_lowercase();
        let action = self.allowed_action.to_ascii_uppercase();
        let fields: [&[u8]; 5] = [
            self.run_id.as_bytes(),
            self.lane_id.as_bytes(),
            host.as_bytes(),
            action.as_bytes(),
            self.secret_ref_id.as_bytes(),
        ];
        let mut out = Vec::new();
        out.extend_from_slice(b"MINT");
        for f in fields {
            out.extend_from_slice(&(f.len() as u64).to_be_bytes());
            out.extend_from_slice(f);
        }
        out.extend_from_slice(&self.expires_at_epoch.to_be_bytes());
        out
    }
}

#[derive(Debug, Clone)]
pub struct ScopedCredentialHandle {
    pub opaque_handle: String,
    pub request: MintRequest,
    pub consumed: bool,
}

/// Enforces t-of-n multi-device approval (e.g., 2-of-3 across phone,
/// Chromebook, hardware key) before a scoped handle is minted.
pub struct QuorumAuthority {
    threshold: usize,
    authorized_signers: Vec<VerifyingKey>,
}

impl QuorumAuthority {
    pub fn new(threshold: usize, authorized_signers: Vec<VerifyingKey>) -> Result<Self, String> {
        if threshold == 0 || threshold > authorized_signers.len() {
            return Err("Invalid quorum threshold configuration".into());
        }
        Ok(Self {
            threshold,
            authorized_signers,
        })
    }

    pub fn sign_request(key: &SigningKey, req: &MintRequest) -> (VerifyingKey, Signature) {
        let sig = key.sign(&req.canonical_bytes());
        (key.verifying_key(), sig)
    }

    pub fn mint_scoped_handle(
        &self,
        req: MintRequest,
        approvals: &[(VerifyingKey, Signature)],
        now_epoch: u64,
        ledger: &mut ProofLedger,
    ) -> Result<ScopedCredentialHandle, String> {
        if req.expires_at_epoch <= now_epoch {
            return Err("Cannot mint an already-expired credential".into());
        }

        let msg = req.canonical_bytes();
        let mut valid_unique_signers = HashSet::new();

        for (vk, sig) in approvals {
            if self.authorized_signers.contains(vk) && vk.verify(&msg, sig).is_ok() {
                valid_unique_signers.insert(vk.to_bytes());
            }
        }

        if valid_unique_signers.len() < self.threshold {
            ledger.append("QUORUM_MINT_REJECTED", &req.lane_id, &msg, None);
            return Err(format!(
                "Quorum not met: got {} valid signatures, need {}",
                valid_unique_signers.len(),
                self.threshold
            ));
        }

        let mut h = Sha256::new();
        h.update(&msg);
        h.update(ledger.tip_hash().as_bytes());
        let handle = format!("MACK_HANDLE_{:x}", h.finalize());

        ledger.append(
            "QUORUM_MINT_APPROVED",
            &req.lane_id,
            handle.as_bytes(),
            None,
        );

        Ok(ScopedCredentialHandle {
            opaque_handle: handle,
            request: req,
            consumed: false,
        })
    }
}
