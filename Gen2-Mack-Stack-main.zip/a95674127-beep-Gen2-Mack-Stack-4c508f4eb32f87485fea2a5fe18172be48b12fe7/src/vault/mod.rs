//! Gen2-Mack-Stack Cryptographic Vault Core
//! Module: mack_stack::vault
//! Zero-trust cryptographic sealing, memory zeroization, and audit ledger integration.

use argon2::{
    password_hash::{rand_core::OsRng, PasswordHasher, SaltString},
    Argon2, Params as ArgonParams, Version,
};
use chacha20poly1305::{
    aead::{Aead, KeyInit},
    XChaCha20Poly1305, XNonce,
};
use sha2::{Digest, Sha256};
use std::time::{SystemTime, UNIX_EPOCH};
use zeroize::{Zeroize, ZeroizeOnDrop};

/// Audit event ledger entry for cryptographic operations
#[derive(Debug, Clone)]
pub struct AuditLedgerEntry {
    pub timestamp: u64,
    pub event_id: String,
    pub prev_hash: String,
    pub operation: String,
    pub payload_hash: String,
    pub signature: String,
}

impl AuditLedgerEntry {
    pub fn new(prev_hash: &str, operation: &str, payload: &[u8]) -> Self {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();

        let mut hasher = Sha256::new();
        hasher.update(payload);
        let payload_hash = format!("{:x}", hasher.finalize());

        let mut ledger_hasher = Sha256::new();
        ledger_hasher.update(prev_hash.as_bytes());
        ledger_hasher.update(operation.as_bytes());
        ledger_hasher.update(payload_hash.as_bytes());
        ledger_hasher.update(timestamp.to_be_bytes());
        let digest = ledger_hasher.finalize();
        let signature = format!("{:x}", digest);

        let event_id = format!(
            "EVT-{}-{:02x}{:02x}{:02x}{:02x}",
            timestamp, digest[0], digest[1], digest[2], digest[3]
        );

        Self {
            timestamp,
            event_id,
            prev_hash: prev_hash.to_string(),
            operation: operation.to_string(),
            payload_hash,
            signature,
        }
    }
}

/// Secure secret container implementing automated memory zeroization on drop.
#[derive(Clone, Zeroize, ZeroizeOnDrop)]
pub struct SecretKeyBytes {
    pub inner: [u8; 32],
}

impl SecretKeyBytes {
    pub fn new(bytes: [u8; 32]) -> Self {
        Self { inner: bytes }
    }
}

/// Encrypted vault container output structure
#[derive(Debug, Clone)]
pub struct SealedVaultPayload {
    pub ciphertext: Vec<u8>,
    pub nonce: [u8; 24],
    pub salt: String,
    pub audit_entry: AuditLedgerEntry,
}

pub struct MackVaultEngine;

impl MackVaultEngine {
    /// Derives a 256-bit key using Argon2id and seals the payload with XChaCha20-Poly1305.
    pub fn seal(
        passphrase: &[u8],
        plaintext: &[u8],
        prev_ledger_hash: &str,
    ) -> Result<SealedVaultPayload, String> {
        let salt = SaltString::generate(&mut OsRng);

        let params = ArgonParams::new(65536, 3, 4, Some(32))
            .map_err(|e| format!("Argon2 params configuration failed: {}", e))?;
        let argon2 = Argon2::new(argon2::Algorithm::Argon2id, Version::V0x13, params);

        let password_hash = argon2
            .hash_password(passphrase, &salt)
            .map_err(|e| format!("Key derivation failed: {}", e))?;

        let hash_tag = password_hash
            .hash
            .ok_or_else(|| "Failed to extract key hash tag".to_string())?;

        let raw_hash = hash_tag.as_bytes();
        if raw_hash.len() < 32 {
            return Err("Derived key length insufficient".into());
        }

        let mut derived_key = [0u8; 32];
        derived_key.copy_from_slice(&raw_hash[..32]);
        let secure_key = SecretKeyBytes::new(derived_key);

        let cipher = XChaCha20Poly1305::new((&secure_key.inner).into());

        let mut nonce_bytes = [0u8; 24];
        getrandom::getrandom(&mut nonce_bytes)
            .map_err(|e| format!("Nonce generation failed: {}", e))?;
        let nonce = XNonce::from_slice(&nonce_bytes);

        let ciphertext = cipher
            .encrypt(nonce, plaintext)
            .map_err(|e| format!("Encryption failed: {}", e))?;

        let audit_entry = AuditLedgerEntry::new(prev_ledger_hash, "MACK_VAULT_SEAL", &ciphertext);

        Ok(SealedVaultPayload {
            ciphertext,
            nonce: nonce_bytes,
            salt: salt.to_string(),
            audit_entry,
        })
    }

    /// Unseals a vault payload using the provided passphrase and verifies ledger integrity.
    pub fn unseal(passphrase: &[u8], payload: &SealedVaultPayload) -> Result<Vec<u8>, String> {
        let salt = SaltString::from_b64(&payload.salt)
            .map_err(|e| format!("Invalid salt encoding: {}", e))?;

        let params = ArgonParams::new(65536, 3, 4, Some(32))
            .map_err(|e| format!("Argon2 params configuration failed: {}", e))?;
        let argon2 = Argon2::new(argon2::Algorithm::Argon2id, Version::V0x13, params);

        let password_hash = argon2
            .hash_password(passphrase, &salt)
            .map_err(|e| format!("Key derivation failed: {}", e))?;

        let hash_tag = password_hash
            .hash
            .ok_or_else(|| "Failed to extract key hash tag".to_string())?;

        let raw_hash = hash_tag.as_bytes();
        if raw_hash.len() < 32 {
            return Err("Derived key length insufficient".into());
        }
        let mut derived_key = [0u8; 32];
        derived_key.copy_from_slice(&raw_hash[..32]);
        let secure_key = SecretKeyBytes::new(derived_key);

        let cipher = XChaCha20Poly1305::new((&secure_key.inner).into());
        let nonce = XNonce::from_slice(&payload.nonce);

        let plaintext = cipher
            .decrypt(nonce, payload.ciphertext.as_ref())
            .map_err(|e| format!("Decryption failed or MAC verification mismatch: {}", e))?;

        Ok(plaintext)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_vault_seal_and_unseal() {
        let passphrase = b"secure-mack-stack-passphrase-2026";
        let secret_data = b"CONFIDENTIAL_MACK_STACK_STATE_VECTOR";
        let genesis_hash = "GENESIS_EVT_1041";

        let sealed =
            MackVaultEngine::seal(passphrase, secret_data, genesis_hash).expect("Sealing failed");

        assert_eq!(sealed.audit_entry.prev_hash, genesis_hash);
        assert_eq!(sealed.audit_entry.operation, "MACK_VAULT_SEAL");

        let unsealed = MackVaultEngine::unseal(passphrase, &sealed).expect("Unsealing failed");

        assert_eq!(unsealed, secret_data);
    }
}

/// AAD-bound envelope sealing (XChaCha20-Poly1305, Argon2id at the
/// vault's own parameters) — the pipeline sealing format, distinct
/// from the vault's at-rest format above.
pub mod envelope_crypto;
