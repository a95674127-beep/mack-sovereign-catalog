#![forbid(unsafe_code)]

use argon2::{Algorithm, Argon2, Params, Version};
use chacha20poly1305::aead::{Aead, KeyInit, Payload};
use chacha20poly1305::{XChaCha20Poly1305, XNonce};
use rand_core::{OsRng, RngCore};
use serde::{Deserialize, Serialize};
use std::fmt;
use zeroize::{Zeroize, Zeroizing};

pub const ARGON2_SALT_LEN: usize = 16;
pub const XCHACHA20_NONCE_LEN: usize = 24;
pub const KEY_BYTES_LEN: usize = 32;
pub const POLY1305_TAG_LEN: usize = 16;

#[derive(Debug)]
pub enum VaultCryptoError {
    Argon2ParamError(String),
    KeyDerivationFailed(String),
    RngFailure(String),
    EncryptionFailure,
    DecryptionFailure,
    CiphertextTooShort { expected_min: usize, actual: usize },
}

impl fmt::Display for VaultCryptoError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Argon2ParamError(e) => write!(f, "Argon2 parameter error: {e}"),
            Self::KeyDerivationFailed(e) => write!(f, "Argon2 key derivation failed: {e}"),
            Self::RngFailure(e) => write!(f, "OS CSPRNG entropy failure: {e}"),
            Self::EncryptionFailure => write!(f, "XChaCha20-Poly1305 encryption failed"),
            Self::DecryptionFailure => write!(
                f,
                "XChaCha20-Poly1305 decryption failed (tampered tag/data)"
            ),
            Self::CiphertextTooShort {
                expected_min,
                actual,
            } => {
                write!(
                    f,
                    "Ciphertext shorter than authentication tag: min {expected_min}, got {actual}"
                )
            }
        }
    }
}

impl std::error::Error for VaultCryptoError {}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EncryptedEnvelope {
    pub salt: [u8; ARGON2_SALT_LEN],
    pub nonce: [u8; XCHACHA20_NONCE_LEN],
    pub ciphertext: Vec<u8>,
}

pub struct EnvelopeVaultCrypto;

impl EnvelopeVaultCrypto {
    fn derive_key(
        passphrase: &[u8],
        salt: &[u8],
    ) -> Result<Zeroizing<[u8; KEY_BYTES_LEN]>, VaultCryptoError> {
        let params = Params::new(64 * 1024, 3, 4, Some(KEY_BYTES_LEN))
            .map_err(|e| VaultCryptoError::Argon2ParamError(e.to_string()))?;
        let argon2 = Argon2::new(Algorithm::Argon2id, Version::V0x13, params);

        let mut derived_key = Zeroizing::new([0u8; KEY_BYTES_LEN]);
        argon2
            .hash_password_into(passphrase, salt, derived_key.as_mut())
            .map_err(|e| VaultCryptoError::KeyDerivationFailed(e.to_string()))?;

        Ok(derived_key)
    }

    pub fn seal(
        passphrase: &[u8],
        aad: &[u8],
        mut plaintext: Zeroizing<Vec<u8>>,
    ) -> Result<EncryptedEnvelope, VaultCryptoError> {
        let mut salt = [0u8; ARGON2_SALT_LEN];
        let mut nonce_bytes = [0u8; XCHACHA20_NONCE_LEN];

        OsRng
            .try_fill_bytes(&mut salt)
            .map_err(|e| VaultCryptoError::RngFailure(format!("Salt generation failed: {e}")))?;
        OsRng
            .try_fill_bytes(&mut nonce_bytes)
            .map_err(|e| VaultCryptoError::RngFailure(format!("Nonce generation failed: {e}")))?;

        let key = Self::derive_key(passphrase, &salt)?;
        let cipher = XChaCha20Poly1305::new_from_slice(key.as_ref())
            .map_err(|_| VaultCryptoError::EncryptionFailure)?;

        let nonce = XNonce::from_slice(&nonce_bytes);
        let payload = Payload {
            msg: plaintext.as_ref(),
            aad,
        };

        let ciphertext = cipher
            .encrypt(nonce, payload)
            .map_err(|_| VaultCryptoError::EncryptionFailure)?;

        plaintext.zeroize();

        Ok(EncryptedEnvelope {
            salt,
            nonce: nonce_bytes,
            ciphertext,
        })
    }

    pub fn open(
        passphrase: &[u8],
        aad: &[u8],
        envelope: &EncryptedEnvelope,
    ) -> Result<Zeroizing<Vec<u8>>, VaultCryptoError> {
        if envelope.ciphertext.len() < POLY1305_TAG_LEN {
            return Err(VaultCryptoError::CiphertextTooShort {
                expected_min: POLY1305_TAG_LEN,
                actual: envelope.ciphertext.len(),
            });
        }

        let key = Self::derive_key(passphrase, &envelope.salt)?;
        let cipher = XChaCha20Poly1305::new_from_slice(key.as_ref())
            .map_err(|_| VaultCryptoError::DecryptionFailure)?;

        let nonce = XNonce::from_slice(&envelope.nonce);
        let payload = Payload {
            msg: &envelope.ciphertext,
            aad,
        };

        let plaintext = cipher
            .decrypt(nonce, payload)
            .map_err(|_| VaultCryptoError::DecryptionFailure)?;

        Ok(Zeroizing::new(plaintext))
    }
}
