//! InfinityMesh cover layer (v0.13.0) — lane-spread, decoyed,
//! short-lived transport sessions wrapped around the Shamir
//! split in [`crate::secret_split`].
//!
//! The design premise: a single observer cannot watch every
//! lane at once, so make him have to be everywhere at once. A
//! session's shares travel on widely spread lanes (of
//! [`LANE_COUNT`]) under unrelated random tags, at staggered
//! times, mixed with decoy shares that are indistinguishable
//! in size, shape, and label distribution. The receiver's
//! control map (tag → session) is the only place pairings
//! exist; it never travels. A decoy's tag is not in the map,
//! so the receiver drops it silently.
//!
//! What this module adds over the raw split, and what it does
//! NOT change:
//! - The split itself stays [`crate::secret_split`]'s Shamir
//!   (threshold k-of-n over GF(256)). The mesh transports the
//!   shares' encodings as opaque payloads and closes the
//!   session as soon as `k` distinct valid shares have
//!   arrived — losing a lane no longer kills the session,
//!   which was the graded paste design's all-or-nothing flaw.
//! - Graded defects of the originating paste, fixed here:
//!   (1) a share with a valid tag but a wrong-length payload
//!   is dropped, never panics the receiver (payload lengths
//!   are validated against the session's expected length
//!   before collection; the mesh itself never indexes into
//!   payloads); (2) collected share payloads are zeroized
//!   when a session closes or expires; (3) expiry is swept
//!   on every public entry point and on demand via
//!   [`InfinityMesh::purge_expired`].
//!
//! HONEST SCOPE: like the split it wraps, this is a
//! single-process model in this release. The mesh holds the
//! sender-side session and the receiver-side control map in
//! one object; no share crosses a real network here, and the
//! multi-device transport remains unbuilt (see `threshold`
//! module status). Expiry is lazy — there is no background
//! thread — so an idle process holds expired sessions until
//! its next call; the TTL bounds how long a session stays
//! *acceptable*, and `purge_expired` bounds the rest when
//! called. The TTL clock starts at session creation, so the
//! caller's whole staggered send window must fit inside it.

use rand::rngs::OsRng;
use rand::RngCore;
use std::collections::HashMap;
use std::fmt;
use std::time::{Duration, Instant};
use zeroize::Zeroize;

use crate::secret_split::SecretShare;

/// Number of lanes shares are spread across.
pub const LANE_COUNT: u8 = 36;
/// Default session time-to-live: 8 seconds from creation.
pub const DEFAULT_TTL: Duration = Duration::from_secs(8);

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MeshError {
    /// Fewer than 2 payloads, or more than [`LANE_COUNT`].
    InvalidShareCount,
    /// Threshold k < 2 or k > n.
    InvalidThreshold,
    /// A payload is empty, or payload lengths differ.
    MismatchedPayloads,
}

impl fmt::Display for MeshError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidShareCount => {
                write!(f, "share count must be between 2 and {}", LANE_COUNT)
            }
            Self::InvalidThreshold => {
                write!(f, "threshold k must be >= 2 and <= n")
            }
            Self::MismatchedPayloads => {
                write!(f, "payloads must be non-empty and all the same length")
            }
        }
    }
}

impl std::error::Error for MeshError {}

fn secure_bytes(n: usize) -> Vec<u8> {
    let mut buf = vec![0u8; n];
    OsRng.fill_bytes(&mut buf);
    buf
}

fn secure_tag() -> [u8; 16] {
    let mut tag = [0u8; 16];
    OsRng.fill_bytes(&mut tag);
    tag
}

/// Classifies opaque metadata (e.g. priority) into a label in
/// `0..4`. Never looks at any payload.
pub fn classify(metadata: u8) -> u8 {
    metadata % 4
}

/// Deterministic lane for a tag + label, in `0..LANE_COUNT`.
/// Used for decoys; real shares get pre-spread lanes instead,
/// so they are guaranteed far apart.
pub fn routing_gate(tag: &[u8; 16], label: u8) -> u8 {
    ((tag[0] as u16 + (label as u16) * 7 + tag[15] as u16) % (LANE_COUNT as u16)) as u8
}

/// Staggered send delays: `base + i * gap` plus a fresh
/// 0–400 ms jitter per share, so send times are not
/// predictable from the schedule alone. Ordering between
/// consecutive shares is guaranteed only when `gap_ms > 400`.
pub fn staggered_delays(n: usize, base_ms: u64, gap_ms: u64) -> Vec<u64> {
    let mut out = Vec::with_capacity(n);
    for i in 0..n {
        let jitter = secure_bytes(2);
        let j = (((jitter[0] as u64) << 8) | (jitter[1] as u64)) % 401;
        out.push(base_ms + (i as u64) * gap_ms + j);
    }
    out
}

/// Encodes a [`SecretShare`] for mesh transport:
/// `[index || data...]`.
pub fn encode_share(share: &SecretShare) -> Vec<u8> {
    let mut out = Vec::with_capacity(1 + share.data.len());
    out.push(share.index);
    out.extend_from_slice(&share.data);
    out
}

/// Decodes a mesh payload back into a [`SecretShare`].
/// Returns `None` for an empty payload or a zero index
/// (x = 0 is the secret itself, never a share index).
pub fn decode_share(payload: &[u8]) -> Option<SecretShare> {
    if payload.len() < 2 || payload[0] == 0 {
        return None;
    }
    Some(SecretShare {
        index: payload[0],
        data: payload[1..].to_vec(),
    })
}

/// One share in flight: a random tag, its lane, its label,
/// and an opaque payload (a [`SecretShare`] encoding, or
/// random bytes for a decoy). The payload is zeroized when
/// the share drops.
#[derive(Clone, Zeroize)]
#[zeroize(drop)]
pub struct MeshShare {
    pub tag: [u8; 16],
    pub lane: u8,
    pub label: u8,
    pub payload: Vec<u8>,
}

/// Sender-side session handle: the tags and pre-spread lanes
/// assigned to a session's shares, in payload order.
#[derive(Clone)]
pub struct MeshSession {
    pub tags: Vec<[u8; 16]>,
    pub lanes: Vec<u8>,
    pub label: u8,
    pub id: [u8; 16],
}

struct SessionState {
    threshold: usize,
    expected_len: usize,
    tags: Vec<[u8; 16]>,
    /// The lane each tag was assigned at `open_session`, and
    /// the session's label. `receive` validates both against
    /// the arriving share (review finding, 2026-11-19) — the
    /// same lane/label binding the encrypted transport enforces
    /// through its AEAD associated data (`crate::mesh_transport`).
    lane_by_tag: HashMap<[u8; 16], u8>,
    label: u8,
    collected: HashMap<[u8; 16], MeshShare>,
    created: Instant,
}

impl SessionState {
    /// Zeroizes every collected payload and drops the state.
    fn wipe(mut self) {
        for share in self.collected.values_mut() {
            share.payload.zeroize();
        }
        self.collected.clear();
    }
}

/// The mesh: a control map (tag → session id) and the open
/// sessions' receiver state. One mesh is one receiver; the
/// pairings it holds never leave it.
pub struct InfinityMesh {
    control: HashMap<[u8; 16], [u8; 16]>,
    sessions: HashMap<[u8; 16], SessionState>,
    ttl: Duration,
    /// Creation time of the oldest session as of the last
    /// insert or sweep (v0.16.0). All sessions share one TTL,
    /// so nothing can be expired while `now < oldest + ttl`;
    /// the watermark lets `purge_expired` skip its full scan
    /// in that common case. It is always <= the true oldest
    /// creation time of an open session (inserts only lower
    /// it, sweeps recompute it exactly), so the skip is safe:
    /// a stale watermark causes an occasional needless scan,
    /// never a missed expiry.
    oldest_created: Option<Instant>,
}

impl Default for InfinityMesh {
    fn default() -> Self {
        Self::new()
    }
}

impl InfinityMesh {
    pub fn new() -> Self {
        Self::with_ttl(DEFAULT_TTL)
    }

    pub fn with_ttl(ttl: Duration) -> Self {
        Self {
            control: HashMap::new(),
            sessions: HashMap::new(),
            ttl,
            oldest_created: None,
        }
    }

    /// Opens a session over `payloads` (n of them, all the
    /// same non-zero length), closing once `threshold`
    /// distinct valid shares have arrived. Returns the
    /// sender-side session handle and the shares to send, in
    /// payload order, each on its pre-spread lane.
    pub fn open_session(
        &mut self,
        payloads: Vec<Vec<u8>>,
        threshold: usize,
        label_hint: u8,
    ) -> Result<(MeshSession, Vec<MeshShare>), MeshError> {
        self.purge_expired();
        let n = payloads.len();
        if !(2..=(LANE_COUNT as usize)).contains(&n) {
            return Err(MeshError::InvalidShareCount);
        }
        if threshold < 2 || threshold > n {
            return Err(MeshError::InvalidThreshold);
        }
        let expected_len = payloads[0].len();
        if expected_len == 0 || payloads.iter().any(|p| p.len() != expected_len) {
            return Err(MeshError::MismatchedPayloads);
        }
        let label = classify(label_hint);
        let id = secure_tag();
        let start = (secure_bytes(1)[0] % LANE_COUNT) as u16;
        let step = ((LANE_COUNT as u16) / (n as u16)).max(1);
        let mut tags: Vec<[u8; 16]> = Vec::with_capacity(n);
        let mut lanes: Vec<u8> = Vec::with_capacity(n);
        let mut shares: Vec<MeshShare> = Vec::with_capacity(n);
        for (i, payload) in payloads.into_iter().enumerate() {
            let mut tag = secure_tag();
            while tags.contains(&tag) || self.control.contains_key(&tag) {
                tag = secure_tag();
            }
            tags.push(tag);
            let lane = ((start + (i as u16) * step) % (LANE_COUNT as u16)) as u8;
            lanes.push(lane);
            self.control.insert(tag, id);
            shares.push(MeshShare {
                tag,
                lane,
                label,
                payload,
            });
        }
        let lane_by_tag: HashMap<[u8; 16], u8> =
            tags.iter().copied().zip(lanes.iter().copied()).collect();
        let created = Instant::now();
        let state = SessionState {
            threshold,
            expected_len,
            tags: tags.clone(),
            lane_by_tag,
            label,
            collected: HashMap::new(),
            created,
        };
        self.sessions.insert(id, state);
        self.oldest_created = Some(match self.oldest_created {
            Some(t) => t.min(created),
            None => created,
        });
        Ok((
            MeshSession {
                tags,
                lanes,
                label,
                id,
            },
            shares,
        ))
    }

    /// Builds a decoy share: a random payload under a random
    /// tag that is not in the control map, on a routing-gate
    /// lane. Same size, shape, and label distribution as a
    /// real share; the receiver drops it silently.
    pub fn make_decoy(&self, len: usize, label_hint: u8) -> MeshShare {
        let tag = secure_tag();
        let label = classify(label_hint);
        let lane = routing_gate(&tag, label);
        MeshShare {
            tag,
            lane,
            label,
            payload: secure_bytes(len),
        }
    }

    /// Receives one share. Returns `Some(payloads)` — the
    /// distinct valid payloads collected, in arrival order —
    /// at the moment the session's threshold is met, and
    /// closes the session. Returns `None` for decoys, unknown
    /// tags, duplicates beyond the first copy, wrong-length
    /// payloads, shares whose lane or label does not match
    /// the lane and label the session assigned to their tag,
    /// and shares of expired or already-closed sessions; all
    /// of those are dropped silently.
    pub fn receive(&mut self, share: MeshShare) -> Option<Vec<Vec<u8>>> {
        self.purge_expired();
        let sid = self.control.get(&share.tag).copied()?;
        let state = self.sessions.get_mut(&sid)?;
        // Lane/label validation (review finding, 2026-11-19):
        // a share carrying a session tag but arriving on a
        // different lane, or under a different label, than the
        // session assigned is not the share that was sent —
        // drop it, mirroring the transport layer's AAD binding
        // of the same two fields.
        if share.label != state.label {
            return None;
        }
        match state.lane_by_tag.get(&share.tag) {
            Some(&assigned) if assigned == share.lane => {}
            _ => return None,
        }
        if share.payload.len() != state.expected_len {
            return None;
        }
        state.collected.entry(share.tag).or_insert(share);
        if state.collected.len() < state.threshold {
            return None;
        }
        let state = self.sessions.remove(&sid)?;
        for t in &state.tags {
            self.control.remove(t);
        }
        let payloads: Vec<Vec<u8>> = state
            .collected
            .into_values()
            .map(|mut s| std::mem::take(&mut s.payload))
            .collect();
        Some(payloads)
    }

    /// Sweeps every session older than the TTL: its control
    /// entries are removed and its collected payloads are
    /// zeroized before the state drops. Returns how many
    /// sessions were purged. Called at the top of
    /// [`Self::open_session`] and [`Self::receive`]; call it
    /// directly to bound how long expired state lingers in an
    /// otherwise idle process.
    pub fn purge_expired(&mut self) -> usize {
        let now = Instant::now();
        // Fast path (v0.16.0): the oldest open session has not
        // reached the TTL, so no session has — skip the scan
        // and its allocation entirely.
        if let Some(oldest) = self.oldest_created {
            if now.duration_since(oldest) < self.ttl {
                return 0;
            }
        }
        let expired: Vec<[u8; 16]> = self
            .sessions
            .iter()
            .filter(|(_, st)| now.duration_since(st.created) >= self.ttl)
            .map(|(sid, _)| *sid)
            .collect();
        let count = expired.len();
        for sid in expired {
            if let Some(state) = self.sessions.remove(&sid) {
                for t in &state.tags {
                    self.control.remove(t);
                }
                state.wipe();
            }
        }
        self.oldest_created = self.sessions.values().map(|st| st.created).min();
        count
    }

    /// Number of sessions currently open.
    pub fn active_sessions(&self) -> usize {
        self.sessions.len()
    }
}

/// Zeroizes and clears a buffer (e.g. a reconstructed secret
/// held as a plain `Vec`). Prefer a zeroizing buffer type
/// where the API allows it.
pub fn zeroize(buf: &mut Vec<u8>) {
    buf.zeroize();
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::secret_split::{reconstruct_secret, split_secret};
    use std::collections::HashSet;

    fn dummy_payloads(n: usize, len: usize) -> Vec<Vec<u8>> {
        (0..n).map(|i| vec![(i as u8) ^ 0x5A; len]).collect()
    }

    #[test]
    fn shamir_end_to_end_with_a_lost_lane() {
        // The headline property: 2-of-3 Shamir shares wrapped
        // in the mesh; one lane's share never arrives and the
        // secret still rebuilds — the paste design died here.
        let secret = b"session-secret-for-the-mesh";
        let shares = split_secret(secret, 2, 3).unwrap();
        let payloads: Vec<Vec<u8>> = shares.iter().map(encode_share).collect();
        let mut mesh = InfinityMesh::new();
        let (_session, wire) = mesh.open_session(payloads, 2, 2).unwrap();
        assert_eq!(mesh.receive(wire[0].clone()), None);
        let decoy = mesh.make_decoy(1 + secret.len(), 2);
        assert_eq!(mesh.receive(decoy), None);
        // wire[2] is lost on its lane; wire[1] meets threshold.
        let got = mesh.receive(wire[1].clone()).expect("threshold met");
        let decoded: Vec<SecretShare> = got.iter().map(|p| decode_share(p).unwrap()).collect();
        let recovered = reconstruct_secret(&decoded, 2).unwrap();
        assert_eq!(recovered.as_slice(), secret.as_slice());
        // Session closed: the lost share arriving late is dropped.
        assert_eq!(mesh.receive(wire[2].clone()), None);
        assert_eq!(mesh.active_sessions(), 0);
    }

    #[test]
    fn below_threshold_returns_none() {
        let mut mesh = InfinityMesh::new();
        let (_s, wire) = mesh.open_session(dummy_payloads(4, 8), 3, 0).unwrap();
        assert_eq!(mesh.receive(wire[0].clone()), None);
        assert_eq!(mesh.receive(wire[1].clone()), None);
        assert!(mesh.receive(wire[2].clone()).is_some());
    }

    #[test]
    fn decoy_dropped_and_harmless() {
        let mut mesh = InfinityMesh::new();
        let (_s, wire) = mesh.open_session(dummy_payloads(4, 8), 2, 3).unwrap();
        let decoy = mesh.make_decoy(8, 3);
        assert_eq!(decoy.payload.len(), 8);
        assert_eq!(mesh.receive(decoy), None);
        assert_eq!(mesh.receive(wire[0].clone()), None);
        assert!(mesh.receive(wire[1].clone()).is_some());
    }

    #[test]
    fn duplicate_share_no_double_count() {
        let mut mesh = InfinityMesh::new();
        let (_s, wire) = mesh.open_session(dummy_payloads(4, 8), 3, 1).unwrap();
        assert_eq!(mesh.receive(wire[0].clone()), None);
        assert_eq!(mesh.receive(wire[0].clone()), None);
        assert_eq!(mesh.receive(wire[1].clone()), None);
        assert!(mesh.receive(wire[2].clone()).is_some());
    }

    #[test]
    fn wrong_lane_or_label_share_dropped() {
        // Regression for the 2026-11-19 review finding: receive
        // never checked that a share arrived on the lane (or
        // under the label) its tag was assigned. A relocated
        // share is dropped; the genuine share still completes
        // the session.
        let mut mesh = InfinityMesh::new();
        let (_s, wire) = mesh.open_session(dummy_payloads(4, 8), 2, 2).unwrap();
        let mut relocated = wire[1].clone();
        relocated.lane = (relocated.lane + 1) % LANE_COUNT;
        assert_eq!(mesh.receive(relocated), None);
        let mut relabeled = wire[1].clone();
        relabeled.label = (relabeled.label + 1) % 4;
        assert_eq!(mesh.receive(relabeled), None);
        assert_eq!(mesh.receive(wire[0].clone()), None);
        assert!(mesh.receive(wire[1].clone()).is_some());
    }

    #[test]
    fn wrong_length_share_dropped_without_panic() {
        // Regression for the lab-graded paste defect: a valid
        // tag carrying a truncated payload panicked the
        // paste's receiver. Here it is dropped and the
        // session still completes on the genuine shares.
        let mut mesh = InfinityMesh::new();
        let (_s, wire) = mesh.open_session(dummy_payloads(4, 16), 2, 2).unwrap();
        let mut damaged = wire[1].clone();
        damaged.payload.truncate(4);
        assert_eq!(mesh.receive(damaged), None);
        assert_eq!(mesh.receive(wire[0].clone()), None);
        assert!(mesh.receive(wire[1].clone()).is_some());
    }

    #[test]
    fn lanes_distinct_for_all_n_and_quartered_at_4() {
        let mut mesh = InfinityMesh::new();
        for n in 2..=(LANE_COUNT as usize) {
            let (session, _wire) = mesh.open_session(dummy_payloads(n, 4), 2, 0).unwrap();
            let set: HashSet<u8> = session.lanes.iter().copied().collect();
            assert_eq!(set.len(), n, "lane collision at n={}", n);
        }
        let (session, _wire) = mesh.open_session(dummy_payloads(4, 4), 2, 0).unwrap();
        for i in 0..4 {
            let expect = (session.lanes[0] as u16 + 9 * i as u16) % (LANE_COUNT as u16);
            assert_eq!(session.lanes[i] as u16, expect);
        }
    }

    #[test]
    fn ttl_expiry_kills_session() {
        let mut mesh = InfinityMesh::with_ttl(Duration::from_millis(50));
        let (_s, wire) = mesh.open_session(dummy_payloads(4, 8), 2, 2).unwrap();
        assert_eq!(mesh.receive(wire[0].clone()), None);
        std::thread::sleep(Duration::from_millis(90));
        assert_eq!(mesh.purge_expired(), 1);
        assert_eq!(mesh.receive(wire[1].clone()), None);
        assert_eq!(mesh.active_sessions(), 0);
    }

    #[test]
    fn two_sessions_isolated() {
        let mut mesh = InfinityMesh::new();
        let (_sa, a) = mesh.open_session(dummy_payloads(3, 6), 2, 0).unwrap();
        let pb: Vec<Vec<u8>> = (0..3).map(|i| vec![(i as u8) ^ 0xC3; 6]).collect();
        let (_sb, b) = mesh.open_session(pb.clone(), 2, 1).unwrap();
        assert_eq!(mesh.receive(a[0].clone()), None);
        assert_eq!(mesh.receive(b[0].clone()), None);
        let got_b = mesh.receive(b[1].clone()).expect("b threshold");
        assert!(got_b.iter().all(|p| pb.contains(p)));
        let got_a = mesh.receive(a[1].clone()).expect("a threshold");
        assert_eq!(got_a.len(), 2);
    }

    #[test]
    fn unknown_tag_dropped() {
        let mut mesh = InfinityMesh::new();
        let bogus = MeshShare {
            tag: [7u8; 16],
            lane: 3,
            label: 0,
            payload: vec![1, 2, 3],
        };
        assert_eq!(mesh.receive(bogus), None);
    }

    #[test]
    fn open_session_validation() {
        let mut mesh = InfinityMesh::new();
        assert!(matches!(
            mesh.open_session(dummy_payloads(1, 4), 2, 0),
            Err(MeshError::InvalidShareCount)
        ));
        assert!(matches!(
            mesh.open_session(dummy_payloads(3, 4), 4, 0),
            Err(MeshError::InvalidThreshold)
        ));
        assert!(matches!(
            mesh.open_session(dummy_payloads(3, 4), 1, 0),
            Err(MeshError::InvalidThreshold)
        ));
        let mut ragged = dummy_payloads(3, 4);
        ragged[1].truncate(2);
        assert!(matches!(
            mesh.open_session(ragged, 2, 0),
            Err(MeshError::MismatchedPayloads)
        ));
        assert!(matches!(
            mesh.open_session(vec![Vec::new(), Vec::new()], 2, 0),
            Err(MeshError::MismatchedPayloads)
        ));
    }

    #[test]
    fn delays_shape_and_gate_ranges() {
        let d = staggered_delays(4, 0, 800);
        assert_eq!(d.len(), 4);
        for (i, &v) in d.iter().enumerate() {
            let base = (i as u64) * 800;
            assert!((base..=base + 400).contains(&v));
        }
        assert!(d.windows(2).all(|w| w[1] > w[0]));
        for m in 0..=255u8 {
            assert!(classify(m) < 4);
        }
        let tag = [200u8; 16];
        for label in 0..=255u8 {
            assert!(routing_gate(&tag, label) < LANE_COUNT);
        }
    }
}
