//! Threshold signatures — REAL FROST (RFC 9591) via `frost-ed25519`,
//! integrated v0.5.0.
//!
//! This is the genuine threshold construction the design note adopted:
//! distributed key generation with NO trusted dealer (no participant
//! ever holds the whole secret), quorum signing, and aggregate
//! signatures that are ordinary Ed25519 signatures — verifiable under
//! `ed25519_dalek::VerifyingKey::verify_strict`, the same verifier the
//! rest of this crate (and the Gen 1 estate) already uses. The
//! construction was proven in the scratch lab on 2026-11-15
//! (`gen2-threshold-lab`, 6/6 checks) before integration.
//!
//! Stated limits, plainly:
//! - This module is the protocol machinery. [`run_dkg`] drives a full
//!   ceremony in-process, which is how a single operator provisions a
//!   group locally and how the tests exercise the protocol.
//! - Moving shares and packages between DEVICES requires an
//!   authenticated transport, which is NOT in this module. Participants
//!   and packages are serializable ([`ThresholdParticipant::to_bytes`])
//!   so a transport can be built on top; until one exists, a
//!   multi-device quorum is not claimed.
//! - The threshold winner's audit note stands: the NCC Group audit
//!   covered frost-core / frost-ed25519 at v0.6-era code; this crate
//!   pins the maintained 2.x line and proves the round trip with its
//!   own tests rather than leaning on the audit.

use std::collections::BTreeMap;

use ed25519_dalek::{Signature as DalekSignature, VerifyingKey as DalekVerifyingKey};
use frost::keys::{dkg, KeyPackage, PublicKeyPackage};
use frost::{Identifier, SigningPackage};
use frost_ed25519 as frost;
use rand::rngs::OsRng;

fn ident(n: u16) -> Result<Identifier, String> {
    Identifier::try_from(n).map_err(|e| format!("invalid participant identifier {n}: {e}"))
}

/// One participant's key material after DKG. In a multi-device
/// deployment this package lives on that participant's device; treat
/// its serialized form as a SECRET.
pub struct ThresholdParticipant {
    identifier: u16,
    key_package: KeyPackage,
}

impl ThresholdParticipant {
    pub fn identifier(&self) -> u16 {
        self.identifier
    }

    /// Serializes the participant's key package (SECRET material).
    pub fn to_bytes(&self) -> Result<Vec<u8>, String> {
        self.key_package
            .serialize()
            .map_err(|e| format!("key package serialization failed: {e}"))
    }

    /// Restores a participant from [`ThresholdParticipant::to_bytes`].
    pub fn from_bytes(identifier: u16, bytes: &[u8]) -> Result<Self, String> {
        let key_package = KeyPackage::deserialize(bytes)
            .map_err(|e| format!("key package deserialization failed: {e}"))?;
        Ok(Self {
            identifier,
            key_package,
        })
    }
}

/// A threshold group: the shared public material from a DKG ceremony.
pub struct ThresholdGroup {
    pub_package: PublicKeyPackage,
}

impl ThresholdGroup {
    /// The group verifying key as an ordinary Ed25519 verifying key —
    /// the form every other verifier in this crate consumes.
    pub fn verifying_key(&self) -> Result<DalekVerifyingKey, String> {
        let bytes: [u8; 32] = self
            .pub_package
            .verifying_key()
            .serialize()
            .map_err(|e| format!("group key serialization failed: {e}"))?
            .try_into()
            .map_err(|_| "group key is not 32 bytes".to_string())?;
        DalekVerifyingKey::from_bytes(&bytes)
            .map_err(|e| format!("group key is not a valid Ed25519 key: {e}"))
    }

    /// Verifies a threshold-produced signature as plain Ed25519
    /// (strict verification).
    pub fn verify(&self, message: &[u8], signature: &DalekSignature) -> Result<(), String> {
        let vk = self.verifying_key()?;
        vk.verify_strict(message, signature)
            .map_err(|_| "threshold signature verification failed".to_string())
    }
}

/// Runs a complete DKG ceremony in-process for the given participant
/// identifiers and threshold (e.g. ids [1,2,3], threshold 2 = 2-of-3).
/// No trusted dealer: the group secret is never assembled anywhere.
pub fn run_dkg(
    participant_ids: &[u16],
    threshold: u16,
) -> Result<(Vec<ThresholdParticipant>, ThresholdGroup), String> {
    if participant_ids.is_empty() {
        return Err("DKG needs at least one participant".into());
    }
    // Review finding (2026-11-19): duplicate participant IDs
    // were accepted, so one identity could silently occupy two
    // seats of the ceremony (and the threshold arithmetic would
    // count it twice). Reject any repeated identifier up front.
    {
        let mut seen = std::collections::HashSet::new();
        for &n in participant_ids {
            if !seen.insert(n) {
                return Err(format!("duplicate participant identifier {n}"));
            }
        }
    }
    if threshold == 0 || (threshold as usize) > participant_ids.len() {
        return Err("invalid threshold for the participant set".into());
    }
    let max_signers =
        u16::try_from(participant_ids.len()).map_err(|_| "too many participants".to_string())?;
    let ids: Vec<Identifier> = participant_ids
        .iter()
        .map(|&n| ident(n))
        .collect::<Result<_, _>>()?;

    // Round 1: broadcast packages.
    let mut r1_secrets = BTreeMap::new();
    let mut r1_packages = BTreeMap::new();
    for &who in &ids {
        let (secret, package) = dkg::part1(who, max_signers, threshold, OsRng)
            .map_err(|e| format!("DKG round 1 failed: {e}"))?;
        r1_secrets.insert(who, secret);
        r1_packages.insert(who, package);
    }

    // Round 2: per-recipient packages.
    let mut r2_secrets = BTreeMap::new();
    let mut received_by: BTreeMap<Identifier, BTreeMap<Identifier, dkg::round2::Package>> =
        BTreeMap::new();
    for &who in &ids {
        let others: BTreeMap<_, _> = r1_packages
            .iter()
            .filter(|(sender, _)| **sender != who)
            .map(|(s, p)| (*s, p.clone()))
            .collect();
        let (secret, to_send) = dkg::part2(
            r1_secrets.remove(&who).ok_or("missing round 1 secret")?,
            &others,
        )
        .map_err(|e| format!("DKG round 2 failed: {e}"))?;
        r2_secrets.insert(who, secret);
        for (recipient, package) in to_send {
            received_by
                .entry(recipient)
                .or_default()
                .insert(who, package);
        }
    }

    // Round 3: finalize. Every participant must derive the same group.
    let mut participants = Vec::new();
    let mut group: Option<PublicKeyPackage> = None;
    for (idx, &who) in ids.iter().enumerate() {
        let others: BTreeMap<_, _> = r1_packages
            .iter()
            .filter(|(sender, _)| **sender != who)
            .map(|(s, p)| (*s, p.clone()))
            .collect();
        let received = received_by.get(&who).ok_or("missing round 2 packages")?;
        let (key_package, public_package) = dkg::part3(&r2_secrets[&who], &others, received)
            .map_err(|e| format!("DKG round 3 failed: {e}"))?;
        match &group {
            None => group = Some(public_package),
            Some(existing) => {
                if existing.verifying_key() != public_package.verifying_key() {
                    return Err(
                        "DKG disagreement: participants derived different group keys".into(),
                    );
                }
            }
        }
        participants.push(ThresholdParticipant {
            identifier: participant_ids[idx],
            key_package,
        });
    }
    Ok((
        participants,
        ThresholdGroup {
            pub_package: group.ok_or("DKG produced no group package")?,
        },
    ))
}

/// Produces a threshold signature over `message` with the given
/// signing participants (a subset of the group at or above threshold).
/// The result is an ordinary Ed25519 signature under the group key.
/// Below-threshold sets fail at aggregation — a lone signer cannot
/// produce a valid signature.
pub fn sign_message(
    group: &ThresholdGroup,
    signers: &[&ThresholdParticipant],
    message: &[u8],
) -> Result<DalekSignature, String> {
    if signers.is_empty() {
        return Err("no signers supplied".into());
    }
    let mut nonces = BTreeMap::new();
    let mut commitments = BTreeMap::new();
    for signer in signers {
        let who = ident(signer.identifier)?;
        let (n, c) = frost::round1::commit(signer.key_package.signing_share(), &mut OsRng);
        nonces.insert(who, n);
        commitments.insert(who, c);
    }
    let signing_package = SigningPackage::new(commitments, message);
    let mut shares = BTreeMap::new();
    for signer in signers {
        let who = ident(signer.identifier)?;
        let share = frost::round2::sign(&signing_package, &nonces[&who], &signer.key_package)
            .map_err(|e| format!("threshold signing round failed: {e}"))?;
        shares.insert(who, share);
    }
    let signature = frost::aggregate(&signing_package, &shares, &group.pub_package)
        .map_err(|e| format!("threshold aggregation failed (below threshold?): {e}"))?;
    let bytes: [u8; 64] = signature
        .serialize()
        .map_err(|e| format!("signature serialization failed: {e}"))?
        .try_into()
        .map_err(|_| "threshold signature is not 64 bytes".to_string())?;
    Ok(DalekSignature::from_bytes(&bytes))
}
