#![forbid(unsafe_code)]

use std::fmt;
use zeroize::Zeroizing;

#[derive(Debug)]
pub enum CdrError {
    DisallowedExecutableHeader(String),
    EmbeddedHostileScriptDetected(String),
    ZeroLengthDisarmedPayload,
}

impl fmt::Display for CdrError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::DisallowedExecutableHeader(h) => {
                write!(f, "Prohibited binary executable header detected: {h}")
            }
            Self::EmbeddedHostileScriptDetected(s) => {
                write!(f, "Embedded hostile script or macro stripped: {s}")
            }
            Self::ZeroLengthDisarmedPayload => {
                write!(f, "CDR reconstruction yielded zero usable bytes")
            }
        }
    }
}

impl std::error::Error for CdrError {}

/// Content Disarm and Reconstruction (CDR) Engine
pub struct ContentDisarmEngine;

impl ContentDisarmEngine {
    /// Sanitizes and reconstructs raw payload bytes, neutralizing executable headers and active scripts.
    pub fn sanitize_and_reconstruct(raw_bytes: &[u8]) -> Result<Zeroizing<Vec<u8>>, CdrError> {
        if raw_bytes.is_empty() {
            return Err(CdrError::ZeroLengthDisarmedPayload);
        }

        // Prohibit known malicious binary headers (ELF, PE, Mach-O)
        if raw_bytes.starts_with(b"\x7fELF") {
            return Err(CdrError::DisallowedExecutableHeader(
                "ELF binary header".to_string(),
            ));
        }
        if raw_bytes.starts_with(b"MZ") {
            return Err(CdrError::DisallowedExecutableHeader(
                "PE/DOS binary header".to_string(),
            ));
        }
        if raw_bytes.starts_with(b"\xfe\xed\xfa\xce") || raw_bytes.starts_with(b"\xca\xfe\xba\xbe")
        {
            return Err(CdrError::DisallowedExecutableHeader(
                "Mach-O binary header".to_string(),
            ));
        }

        // Search for active script and macro tags
        let hostile_patterns: &[&[u8]] = &[
            b"<script",
            b"javascript:",
            b"vbscript:",
            b"/bin/sh",
            b"/bin/bash",
            b"powershell",
            b"cmd.exe",
        ];

        let lower = raw_bytes.to_ascii_lowercase();
        for &pattern in hostile_patterns {
            if lower.windows(pattern.len()).any(|w| w == pattern) {
                let pattern_str = String::from_utf8_lossy(pattern).to_string();
                return Err(CdrError::EmbeddedHostileScriptDetected(pattern_str));
            }
        }

        // Produce reconstructed clean buffer
        Ok(Zeroizing::new(raw_bytes.to_vec()))
    }
}

/// The result of a text disarm-and-rebuild: the rebuilt bytes and a
/// plain record of what was removed. Unlike `sanitize_and_reconstruct`
/// (which REJECTS payloads carrying active content), this function is
/// for text that must be delivered in cleaned form.
#[derive(Debug)]
pub struct TextDisarmOutcome {
    pub bytes: Zeroizing<Vec<u8>>,
    /// Removal classes applied, in application order (each at most once).
    pub removed: Vec<&'static str>,
    /// True when the rebuilt bytes differ from the input.
    pub changed: bool,
}

impl ContentDisarmEngine {
    /// Disarms and REBUILDS a text payload (v0.7.0): removes whole
    /// `<script>...</script>` blocks, neutralizes `javascript:` /
    /// `vbscript:` URI schemes, strips NUL bytes, and strips ANSI
    /// escape sequences — returning the cleaned bytes, not the
    /// original. Benign text passes through byte-identical. A payload
    /// that rebuilds to nothing is an error, matching the engine's
    /// zero-length rule.
    pub fn disarm_text_payload(raw_bytes: &[u8]) -> Result<TextDisarmOutcome, CdrError> {
        if raw_bytes.is_empty() {
            return Err(CdrError::ZeroLengthDisarmedPayload);
        }
        let mut removed: Vec<&'static str> = Vec::new();
        let mut work: Vec<u8> = raw_bytes.to_vec();

        // 1. Whole script blocks (case-insensitive). An unclosed block
        //    is cut to the end of the payload.
        loop {
            let lower = work.to_ascii_lowercase();
            let Some(start) = find_subslice(&lower, b"<script") else {
                break;
            };
            let end = find_subslice(&lower[start..], b"</script>")
                .map(|e| start + e + b"</script>".len())
                .unwrap_or(work.len());
            work.drain(start..end);
            if !removed.contains(&"script-block") {
                removed.push("script-block");
            }
        }

        // 2. Script URI schemes, neutralized in place.
        for (scheme, label) in [
            (&b"javascript:"[..], "javascript-scheme"),
            (&b"vbscript:"[..], "vbscript-scheme"),
        ] {
            let mut replaced = false;
            loop {
                let lower = work.to_ascii_lowercase();
                let Some(pos) = find_subslice(&lower, scheme) else {
                    break;
                };
                work.splice(pos..pos + scheme.len(), *b"blocked:");
                replaced = true;
            }
            if replaced {
                removed.push(label);
            }
        }

        // 3. NUL bytes.
        if work.contains(&0) {
            work.retain(|&b| b != 0);
            removed.push("nul-bytes");
        }

        // 4. ANSI escape sequences: ESC [ ... final byte in 0x40..=0x7E.
        {
            let mut out: Vec<u8> = Vec::with_capacity(work.len());
            let mut i = 0;
            let mut stripped = false;
            while i < work.len() {
                if work[i] == 0x1b && i + 1 < work.len() && work[i + 1] == b'[' {
                    let mut j = i + 2;
                    while j < work.len() && !(0x40..=0x7e).contains(&work[j]) {
                        j += 1;
                    }
                    if j < work.len() {
                        j += 1; // consume the final byte
                    }
                    i = j;
                    stripped = true;
                } else {
                    out.push(work[i]);
                    i += 1;
                }
            }
            if stripped {
                removed.push("ansi-escapes");
                work = out;
            }
        }

        if work.is_empty() {
            return Err(CdrError::ZeroLengthDisarmedPayload);
        }
        let changed = work != raw_bytes;
        Ok(TextDisarmOutcome {
            bytes: Zeroizing::new(work),
            removed,
            changed,
        })
    }
}

fn find_subslice(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() || haystack.len() < needle.len() {
        return None;
    }
    haystack.windows(needle.len()).position(|w| w == needle)
}
