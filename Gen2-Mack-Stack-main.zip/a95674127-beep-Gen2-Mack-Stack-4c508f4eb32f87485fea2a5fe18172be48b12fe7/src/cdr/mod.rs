//! Content disarm and reconstruction.
//!
//! STATUS (2026-11-15): a first-step filter is implemented — executable
//! magic headers (ELF/PE/Mach-O) are rejected and embedded script
//! patterns are detected. It does not yet parse or rebuild document
//! formats; payloads that pass are returned unchanged.

pub mod content_disarm;
