//! Shamir secret splitting over GF(256) (v0.12.0) — the
//! mechanism by which `mack-proxy` holds its session secret.
//!
//! The proxy splits the secret it read from its environment into
//! `n` shares with a threshold of `k` (the session configuration
//! is k = 2 of n = 3, [`SPLIT_THRESHOLD`] of
//! [`SPLIT_SHARE_COUNT`]) and drops the assembled buffer. From
//! then on the proxy holds ONLY shares. At each credential
//! injection it reconstructs the secret into a zeroizing buffer,
//! builds the `Authorization` header from it, and the buffer is
//! wiped on drop — so the assembled secret exists only
//! transiently, inside one burn, never at rest in the proxy.
//!
//! HONEST SCOPE: in this release all shares are co-located in
//! the proxy process. Splitting here is an in-process hygiene
//! measure — it removes the long-lived assembled secret from
//! the proxy's memory and forces every use through an explicit
//! reconstruct-and-wipe — it is NOT multi-party custody. No
//! share leaves the process; distribution of shares across
//! devices waits on the multi-device transport that remains
//! unbuilt (see `threshold` module status).
//!
//! Implementation: hand-rolled GF(256) arithmetic (AES field,
//! polynomial 0x11B), no new dependencies. The polynomial's
//! constant coefficient IS the secret byte; the remaining
//! coefficients are drawn from the OS CSPRNG (`rand`'s `OsRng`)
//! per byte. Shares are zeroized on drop; reconstruction returns
//! a [`Zeroizing`] buffer.

use rand::rngs::OsRng;
use rand::RngCore;
use std::fmt;
use zeroize::{Zeroize, Zeroizing};

/// Threshold used for the proxy's session secret.
pub const SPLIT_THRESHOLD: u8 = 2;
/// Share count used for the proxy's session secret.
pub const SPLIT_SHARE_COUNT: u8 = 3;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SplitError {
    /// k < 2 or n < k.
    InvalidThreshold,
    /// The secret to split is empty.
    EmptySecret,
    /// Fewer than k shares were presented for reconstruction.
    InsufficientShares,
    /// Share lengths differ, a share is empty, or an index is 0
    /// (x = 0 is the secret itself and is never a share index).
    MalformedShares,
    /// Two presented shares carry the same index.
    DuplicateShareIndex,
}

impl fmt::Display for SplitError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidThreshold => write!(f, "threshold k must be >= 2 and <= n"),
            Self::EmptySecret => write!(f, "cannot split an empty secret"),
            Self::InsufficientShares => {
                write!(f, "fewer shares than the threshold k were provided")
            }
            Self::MalformedShares => {
                write!(
                    f,
                    "share lengths differ, a share is empty, or an index is 0"
                )
            }
            Self::DuplicateShareIndex => write!(f, "duplicate share index presented"),
        }
    }
}

impl std::error::Error for SplitError {}

/// One Shamir share: an x-coordinate (1..=n) and one y-byte per
/// secret byte. The payload is zeroized when the share drops.
#[derive(Clone, Zeroize)]
#[zeroize(drop)]
pub struct SecretShare {
    pub index: u8,
    pub data: Vec<u8>,
}

/// GF(256) multiplication, AES field (irreducible polynomial
/// 0x11B), Russian-peasant form.
fn gf256_mul(mut a: u8, mut b: u8) -> u8 {
    let mut p = 0u8;
    for _ in 0..8 {
        if (b & 1) != 0 {
            p ^= a;
        }
        let hi_bit = a & 0x80;
        a <<= 1;
        if hi_bit != 0 {
            a ^= 0x1b;
        }
        b >>= 1;
    }
    p
}

/// GF(256) multiplicative inverse via Fermat's little theorem
/// (a^254). By convention here gf256_inv(0) == 0; callers never
/// invert 0 (denominators are differences of distinct nonzero
/// indices).
fn gf256_inv(a: u8) -> u8 {
    if a == 0 {
        return 0;
    }
    let mut result = 1u8;
    let mut base = a;
    let mut exp = 254u16;
    while exp > 0 {
        if (exp & 1) != 0 {
            result = gf256_mul(result, base);
        }
        base = gf256_mul(base, base);
        exp >>= 1;
    }
    result
}

/// Splits `secret` into `n` shares, any `k` of which reconstruct
/// it. The constant coefficient of each byte's polynomial IS the
/// secret byte; coefficients 1..k are fresh OS randomness per
/// byte.
pub fn split_secret(secret: &[u8], k: u8, n: u8) -> Result<Vec<SecretShare>, SplitError> {
    if k < 2 || n < k {
        return Err(SplitError::InvalidThreshold);
    }
    if secret.is_empty() {
        return Err(SplitError::EmptySecret);
    }
    let mut rng = OsRng;
    let mut shares: Vec<SecretShare> = (1..=n)
        .map(|index| SecretShare {
            index,
            data: vec![0u8; secret.len()],
        })
        .collect();
    // Per-byte polynomial coefficients; wiped on drop. The
    // constant term of each byte's polynomial IS the secret
    // byte; coefficients 1..k are fresh OS randomness per byte.
    // v0.16.0: draw ALL of that randomness in one CSPRNG call
    // up front instead of one call per byte — the distribution
    // is identical (independent uniform bytes), only the syscall
    // count changes.
    let k = k as usize;
    let mut random_coeffs = Zeroizing::new(vec![0u8; (k - 1) * secret.len()]);
    rng.fill_bytes(&mut random_coeffs);
    for (byte_pos, &secret_byte) in secret.iter().enumerate() {
        let row = &random_coeffs[byte_pos * (k - 1)..(byte_pos + 1) * (k - 1)];
        for share in &mut shares {
            let x = share.index;
            // Horner evaluation at x over the coefficients
            // [secret_byte, row[0], ..., row[k-2]].
            let mut y = 0u8;
            for &c in row.iter().rev() {
                y = gf256_mul(y, x) ^ c;
            }
            y = gf256_mul(y, x) ^ secret_byte;
            share.data[byte_pos] = y;
        }
    }
    Ok(shares)
}

/// Reconstructs the secret from the first `k` of `shares` via
/// Lagrange interpolation at x = 0. The result lives in a
/// zeroizing buffer. Extra shares beyond k are ignored;
/// presenting fewer than k, duplicate indices, a zero index, or
/// mismatched share lengths is an error.
pub fn reconstruct_secret(shares: &[SecretShare], k: u8) -> Result<Zeroizing<Vec<u8>>, SplitError> {
    if k < 2 {
        return Err(SplitError::InvalidThreshold);
    }
    if (shares.len() as u32) < (k as u32) {
        return Err(SplitError::InsufficientShares);
    }
    let active = &shares[..(k as usize)];
    let secret_len = active[0].data.len();
    if secret_len == 0
        || active
            .iter()
            .any(|s| s.data.len() != secret_len || s.index == 0)
    {
        return Err(SplitError::MalformedShares);
    }
    for i in 0..active.len() {
        for j in (i + 1)..active.len() {
            if active[i].index == active[j].index {
                return Err(SplitError::DuplicateShareIndex);
            }
        }
    }
    // The Lagrange basis coefficients at x = 0 depend only on
    // the share indices, never on the byte position, so compute
    // them once (v0.16.0). The previous form recomputed them —
    // including a field inversion — for every byte, which made
    // reconstruction cost grow with secret length times the
    // per-byte coefficient cost. The interpolated values are
    // bit-for-bit identical.
    let mut lagrange = Vec::with_capacity(active.len());
    for (i, share_i) in active.iter().enumerate() {
        let xi = share_i.index;
        let mut num = 1u8;
        let mut den = 1u8;
        for (j, share_j) in active.iter().enumerate() {
            if i == j {
                continue;
            }
            let xj = share_j.index;
            num = gf256_mul(num, xj);
            den = gf256_mul(den, xi ^ xj);
        }
        lagrange.push(gf256_mul(num, gf256_inv(den)));
    }
    let mut secret = Zeroizing::new(vec![0u8; secret_len]);
    for byte_pos in 0..secret_len {
        let mut acc = 0u8;
        for (i, share_i) in active.iter().enumerate() {
            acc ^= gf256_mul(share_i.data[byte_pos], lagrange[i]);
        }
        secret[byte_pos] = acc;
    }
    Ok(secret)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn secret_of_len(len: usize) -> Vec<u8> {
        (0..len).map(|i| (i as u8) ^ 0xA5).collect()
    }

    #[test]
    fn roundtrip_for_several_lengths() {
        for len in [1usize, 2, 16, 32, 64] {
            let secret = secret_of_len(len);
            let shares = split_secret(&secret, SPLIT_THRESHOLD, SPLIT_SHARE_COUNT).unwrap();
            assert_eq!(shares.len(), 3);
            let recovered = reconstruct_secret(&shares, SPLIT_THRESHOLD).unwrap();
            assert_eq!(
                recovered.as_slice(),
                secret.as_slice(),
                "roundtrip failed at length {len}"
            );
        }
    }

    #[test]
    fn any_two_of_three_shares_reconstruct() {
        let secret = b"sk-live-roundtrip-secret";
        let shares = split_secret(secret, 2, 3).unwrap();
        for pair in [[0usize, 1], [0, 2], [1, 2]] {
            let subset = vec![shares[pair[0]].clone(), shares[pair[1]].clone()];
            let recovered = reconstruct_secret(&subset, 2).unwrap();
            assert_eq!(recovered.as_slice(), secret.as_slice(), "pair {pair:?}");
        }
        // All three shares also reconstruct (first k are used).
        let recovered = reconstruct_secret(&shares, 2).unwrap();
        assert_eq!(recovered.as_slice(), secret.as_slice());
    }

    #[test]
    fn one_share_is_not_enough() {
        let shares = split_secret(b"secret", 2, 3).unwrap();
        let err = reconstruct_secret(&shares[..1], 2).unwrap_err();
        assert_eq!(err, SplitError::InsufficientShares);
    }

    #[test]
    fn flipped_share_byte_yields_a_different_secret() {
        let secret = b"integrity-matters-here";
        let mut shares = split_secret(secret, 2, 3).unwrap();
        shares[0].data[0] ^= 0xFF;
        let recovered = reconstruct_secret(&shares, 2).unwrap();
        assert_ne!(
            recovered.as_slice(),
            secret.as_slice(),
            "a tampered share must not reconstruct the original secret"
        );
    }

    #[test]
    fn duplicate_index_and_mismatched_length_are_errors() {
        let shares = split_secret(b"0123456789abcdef", 2, 3).unwrap();
        let dup = vec![shares[0].clone(), shares[0].clone()];
        assert_eq!(
            reconstruct_secret(&dup, 2).unwrap_err(),
            SplitError::DuplicateShareIndex
        );
        let mut short = shares[1].clone();
        short.data.truncate(4);
        let mixed = vec![shares[0].clone(), short];
        assert_eq!(
            reconstruct_secret(&mixed, 2).unwrap_err(),
            SplitError::MalformedShares
        );
        let zero_index = SecretShare {
            index: 0,
            data: shares[0].data.clone(),
        };
        let with_zero = vec![zero_index, shares[1].clone()];
        assert_eq!(
            reconstruct_secret(&with_zero, 2).unwrap_err(),
            SplitError::MalformedShares
        );
    }

    #[test]
    fn invalid_parameters_are_refused() {
        // `.err()` rather than `.unwrap_err()`: SecretShare
        // deliberately does not derive Debug (it is secret
        // material), which unwrap_err would require of the Ok
        // type.
        assert_eq!(
            split_secret(b"x", 1, 3).err(),
            Some(SplitError::InvalidThreshold)
        );
        assert_eq!(
            split_secret(b"x", 3, 2).err(),
            Some(SplitError::InvalidThreshold)
        );
        assert_eq!(split_secret(b"", 2, 3).err(), Some(SplitError::EmptySecret));
    }
}
