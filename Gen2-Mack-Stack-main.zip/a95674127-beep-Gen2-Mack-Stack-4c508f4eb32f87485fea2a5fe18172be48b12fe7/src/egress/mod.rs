//! Egress sentinel — default-deny destination policy for lane traffic.
//!
//! Merged 2026-11-15 from the graded 7-pillar package, as received (its
//! logic graded sound). STATUS: this is a policy DECISION layer. It holds
//! the allowlist and the metadata blackhole and returns a verdict for each
//! request, logging the verdict to the ledger. It opens and blocks no
//! sockets itself — enforcement belongs to the caller (the egress proxy
//! consults it first). Matching is on normalized host strings, before any
//! DNS resolution.

use crate::ledger::ProofLedger;
use std::collections::HashSet;

/// Known cloud & link-local metadata endpoints that must ALWAYS be blackholed.
const BLACKHOLED_ENDPOINTS: &[&str] = &[
    "169.254.169.254",
    "169.254.170.2",
    "fd00:ec2::254",
    "metadata.google.internal",
    "metadata",
    "100.100.100.200",
];

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EgressVerdict {
    Allowed,
    DeniedMetadataBlackhole,
    DeniedNotAllowlisted,
    DeniedInsecureProtocol,
}

pub struct EgressSentinel {
    allowlisted_hosts: HashSet<String>,
}

impl Default for EgressSentinel {
    fn default() -> Self {
        Self::new()
    }
}

impl EgressSentinel {
    /// Starts with an empty allowlist (strict default-deny).
    pub fn new() -> Self {
        Self {
            allowlisted_hosts: HashSet::new(),
        }
    }

    pub fn allow_host(&mut self, host: &str) -> Result<(), String> {
        let normalized = host.trim().to_ascii_lowercase();
        if Self::is_blackholed(&normalized) {
            return Err(format!(
                "SECURITY VIOLATION: Cannot allowlist blackholed metadata endpoint '{}'",
                normalized
            ));
        }
        self.allowlisted_hosts.insert(normalized);
        Ok(())
    }

    pub fn is_blackholed(host: &str) -> bool {
        let h = host.trim().to_ascii_lowercase();
        BLACKHOLED_ENDPOINTS
            .iter()
            .any(|&blocked| h == blocked || h.starts_with("169.254."))
    }

    pub fn evaluate_request(
        &self,
        lane_id: &str,
        scheme: &str,
        host: &str,
        ledger: &mut ProofLedger,
    ) -> EgressVerdict {
        let normalized_host = host.trim().to_ascii_lowercase();
        let normalized_scheme = scheme.trim().to_ascii_lowercase();

        if Self::is_blackholed(&normalized_host) {
            ledger.append(
                "EGRESS_BLOCKED_METADATA",
                lane_id,
                normalized_host.as_bytes(),
                None,
            );
            return EgressVerdict::DeniedMetadataBlackhole;
        }

        if normalized_scheme != "https" {
            ledger.append(
                "EGRESS_BLOCKED_INSECURE_SCHEME",
                lane_id,
                format!("{}://{}", normalized_scheme, normalized_host).as_bytes(),
                None,
            );
            return EgressVerdict::DeniedInsecureProtocol;
        }

        if !self.allowlisted_hosts.contains(&normalized_host) {
            ledger.append(
                "EGRESS_BLOCKED_UNLISTED_HOST",
                lane_id,
                normalized_host.as_bytes(),
                None,
            );
            return EgressVerdict::DeniedNotAllowlisted;
        }

        ledger.append("EGRESS_ALLOWED", lane_id, normalized_host.as_bytes(), None);
        EgressVerdict::Allowed
    }
}
