//! Blind egress proxy — credential swap logic at the egress boundary.
//!
//! Merged 2026-11-15 from the graded 7-pillar package and adapted to this
//! crate's own vault (MackVaultEngine). The check order is the graded one:
//! sentinel verdict first, then handle state — consumed, expiry, and
//! run/lane/host/action scope — then the handle is burned, and only then
//! is the secret unsealed, inside this boundary.
//!
//! STATUS, honestly: this module performs the swap DECISION and the
//! unsealing. It dispatches no network traffic itself — the transport
//! layers live in the `mack-proxy` binary (loopback HTTP since v0.4.0;
//! CONNECT + split-TLS HTTPS since v0.9.0, see `tls` submodule) and
//! every dispatch goes through this module's checks first. The frame
//! carries the injected header, so callers must treat it as secret
//! material: never log it, never hand it to a lane. The lane itself
//! only ever holds the opaque handle.
//!
//! Since v0.12.0 a secret can also be registered as Shamir SHARES
//! ([`BlindEgressProxy::register_split_secret`], see
//! `secret_split`): the proxy then holds no assembled or sealed
//! form of that secret at all — at the burn it reconstructs the
//! secret into a zeroizing buffer, builds the header from it, and
//! the buffer is wiped on drop. The `mack-proxy` binary registers
//! its session secret this way. Vault-sealed registration remains
//! for the library's other callers.

pub mod tls;

use crate::auth::ScopedCredentialHandle;
use crate::egress::{EgressSentinel, EgressVerdict};
use crate::ledger::ProofLedger;
use crate::secret_split::{reconstruct_secret, SecretShare, SPLIT_THRESHOLD};
use crate::vault::{MackVaultEngine, SealedVaultPayload};
use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct OutboundRequest {
    pub run_id: String,
    pub lane_id: String,
    pub scheme: String,
    pub host: String,
    pub action: String,
    pub handle_token: String,
}

#[derive(Debug, Clone)]
pub struct DispatchedEgressFrame {
    pub destination: String,
    pub injected_auth_header: String,
    pub ledger_receipt_hash: String,
}

/// Holds sealed secrets and active handles; swaps real credentials ONLY
/// at the egress boundary, after every check has passed.
pub struct BlindEgressProxy {
    sealed_secrets: HashMap<String, SealedVaultPayload>,
    split_secrets: HashMap<String, Vec<SecretShare>>,
    active_handles: HashMap<String, ScopedCredentialHandle>,
}

impl Default for BlindEgressProxy {
    fn default() -> Self {
        Self::new()
    }
}

impl BlindEgressProxy {
    pub fn new() -> Self {
        Self {
            sealed_secrets: HashMap::new(),
            split_secrets: HashMap::new(),
            active_handles: HashMap::new(),
        }
    }

    pub fn register_sealed_secret(&mut self, ref_id: &str, sealed: SealedVaultPayload) {
        self.sealed_secrets.insert(ref_id.to_string(), sealed);
    }

    /// Registers a secret as Shamir shares (v0.12.0). The proxy
    /// holds ONLY the shares for this reference; the assembled
    /// secret is reconstructed transiently at each burn (see
    /// `secret_split` for the co-location honesty note).
    pub fn register_split_secret(&mut self, ref_id: &str, shares: Vec<SecretShare>) {
        self.split_secrets.insert(ref_id.to_string(), shares);
    }

    pub fn register_handle(&mut self, handle: ScopedCredentialHandle) {
        self.active_handles
            .insert(handle.opaque_handle.clone(), handle);
    }

    /// Executes the blind credential swap at the egress boundary.
    /// The calling lane never sees the unsealed secret.
    pub fn execute_egress(
        &mut self,
        req: &OutboundRequest,
        sentinel: &EgressSentinel,
        vault_passphrase: &[u8],
        now_epoch: u64,
        ledger: &mut ProofLedger,
    ) -> Result<DispatchedEgressFrame, String> {
        // 1. Default-deny egress & metadata blackhole first.
        let verdict = sentinel.evaluate_request(&req.lane_id, &req.scheme, &req.host, ledger);
        if verdict != EgressVerdict::Allowed {
            return Err(format!("Egress blocked by Sentinel: {:?}", verdict));
        }

        // 2. Validate the scoped handle (single-run, single-host,
        //    single-action, TTL, single-use).
        let handle = self
            .active_handles
            .get_mut(&req.handle_token)
            .ok_or_else(|| "Unknown or forged credential handle".to_string())?;

        if handle.consumed {
            ledger.append(
                "HANDLE_REPLAY_BLOCKED",
                &req.lane_id,
                req.handle_token.as_bytes(),
                None,
            );
            return Err("Credential handle already consumed (single-use violation)".into());
        }

        if now_epoch >= handle.request.expires_at_epoch {
            ledger.append(
                "HANDLE_EXPIRED_BLOCKED",
                &req.lane_id,
                req.handle_token.as_bytes(),
                None,
            );
            return Err("Credential handle expired".into());
        }

        if handle.request.run_id != req.run_id
            || handle.request.lane_id != req.lane_id
            || !handle.request.target_host.eq_ignore_ascii_case(&req.host)
            || !handle
                .request
                .allowed_action
                .eq_ignore_ascii_case(&req.action)
        {
            ledger.append(
                "HANDLE_SCOPE_MISMATCH",
                &req.lane_id,
                req.handle_token.as_bytes(),
                None,
            );
            return Err(
                "Credential handle scope mismatch (cross-run/host/action exfiltration blocked)"
                    .into(),
            );
        }

        // Burn the single-use handle immediately.
        handle.consumed = true;
        let secret_ref = handle.request.secret_ref_id.clone();

        // 3. Materialize the secret inside the proxy boundary
        //    only. A split-registered secret is reconstructed
        //    from its shares into a zeroizing buffer that is
        //    wiped when it drops at the end of this call; a
        //    vault-registered secret is unsealed. Either way the
        //    only lasting copy is the injected header itself,
        //    exactly as before.
        let secret_str = if let Some(shares) = self.split_secrets.get(&secret_ref) {
            let recovered = reconstruct_secret(shares, SPLIT_THRESHOLD)
                .map_err(|e| format!("Secret share reconstruction failed: {e}"))?;
            let s = std::str::from_utf8(&recovered)
                .map_err(|_| "Secret payload is not valid UTF-8".to_string())?
                .to_string();
            // `recovered` drops here and is zeroized.
            s
        } else {
            let sealed = self
                .sealed_secrets
                .get(&secret_ref)
                .ok_or_else(|| "Referenced secret not found in vault".to_string())?;
            let plaintext = MackVaultEngine::unseal(vault_passphrase, sealed)?;
            String::from_utf8(plaintext)
                .map_err(|_| "Secret payload is not valid UTF-8".to_string())?
        };

        let receipt = ledger.append(
            "BLIND_CREDENTIAL_INJECTED",
            &req.lane_id,
            format!("{}->{}", req.handle_token, req.host).as_bytes(),
            None,
        );

        Ok(DispatchedEgressFrame {
            destination: format!("{}://{}", req.scheme, req.host),
            injected_auth_header: format!("Bearer {}", secret_str),
            ledger_receipt_hash: receipt.entry_hash,
        })
    }
}
