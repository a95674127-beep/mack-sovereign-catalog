//! TLS transport support for the blind-egress proxy (v0.9.0).
//!
//! The transport design was adopted from an externally proposed
//! package after lab grading on 2026-11-15 (grade file Part 13): the
//! CONNECT + split-TLS mechanism was proven live in the lab, while
//! the package's wholesale replacement of the proxy — unconfined
//! child, unsigned records, a plain-env secret — was rejected. What
//! lives here is only the transport piece, rebuilt on this crate's
//! foundations: the swap decision, the vault, the sentinel, and the
//! signed ledger stay in `super` and the `mack-proxy` binary.
//!
//! Design, stated plainly:
//! - A single-session, in-memory root CA is generated per proxy run.
//!   Its private key never leaves the proxy process and never touches
//!   disk. Only the PUBLIC certificate (PEM) is written out, so the
//!   child can pin it as its trust root for this session.
//! - The proxy terminates the child's TLS (split-TLS) because
//!   credential injection is impossible through an opaque tunnel.
//!   That means the proxy process sees request plaintext at the
//!   egress boundary — inherent to the design, stated here and in
//!   THREAT_MODEL.md rather than hidden. The child never sees the
//!   real secret; the upstream never sees the child's handle.
//! - Upstream certificates are verified against the Mozilla root
//!   store (webpki-roots). An operator may ADD roots from a PEM file
//!   (private CA / testing) — roots are never removed or replaced.

use rcgen::{BasicConstraints, CertificateParams, DistinguishedName, DnType, IsCa, KeyPair};
use rustls::pki_types::pem::PemObject;
use rustls::pki_types::{CertificateDer, PrivateKeyDer, PrivatePkcs8KeyDer};
use rustls::{ClientConfig, RootCertStore, ServerConfig};
use std::collections::HashMap;
use std::path::Path;
use std::sync::{Arc, RwLock};
use zeroize::Zeroize;

/// Installs the ring crypto provider as the rustls process default.
/// This crate compiles exactly one provider (ring); installing it
/// explicitly keeps provider selection deterministic instead of
/// depending on feature unification across the dependency tree —
/// the failure mode that silently killed TLS accepts in the graded
/// package. Idempotent: a second install attempt is ignored.
pub fn ensure_crypto_provider() {
    let _ = rustls::crypto::ring::default_provider().install_default();
}

/// Single-session in-memory root CA for TLS termination.
pub struct EphemeralSessionCa {
    ca_cert_pem: String,
    ca_cert: rcgen::Certificate,
    ca_key_pair: KeyPair,
    leaf_cache: RwLock<HashMap<String, Arc<ServerConfig>>>,
}

impl EphemeralSessionCa {
    pub fn generate() -> Result<Self, String> {
        ensure_crypto_provider();
        let mut params = CertificateParams::default();
        params.is_ca = IsCa::Ca(BasicConstraints::Unconstrained);
        let mut dn = DistinguishedName::new();
        dn.push(DnType::CommonName, "Mack-Stack Ephemeral Session Root CA");
        dn.push(DnType::OrganizationName, "Gen2-Mack-Stack Runtime");
        params.distinguished_name = dn;

        let ca_key_pair = KeyPair::generate().map_err(|e| e.to_string())?;
        let ca_cert = params
            .self_signed(&ca_key_pair)
            .map_err(|e| e.to_string())?;

        Ok(Self {
            ca_cert_pem: ca_cert.pem(),
            ca_cert,
            ca_key_pair,
            leaf_cache: RwLock::new(HashMap::new()),
        })
    }

    /// The public CA certificate in PEM form — the only part of this
    /// CA that may leave the proxy process.
    pub fn public_ca_pem(&self) -> &str {
        &self.ca_cert_pem
    }

    /// A rustls server config terminating TLS for `host`, backed by a
    /// leaf certificate minted by the session CA. Cached per host.
    pub fn server_config_for_host(&self, host: &str) -> Result<Arc<ServerConfig>, String> {
        if let Some(existing) = self.leaf_cache.read().unwrap().get(host) {
            return Ok(Arc::clone(existing));
        }

        let mut leaf_params =
            CertificateParams::new(vec![host.to_string()]).map_err(|e| e.to_string())?;
        let mut dn = DistinguishedName::new();
        dn.push(DnType::CommonName, host);
        leaf_params.distinguished_name = dn;

        let leaf_key = KeyPair::generate().map_err(|e| e.to_string())?;
        let leaf_cert = leaf_params
            .signed_by(&leaf_key, &self.ca_cert, &self.ca_key_pair)
            .map_err(|e| e.to_string())?;

        let mut key_der_bytes = leaf_key.serialize_der();
        let priv_key = PrivateKeyDer::Pkcs8(PrivatePkcs8KeyDer::from(key_der_bytes.clone()));
        key_der_bytes.zeroize();

        let config = ServerConfig::builder()
            .with_no_client_auth()
            .with_single_cert(vec![leaf_cert.der().clone()], priv_key)
            .map_err(|e| e.to_string())?;

        let arc_config = Arc::new(config);
        self.leaf_cache
            .write()
            .unwrap()
            .insert(host.to_string(), Arc::clone(&arc_config));
        Ok(arc_config)
    }
}

/// Builds the upstream (client) TLS config: Mozilla roots from
/// webpki-roots, plus every certificate in `extra_roots_pem` when a
/// path is given (private CA / test CA seam — additive only).
pub fn upstream_client_config(extra_roots_pem: Option<&Path>) -> Result<Arc<ClientConfig>, String> {
    ensure_crypto_provider();
    let mut store = RootCertStore::empty();
    store.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
    if let Some(path) = extra_roots_pem {
        let pem_bytes = std::fs::read(path)
            .map_err(|e| format!("cannot read extra roots PEM {}: {e}", path.display()))?;
        let pem_text = String::from_utf8_lossy(&pem_bytes);
        let mut added = 0usize;
        // Split the bundle into blocks and parse each certificate.
        for block in pem_text.split("-----BEGIN CERTIFICATE-----").skip(1) {
            let full = format!("-----BEGIN CERTIFICATE-----{}", block);
            let cert = CertificateDer::from_pem_slice(full.as_bytes())
                .map_err(|e| format!("bad PEM in {}: {e}", path.display()))?;
            store
                .add(cert)
                .map_err(|e| format!("cannot add root from {}: {e}", path.display()))?;
            added += 1;
        }
        if added == 0 {
            return Err(format!("no certificates found in {}", path.display()));
        }
    }
    let config = ClientConfig::builder()
        .with_root_certificates(store)
        .with_no_client_auth();
    Ok(Arc::new(config))
}
