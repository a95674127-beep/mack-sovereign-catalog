//! Smoke entry point: exercises the vault core's seal/unseal round trip.

use mack_security_runtime::vault::MackVaultEngine;

fn main() {
    let sealed = MackVaultEngine::seal(b"smoke-passphrase", b"gen2-smoke-vector", "GENESIS")
        .expect("seal failed");
    let opened = MackVaultEngine::unseal(b"smoke-passphrase", &sealed).expect("unseal failed");
    assert_eq!(opened, b"gen2-smoke-vector");
    println!(
        "mack-security-runtime: vault seal/unseal smoke OK (audit event {})",
        sealed.audit_entry.event_id
    );
}
