#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ForensicEvidenceArtifact {
    pub case_id: String,
    pub timestamp_unix_millis: u64,
    pub payload_sha256: String,
    pub extracted_indicators: Vec<String>,
    pub custody_chain_hash: String,
}

pub struct ForensicDecompressionChamber;

impl ForensicDecompressionChamber {
    pub fn seal_evidence(chamber_lane: u8, raw_payload: &[u8]) -> ForensicEvidenceArtifact {
        let mut hasher = Sha256::new();
        hasher.update(raw_payload);
        let payload_sha256 = format!("{:x}", hasher.finalize());

        let timestamp_unix_millis = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_millis() as u64)
            .unwrap_or(0);

        let case_id = format!("MACK-CHAMBER-{chamber_lane}-{timestamp_unix_millis}");

        // Extract forensic strings without executing payload
        let mut indicators = Vec::new();
        let text = String::from_utf8_lossy(raw_payload);
        for line in text.lines() {
            if line.contains("C2_IP:") || line.contains("ORIGIN:") || line.contains("CANARY:") {
                indicators.push(line.trim().to_string());
            }
        }

        let mut custody_hasher = Sha256::new();
        custody_hasher.update(case_id.as_bytes());
        custody_hasher.update(payload_sha256.as_bytes());
        custody_hasher.update(timestamp_unix_millis.to_be_bytes());
        let custody_chain_hash = format!("{:x}", custody_hasher.finalize());

        ForensicEvidenceArtifact {
            case_id,
            timestamp_unix_millis,
            payload_sha256,
            extracted_indicators: indicators,
            custody_chain_hash,
        }
    }
}
