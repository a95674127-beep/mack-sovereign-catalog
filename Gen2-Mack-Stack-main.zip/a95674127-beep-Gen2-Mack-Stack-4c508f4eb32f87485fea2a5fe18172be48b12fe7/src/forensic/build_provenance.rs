#![forbid(unsafe_code)]

use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fmt;

#[derive(Debug)]
pub enum ProvenanceError {
    SourceMerkleMismatch { expected: String, actual: String },
    LockfileMismatch { expected: String, actual: String },
    BinaryMismatch { expected: String, actual: String },
    MissingRemapPathPrefix,
    InvalidSourceDateEpoch,
    SignatureInvalid,
    SignatureEncoding,
    Serialization(String),
}

impl fmt::Display for ProvenanceError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::SourceMerkleMismatch { expected, actual } => {
                write!(
                    f,
                    "Source tree Merkle root mismatch: expected {expected}, calculated {actual}"
                )
            }
            Self::LockfileMismatch { expected, actual } => {
                write!(
                    f,
                    "Cargo.lock SHA256 mismatch: expected {expected}, calculated {actual}"
                )
            }
            Self::BinaryMismatch { expected, actual } => {
                write!(
                    f,
                    "Target binary SHA256 mismatch: expected {expected}, calculated {actual}"
                )
            }
            Self::MissingRemapPathPrefix => {
                write!(
                    f,
                    "Non-deterministic build: missing --remap-path-prefix in compiler flags"
                )
            }
            Self::InvalidSourceDateEpoch => {
                write!(
                    f,
                    "Invalid SOURCE_DATE_EPOCH: timestamp must be non-zero normalized UTC"
                )
            }
            Self::SignatureInvalid => {
                write!(
                    f,
                    "Release authority signature verification failed on build provenance"
                )
            }
            Self::SignatureEncoding => {
                write!(f, "Invalid Ed25519 signature format in provenance block")
            }
            Self::Serialization(e) => {
                write!(f, "Provenance serialization error: {e}")
            }
        }
    }
}

impl std::error::Error for ProvenanceError {}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SourceFileDigest {
    pub path: String,
    pub sha256: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BuildProvenance {
    pub build_id: String,
    pub target_triple: String,
    pub rustc_version: String,
    pub source_date_epoch: u64,
    pub source_merkle_root: String,
    pub cargo_lock_sha256: String,
    pub compiler_flags: Vec<String>,
    pub binary_sha256: String,
    pub release_key_id: String,
    pub signature: Vec<u8>,
}

/// Inputs for constructing a [`BuildProvenance`] record: every value the
/// record is built from, grouped into one parameter object so
/// `create_signed` stays within argument limits without losing a field.
pub struct ProvenanceInputs<'a> {
    pub build_id: String,
    pub target_triple: String,
    pub rustc_version: String,
    pub source_date_epoch: u64,
    pub files: &'a [(String, &'a [u8])],
    pub cargo_lock: &'a [u8],
    pub compiler_flags: Vec<String>,
    pub binary_bytes: &'a [u8],
    pub release_key_id: String,
}

/// Canonical signable digest over every field of a provenance
/// record, INCLUDING `compiler_flags` (review finding, 2026-11-19:
/// the v0.14.2 digest omitted the flags, so a record's signature
/// did not bind the flags it carried — flags could be edited on a
/// signed record without invalidating it). Each flag is
/// length-prefixed and the flag count is hashed first, so no
/// repartitioning of the flag list can collide. `create_signed`
/// and `verify` both use this one function so they cannot drift.
#[allow(clippy::too_many_arguments)]
fn signable_digest(
    build_id: &str,
    target_triple: &str,
    rustc_version: &str,
    source_date_epoch: u64,
    source_merkle_root: &str,
    cargo_lock_sha256: &str,
    binary_sha256: &str,
    release_key_id: &str,
    compiler_flags: &[String],
) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(build_id.as_bytes());
    hasher.update(target_triple.as_bytes());
    hasher.update(rustc_version.as_bytes());
    hasher.update(source_date_epoch.to_be_bytes());
    hasher.update(source_merkle_root.as_bytes());
    hasher.update(cargo_lock_sha256.as_bytes());
    hasher.update(binary_sha256.as_bytes());
    hasher.update(release_key_id.as_bytes());
    hasher.update((compiler_flags.len() as u64).to_be_bytes());
    for flag in compiler_flags {
        hasher.update((flag.len() as u64).to_be_bytes());
        hasher.update(flag.as_bytes());
    }
    hasher.finalize().into()
}

impl BuildProvenance {
    /// Deterministically computes the Merkle root of the source tree.
    ///
    /// Review finding (2026-11-19): the v0.14.2 construction hashed
    /// `path || hex(file_hash)` with no length prefixes and no
    /// domain separation, so field boundaries were ambiguous (a
    /// path/hash pair could be repartitioned to collide) and leaf
    /// hashes were bare SHA-256 of content, interchangeable with
    /// hashes from any other context. The construction below fixes
    /// both: leaf digests are computed under a leaf domain string
    /// over length-prefixed path and content, and the root is
    /// computed under a distinct root domain string over the file
    /// count and the raw leaf digests.
    pub fn compute_source_merkle(files: &[(String, &[u8])]) -> String {
        const LEAF_DOMAIN: &[u8] = b"mack-gen2/source-file/v1";
        const ROOT_DOMAIN: &[u8] = b"mack-gen2/source-merkle/v1";

        let mut sorted_files = files.to_vec();
        sorted_files.sort_by(|a, b| a.0.cmp(&b.0));

        let mut hasher = Sha256::new();
        hasher.update(ROOT_DOMAIN);
        hasher.update((sorted_files.len() as u64).to_be_bytes());
        for (path, content) in sorted_files {
            let mut leaf_hasher = Sha256::new();
            leaf_hasher.update(LEAF_DOMAIN);
            leaf_hasher.update((path.len() as u64).to_be_bytes());
            leaf_hasher.update(path.as_bytes());
            leaf_hasher.update((content.len() as u64).to_be_bytes());
            leaf_hasher.update(content);
            hasher.update(leaf_hasher.finalize());
        }
        hex::encode(hasher.finalize())
    }

    /// Computes the SHA256 digest of arbitrary bytes
    pub fn hash_bytes(data: &[u8]) -> String {
        let mut hasher = Sha256::new();
        hasher.update(data);
        hex::encode(hasher.finalize())
    }

    /// Constructs and signs a new BuildProvenance record under release authority
    pub fn create_signed(
        inputs: ProvenanceInputs<'_>,
        signing_key: &SigningKey,
    ) -> Result<Self, ProvenanceError> {
        let ProvenanceInputs {
            build_id,
            target_triple,
            rustc_version,
            source_date_epoch,
            files,
            cargo_lock,
            compiler_flags,
            binary_bytes,
            release_key_id,
        } = inputs;
        if source_date_epoch == 0 {
            return Err(ProvenanceError::InvalidSourceDateEpoch);
        }

        let has_remap = compiler_flags
            .iter()
            .any(|f| f.contains("--remap-path-prefix"));
        if !has_remap {
            return Err(ProvenanceError::MissingRemapPathPrefix);
        }

        let source_merkle_root = Self::compute_source_merkle(files);
        let cargo_lock_sha256 = Self::hash_bytes(cargo_lock);
        let binary_sha256 = Self::hash_bytes(binary_bytes);

        // Signable digest over canonical fields, compiler flags
        // included (see `signable_digest`).
        let digest = signable_digest(
            &build_id,
            &target_triple,
            &rustc_version,
            source_date_epoch,
            &source_merkle_root,
            &cargo_lock_sha256,
            &binary_sha256,
            &release_key_id,
            &compiler_flags,
        );

        let signature = signing_key.sign(&digest).to_vec();

        Ok(Self {
            build_id,
            target_triple,
            rustc_version,
            source_date_epoch,
            source_merkle_root,
            cargo_lock_sha256,
            compiler_flags,
            binary_sha256,
            release_key_id,
            signature,
        })
    }

    /// Verifies reproducible build integrity and signed provenance attestation
    pub fn verify(
        &self,
        authority_verifying_key: &VerifyingKey,
        current_files: &[(String, &[u8])],
        current_lock: &[u8],
        current_binary: &[u8],
    ) -> Result<(), ProvenanceError> {
        if self.source_date_epoch == 0 {
            return Err(ProvenanceError::InvalidSourceDateEpoch);
        }

        let has_remap = self
            .compiler_flags
            .iter()
            .any(|f| f.contains("--remap-path-prefix"));
        if !has_remap {
            return Err(ProvenanceError::MissingRemapPathPrefix);
        }

        let computed_merkle = Self::compute_source_merkle(current_files);
        if computed_merkle != self.source_merkle_root {
            return Err(ProvenanceError::SourceMerkleMismatch {
                expected: self.source_merkle_root.clone(),
                actual: computed_merkle,
            });
        }

        let computed_lock = Self::hash_bytes(current_lock);
        if computed_lock != self.cargo_lock_sha256 {
            return Err(ProvenanceError::LockfileMismatch {
                expected: self.cargo_lock_sha256.clone(),
                actual: computed_lock,
            });
        }

        let computed_binary = Self::hash_bytes(current_binary);
        if computed_binary != self.binary_sha256 {
            return Err(ProvenanceError::BinaryMismatch {
                expected: self.binary_sha256.clone(),
                actual: computed_binary,
            });
        }

        // Recompute signature digest (same canonical form as
        // `create_signed`, compiler flags included).
        let digest = signable_digest(
            &self.build_id,
            &self.target_triple,
            &self.rustc_version,
            self.source_date_epoch,
            &self.source_merkle_root,
            &self.cargo_lock_sha256,
            &self.binary_sha256,
            &self.release_key_id,
            &self.compiler_flags,
        );

        let sig_bytes: [u8; 64] = self
            .signature
            .as_slice()
            .try_into()
            .map_err(|_| ProvenanceError::SignatureEncoding)?;
        let sig = Signature::from_bytes(&sig_bytes);

        authority_verifying_key
            .verify(&digest, &sig)
            .map_err(|_| ProvenanceError::SignatureInvalid)?;

        Ok(())
    }
}
