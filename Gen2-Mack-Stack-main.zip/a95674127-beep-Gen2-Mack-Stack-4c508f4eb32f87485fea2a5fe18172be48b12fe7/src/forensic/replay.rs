//! Deterministic forensic replay (v0.7.0) — REAL re-execution.
//!
//! A recorded run captures a workload's input and the SHA-256 digest
//! of its output. Replay RE-EXECUTES the workload on the recorded
//! input and compares digests. A match proves the recorded output is
//! exactly what this workload produces from this input; a mismatch is
//! a FINDING (reported, not hidden): the record was tampered with, or
//! the workload is not deterministic (it read a clock, randomness, or
//! the environment), which is itself forensically material.
//!
//! This replaces the weaker transcript re-verification pattern (which
//! re-checks signatures over a transcript but re-executes nothing)
//! that an external design proposed under the same name and this
//! crate declined to adopt.
//!
//! [`replay_run_confined`] runs the re-execution inside the crate's
//! pinned sandbox worker, under the same Landlock + seccomp
//! confinement a lane execution gets, when a spool directory is
//! available.

use sha2::{Digest, Sha256};
use std::path::PathBuf;
use std::sync::{Arc, Mutex};

use crate::sandbox::worker_runner::PinnedWorkerRunner;

fn sha256_hex(bytes: &[u8]) -> String {
    let mut h = Sha256::new();
    h.update(bytes);
    format!("{:x}", h.finalize())
}

/// A recorded workload execution: the input, the digest of the output
/// it produced, and the proof-ledger tip at record time (the anchor
/// tying this run to the chain).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RecordedRun {
    pub input: Vec<u8>,
    pub expected_output_sha256: String,
    pub ledger_tip_at_record: String,
}

/// Records a run: digests the output the workload actually produced.
pub fn record_run(input: &[u8], output: &[u8], ledger_tip_at_record: &str) -> RecordedRun {
    RecordedRun {
        input: input.to_vec(),
        expected_output_sha256: sha256_hex(output),
        ledger_tip_at_record: ledger_tip_at_record.to_string(),
    }
}

/// The outcome of a replay. `digest_matches == false` is a finding,
/// not an error.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReplayReport {
    pub recomputed_output_sha256: String,
    pub digest_matches: bool,
    /// True when the re-execution ran inside the sandbox worker.
    pub confined: bool,
}

/// Re-executes the workload on the recorded input (unconfined) and
/// compares the output digest with the record.
pub fn replay_run<F>(record: &RecordedRun, workload: F) -> ReplayReport
where
    F: FnOnce(&[u8]) -> Vec<u8>,
{
    let output = workload(&record.input);
    let recomputed = sha256_hex(&output);
    ReplayReport {
        digest_matches: recomputed == record.expected_output_sha256,
        recomputed_output_sha256: recomputed,
        confined: false,
    }
}

/// Re-executes the workload inside the pinned sandbox worker
/// (Landlock + seccomp, fail-closed) and compares digests. An
/// enforcement failure aborts the replay and is returned as an error
/// naming the enforcement layer — the replay never silently falls
/// back to running unconfined.
pub fn replay_run_confined<F>(
    record: &RecordedRun,
    spool_dir: PathBuf,
    workload: F,
) -> Result<ReplayReport, String>
where
    F: FnOnce(&[u8]) -> Vec<u8> + Send + 'static,
{
    let input = record.input.clone();
    let slot: Arc<Mutex<Option<Vec<u8>>>> = Arc::new(Mutex::new(None));
    let slot_in_worker = Arc::clone(&slot);
    let handle = PinnedWorkerRunner::new(spool_dir).spawn_pinned_worker(move || {
        let output = workload(&input);
        *slot_in_worker.lock().map_err(|_| "replay slot poisoned")? = Some(output);
        Ok(())
    });
    match handle.join() {
        Ok(Ok(())) => {}
        Ok(Err(e)) => return Err(e),
        Err(_) => return Err("replay worker thread died unexpectedly".into()),
    }
    let output = slot
        .lock()
        .map_err(|_| "replay slot poisoned")?
        .take()
        .ok_or("replay worker produced no output")?;
    let recomputed = sha256_hex(&output);
    Ok(ReplayReport {
        digest_matches: recomputed == record.expected_output_sha256,
        recomputed_output_sha256: recomputed,
        confined: true,
    })
}
