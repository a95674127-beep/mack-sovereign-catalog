//! Forensic evidence and build provenance.
//!
//! STATUS (2026-11-15): implemented — signed build-provenance records
//! (source Merkle root, lockfile and binary digests; these are records,
//! not an SLSA level — SLSA levels describe build platforms) and the
//! evidence chamber (payload hashing, indicator extraction, custody
//! records). Execution-transcript verification is provided by the
//! ledger's verify_chain over its entries.

pub mod build_provenance;
pub mod evidence_chamber;
pub mod replay;
