//! Proof fabric — intent-bound execution envelopes and attestation.
//!
//! STATUS (2026-11-15): implemented — IntentBoundEnvelope (signed
//! envelopes over domain-tagged, length-prefixed canonical bytes),
//! CompoundAttestationChain (signed delegation chains), capability
//! leases with a named clock source, and the seen-nonce replay store
//! (v0.6.0, `leases`).

pub mod compound_attestation;
pub mod execution_envelope;
pub mod leases;
