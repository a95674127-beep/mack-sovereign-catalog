#![forbid(unsafe_code)]

use ed25519_dalek::{Signature, Signer, Verifier, VerifyingKey};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fmt;

#[derive(Debug)]
pub enum CompoundAttestationError {
    ChainBroken {
        link_index: usize,
        expected_parent: String,
        actual_parent: String,
    },
    InvalidSignature {
        link_index: usize,
        error: String,
    },
    SignatureEncoding,
}

impl fmt::Display for CompoundAttestationError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::ChainBroken {
                link_index,
                expected_parent,
                actual_parent,
            } => {
                write!(f, "Compound attestation broken at link #{link_index}: expected parent {expected_parent}, got {actual_parent}")
            }
            Self::InvalidSignature { link_index, error } => {
                write!(f, "Agent signature invalid at link #{link_index}: {error}")
            }
            Self::SignatureEncoding => write!(f, "Invalid Ed25519 signature wire format"),
        }
    }
}

impl std::error::Error for CompoundAttestationError {}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DelegationLink {
    pub link_index: usize,
    pub parent_delegation_hash: String,
    pub delegator_agent_id: String,
    pub recipient_agent_id: String,
    pub task_intent_hash: String,
    pub agent_signature: Vec<u8>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompoundAttestationChain {
    pub root_envelope_hash: String,
    pub links: Vec<DelegationLink>,
}

impl CompoundAttestationChain {
    pub fn new(root_envelope_hash: String) -> Self {
        Self {
            root_envelope_hash,
            links: Vec::new(),
        }
    }

    pub fn append_delegation(
        &mut self,
        delegator_id: &str,
        recipient_id: &str,
        task_intent_hash: &str,
        signing_key: &ed25519_dalek::SigningKey,
    ) -> Result<String, CompoundAttestationError> {
        let parent_hash = match self.links.last() {
            Some(last) => {
                let mut h = Sha256::new();
                h.update(last.parent_delegation_hash.as_bytes());
                h.update(last.task_intent_hash.as_bytes());
                format!("{:x}", h.finalize())
            }
            None => self.root_envelope_hash.clone(),
        };

        let link_index = self.links.len();

        let sig_payload = Self::sig_payload(
            link_index,
            &parent_hash,
            delegator_id,
            recipient_id,
            task_intent_hash,
        );

        let sig = signing_key.sign(&sig_payload);

        let link = DelegationLink {
            link_index,
            parent_delegation_hash: parent_hash.clone(),
            delegator_agent_id: delegator_id.to_string(),
            recipient_agent_id: recipient_id.to_string(),
            task_intent_hash: task_intent_hash.to_string(),
            agent_signature: sig.to_vec(),
        };

        self.links.push(link);
        Ok(parent_hash)
    }

    /// Canonical signature payload: domain-tagged, length-prefixed fields.
    /// (Fixed at unification, 2026-11-15: the as-received version signed
    /// raw concatenated strings, which leaves field boundaries ambiguous.)
    fn sig_payload(
        link_index: usize,
        parent_hash: &str,
        delegator_id: &str,
        recipient_id: &str,
        task_intent_hash: &str,
    ) -> Vec<u8> {
        let mut v = Vec::new();
        v.extend_from_slice(b"MACK_DELEGATION_V1");
        v.extend_from_slice(&(link_index as u64).to_be_bytes());
        for field in [parent_hash, delegator_id, recipient_id, task_intent_hash] {
            v.extend_from_slice(&(field.len() as u64).to_be_bytes());
            v.extend_from_slice(field.as_bytes());
        }
        v
    }

    pub fn verify_continuity(
        &self,
        agent_keys: &std::collections::HashMap<String, VerifyingKey>,
    ) -> Result<(), CompoundAttestationError> {
        let mut expected_parent = self.root_envelope_hash.clone();

        for (idx, link) in self.links.iter().enumerate() {
            if link.parent_delegation_hash != expected_parent {
                return Err(CompoundAttestationError::ChainBroken {
                    link_index: idx,
                    expected_parent,
                    actual_parent: link.parent_delegation_hash.clone(),
                });
            }

            let key = agent_keys.get(&link.delegator_agent_id).ok_or_else(|| {
                CompoundAttestationError::InvalidSignature {
                    link_index: idx,
                    error: format!("Unknown delegator {}", link.delegator_agent_id),
                }
            })?;

            let sig_payload = Self::sig_payload(
                link.link_index,
                &link.parent_delegation_hash,
                &link.delegator_agent_id,
                &link.recipient_agent_id,
                &link.task_intent_hash,
            );

            let sig_bytes: [u8; 64] = link
                .agent_signature
                .as_slice()
                .try_into()
                .map_err(|_| CompoundAttestationError::SignatureEncoding)?;
            let sig = Signature::from_bytes(&sig_bytes);

            key.verify(&sig_payload, &sig).map_err(|e| {
                CompoundAttestationError::InvalidSignature {
                    link_index: idx,
                    error: e.to_string(),
                }
            })?;

            let mut h = Sha256::new();
            h.update(link.parent_delegation_hash.as_bytes());
            h.update(link.task_intent_hash.as_bytes());
            expected_parent = format!("{:x}", h.finalize());
        }

        Ok(())
    }
}
