//! Capability leases + the seen-nonce replay store (v0.6.0).
//!
//! Two design-stage items from the proof-fabric track, built:
//!
//! 1. **Capability leases.** A lease is a signed, scoped, short-lived
//!    grant: one principal, one named capability, bound to ONE
//!    execution envelope (by nonce), issued and expiring at named
//!    epochs. Expiry is judged against a [`Clock`] — the clock source
//!    is an explicit, named part of the API (the design note's
//!    requirement), never a hidden system call inside verification.
//!    [`SystemClock`] is the production source; [`ManualClock`] makes
//!    expiry deterministic in tests and simulations.
//!
//! 2. **Seen-nonce replay store.** The envelope's signature has always
//!    carried a nonce; until now nothing remembered seeing one, so a
//!    captured envelope could be replayed verbatim. [`SeenNonceStore`]
//!    records (authority, principal, nonce) triples —
//!    [`verify_envelope_once`] verifies the envelope FIRST (so forged
//!    envelopes cannot poison the store) and then rejects any envelope
//!    whose nonce was already spent.
//!
//! Stated limit: the store is in-memory. A deployment that restarts
//! must persist spent nonces (the natural backing is the proof
//! ledger); persistence is the caller's layer and is not claimed here.

use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use sha2::{Digest, Sha256};
use std::collections::HashSet;
use std::fmt;
use std::time::{SystemTime, UNIX_EPOCH};

use super::execution_envelope::{EnvelopeError, IntentBoundEnvelope};

/// The named clock source lease expiry is judged against.
pub trait Clock {
    fn now_epoch(&self) -> u64;
}

/// Production clock: seconds since the Unix epoch.
pub struct SystemClock;

impl Clock for SystemClock {
    fn now_epoch(&self) -> u64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs()
    }
}

/// Deterministic clock for tests and simulations.
pub struct ManualClock {
    now: u64,
}

impl ManualClock {
    pub fn new(now_epoch: u64) -> Self {
        Self { now: now_epoch }
    }
    pub fn set(&mut self, now_epoch: u64) {
        self.now = now_epoch;
    }
    pub fn advance(&mut self, secs: u64) {
        self.now += secs;
    }
}

impl Clock for ManualClock {
    fn now_epoch(&self) -> u64 {
        self.now
    }
}

/// Maximum lease lifetime: one hour. Leases are short-lived by design;
/// longer authority belongs in a fresh lease, not a longer one.
pub const MAX_LEASE_TTL_SECS: u64 = 3_600;

#[derive(Debug)]
pub enum LeaseError {
    SignatureInvalid,
    Expired {
        expires_at_epoch: u64,
        now_epoch: u64,
    },
    NotYetValid {
        issued_at_epoch: u64,
        now_epoch: u64,
    },
    TtlTooLong {
        ttl_secs: u64,
    },
    ScopeMismatch(String),
    ReplayDetected,
    Envelope(EnvelopeError),
}

impl fmt::Display for LeaseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::SignatureInvalid => write!(f, "Lease signature rejected by authority"),
            Self::Expired {
                expires_at_epoch,
                now_epoch,
            } => {
                write!(f, "Lease expired at {expires_at_epoch} (now {now_epoch})")
            }
            Self::NotYetValid {
                issued_at_epoch,
                now_epoch,
            } => {
                write!(
                    f,
                    "Lease not valid before {issued_at_epoch} (now {now_epoch})"
                )
            }
            Self::TtlTooLong { ttl_secs } => {
                write!(
                    f,
                    "Lease TTL {ttl_secs}s exceeds the {MAX_LEASE_TTL_SECS}s cap"
                )
            }
            Self::ScopeMismatch(what) => write!(f, "Lease scope mismatch: {what}"),
            Self::ReplayDetected => write!(f, "Envelope nonce already spent (replay rejected)"),
            Self::Envelope(e) => write!(f, "Envelope error: {e}"),
        }
    }
}

impl std::error::Error for LeaseError {}

impl From<EnvelopeError> for LeaseError {
    fn from(e: EnvelopeError) -> Self {
        Self::Envelope(e)
    }
}

/// A signed, scoped, expiring capability grant bound to one envelope.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CapabilityLease {
    pub lease_id: String,
    pub principal_id: String,
    /// The capability being granted, as one opaque scoped string
    /// (e.g. "egress:api.example.com:POST"). Interpretation belongs to
    /// the enforcing caller; the lease binds it exactly.
    pub capability: String,
    /// The nonce of the single execution envelope this lease serves.
    pub envelope_nonce: u64,
    pub issued_at_epoch: u64,
    pub expires_at_epoch: u64,
    pub signature: Vec<u8>,
}

impl CapabilityLease {
    /// Issues a lease signed by the authority, valid from the clock's
    /// current epoch for `ttl_secs` (capped at [`MAX_LEASE_TTL_SECS`]).
    pub fn issue(
        authority: &SigningKey,
        principal_id: &str,
        capability: &str,
        envelope_nonce: u64,
        clock: &dyn Clock,
        ttl_secs: u64,
    ) -> Result<Self, LeaseError> {
        if ttl_secs == 0 || ttl_secs > MAX_LEASE_TTL_SECS {
            return Err(LeaseError::TtlTooLong { ttl_secs });
        }
        let issued_at_epoch = clock.now_epoch();
        let expires_at_epoch = issued_at_epoch + ttl_secs;
        let mut lease = Self {
            lease_id: String::new(),
            principal_id: principal_id.to_string(),
            capability: capability.to_string(),
            envelope_nonce,
            issued_at_epoch,
            expires_at_epoch,
            signature: Vec::new(),
        };
        lease.lease_id = lease.derive_id();
        let sig = authority.sign(&lease.canonical_bytes());
        lease.signature = sig.to_vec();
        Ok(lease)
    }

    fn derive_id(&self) -> String {
        let mut h = Sha256::new();
        h.update(b"MACK_LEASE_ID_V1");
        h.update(self.principal_id.as_bytes());
        h.update(self.capability.as_bytes());
        h.update(self.envelope_nonce.to_be_bytes());
        h.update(self.issued_at_epoch.to_be_bytes());
        format!("LEASE_{:x}", h.finalize())
    }

    /// Canonical signing bytes: domain-tagged, length-prefixed — the
    /// same discipline as the envelope's `MACK_ENVELOPE_V1` encoding.
    fn canonical_bytes(&self) -> Vec<u8> {
        let mut out = Vec::new();
        out.extend_from_slice(b"MACK_LEASE_V1");
        for field in [
            self.lease_id.as_bytes(),
            self.principal_id.as_bytes(),
            self.capability.as_bytes(),
        ] {
            out.extend_from_slice(&(field.len() as u64).to_be_bytes());
            out.extend_from_slice(field);
        }
        out.extend_from_slice(&self.envelope_nonce.to_be_bytes());
        out.extend_from_slice(&self.issued_at_epoch.to_be_bytes());
        out.extend_from_slice(&self.expires_at_epoch.to_be_bytes());
        out
    }

    /// Verifies the authority signature and the validity window
    /// against the named clock.
    pub fn verify(&self, authority_vk: &VerifyingKey, clock: &dyn Clock) -> Result<(), LeaseError> {
        if self.lease_id != self.derive_id() {
            return Err(LeaseError::SignatureInvalid);
        }
        let sig_bytes: [u8; 64] = self
            .signature
            .as_slice()
            .try_into()
            .map_err(|_| LeaseError::SignatureInvalid)?;
        authority_vk
            .verify(&self.canonical_bytes(), &Signature::from_bytes(&sig_bytes))
            .map_err(|_| LeaseError::SignatureInvalid)?;
        let now = clock.now_epoch();
        if now < self.issued_at_epoch {
            return Err(LeaseError::NotYetValid {
                issued_at_epoch: self.issued_at_epoch,
                now_epoch: now,
            });
        }
        if now >= self.expires_at_epoch {
            return Err(LeaseError::Expired {
                expires_at_epoch: self.expires_at_epoch,
                now_epoch: now,
            });
        }
        Ok(())
    }

    /// Full authorization check for one envelope: signature + window,
    /// then the binding — same principal, and the lease must name this
    /// envelope's nonce.
    pub fn authorize(
        &self,
        authority_vk: &VerifyingKey,
        envelope: &IntentBoundEnvelope,
        clock: &dyn Clock,
    ) -> Result<(), LeaseError> {
        self.verify(authority_vk, clock)?;
        if self.principal_id != envelope.principal_id {
            return Err(LeaseError::ScopeMismatch(format!(
                "lease principal {} != envelope principal {}",
                self.principal_id, envelope.principal_id
            )));
        }
        if self.envelope_nonce != envelope.nonce {
            return Err(LeaseError::ScopeMismatch(format!(
                "lease is bound to envelope nonce {}, not {}",
                self.envelope_nonce, envelope.nonce
            )));
        }
        Ok(())
    }
}

/// Remembers spent envelope nonces, keyed by (authority, principal,
/// nonce) so one principal's nonce cannot collide with another's, and
/// one authority's space cannot collide with a different authority's.
#[derive(Debug, Default)]
pub struct SeenNonceStore {
    seen: HashSet<([u8; 32], String, u64)>,
}

impl SeenNonceStore {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn spent_count(&self) -> usize {
        self.seen.len()
    }

    /// Records a nonce as spent; fails if it was already spent.
    pub fn check_and_record(
        &mut self,
        authority_vk: &VerifyingKey,
        envelope: &IntentBoundEnvelope,
    ) -> Result<(), LeaseError> {
        let key = (
            authority_vk.to_bytes(),
            envelope.principal_id.clone(),
            envelope.nonce,
        );
        if !self.seen.insert(key) {
            return Err(LeaseError::ReplayDetected);
        }
        Ok(())
    }
}

/// The guarded verification path: verify the envelope's signature and
/// payload digest FIRST (a forged envelope must not poison the store),
/// then spend its nonce. The same envelope presented twice fails the
/// second time with [`LeaseError::ReplayDetected`].
pub fn verify_envelope_once(
    store: &mut SeenNonceStore,
    envelope: &IntentBoundEnvelope,
    payload_bytes: &[u8],
    authority_vk: &VerifyingKey,
) -> Result<(), LeaseError> {
    envelope.verify(payload_bytes, authority_vk)?;
    store.check_and_record(authority_vk, envelope)
}
