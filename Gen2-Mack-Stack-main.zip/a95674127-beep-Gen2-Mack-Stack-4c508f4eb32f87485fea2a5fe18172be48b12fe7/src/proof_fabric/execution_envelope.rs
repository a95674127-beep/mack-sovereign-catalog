#![forbid(unsafe_code)]

use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fmt;

#[derive(Debug)]
pub enum EnvelopeError {
    SerializationFailed(String),
    DeserializationFailed(String),
    SignatureVerificationFailed,
    InvalidSignatureFormat,
    PayloadDigestMismatch { expected: String, actual: String },
}

impl fmt::Display for EnvelopeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::SerializationFailed(e) => write!(f, "Envelope serialization failed: {e}"),
            Self::DeserializationFailed(e) => write!(f, "Envelope deserialization failed: {e}"),
            Self::SignatureVerificationFailed => {
                write!(f, "Ed25519 envelope signature rejected by authority")
            }
            Self::InvalidSignatureFormat => write!(f, "Invalid Ed25519 signature format"),
            Self::PayloadDigestMismatch { expected, actual } => {
                write!(
                    f,
                    "Payload tamper detected: expected digest {expected}, computed {actual}"
                )
            }
        }
    }
}

impl std::error::Error for EnvelopeError {}

/// Cryptographically sealed execution envelope binding caller identity, payload hash, and routing intent.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct IntentBoundEnvelope {
    pub principal_id: String,
    pub provenance_chain_hash: String,
    pub payload_sha256: String,
    pub nonce: u64,
    pub signature: Vec<u8>,
}

impl IntentBoundEnvelope {
    /// Creates and signs a new envelope bound to specific payload bytes using the authority key.
    pub fn sign_new(
        principal_id: &str,
        provenance_chain_hash: &str,
        payload_bytes: &[u8],
        nonce: u64,
        authority_signing_key: &SigningKey,
    ) -> Result<Self, EnvelopeError> {
        let mut hasher = Sha256::new();
        hasher.update(payload_bytes);
        let payload_sha256 = format!("{:x}", hasher.finalize());

        let mut env = Self {
            principal_id: principal_id.to_string(),
            provenance_chain_hash: provenance_chain_hash.to_string(),
            payload_sha256,
            nonce,
            signature: Vec::new(),
        };

        let message = env.canonical_signable_bytes()?;
        let sig = authority_signing_key.sign(&message);
        env.signature = sig.to_vec();

        Ok(env)
    }

    /// Verifies envelope signature against the authority verifying key and validates payload digest.
    pub fn verify(
        &self,
        payload_bytes: &[u8],
        authority_verifying_key: &VerifyingKey,
    ) -> Result<(), EnvelopeError> {
        // Step 1: Verify payload SHA-256 digest
        let mut hasher = Sha256::new();
        hasher.update(payload_bytes);
        let computed_digest = format!("{:x}", hasher.finalize());

        if computed_digest != self.payload_sha256 {
            return Err(EnvelopeError::PayloadDigestMismatch {
                expected: self.payload_sha256.clone(),
                actual: computed_digest,
            });
        }

        // Step 2: Verify signature over canonical message
        let sig_bytes: [u8; 64] = self
            .signature
            .as_slice()
            .try_into()
            .map_err(|_| EnvelopeError::InvalidSignatureFormat)?;

        let signature = Signature::from_bytes(&sig_bytes);
        let message = self.canonical_signable_bytes()?;

        authority_verifying_key
            .verify(&message, &signature)
            .map_err(|_| EnvelopeError::SignatureVerificationFailed)
    }

    /// Canonical signing bytes: domain-tagged, length-prefixed fields.
    /// (Fixed at unification, 2026-11-15: the as-received version signed a
    /// bincode serialization, which is not a stable canonical format.
    /// The nonce is carried and signed; replay rejection lives in
    /// `proof_fabric::leases` (`SeenNonceStore` + `verify_envelope_once`,
    /// v0.6.0).)
    fn canonical_signable_bytes(&self) -> Result<Vec<u8>, EnvelopeError> {
        let mut out = Vec::new();
        out.extend_from_slice(b"MACK_ENVELOPE_V1");
        for field in [
            self.principal_id.as_bytes(),
            self.provenance_chain_hash.as_bytes(),
            self.payload_sha256.as_bytes(),
        ] {
            out.extend_from_slice(&(field.len() as u64).to_be_bytes());
            out.extend_from_slice(field);
        }
        out.extend_from_slice(&self.nonce.to_be_bytes());
        Ok(out)
    }
}
