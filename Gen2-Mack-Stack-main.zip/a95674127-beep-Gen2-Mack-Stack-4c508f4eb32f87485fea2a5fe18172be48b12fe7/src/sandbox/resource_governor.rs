//! Resource governor (v0.11.0) — per-child resource containment
//! for the `mack-proxy` launcher, in two layers with different
//! guarantees, reported separately by the launcher:
//!
//! 1. **rlimits** (always applied): the launcher sets
//!    `RLIMIT_AS`, `RLIMIT_CPU`, `RLIMIT_FSIZE`, and `RLIMIT_CORE`
//!    in the child's `pre_exec`. They need no privileges, are
//!    inherited across fork/exec, and a failure to set one aborts
//!    the spawn (fail-closed). The `setrlimit` calls themselves are
//!    made by the binary (this crate forbids `unsafe` in the
//!    library); the limit VALUES live here. Process COUNT is
//!    deliberately not an rlimit: `RLIMIT_NPROC` is charged per
//!    real UID across the whole system, so one workload's limit
//!    would be consumed by every other process the user runs —
//!    process-count limiting is cgroup-only (layer 2) and is
//!    reported as unenforced when layer 2 is unavailable.
//! 2. **cgroup v2** (only when a delegated writable subtree
//!    exists): the launcher creates a per-run cgroup, sets
//!    `memory.max`, `cpu.max`, and `pids.max`, and the child moves
//!    itself into it in `pre_exec` before exec. Where the cgroup
//!    filesystem is not delegated/writable (a container without
//!    delegation, most CI sandboxes), creation fails and the layer
//!    is simply absent — the launcher REPORTS that absence; it
//!    never prints a cgroup claim it did not apply.

use std::fmt;
use std::fs;
use std::path::{Path, PathBuf};

pub const CGROUP_ROOT: &str = "/sys/fs/cgroup";

pub const DEFAULT_AS_MIB: u64 = 512;
pub const DEFAULT_CPU_SECS: u64 = 60;
pub const DEFAULT_FSIZE_MIB: u64 = 128;
pub const DEFAULT_CGROUP_MEMORY_MIB: u64 = 512;
pub const DEFAULT_CGROUP_PIDS: u64 = 64;
/// cpu.max quota/period for "100% of one CPU": 100000us per
/// 100000us period.
pub const CGROUP_CPU_MAX: &str = "100000 100000";

/// The rlimit layer's values. `RLIMIT_CORE` is not configurable:
/// it is always 0 (a confined workload leaves no core dumps).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ResourceLimits {
    pub address_space_bytes: u64,
    pub cpu_seconds: u64,
    pub file_size_bytes: u64,
}

impl Default for ResourceLimits {
    fn default() -> Self {
        Self {
            address_space_bytes: DEFAULT_AS_MIB * 1024 * 1024,
            cpu_seconds: DEFAULT_CPU_SECS,
            file_size_bytes: DEFAULT_FSIZE_MIB * 1024 * 1024,
        }
    }
}

impl fmt::Display for ResourceLimits {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "RLIMIT_AS={} MiB, RLIMIT_CPU={} s, RLIMIT_FSIZE={} MiB, RLIMIT_CORE=0",
            self.address_space_bytes / (1024 * 1024),
            self.cpu_seconds,
            self.file_size_bytes / (1024 * 1024)
        )
    }
}

/// Moves the calling process into the cgroup at `dir` by writing
/// to its `cgroup.procs` (writing "0" names the current process).
/// Free function so a launcher's `pre_exec` closure — which holds
/// the cgroup's path, not the owning handle — performs exactly the
/// same operation as [`CgroupV2::join_current_process`].
pub fn join_cgroup(dir: &Path) -> Result<(), String> {
    fs::write(dir.join("cgroup.procs"), "0")
        .map_err(|e| format!("failed to join cgroup {}: {e}", dir.display()))
}

/// A per-run cgroup v2 created under the delegated subtree.
pub struct CgroupV2 {
    dir: PathBuf,
    memory_max_bytes: u64,
    pids_max: u64,
}

impl CgroupV2 {
    /// Creates `<CGROUP_ROOT>/<name>` and sets `memory.max`
    /// (bytes), `cpu.max` (100% of one CPU), and `pids.max`.
    /// Any failure — not a v2 hierarchy, no write access, a
    /// controller refusing a value — removes the directory and
    /// returns the reason, so the caller can report the layer as
    /// unavailable instead of pretending it was applied.
    pub fn try_create(
        name: &str,
        memory_max_bytes: u64,
        pids_max: u64,
    ) -> Result<CgroupV2, String> {
        let root = Path::new(CGROUP_ROOT);
        if !root.join("cgroup.controllers").exists() {
            return Err(format!(
                "{CGROUP_ROOT} is not a cgroup v2 hierarchy (no cgroup.controllers)"
            ));
        }
        let dir = root.join(name);
        fs::create_dir(&dir).map_err(|e| {
            format!(
                "no delegated writable cgroup v2 subtree (mkdir {}: {e})",
                dir.display()
            )
        })?;
        let cg = CgroupV2 {
            dir,
            memory_max_bytes,
            pids_max,
        };
        let attempt = (|| -> Result<(), String> {
            cg.write_control("memory.max", &memory_max_bytes.to_string())?;
            cg.write_control("cpu.max", CGROUP_CPU_MAX)?;
            cg.write_control("pids.max", &pids_max.to_string())?;
            Ok(())
        })();
        if let Err(reason) = attempt {
            cg.cleanup();
            return Err(reason);
        }
        Ok(cg)
    }

    fn write_control(&self, file: &str, value: &str) -> Result<(), String> {
        fs::write(self.dir.join(file), value).map_err(|e| {
            format!(
                "cgroup control {}.{} refused value {value:?}: {e}",
                self.dir.display(),
                file
            )
        })
    }

    pub fn dir(&self) -> &Path {
        &self.dir
    }

    /// Moves the CALLING process into this cgroup. The launcher
    /// calls this from the child's `pre_exec`, after the rlimits
    /// are set and before the seccomp profile is installed, so the
    /// workload is inside the cgroup from its first instruction.
    pub fn join_current_process(&self) -> Result<(), String> {
        join_cgroup(&self.dir)
    }

    /// Removes the cgroup directory. Best-effort: if workload
    /// descendants still occupy it, the kernel refuses and the
    /// empty directory is left for the operator — reported by the
    /// boolean result, never hidden.
    pub fn cleanup(&self) -> bool {
        fs::remove_dir(&self.dir).is_ok()
    }

    /// The one-line claim the launcher may print for this layer —
    /// used only when the cgroup was actually created and the
    /// child actually joined it.
    pub fn report(&self) -> String {
        format!(
            "cgroup v2 applied at {} (memory.max={} MiB, cpu.max=100% of one CPU, pids.max={})",
            self.dir.display(),
            self.memory_max_bytes / (1024 * 1024),
            self.pids_max
        )
    }
}
