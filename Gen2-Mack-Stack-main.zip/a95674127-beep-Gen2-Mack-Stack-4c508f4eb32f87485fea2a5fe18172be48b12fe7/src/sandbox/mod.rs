//! Execution lanes and isolation.
//!
//! STATUS (2026-11-15): Tier 1 is implemented — Landlock (fail-closed)
//! and seccomp enforcers built on the real `landlock` and `seccompiler`
//! crates, plus a pinned worker thread that applies both before running
//! a workload. Since v0.10.0 the Landlock enforcer also provides
//! network confinement (TCP connect, per-port), applied to the
//! `mack-proxy` child. Since v0.11.0 the `mack-proxy` child also
//! runs under a baseline seccomp workload profile (denylist,
//! including UDP/raw socket denial) and the resource governor
//! (rlimits always; cgroup v2 where a delegated subtree exists).
//! Tier 2 (Firecracker microVM) is dispatch policy and
//! configuration only — no VM is created anywhere in this crate.

pub mod isolation_tier;
pub mod landlock_enforcer;
pub mod resource_governor;
pub mod seccomp_filter;
pub mod worker_runner;
