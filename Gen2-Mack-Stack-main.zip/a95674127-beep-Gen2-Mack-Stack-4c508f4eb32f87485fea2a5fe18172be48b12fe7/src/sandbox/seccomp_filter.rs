#![forbid(unsafe_code)]

use seccompiler::{
    BpfProgram, SeccompAction, SeccompCmpArgLen, SeccompCmpOp, SeccompCondition, SeccompFilter,
    SeccompRule, TargetArch,
};
use std::collections::BTreeMap;
use std::fmt;

#[derive(Debug)]
pub enum SeccompEnforcerError {
    FilterCompilation(String),
    ApplicationFailed(String),
}

impl fmt::Display for SeccompEnforcerError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::FilterCompilation(e) => write!(f, "Failed to compile Seccomp BPF filter: {e}"),
            Self::ApplicationFailed(e) => write!(f, "Failed to apply Seccomp filter: {e}"),
        }
    }
}

impl std::error::Error for SeccompEnforcerError {}

pub struct SeccompEnforcer;

impl SeccompEnforcer {
    pub fn build_worker_bpf() -> Result<BpfProgram, SeccompEnforcerError> {
        let mut rules = BTreeMap::new();

        let allowed_syscalls = [
            libc::SYS_read,
            libc::SYS_close,
            libc::SYS_fstat,
            libc::SYS_lseek,
            libc::SYS_mmap,
            libc::SYS_mprotect,
            libc::SYS_munmap,
            libc::SYS_brk,
            libc::SYS_rt_sigaction,
            libc::SYS_rt_sigprocmask,
            libc::SYS_rt_sigreturn,
            libc::SYS_exit_group,
            // Added at unification (2026-11-15): SYS_exit is how a worker
            // THREAD terminates itself. Without it the filter killed the
            // whole process with SIGSYS when a worker thread exited —
            // proven empirically in tests/worker_sandbox.rs. exit_group
            // (process exit) above is not a substitute for thread exit.
            libc::SYS_exit,
            // Added at unification (2026-11-15), strace-proven: after the
            // filter applies, a Rust worker thread's normal lifecycle
            // calls sigaltstack (teardown of the alt signal stack) and
            // futex (the join latch that wakes the joining thread).
            // Without them the KillProcess default killed the host
            // process with SIGSYS at worker exit — the as-received
            // 16-syscall list could never let a Rust worker finish.
            libc::SYS_sigaltstack,
            libc::SYS_futex,
            // Added at unification (2026-11-15), strace-proven: glibc
            // releases the worker thread's stack with madvise
            // (MADV_DONTNEED) during teardown; it was the next SIGSYS
            // after sigaltstack/futex were allowed.
            libc::SYS_madvise,
            libc::SYS_clock_gettime,
            libc::SYS_nanosleep,
            libc::SYS_getrandom,
            libc::SYS_sched_yield,
        ];

        for &sys in &allowed_syscalls {
            rules.insert(sys, vec![]);
        }

        let stdout_rule = SeccompRule::new(vec![SeccompCondition::new(
            0,
            SeccompCmpArgLen::Dword,
            SeccompCmpOp::Le,
            2,
        )
        .map_err(|e| {
            SeccompEnforcerError::FilterCompilation(format!("Condition error: {e:?}"))
        })?])
        .map_err(|e| SeccompEnforcerError::FilterCompilation(format!("Rule error: {e:?}")))?;
        rules.insert(libc::SYS_write, vec![stdout_rule]);

        let filter = SeccompFilter::new(
            rules,
            SeccompAction::KillProcess,
            SeccompAction::Allow,
            TargetArch::x86_64,
        )
        .map_err(|e| SeccompEnforcerError::FilterCompilation(format!("Filter error: {e:?}")))?;

        let bpf: BpfProgram = filter.try_into().map_err(|e| {
            SeccompEnforcerError::FilterCompilation(format!("BPF conversion error: {e:?}"))
        })?;

        Ok(bpf)
    }

    pub fn apply_filter(bpf: &BpfProgram) -> Result<(), SeccompEnforcerError> {
        seccompiler::apply_filter(bpf).map_err(|e| {
            SeccompEnforcerError::ApplicationFailed(format!("Failed to activate filter: {e:?}"))
        })
    }

    /// Baseline seccomp profile for ARBITRARY workload children
    /// (v0.11.0) — the profile `mack-proxy` installs on the child it
    /// spawns. This is the opposite posture from
    /// [`Self::build_worker_bpf`]: that filter is a tight ALLOWLIST
    /// fitted to this crate's own worker thread; an arbitrary child
    /// command (a shell, curl, an agent runtime) cannot run under an
    /// allowlist written for someone else. The workload profile is
    /// therefore a DENYLIST over a default-allow: the syscalls below
    /// fail with `EPERM` (never a kill, so runtimes that probe for a
    /// feature can fall back), and everything else is untouched.
    ///
    /// What it denies:
    /// - Privilege/kernel-surface syscalls outright: `ptrace`,
    ///   `mount`, `umount2`, `init_module`, `finit_module`,
    ///   `delete_module`, `bpf`, `perf_event_open`,
    ///   `io_uring_setup`/`io_uring_enter`/`io_uring_register`,
    ///   `kexec_load`, `add_key`, `keyctl`, `request_key`,
    ///   `open_by_handle_at`, `swapon`, `swapoff`, `reboot`,
    ///   `setns`.
    /// - Namespace creation: `unshare` and `clone` fail with EPERM
    ///   when any `CLONE_NEW*` flag is present (arg-filtered per
    ///   flag bit; ordinary fork/thread flags pass). `clone3` is
    ///   NOT filtered — its flags sit behind a pointer seccomp
    ///   cannot inspect — and is a documented residual: Landlock's
    ///   filesystem/network rules continue to bind a child that
    ///   creates its own namespaces, and a private net namespace
    ///   also severs the child's path to the proxy.
    /// - Direct datagram/raw networking, via `socket()` argument
    ///   filtering: `socket(AF_INET|AF_INET6, SOCK_DGRAM)` and
    ///   `socket(*, SOCK_RAW)` fail with EPERM (the type comparison
    ///   masks the low nibble, so `SOCK_CLOEXEC`/`SOCK_NONBLOCK`
    ///   flags do not evade it). This is what removes the child's
    ///   direct UDP path — Landlock's network rules govern TCP
    ///   connect only — leaving TCP to the proxy's port (under
    ///   Landlock) as the child's only network egress.
    ///
    /// Architecture: the filter is built for the host architecture
    /// (x86_64 and aarch64 are wired; any other architecture is a
    /// build error here, so the caller fails closed rather than
    /// spawning a child under a filter built for the wrong syscall
    /// table). Only x86_64 is compiled and test-proven in this
    /// repository's environment; the aarch64 path uses the same
    /// `libc` constants and seccompiler target selection.
    pub fn build_workload_bpf() -> Result<BpfProgram, SeccompEnforcerError> {
        let arch = match std::env::consts::ARCH {
            "x86_64" => TargetArch::x86_64,
            "aarch64" => TargetArch::aarch64,
            other => {
                return Err(SeccompEnforcerError::FilterCompilation(format!(
                    "no workload seccomp profile for architecture {other}"
                )))
            }
        };

        let mut rules: BTreeMap<i64, Vec<SeccompRule>> = BTreeMap::new();

        // Unconditional denials: an empty rule set in seccompiler
        // matches every invocation of the syscall.
        let denied = [
            libc::SYS_ptrace,
            libc::SYS_mount,
            libc::SYS_umount2,
            libc::SYS_init_module,
            libc::SYS_finit_module,
            libc::SYS_delete_module,
            libc::SYS_bpf,
            libc::SYS_perf_event_open,
            libc::SYS_io_uring_setup,
            libc::SYS_io_uring_enter,
            libc::SYS_io_uring_register,
            libc::SYS_kexec_load,
            libc::SYS_add_key,
            libc::SYS_keyctl,
            libc::SYS_request_key,
            libc::SYS_open_by_handle_at,
            libc::SYS_swapon,
            libc::SYS_swapoff,
            libc::SYS_reboot,
            libc::SYS_setns,
        ];
        for sys in denied {
            rules.insert(sys, vec![]);
        }

        let cond = |arg: u8, op: SeccompCmpOp, value: u64| {
            SeccompCondition::new(arg, SeccompCmpArgLen::Dword, op, value).map_err(|e| {
                SeccompEnforcerError::FilterCompilation(format!("Condition error: {e:?}"))
            })
        };
        let rule = |conds: Vec<SeccompCondition>| {
            SeccompRule::new(conds)
                .map_err(|e| SeccompEnforcerError::FilterCompilation(format!("Rule error: {e:?}")))
        };

        // socket(domain, type, protocol): deny datagram sockets on
        // the Internet families and raw sockets on any family. The
        // type argument is compared on its low nibble (the socket
        // type proper); flag bits above it (SOCK_NONBLOCK,
        // SOCK_CLOEXEC) are masked out of the comparison.
        const SOCK_TYPE_MASK: u64 = 0xf;
        let socket_rules = vec![
            rule(vec![
                cond(0, SeccompCmpOp::Eq, libc::AF_INET as u64)?,
                cond(
                    1,
                    SeccompCmpOp::MaskedEq(SOCK_TYPE_MASK),
                    libc::SOCK_DGRAM as u64,
                )?,
            ])?,
            rule(vec![
                cond(0, SeccompCmpOp::Eq, libc::AF_INET6 as u64)?,
                cond(
                    1,
                    SeccompCmpOp::MaskedEq(SOCK_TYPE_MASK),
                    libc::SOCK_DGRAM as u64,
                )?,
            ])?,
            rule(vec![cond(
                1,
                SeccompCmpOp::MaskedEq(SOCK_TYPE_MASK),
                libc::SOCK_RAW as u64,
            )?])?,
        ];
        rules.insert(libc::SYS_socket, socket_rules);

        // Namespace creation through unshare(flags) and
        // clone(flags, ...): one rule per CLONE_NEW* bit — a rule
        // matches when that bit is set, so any namespace flag at
        // all denies the call, while plain fork/thread flags pass.
        let namespace_bits = [
            libc::CLONE_NEWNS,
            libc::CLONE_NEWCGROUP,
            libc::CLONE_NEWUTS,
            libc::CLONE_NEWIPC,
            libc::CLONE_NEWUSER,
            libc::CLONE_NEWPID,
            libc::CLONE_NEWNET,
        ];
        let mut namespace_rules = Vec::new();
        for bit in namespace_bits {
            let bit = bit as u64;
            namespace_rules.push(rule(vec![cond(0, SeccompCmpOp::MaskedEq(bit), bit)?])?);
        }
        rules.insert(libc::SYS_unshare, namespace_rules.clone());
        rules.insert(libc::SYS_clone, namespace_rules);

        let filter = SeccompFilter::new(
            rules,
            SeccompAction::Allow,
            SeccompAction::Errno(libc::EPERM as u32),
            arch,
        )
        .map_err(|e| SeccompEnforcerError::FilterCompilation(format!("Filter error: {e:?}")))?;

        let bpf: BpfProgram = filter.try_into().map_err(|e| {
            SeccompEnforcerError::FilterCompilation(format!("BPF conversion error: {e:?}"))
        })?;

        Ok(bpf)
    }
}
