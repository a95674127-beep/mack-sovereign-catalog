//! Pinned worker thread: applies Landlock (fail-closed) and the seccomp
//! BPF filter to a dedicated OS thread, then runs the caller's workload
//! inside those restrictions.
//!
//! Adapted 2026-11-15 from the graded external tree: the as-received
//! version applied the restrictions and then ran an empty loop, and held
//! an unused reference to a lane mesh that was not adopted. This version
//! takes the workload as a closure, so what runs inside the sandbox is
//! explicit at the call site.

use std::path::PathBuf;
use std::thread;

use crate::sandbox::landlock_enforcer::LandlockSandbox;
use crate::sandbox::seccomp_filter::SeccompEnforcer;

pub struct PinnedWorkerRunner {
    spool_dir: PathBuf,
}

impl PinnedWorkerRunner {
    pub fn new(spool_dir: PathBuf) -> Self {
        Self { spool_dir }
    }

    /// Spawns a dedicated OS thread. Landlock and seccomp are applied
    /// before the workload runs; any enforcement failure aborts the
    /// workload (fail-closed).
    pub fn spawn_pinned_worker<F>(self, workload: F) -> thread::JoinHandle<Result<(), String>>
    where
        F: FnOnce() -> Result<(), String> + Send + 'static,
    {
        thread::Builder::new()
            .name("mack-pinned-worker".to_string())
            .spawn(move || {
                LandlockSandbox::enforce_strict_isolation(&[self.spool_dir.as_path()])
                    .map_err(|e| format!("Landlock enforcement failed: {e}"))?;

                let bpf = SeccompEnforcer::build_worker_bpf()
                    .map_err(|e| format!("Seccomp compilation failed: {e}"))?;
                SeccompEnforcer::apply_filter(&bpf)
                    .map_err(|e| format!("Seccomp activation failed: {e}"))?;

                workload()
            })
            .unwrap_or_else(|e| {
                thread::spawn(move || Err(format!("Failed to spawn worker thread: {e}")))
            })
    }
}
