#![forbid(unsafe_code)]

use landlock::{
    Access, AccessFs, AccessNet, CompatLevel, Compatible, NetPort, PathBeneath, PathFd,
    RestrictionStatus, Ruleset, RulesetAttr, RulesetCreated, RulesetCreatedAttr, RulesetStatus,
    ABI,
};
use std::fmt;
use std::path::Path;

#[derive(Debug)]
pub enum LandlockEnforcerError {
    UnsupportedKernelAbi,
    RulesetCreationFailed(String),
    PathAccessError(String),
    EnforcementFailed(String),
    NetworkConfinementUnsupported(String),
}

impl fmt::Display for LandlockEnforcerError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnsupportedKernelAbi => write!(
                f,
                "Linux kernel lacks Landlock LSM support (requires 5.13+)"
            ),
            Self::RulesetCreationFailed(e) => {
                write!(f, "Failed to construct Landlock ruleset: {e}")
            }
            Self::PathAccessError(e) => write!(f, "Failed to resolve path descriptor: {e}"),
            Self::EnforcementFailed(e) => write!(f, "Failed to apply Landlock restriction: {e}"),
            Self::NetworkConfinementUnsupported(e) => write!(
                f,
                "Landlock network confinement unavailable (requires Landlock ABI v4 / kernel 6.7+): {e}"
            ),
        }
    }
}

impl std::error::Error for LandlockEnforcerError {}

pub struct LandlockSandbox;

impl LandlockSandbox {
    pub fn enforce_strict_isolation(
        read_only_paths: &[&Path],
    ) -> Result<RestrictionStatus, LandlockEnforcerError> {
        let abi = ABI::V1;
        let ruleset = Ruleset::default()
            .handle_access(AccessFs::from_all(abi))
            .map_err(|e| LandlockEnforcerError::RulesetCreationFailed(format!("{e:?}")))?
            .create()
            .map_err(|e| LandlockEnforcerError::RulesetCreationFailed(format!("{e:?}")))?;

        let ruleset = Self::add_read_rules(ruleset, read_only_paths, abi)?;
        Self::finish(ruleset)
    }

    /// Strict filesystem isolation (as [`Self::enforce_strict_isolation`])
    /// plus deliberate Landlock network confinement: the calling
    /// thread's outbound TCP `connect()` is restricted to
    /// `allowed_tcp_connect_ports` and denied by the kernel for every
    /// other port, before any packet is sent.
    ///
    /// What an `Ok` result guarantees:
    /// - Outbound TCP connects to the listed ports are permitted;
    ///   outbound TCP connects to any other port fail with `EACCES`
    ///   at `connect()` time.
    /// - The filesystem rules are exactly those of
    ///   `enforce_strict_isolation`.
    ///
    /// What it does NOT guarantee (Landlock ABI v4 semantics — the
    /// rules match ports, not addresses or protocols):
    /// - A connect to ANY address on an allowed port passes the
    ///   ruleset; Landlock cannot express "this port on loopback
    ///   only". Callers must choose allowed ports accordingly (the
    ///   `mack-proxy` child is allowed only the proxy's per-run
    ///   ephemeral loopback port).
    /// - Only TCP `connect()` is governed. UDP and other protocols
    ///   are outside Landlock's network rules, and `bind()` /
    ///   listening is not restricted (`AccessNet::BindTcp` is
    ///   deliberately not handled).
    ///
    /// Fail-closed: network handling is a hard requirement. On a
    /// kernel without Landlock network support (ABI < v4, kernel
    /// < 6.7) this returns
    /// [`LandlockEnforcerError::NetworkConfinementUnsupported`]
    /// instead of silently running without network rules, and a
    /// partially enforced ruleset is an error, exactly as in
    /// `enforce_strict_isolation`.
    pub fn enforce_strict_isolation_with_network(
        read_only_paths: &[&Path],
        allowed_tcp_connect_ports: &[u16],
    ) -> Result<RestrictionStatus, LandlockEnforcerError> {
        let ruleset = Self::build_ruleset(read_only_paths, allowed_tcp_connect_ports)?;
        Self::finish(ruleset)
    }

    /// Builds the exact ruleset
    /// [`Self::enforce_strict_isolation_with_network`] would
    /// enforce, WITHOUT restricting the calling process
    /// (v0.14.2). A caller (the `mack-proxy` parent) probes
    /// with this at startup so a kernel that cannot provide
    /// the required confinement — in particular one without
    /// Landlock NET rules — is reported with its real reason
    /// immediately, instead of surfacing later as a masked
    /// `EINVAL` when the child's `pre_exec` fails at spawn.
    ///
    /// The support failure this exists to catch
    /// (`HandleAccesses(Net(Compat(...)))`) is raised while
    /// BUILDING the ruleset, so probing the build is a true
    /// test of it. A successful probe does not by itself
    /// guarantee `restrict_self` succeeds; it guarantees the
    /// kernel accepts every access right and rule the real
    /// enforcement will request.
    pub fn probe_strict_isolation_with_network(
        read_only_paths: &[&Path],
        allowed_tcp_connect_ports: &[u16],
    ) -> Result<(), LandlockEnforcerError> {
        let _ruleset = Self::build_ruleset(read_only_paths, allowed_tcp_connect_ports)?;
        Ok(())
    }

    fn build_ruleset(
        read_only_paths: &[&Path],
        allowed_tcp_connect_ports: &[u16],
    ) -> Result<RulesetCreated, LandlockEnforcerError> {
        let abi = ABI::V1;
        let mut ruleset = Ruleset::default()
            // Nothing in this ruleset is best-effort: if the kernel
            // cannot handle every requested access right — in
            // particular the network rights below — building the
            // ruleset errors out and the caller fails closed rather
            // than running a workload without network confinement.
            .set_compatibility(CompatLevel::HardRequirement)
            .handle_access(AccessFs::from_all(abi))
            .map_err(|e| LandlockEnforcerError::RulesetCreationFailed(format!("{e:?}")))?
            .handle_access(AccessNet::ConnectTcp)
            .map_err(|e| LandlockEnforcerError::NetworkConfinementUnsupported(format!("{e:?}")))?
            .create()
            .map_err(|e| LandlockEnforcerError::RulesetCreationFailed(format!("{e:?}")))?;

        ruleset = Self::add_read_rules(ruleset, read_only_paths, abi)?;

        for &port in allowed_tcp_connect_ports {
            ruleset = ruleset
                .add_rule(NetPort::new(port, AccessNet::ConnectTcp))
                .map_err(|e| {
                    LandlockEnforcerError::NetworkConfinementUnsupported(format!(
                        "Failed net rule for port {port}: {e:?}"
                    ))
                })?;
        }

        Ok(ruleset)
    }

    fn add_read_rules(
        mut ruleset: RulesetCreated,
        read_only_paths: &[&Path],
        abi: ABI,
    ) -> Result<RulesetCreated, LandlockEnforcerError> {
        for path in read_only_paths {
            let fd = PathFd::new(path).map_err(|e| {
                LandlockEnforcerError::PathAccessError(format!("Failed opening {path:?}: {e:?}"))
            })?;
            ruleset = ruleset
                .add_rule(PathBeneath::new(fd, AccessFs::from_read(abi)))
                .map_err(|e| {
                    LandlockEnforcerError::PathAccessError(format!(
                        "Failed rule for {path:?}: {e:?}"
                    ))
                })?;
        }
        Ok(ruleset)
    }

    fn finish(ruleset: RulesetCreated) -> Result<RestrictionStatus, LandlockEnforcerError> {
        let status = ruleset
            .restrict_self()
            .map_err(|e| LandlockEnforcerError::EnforcementFailed(format!("{e:?}")))?;

        // Fail-closed (fixed at unification, 2026-11-15): the as-received
        // version accepted PartiallyEnforced as success. Allen's design
        // rule is fail-closed — partial enforcement is an error.
        match status.ruleset {
            RulesetStatus::FullyEnforced => Ok(status),
            RulesetStatus::PartiallyEnforced => Err(LandlockEnforcerError::EnforcementFailed(
                "Landlock ruleset only partially enforced; failing closed".to_string(),
            )),
            RulesetStatus::NotEnforced => Err(LandlockEnforcerError::UnsupportedKernelAbi),
        }
    }
}
