#![forbid(unsafe_code)]

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum IsolationTierType {
    /// Tier 1: Linux LSM (Landlock) + Seccomp BPF in-process sandbox
    Tier1KernelSandboxed,
    /// Tier 2: Firecracker microVM hardware virtualization boundary
    Tier2FirecrackerMicroVm,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FirecrackerVmConfig {
    pub kernel_image_path: String,
    pub rootfs_path: String,
    pub vcpu_count: u8,
    pub mem_size_mib: u32,
    pub jailer_uid: u32,
    pub jailer_gid: u32,
    pub jailer_chroot_base: String,
    pub default_deny_egress: bool,
}

impl Default for FirecrackerVmConfig {
    fn default() -> Self {
        Self {
            kernel_image_path: "/opt/mack/kernels/vmlinux-hardened.bin".to_string(),
            rootfs_path: "/opt/mack/rootfs/sovereign-rootfs.ext4".to_string(),
            vcpu_count: 2,
            mem_size_mib: 512,
            jailer_uid: 10001,
            jailer_gid: 10001,
            jailer_chroot_base: "/srv/jailer".to_string(),
            default_deny_egress: true,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkloadDispatchProfile {
    pub workload_id: String,
    pub tier: IsolationTierType,
    pub firecracker_config: Option<FirecrackerVmConfig>,
    pub memory_limit_bytes: usize,
    pub cpu_time_limit_ms: u64,
}

impl WorkloadDispatchProfile {
    pub fn select_tier_for_risk(workload_id: &str, risk_score: u8) -> Self {
        // Workloads exceeding risk threshold 50 are routed to hardware microVM
        if risk_score >= 50 {
            Self {
                workload_id: workload_id.to_string(),
                tier: IsolationTierType::Tier2FirecrackerMicroVm,
                firecracker_config: Some(FirecrackerVmConfig::default()),
                memory_limit_bytes: 512 * 1024 * 1024,
                cpu_time_limit_ms: 10_000,
            }
        } else {
            Self {
                workload_id: workload_id.to_string(),
                tier: IsolationTierType::Tier1KernelSandboxed,
                firecracker_config: None,
                memory_limit_bytes: 128 * 1024 * 1024,
                cpu_time_limit_ms: 2_000,
            }
        }
    }
}
