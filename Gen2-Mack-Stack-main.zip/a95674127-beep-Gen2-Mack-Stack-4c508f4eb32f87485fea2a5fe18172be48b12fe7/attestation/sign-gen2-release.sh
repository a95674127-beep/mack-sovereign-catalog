#!/usr/bin/env bash
# Sign the Gen 2 v0.14.2 release attestation with Allen's MACK release key.
#
# Usage: ./sign-gen2-release.sh /path/to/private-key
#
# The private key lives in Allen's private Google Drive folder
# "MACK Signing Key". It is never committed, never printed, and this
# script never copies it. The key has no passphrase; the file itself
# is the credential, so keep it owner-only wherever it is used.
set -euo pipefail

KEY="${1:?usage: sign-gen2-release.sh /path/to/private-key}"
DIR="$(cd "$(dirname "$0")" && pwd)"
DOC="$DIR/ATTESTATION.md"

[ -f "$KEY" ] || { echo "key file not found: $KEY" >&2; exit 1; }
[ -f "$DOC" ] || { echo "attestation not found: $DOC (rename the approved draft to ATTESTATION.md first)" >&2; exit 1; }

# 1. Sign (OpenSSH SSHSIG, namespace mack-release — same as Gen 1).
ssh-keygen -Y sign -f "$KEY" -n mack-release "$DOC"

# 2. Verify our own signature before anything is published.
ssh-keygen -Y verify -f "$DIR/allowed_signers" -I allenmack \
  -n mack-release -s "$DOC.sig" < "$DOC"

echo
echo "Signed + verified: $DOC.sig"
echo "Public key fingerprint (must match the record):"
ssh-keygen -lf "$DIR/allen-mack-release.pub"
