# OWNER RELEASE ATTESTATION — Gen 2 Mack-Stack

**Owner:** Allen Mack, sole human author and owner
**Repository:** `a95674127-beep/Gen2-Mack-Stack` (private)
**Release:** v0.14.2
**Date of attestation:** November 19, 2026

## Release state attested

- Main head at signing: **`0e85f4facc25ecde3f64b6552665fceca1cc12de`**.
- The two commits on top of `03ccbbc1` add workflow files only
  (`fcaf2e39` gitleaks.yml; `0e85f4fa` ci.yml). No source file changed
  after `03ccbbc1`; every code verification below therefore applies to
  the code at head exactly, and each run is cited against the commit
  it actually ran on.

## Verification results attested

1. **Test suite:** 121 passed / 0 failed locally on `03ccbbc1`
   (52 unit + 69 integration across 19 integration suites), November 19,
   2026. Full terminal printout retained with SHA-256
   `983b494ecd3f38b35461fb8f81de5fb0ac2de8fde5228aacafd38b33bd19bd98`.
2. **Continuous integration:** GitHub Actions CI run #1 on head
   `0e85f4fa` — SUCCESS in 2m 13s: `cargo test`, `cargo clippy
   --all-targets -- -D warnings`, `cargo fmt --check` on GitHub-hosted
   Ubuntu runners. CI green means `cargo test` exited 0 on a source
   tree identical to the locally validated `03ccbbc1`.
3. **Secret scan (full git history):** GitHub Actions Secret Scan runs
   #1 (on `fcaf2e3`, 8s) and #2 (on `0e85f4fa`, 9s) — both SUCCESS.
   gitleaks 8.28.0, checkout fetch-depth 0, `gitleaks detect` over the
   entire history: no leaks found in any commit.
4. **Fuzzing (local, November 18, 2026):** `fuzz_ledger_verify`
   592,077 executions and `fuzz_secret_split` 4,834,714 executions,
   zero crashes.

## Stated plainly

- The repository was public for roughly nine minutes on November 19,
  2026 (15:25–15:34 EST) solely to run the Actions above on free
  public-repository minutes, then returned to private.
- No independent third-party security review has been performed.
- Sales to date: $0.

## Signature

Signed with the owner's MACK release signing key (Ed25519, fingerprint
`SHA256:iKgJ7s1r96fDWGlcPYObuL1cGYJNYL5e1npeF3KSZws`), OpenSSH signature,
namespace `mack-release`. Verify with:

```
ssh-keygen -Y verify -f allowed_signers -I allenmack -n mack-release -s ATTESTATION.md.sig < ATTESTATION.md
```
