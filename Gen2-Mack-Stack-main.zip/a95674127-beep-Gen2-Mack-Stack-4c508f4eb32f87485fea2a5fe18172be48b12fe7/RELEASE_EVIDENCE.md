# Release evidence — Gen 2 Mack-Stack

What a release of this repository can show an evaluator, how to
reproduce it, and — stated as plainly — what it does not yet
include.

## Binary SHA-256 hashes (reproduce at release time)

Hashes are computed at release time on the machine that built the
release; they are not committed to this repository, because a
committed hash nobody can reproduce is worse than none. To
reproduce:

```bash
cargo build --release --locked
sha256sum target/release/mack-security-runtime \
          target/release/mack-proxy \
          target/release/mack-ledger-verify
```

To check that the build itself is reproducible (same source and
lockfile → bit-identical binaries), run the two-clean-build
comparison:

```bash
scripts/verify_reproducible_build.sh
```

It builds both main binaries twice from clean and compares their
SHA-256 digests; it prints PASS only when they are identical.

## Software bill of materials

`sbom.cdx.json` (repository root) is a CycloneDX 1.5 SBOM of the
locked dependency tree: every package with its name, version, and
license as cargo metadata reports them. Packages reachable only
through dev-dependency edges (test/bench tooling that never
ships) are marked `scope: excluded`; everything the binaries are
built from is `scope: required`. Regenerate and diff at release
time:

```bash
python3 scripts/generate_sbom.py
```

The generator's output is deterministic (no timestamp or serial
number), so regeneration at the same lockfile produces the same
file.

## What is NOT claimed yet: signed build provenance

Signed Sigstore/SLSA provenance via GitHub Actions artifact
attestations is **deferred**, for two concrete reasons:

- GitHub Actions is unavailable to this repository until the
  2026-12-01 quota reset.
- Workflow files are placed by the repository owner; the
  automation used to build this release cannot add them.

Until both change, no signed-provenance claim is made for any
release of this repository. The crate's `forensic` module does
produce signed build-provenance *records* (source Merkle root,
lockfile and binary digests, Ed25519-signed) — those are records
an evaluator can verify, and they are not represented as an SLSA
level or a substitute for the deferred attestation pipeline.

## Session-ledger evidence

Runs of `mack-proxy --ledger <path>` produce an append-only
signed ledger file that any evaluator can verify without the
proxy, the signing key, or a live session:

```bash
mack-ledger-verify <ledger-file>          # or an export directory
```

See `src/ledger/store.rs` for the format, the torn-tail
crash-recovery rule, and the export/manifest cross-check.

Since v0.12.0 two more artifacts strengthen that evidence:

- **Checkpoint sidecar.** `mack-ledger-verify <ledger-file>
  --extract-checkpoint <sidecar.json>` copies the ledger's
  latest signed checkpoint into a small JSON file an evaluator
  can keep separately. `mack-ledger-verify <ledger-file>
  --against-checkpoint <sidecar.json>` then proves the file
  still reaches exactly that checkpoint: a rolled-back tail
  fails as `TailTruncation` (naming both record counts), extra
  records or a different head as `CheckpointMismatch`, and a
  forged sidecar signature as a signature failure.
- **Session receipt.** A run's `<ledger>.receipt.json` (also
  printed to the proxy's stdout) is signed with the same key
  that signed the ledger and binds the crate version, a digest
  of the confinement policy the run actually applied, the
  ledger's final head hash and record count, and the SHA-256
  of the proxy executable measured at receipt time. Verify it
  against the authority key named in the ledger header; the
  receipt's `key_provenance` field states whether that key is
  the operator's persistent authority key (`authority`) or a
  per-session ephemeral one (`session-ephemeral`, in-memory
  runs only — worth less, and labeled so). The executable hash
  in a receipt is a measurement of a run, not a committed
  release hash — the no-committed-hashes rule above stands.
