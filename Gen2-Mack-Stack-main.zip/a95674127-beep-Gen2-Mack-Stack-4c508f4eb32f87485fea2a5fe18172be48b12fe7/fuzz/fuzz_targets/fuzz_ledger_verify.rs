#![no_main]
use libfuzzer_sys::fuzz_target;

use mack_security_runtime::ledger::store;
use std::io::Write;

// Attacker-controlled bytes as a persistent ledger file. The
// store's parsers (verify_file: full JSONL parse + chain +
// signature verification; extract_checkpoint: sidecar parse)
// must never panic — any input yields Ok or a typed
// LedgerStoreError.
fuzz_target!(|data: &[u8]| {
    let path = std::env::temp_dir().join(format!(
        "mack-fuzz-ledger-{}-{}.jsonl",
        std::process::id(),
        data.len()
    ));
    let written = std::fs::File::create(&path)
        .and_then(|mut f| f.write_all(data))
        .is_ok();
    if written {
        let _ = store::verify_file(&path);
        let _ = store::extract_checkpoint(&path);
    }
    let _ = std::fs::remove_file(&path);
});
