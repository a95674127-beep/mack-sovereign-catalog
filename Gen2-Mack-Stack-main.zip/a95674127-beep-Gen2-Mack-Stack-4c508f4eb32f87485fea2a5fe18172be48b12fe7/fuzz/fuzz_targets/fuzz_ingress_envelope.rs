#![no_main]
use libfuzzer_sys::fuzz_target;
use mack_security_runtime::proof_fabric::execution_envelope::IntentBoundEnvelope;
use ed25519_dalek::SigningKey;
use rand_core::OsRng;

fuzz_target!(|data: &[u8]| {
    // Tests that arbitrary garbage input never causes panic in envelope parsing or verification
    if let Ok(envelope) = bincode::deserialize::<IntentBoundEnvelope>(data) {
        let dummy_verifying_key = SigningKey::generate(&mut OsRng).verifying_key();
        let _ = envelope.verify(data, &dummy_verifying_key);
    }
});
