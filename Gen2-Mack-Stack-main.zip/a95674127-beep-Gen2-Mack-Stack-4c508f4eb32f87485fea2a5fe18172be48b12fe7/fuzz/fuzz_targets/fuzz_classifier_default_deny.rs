#![no_main]
use libfuzzer_sys::fuzz_target;
use mack_security_runtime::cdr::content_disarm::ContentDisarmEngine;

fuzz_target!(|data: &[u8]| {
    // Tests that arbitrary byte streams are safely filtered by CDR without panicking
    let _ = ContentDisarmEngine::sanitize_and_reconstruct(data);
});
