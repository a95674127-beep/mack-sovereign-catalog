#![no_main]
use libfuzzer_sys::fuzz_target;

use mack_security_runtime::secret_split::{reconstruct_secret, SecretShare};

// Attacker-controlled share sets for the Shamir
// reconstruction. Layout: byte 0 is the threshold k; the
// rest is a sequence of (index, length, data) share records
// with fuzz-chosen lengths. Reconstruction must never
// panic — invalid sets yield a typed SplitError (index 0,
// duplicates, mismatched lengths, too few shares are all
// expected, ordinary outcomes here).
fuzz_target!(|data: &[u8]| {
    if data.len() < 2 {
        return;
    }
    let k = data[0];
    let mut rest = &data[1..];
    let mut shares: Vec<SecretShare> = Vec::new();
    while rest.len() >= 2 && shares.len() < 8 {
        let index = rest[0];
        let len = (rest[1] as usize).min(rest.len() - 2);
        shares.push(SecretShare {
            index,
            data: rest[2..2 + len].to_vec(),
        });
        rest = &rest[2 + len..];
    }
    if !shares.is_empty() {
        let _ = reconstruct_secret(&shares, k);
    }
});
