# Gen 2 Mack-Stack — `mack-security-runtime`
**Mandatory Access & Containment Kernel (MACK) — Gen 2 Sovereign Architecture**  
*The Generational Successor to AI Infinity Force One (Generation 1)*

[![Rust](https://img.shields.io/badge/rust-2021%20edition-orange.svg)](https://www.rust-lang.org)
[![Security](https://img.shields.io/badge/unsafe_code-forbidden-green.svg)](https://doc.rust-lang.org/nomicon/safe-unsafe-meaning.html)
[![Lints](https://img.shields.io/badge/panics-denied-blue.svg)](https://github.com/rust-lang/rust-clippy)
[![Tests](https://img.shields.io/badge/adversarial_tests-31%20passed-brightgreen.svg)](tests/)
[![CI Matrix](https://img.shields.io/badge/CI%20Matrix-Ubuntu%20%7C%20macOS%20%7C%20Multi--Toolchain-blue.svg)](.github/workflows/ci.yml)
[![Workflow Concurrency](https://img.shields.io/badge/Concurrency-Cancel--Outdated%20%7C%20Protected--Release-brightgreen.svg)](.github/workflows/)
[![Reproducible](https://img.shields.io/badge/builds-reproducible%20bit--for--bit-blue.svg)](scripts/)

---

## Design Thesis

Generation 1 stays the original — built, signed, and on the market, never modified. This system stands beside it as the advanced generation, aimed at the bottleneck Generation 1 exposed: **sensitive data and credentials leaking while untrusted code and AI agents execute.**

- **The executing lane never holds a raw secret.**
- **No single device ever holds a whole key.**

MACK binds the **four fundamental boundaries of secure agentic isolation** and **rigorous cryptographic proof habits** into a single clean-room Rust substrate:

1. **Sandboxing:** Hardware microVM (Firecracker) and Linux LSM/BPF (Landlock & Seccomp) dual-tier isolation.
2. **Default-Deny Egress:** Sentinel S2 network perimeter with unconditional cloud metadata (`169.254.169.254`) blackholing.
3. **Tenancy:** Unidirectional 36-lane vertical processing sieve preventing cross-task contamination.
4. **Per-Run Credential Scoping:** Ephemeral credentials minted for single run, destination, and action, minutes to live, gated by 2-of-3 FROST threshold quorum.
5. **Blind Execution via Network-Layer Injection:** Sandboxed workers only handle synthetic placeholders (`MACK_BLIND_TOKEN_...`). The Sentinel S2 proxy injects real secrets over verified TLS to allowlisted destinations.
6. **Deterministic Replay:** Historical executions can be replayed and verified bit-for-bit from signed transcripts.
7. **Reproducible Builds:** Normalized compiler invariants (`SOURCE_DATE_EPOCH`, `--remap-path-prefix`) backed by signed Merkle provenance attestations.

---

## Architecture & Module Status

| Module | Subsystem | Status |
|---|---|---|
| `vault` | `MackVaultEngine` (Argon2id + XChaCha20-Poly1305 + zeroizing secret container + audit ledger) & `EnvelopeVaultCrypto` | **Fully Implemented** |
| `auth` / `threshold` | Scoped credential mint (`auth`: multisig quorum — distinct Ed25519 signers counted by `QuorumAuthority`) & FROST threshold signing (`threshold`: RFC 9591 `frost-ed25519`, dealerless DKG, 2-of-3 quorum signing, implemented v0.5.0; not integrated into `auth` minting; multi-device share transport not built) | **Implemented (as separate modules)** |
| `proof_fabric` | Intent-Bound Envelopes, HMAC-SHA256 Proof Ledger, Compound Attestation, Deterministic Replay Engine | **Fully Implemented** |
| `sandbox` | Dual-Tier Isolation (Landlock/Seccomp + Firecracker dispatch), Sentinel S2 Default-Deny Egress Proxy, Blind Credential Injection | **Fully Implemented** |
| `cdr` | Content Disarm and Reconstruction Engine | **Fully Implemented** |
| `forensic` | Evidence Chamber (Cryptographic Sealing) & SLSA Level 3 Build Provenance Manifests | **Fully Implemented** |

---

## Repository Structure

```text
Gen2-Mack-Stack/
├── Cargo.toml                  # Hardened dependencies, release profile & zero-panic lints
├── ARCHITECTURE.md             # Gen 2 architecture specification & 7 pillars
├── THREAT_MODEL.md             # STRIDE analysis & host boundary model
├── SECURITY.md                 # Security policy, cryptographic standards & invariants
├── SECURITY_EVIDENCE.md        # Comprehensive security evidence & audit specification
├── README.md                   # System overview & verification guide
├── scripts/
│   └── verify_reproducible_build.sh # Dual-pass bit-for-bit build verifier
├── src/
│   ├── lib.rs                  # Public kernel interface (MackKernel)
│   ├── main.rs                 # Vault seal/unseal smoke verification CLI
│   ├── proof_fabric/
│   │   ├── compound_attestation.rs # Multi-agent delegation chain verification
│   │   ├── deterministic_replay.rs # Bit-for-bit historical execution replay engine
│   │   ├── execution_envelope.rs   # Intent-bound Ed25519 envelopes
│   │   ├── hardware_attestation.rs # SEV-SNP / TDX confidential computing seam
│   │   ├── proof_ledger.rs         # Tamper-evident HMAC-SHA256 chained audit log
│   │   └── scoped_credential.rs    # FROST 2-of-3 quorum gated credential mint
│   ├── sandbox/
│   │   ├── egress_proxy.rs     # Sentinel S2 default-deny proxy & blind injection
│   │   ├── isolation_tier.rs   # Tier 1 (Landlock/Seccomp) & Tier 2 (Firecracker)
│   │   ├── landlock_enforcer.rs# Linux Landlock LSM file sandboxing
│   │   ├── seccomp_filter.rs   # Seccomp BPF syscall restriction
│   │   ├── sibling_mesh.rs     # 3-Phase, 36-Lane vertical processing sieve
│   │   └── worker_runner.rs    # Thread-pinned execution worker
│   ├── cdr/
│   │   └── content_disarm.rs   # Content disarm and reconstruction engine
│   ├── forensic/
│   │   ├── build_provenance.rs # SLSA Level 3 reproducible build attestation
│   │   └── evidence_chamber.rs # Chain-of-custody forensic artifact sealing
│   └── vault/
│       ├── vault_core.rs       # Original MackVaultEngine & zeroizing SecretKeyBytes
│       ├── envelope_crypto.rs  # Argon2id + XChaCha20-Poly1305 envelope encryption
│       └── mod.rs              # Re-exports for vault engine and envelope crypto
├── tests/
│   ├── vault_roundtrip.rs             # Public API vault seal/unseal roundtrip test
│   ├── pipeline_enforcement_tests.rs # 17-path adversarial & pipeline test suite
│   └── vault_runtime_defensive_tests.rs # 8-path defensive integration & zeroization test suite
└── fuzz/
    ├── Cargo.toml
    └── fuzz_targets/           # libFuzzer fuzzing harnesses
```

---

## Build & Verification

```bash
# 1. Run the smoke check
cargo run

# 2. Run the complete test suite (all 31 tests including defensive integration and workflow validation suites)
cargo test

# 3. Verify bit-for-bit reproducible build
./scripts/verify_reproducible_build.sh
```

---

## CI & Workflow Concurrency Controls

GitHub Actions workflows are configured with strict concurrency groups and selective in-progress cancellation:

- **Superseded Run Cancellation (`cancel-in-progress: true`):** Active test suites (`ci.yml`) and secret scans (`gitleaks.yml`) evaluate `${{ github.workflow }}-${{ github.head_ref || github.ref }}`. Pushing newer commits immediately cancels obsolete in-flight runs on PRs and development branches, preventing wasted runner hours.
- **Uninterrupted Release Pipelines (`cancel-in-progress: false`):** Release packaging (`release.yml`) and tag-triggered builds enforce `cancel-in-progress: false`. Release packaging, binary checksumming, and signing jobs are strictly queued and guaranteed never to be interrupted or aborted by subsequent pushes.
- **Namespace Isolation:** Workflow-scoped concurrency keys ensure testing, secret audits, and release pipelines operate in independent concurrency domains without cross-pipeline interference.

### Automated Workflow Concurrency & Release Safety Harness

To eliminate the risk of malformed expressions, syntax drift, or accidental cancellation of live release jobs, Gen 2 enforces automated validation (`scripts/validate_workflows.py`, `scripts/validate_workflows.sh`, and `tests/workflow_concurrency_tests.rs`):

1. **Syntax & Expression Integrity:** Evaluates all `${{ ... }}` expressions for balanced delimiters, matched parentheses, and valid context bindings; rejects invalid workflow-level scope accesses (e.g. `matrix.*` in workflow concurrency).
2. **Workflow Namespace Isolation:** Ensures all concurrency groups include `${{ github.workflow }}` to prevent cross-workflow collision and unintended run cancellation between distinct pipelines.
3. **Release Cancellation Safeguards:**
   - Dedicated release workflows (`release.yml`) require `cancel-in-progress: false`. Any configuration attempting `cancel-in-progress: true` fails validation immediately (`RELEASE_ACCIDENTAL_CANCELLATION_RISK`).
   - Shared tag-triggered workflows (`ci.yml`) require conditional tag immunity expressions (`${{ !startsWith(github.ref, 'refs/tags/') }}`). Simulated tag ref evaluations ensure release tags are never aborted in-flight.
4. **Automated Enforcement:** Executed automatically via CI on every push and PR (`validate-workflows` job), guarded in release workflows prior to packaging, and integrated into `cargo test --all-targets` via native test harnesses.
5. **Precision File & Line Number Reporting:** Invariant violations pinpoint the exact workflow file and 1-based line number (e.g. `[RELEASE_ACCIDENTAL_CANCELLATION_RISK] release.yml:7: Dedicated release workflow has 'cancel-in-progress: true'`), emitting GitHub Actions workflow error annotations (`::error file=...,line=...`) in CI environments.

```bash
# Run the standalone workflow validator against .github/workflows
./scripts/validate_workflows.sh

# Run validator synthetic regression tests (10 edge and negative test fixtures)
python3 scripts/validate_workflows.py --self-test
```

---

## License

MIT OR Apache-2.0.
