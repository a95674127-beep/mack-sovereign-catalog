# SF-ITES — Smart-Flow Integrated Thermal Extraction System

Retrofit IoT safety controller + telemetry for water extraction pumps.
An ESP32 watches current, flow, pressure, and motor temperature, and cuts
pump power through a series-wired relay on dry-run, overcurrent,
overtemperature, cavitation, phase imbalance, or sensor failure. A
Raspberry Pi logs everything locally, syncs encrypted batches to the
cloud, and serves a status dashboard.

## Layout

```
sf-ites/
├── firmware/esp32/        ESP32 edge firmware (Arduino/C++)
│   ├── sf_ites_main.ino   main loop, sensor drivers, serial protocol
│   ├── config.h           ALL pins/thresholds/timing — start here
│   ├── anomaly.h/.cpp     rolling baselines, cavitation/bearing/imbalance
│   └── safety.h/.cpp      fail-safe state machine + trip logic
├── gateway/raspberry_pi/  Pi-side Python
│   ├── telemetry.py       serial ingest → SQLite
│   ├── sync.py            encrypted batch upload (stub endpoint)
│   ├── dashboard.py       local web UI (:8080, stdlib only)
│   └── config.py          settings (secrets via env vars)
└── docs/
    ├── ARCHITECTURE.md    block diagram, data flow, failure modes
    ├── WIRING.md          pin-by-pin wiring, relay notes
    ├── BOM.md             parts + approximate costs
    └── TESTING.md         bench-test procedure (no pump needed)
```

## Bring-up order

1. Read `docs/ARCHITECTURE.md` (10 min).
2. Set `config.h` to your pump's ratings.
3. Flash with `TEST_MODE 1`, run `docs/TESTING.md` Test 2.
4. Wire sensors per `docs/WIRING.md`, run Tests 1, 3, 4.
5. Set `TEST_MODE 0`, commission on the real pump with a clamp meter.
6. Pi: `pip install -r requirements.txt`, run `telemetry.py` + `dashboard.py`.

## Honest status (read this)

- **Prototype firmware.** Written carefully, never run on real pump
  hardware. No test results exist beyond the Python parser self-test.
- **No certifications.** Not UL/CE listed. Mains-side work needs a
  qualified electrician.
- **One documented blind spot:** software cannot detect a welded relay
  contact. `WIRING.md` describes the aux-contact mitigation for v2.
- **Cloud sync is a stub.** `sync.py` buffers locally until you configure
  a real endpoint; it will not phone home to a placeholder.
- **Prices in BOM.md are approximate.** Verify before ordering.

## License / ownership

Proprietary — Allen Mack / Infinity Force One Studios. All rights reserved.
