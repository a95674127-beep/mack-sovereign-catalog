"""
Layer 1 Safety Simulator — SF-ITES dry-run / overload / overtemp protection.

Patched 2026-10-09 from Allen Mack's original simulation:
  1. Relay now defaults to OFF (fail-safe). Only energizes after a clean
     calibration. Previously defaulted to ON before baseline existed.
  2. Sensor-failure handling: invalid readings (None, NaN, out-of-range)
     for N consecutive samples trips the system instead of running blind.
  3. Thermal monitoring added: winding/casing temperature baseline with
     overtemperature trip, per the SF-ITES hardware spec.
  4. Calibration extended to 30 s default (was 3 s). Demo override kept
     short with a comment marking production minimum.

Original logic preserved: dual-condition dry-run check, latched trips,
fault confirmation windows to reject nuisance trips.
"""

import math
import time
import random


class Layer1SafetySimulator:
    # ---- Tunables -------------------------------------------------------
    CALIBRATION_DURATION = 30.0      # seconds; production minimum
    DRY_RUN_CURRENT_RATIO = 0.50     # current < 50% of baseline ...
    DRY_RUN_FLOW_MAX = 0.2           # ... AND flow < 0.2 L/min ...
    OVERLOAD_CURRENT_RATIO = 1.15    # current > 115% of baseline ...
    OVERTEMP_RISE_C = 25.0           # temp > baseline + 25 C ...
    FAULT_WINDOW_S = 3.0             # ... sustained this long -> trip
    SENSOR_BAD_LIMIT = 5             # consecutive bad reads -> sensor fault
    # Plausible sensor ranges; anything outside is a failed sensor, not data.
    CURRENT_RANGE = (0.0, 50.0)      # amps
    FLOW_RANGE = (0.0, 100.0)        # L/min
    TEMP_RANGE = (-20.0, 150.0)      # deg C
    # ---------------------------------------------------------------------

    def __init__(self):
        self.normal_current_baseline = 0.0
        self.normal_temp_baseline = 0.0
        # FAIL-SAFE: relay starts OFF. The pump cannot energize until
        # calibration completes cleanly (see calibrate()).
        self.relay_state = False  # True = ON (energized), False = OFF (safe)
        self.calibrated = False
        self.system_tripped = False
        self.trip_reason = None
        self.dry_run_timer = None
        self.overload_timer = None
        self.overtemp_timer = None
        self._bad_sensor_count = 0

    # ------------------------------------------------------------------
    def calibrate(self, duration=None):
        """Establish current + temperature baselines, then energize relay."""
        duration = duration if duration is not None else self.CALIBRATION_DURATION
        print("[INFO] Initializing startup calibration routine...")
        print(f"[INFO] Sampling for {duration:.0f} s. Relay held OFF (fail-safe).")
        current_sum = 0.0
        temp_sum = 0.0
        samples = 0
        start_time = time.time()

        while time.time() - start_time < duration:
            # Simulated healthy-pump readings.
            simulated_current = 5.0 + random.uniform(-0.1, 0.1)
            simulated_temp = 42.0 + random.uniform(-1.0, 1.0)
            current_sum += simulated_current
            temp_sum += simulated_temp
            samples += 1
            time.sleep(0.1)

        if samples == 0:
            self.trigger_fault("CALIBRATION FAILURE: no samples collected")
            return False

        self.normal_current_baseline = current_sum / samples
        self.normal_temp_baseline = temp_sum / samples
        self.calibrated = True
        # Only now is it safe to energize.
        self.relay_state = True
        print(f"[INFO] Baseline Current Established: "
              f"{self.normal_current_baseline:.2f} A")
        print(f"[INFO] Baseline Temperature Established: "
              f"{self.normal_temp_baseline:.1f} C")
        print("[INFO] Calibration clean. Relay energized (ON).\n")
        return True

    # ------------------------------------------------------------------
    def _sensors_valid(self, current_rms, flow_rate, temp_c):
        """Reject None, NaN, and out-of-range readings as sensor failure."""
        for value, (lo, hi), name in (
            (current_rms, self.CURRENT_RANGE, "current"),
            (flow_rate, self.FLOW_RANGE, "flow"),
            (temp_c, self.TEMP_RANGE, "temperature"),
        ):
            if value is None or (
                isinstance(value, float) and math.isnan(value)
            ) or not (lo <= value <= hi):
                print(f"[WARN] Invalid {name} reading: {value!r}")
                return False
        return True

    # ------------------------------------------------------------------
    def evaluate_sensors(self, current_rms, flow_rate, temp_c):
        """Return True while safe to run. Trips (latching) on any fault."""
        if self.system_tripped:
            return False
        if not self.calibrated:
            # Never evaluate against a baseline that does not exist.
            return False

        # --- Sensor integrity: N consecutive bad reads -> trip, don't run blind
        if not self._sensors_valid(current_rms, flow_rate, temp_c):
            self._bad_sensor_count += 1
            if self._bad_sensor_count >= self.SENSOR_BAD_LIMIT:
                self.trigger_fault(
                    "CRITICAL: Sensor Fault "
                    f"({self._bad_sensor_count} consecutive invalid readings) "
                    "-> Cutting Relay"
                )
                return False
            return True  # tolerate isolated glitches
        self._bad_sensor_count = 0

        current_time = time.time()

        # --- Dry-Run: current < 50% baseline AND flow ~ 0, sustained ---
        if (current_rms < (self.normal_current_baseline * self.DRY_RUN_CURRENT_RATIO)
                and flow_rate < self.DRY_RUN_FLOW_MAX):
            if self.dry_run_timer is None:
                self.dry_run_timer = current_time
            elif current_time - self.dry_run_timer > self.FAULT_WINDOW_S:
                self.trigger_fault("CRITICAL: Dry Run Detected -> Cutting Relay")
                return False
        else:
            self.dry_run_timer = None

        # --- Overload: current > 115% baseline, sustained ---
        if current_rms > (self.normal_current_baseline * self.OVERLOAD_CURRENT_RATIO):
            if self.overload_timer is None:
                self.overload_timer = current_time
            elif current_time - self.overload_timer > self.FAULT_WINDOW_S:
                self.trigger_fault("CRITICAL: Overload Detected -> Cutting Relay")
                return False
        else:
            self.overload_timer = None

        # --- Overtemperature: temp > baseline + 25 C, sustained ---
        if temp_c > (self.normal_temp_baseline + self.OVERTEMP_RISE_C):
            if self.overtemp_timer is None:
                self.overtemp_timer = current_time
            elif current_time - self.overtemp_timer > self.FAULT_WINDOW_S:
                self.trigger_fault(
                    "CRITICAL: Overtemperature Detected "
                    f"({temp_c:.1f} C) -> Cutting Relay"
                )
                return False
        else:
            self.overtemp_timer = None

        return True

    # ------------------------------------------------------------------
    def reset(self):
        """Manual reset after a trip. Requires human inspection first."""
        if not self.system_tripped:
            print("[INFO] No trip to reset.")
            return
        print(f"[INFO] Manual reset acknowledged. Previous trip: {self.trip_reason}")
        print("[INFO] Re-running calibration before re-energizing.")
        self.system_tripped = False
        self.trip_reason = None
        self.calibrated = False
        self.relay_state = False  # fail-safe: off until recalibrated
        self.dry_run_timer = None
        self.overload_timer = None
        self.overtemp_timer = None
        self._bad_sensor_count = 0
        self.calibrate()

    # ------------------------------------------------------------------
    def trigger_fault(self, reason):
        self.system_tripped = True
        self.trip_reason = reason
        self.relay_state = False
        print(f"\n[FAULT TRIGGERED] {reason}")
        print("[SYSTEM STATUS] Relay Disconnected (OFF) — latched.\n")


def run_simulation():
    sim = Layer1SafetySimulator()
    # Demo uses a short calibration; production minimum is 30 s
    # (see CALIBRATION_DURATION).
    sim.calibrate(duration=3.0)

    print("--- SCENARIO 1: Normal Operating State ---")
    for i in range(3):
        current, flow, temp = 5.0, 2.5, 42.0
        status = "ON" if sim.relay_state else "OFF"
        print(f"Reading [{i+1}] -> Current: {current} A | Flow: {flow} L/min "
              f"| Temp: {temp} C | Relay: {status}")
        sim.evaluate_sensors(current, flow, temp)
        time.sleep(1)

    print("\n--- SCENARIO 2: Dry-Run (pump lifted out of water) ---")
    print("Flow drops to 0.0 L/min, Current drops to 1.2 A...")
    start_dry = time.time()
    while not sim.system_tripped and (time.time() - start_dry < 6.0):
        print("Telemetry -> Current: 1.2 A | Flow: 0.0 L/min | Temp: 44.0 C "
              "| Monitoring fault window...")
        sim.evaluate_sensors(1.2, 0.0, 44.0)
        time.sleep(1)

    if sim.system_tripped:
        print("--- SCENARIO 3: Sensor failure while running ---")
        print("Resetting, then feeding NaN flow readings...")
        sim.reset()
        for i in range(7):
            print(f"Reading [{i+1}] -> Current: 5.0 A | Flow: NaN | Temp: 42.0 C")
            sim.evaluate_sensors(5.0, float("nan"), 42.0)
            time.sleep(0.5)
            if sim.system_tripped:
                break


if __name__ == "__main__":
    run_simulation()
