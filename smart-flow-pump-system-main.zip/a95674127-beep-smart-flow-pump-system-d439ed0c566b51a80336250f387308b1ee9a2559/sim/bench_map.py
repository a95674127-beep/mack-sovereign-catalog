"""Bench map for the SF-ITES ESP32.

Pins and scale formulas are copied from firmware/esp32/config.h and
sf_ites_main.ino. This module does not drive GPIO and does not connect
mains. It turns a low-voltage bench observation into the two serial
payloads the gateway already parses.
"""

import json

# DevKit v1. Input-only ADC pins cannot be outputs.
PINS = {
    "CT1": {"gpio": 34, "adc": "ADC1_CH6", "direction": "in", "level": "analog"},
    "CT2": {"gpio": 35, "adc": "ADC1_CH7", "direction": "in", "level": "analog"},
    "CT3": {"gpio": 32, "adc": "ADC1_CH4", "direction": "in", "level": "analog"},
    "FLOW": {"gpio": 25, "direction": "in", "level": "pulse", "pull": "INPUT_PULLUP"},
    "PRESSURE": {"gpio": 33, "adc": "ADC1_CH5", "direction": "in", "level": "analog"},
    "TEMP": {"gpio": 26, "direction": "in", "level": "1-wire"},
    "RELAY": {"gpio": 27, "direction": "out", "engaged": "LOW", "safe": "HIGH"},
    "START": {"gpio": 14, "direction": "in", "idle": "HIGH", "pressed": "LOW"},
    "RESET": {"gpio": 4, "direction": "in", "idle": "HIGH", "pressed": "LOW"},
    "STATUS_LED": {"gpio": 2, "direction": "out"},
    "BUZZER": {"gpio": 13, "direction": "out", "on": "HIGH"},
}

ADC_VREF = 3.3
ADC_MAX_COUNTS = 4095.0
ADC_MID_COUNTS = 2048.0
CT_AMPS_PER_VOLT = 30.0
FLOW_PULSES_PER_LITER = 450.0
PRESS_V_MIN = 0.5
PRESS_V_MAX = 4.5
PRESS_KPA_MAX = 1200.0
SERIAL_BAUD = 115200
DEVICE_ID_FIRMWARE = "pump-01"
DEVICE_ID_GATEWAY_DEFAULT = "pump-01"

# Legacy 1 Hz line fields, in the order sf_ites_main.ino prints them.
LEGACY_FIELDS = (
    "t",
    "i",
    "flow",
    "press",
    "temp",
    "state",
    "trip",
    "warn",
    "drift",
    "imb",
)

# Signed packet fields, declaration order from SIGNING_CONTRACT.md.
CANONICAL_FIELDS = (
    "schema_version",
    "device_id",
    "seq",
    "timestamp_ms",
    "current_rms",
    "flow_rate",
    "temp_c",
    "pressure_kpa",
)


def counts_to_amps(rms_counts):
    """Irms = rms_counts * (ADC_VREF / ADC_MAX_COUNTS) * CT_AMPS_PER_VOLT."""
    vrms = rms_counts * (ADC_VREF / ADC_MAX_COUNTS)
    return vrms * CT_AMPS_PER_VOLT


def pulses_to_lpm(pulses, interval_ms):
    """liters / (dt_minutes). Zero interval returns 0, matching the firmware."""
    if interval_ms == 0:
        return 0.0
    liters = pulses / FLOW_PULSES_PER_LITER
    return liters / (interval_ms / 60000.0)


def volts_to_kpa(volts):
    """0.5 V = 0 kPa, 4.5 V = 1200 kPa. Out of the firmware window is None."""
    if volts < PRESS_V_MIN - 0.2 or volts > PRESS_V_MAX + 0.5:
        return None
    kpa = (volts - PRESS_V_MIN) / (PRESS_V_MAX - PRESS_V_MIN) * PRESS_KPA_MAX
    return 0.0 if kpa < 0 else kpa


def legacy_line(t_ms, amps, flow, press, temp, state, trip, warn, drift, imb):
    """One newline-terminated legacy telemetry object. Field names match the firmware."""
    body = {
        "t": t_ms,
        "i": [round(amps[0], 2), round(amps[1], 2), round(amps[2], 2)],
        "flow": round(flow, 1),
        "press": round(press, 1),
        "temp": round(temp, 1),
        "state": state,
        "trip": trip,
        "warn": list(warn),
        "drift": round(drift, 1),
        "imb": round(imb, 1),
    }
    return json.dumps(body, separators=(",", ":"))


def trip_alert(trip, t_ms):
    return json.dumps({"alert": "TRIP", "trip": trip, "t": t_ms}, separators=(",", ":"))


def canonical_packet(seq, timestamp_ms, current_rms, flow_rate, temp_c, pressure_kpa, device_id=DEVICE_ID_FIRMWARE):
    """Field order is the signed order. This does not sign the packet."""
    return {
        "schema_version": 1,
        "device_id": device_id,
        "seq": seq,
        "timestamp_ms": timestamp_ms,
        "current_rms": current_rms,
        "flow_rate": flow_rate,
        "temp_c": temp_c,
        "pressure_kpa": pressure_kpa,
    }
