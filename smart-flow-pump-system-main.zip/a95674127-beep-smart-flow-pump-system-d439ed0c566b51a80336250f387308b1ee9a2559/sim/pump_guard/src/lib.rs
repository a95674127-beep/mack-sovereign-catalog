//! Host model of `SafetyController::checkDryRun` in the ESP32 firmware.
//!
//! Constants match `firmware/esp32/config.h`. This crate does not flash a
//! board, drive a relay, or certify the pump. A passing test means the
//! sustain-and-latch rule behaves as written here.

pub const DRY_RUN_FLOW_LPM: f32 = 2.0;
pub const DRY_RUN_CURRENT_A: f32 = 1.0;
pub const DRY_RUN_TRIP_SECONDS: u32 = 10;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Trip {
    None,
    DryRun,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Phase {
    Running,
    Latched,
}

pub struct DryRunGuard {
    phase: Phase,
    since_ms: Option<u32>,
}

impl DryRunGuard {
    pub fn new() -> Self {
        Self {
            phase: Phase::Running,
            since_ms: None,
        }
    }

    pub fn tripped(&self) -> bool {
        self.phase == Phase::Latched
    }

    /// One evaluation, using the firmware predicate:
    /// flow below 2.0 L/min and current above 1.0 A, sustained for 10 seconds.
    /// A latched trip stays latched. Recovered flow resets the timer only
    /// before the latch.
    pub fn update(&mut self, current_a: f32, flow_lpm: f32, now_ms: u32) -> Trip {
        if self.phase == Phase::Latched {
            return Trip::DryRun;
        }
        let dry = flow_lpm < DRY_RUN_FLOW_LPM && current_a > DRY_RUN_CURRENT_A;
        if dry {
            let since = *self.since_ms.get_or_insert(now_ms);
            if now_ms.wrapping_sub(since) >= DRY_RUN_TRIP_SECONDS * 1000 {
                self.phase = Phase::Latched;
                self.since_ms = None;
                return Trip::DryRun;
            }
        } else {
            self.since_ms = None;
        }
        Trip::None
    }
}

impl Default for DryRunGuard {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn brief_dry_spell_does_not_trip() {
        let mut guard = DryRunGuard::new();
        assert_eq!(guard.update(1.8, 0.0, 0), Trip::None);
        assert_eq!(guard.update(1.8, 0.0, 9_999), Trip::None);
        assert!(!guard.tripped());
    }

    #[test]
    fn sustained_dry_run_latches_at_ten_seconds() {
        let mut guard = DryRunGuard::new();
        assert_eq!(guard.update(1.8, 0.0, 1_000), Trip::None);
        assert_eq!(guard.update(1.8, 0.0, 11_000), Trip::DryRun);
        assert_eq!(guard.update(1.8, 20.0, 12_000), Trip::DryRun);
        assert!(guard.tripped());
    }

    #[test]
    fn flow_returning_before_the_window_resets_the_timer() {
        let mut guard = DryRunGuard::new();
        assert_eq!(guard.update(1.8, 0.0, 0), Trip::None);
        assert_eq!(guard.update(1.8, 5.0, 9_000), Trip::None);
        assert_eq!(guard.update(1.8, 0.0, 10_000), Trip::None);
        assert_eq!(guard.update(1.8, 0.0, 19_999), Trip::None);
        assert!(!guard.tripped());
    }

    #[test]
    fn current_below_the_motor_threshold_is_not_a_dry_run() {
        let mut guard = DryRunGuard::new();
        assert_eq!(guard.update(1.0, 0.0, 0), Trip::None);
        assert_eq!(guard.update(1.0, 0.0, 60_000), Trip::None);
    }
}
