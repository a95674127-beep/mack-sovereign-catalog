# pump_guard

Host model of the dry-run rule in `firmware/esp32/safety.cpp`.

The firmware trips when flow stays below 2.0 L/min and current stays above 1.0 A for 10 seconds, then latches. These tests check that rule on the workstation. They do not flash an ESP32, close a relay, or certify a pump.

```sh
cargo test
```
