import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "gateway" / "raspberry_pi"))

import bench_map
import telemetry


def test_pin_map_matches_config_h():
    assert bench_map.PINS["CT1"]["gpio"] == 34
    assert bench_map.PINS["FLOW"]["gpio"] == 25
    assert bench_map.PINS["PRESSURE"]["gpio"] == 33
    assert bench_map.PINS["TEMP"]["gpio"] == 26
    assert bench_map.PINS["RELAY"]["gpio"] == 27
    assert bench_map.PINS["RELAY"]["engaged"] == "LOW"
    assert bench_map.PINS["RELAY"]["safe"] == "HIGH"
    assert bench_map.PINS["START"]["gpio"] == 14
    assert bench_map.PINS["RESET"]["gpio"] == 4
    assert bench_map.SERIAL_BAUD == 115200


def test_scales_match_firmware_formulas():
    # 0.25 V RMS on the SCT-013-030V is 7.5 A.
    assert abs(bench_map.counts_to_amps(0.25 / bench_map.ADC_VREF * bench_map.ADC_MAX_COUNTS) - 7.5) < 1e-6
    # 450 pulses in 1000 ms is 60 L/min.
    assert abs(bench_map.pulses_to_lpm(450, 1000) - 60.0) < 1e-9
    assert bench_map.pulses_to_lpm(10, 0) == 0.0
    assert abs(bench_map.volts_to_kpa(0.5) - 0.0) < 1e-9
    assert abs(bench_map.volts_to_kpa(4.5) - 1200.0) < 1e-6
    assert bench_map.volts_to_kpa(0.1) is None


def test_legacy_line_is_what_the_gateway_stores():
    raw = bench_map.legacy_line(35000, (7.5, 0.0, 0.0), 0.5, 300.0, 45.0, "RUNNING", "NONE", [], 0.0, -1.0)
    kind, obj = telemetry.parse_line(raw)
    assert kind == "reading"
    assert obj["i"][0] == 7.5
    assert obj["flow"] == 0.5
    assert list(obj) == list(bench_map.LEGACY_FIELDS)
    alert = bench_map.trip_alert("DRY_RUN", 35000)
    akind, aobj = telemetry.parse_line(alert)
    assert akind == "alert"
    assert aobj == {"alert": "TRIP", "trip": "DRY_RUN", "t": 35000}


def test_canonical_fields_follow_the_signing_contract():
    packet = bench_map.canonical_packet(42, 1784000001234, 7.5, 0.5, 45.0, 300.0)
    assert tuple(packet) == bench_map.CANONICAL_FIELDS
    encoded = json.dumps(packet, separators=(",", ":"))
    assert encoded.startswith('{"schema_version":1,"device_id":"pump-01"')
    assert "signature" not in encoded


def test_device_ids_match():
    assert bench_map.DEVICE_ID_FIRMWARE == bench_map.DEVICE_ID_GATEWAY_DEFAULT == "pump-01"


if __name__ == "__main__":
    test_pin_map_matches_config_h()
    test_scales_match_firmware_formulas()
    test_legacy_line_is_what_the_gateway_stores()
    test_canonical_fields_follow_the_signing_contract()
    test_device_ids_match()
    print("ok")
