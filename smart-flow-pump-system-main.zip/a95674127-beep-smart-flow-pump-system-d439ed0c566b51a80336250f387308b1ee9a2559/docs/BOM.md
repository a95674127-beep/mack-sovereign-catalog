# SF-ITES Bill of Materials

> Prices are **approximate street prices (2026)** for budgeting only —
> verify current prices before ordering. "Example" parts are suggestions,
> not endorsements. Size the relay/contactor to YOUR pump's nameplate amps.

## Edge controller (ESP32 side)

| Qty | Part | Example | ≈ USD |
|---|---|---|---|
| 1 | ESP32 dev board | ESP32-WROOM-32 DevKit v1 | 8–12 |
| 1 | CT current sensor, voltage-output | SCT-013-030V (30 A / 1 V) | 10–14 |
| 1 | Flow meter, hall-effect | YF-S201 (1–30 L/min) | 8–12 |
| 1 | Pressure transducer 0.5–4.5 V | 0–1.2 MPa sealed gauge type | 12–18 |
| 1 | Temperature probe, waterproof | DS18B20 stainless | 3–5 |
| 1 | Relay module (≤10 A pump) | 1-ch 5 V optoisolated, 10 A/250 VAC | 5–8 |
| — | **OR** contactor (>10 A pump) | 2-pole contactor rated ≥ pump FLA × 1.25, 120 V coil | 20–45 |
| 2 | Pushbuttons (START/RESET) | 12 mm momentary, normally-open | 2–4 |
| 1 | Piezo buzzer | 3–5 V active buzzer | 1–2 |
| 2 | Resistor 100 kΩ | CT bias divider | <1 |
| 1 | Resistor 4.7 kΩ | DS18B20 pull-up | <1 |
| 1 | Resistor 10 kΩ | CT series (optional) | <1 |
| 1 | Capacitor 10 nF | CT noise filter (optional) | <1 |
| 1 | 5 V supply, ≥1 A | USB supply or buck module | 5–10 |
| 1 | Enclosure, IP65 | 150×110×70 mm-ish, with cable glands | 10–18 |
| 1 | Fuse holder + fuse | per pump nameplate | 3–6 |
| — | Terminal blocks, hookup wire | — | 5–10 |

**Edge subtotal: ≈ $75–135** (contactor option at the high end)

## Gateway (Raspberry Pi side)

| Qty | Part | Example | ≈ USD |
|---|---|---|---|
| 1 | Raspberry Pi 3B+ (or Pi 4 / Zero 2 W) | — | 35–55 |
| 1 | microSD card, 32 GB, quality brand | SanDisk/Samsung Endurance | 8–12 |
| 1 | Pi power supply 5 V / 2.5–3 A | Official Raspberry Pi PSU | 8–12 |
| 1 | USB-A to micro-USB cable | ESP32 ↔ Pi serial link | 3–5 |

**Gateway subtotal: ≈ $55–85**

## System total: ≈ $130–220 per pump station

At small scale this is a parts-cost build, not a product cost — enclosure
labor, mains wiring, and calibration time are extra. The commercial case
rests on what it *prevents* (one burned 2 HP motor ≈ $400–900; one lost
irrigation day ≫ that), not on the parts being cheap.

## Sourcing notes

- Buy the **voltage-output** SCT-013 (`-030V`), not the current-output
  `-000` — no burden resistor to size, harder to get wrong.
- YF-S201 tops out around 30 L/min; for larger flows use a bigger
  hall-effect meter and change `FLOW_PULSES_PER_LITER`.
- If the pump is 3-phase, buy **three** CT sensors and set
  `CT_CHANNELS 3` — single CT cannot see phase imbalance, and the
  firmware says so instead of pretending.
