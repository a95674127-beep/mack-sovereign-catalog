# SF-ITES Bench Testing

> **Status: this procedure validates the firmware logic on the bench. It is
> NOT a substitute for testing on a real pump, and no real-pump test has
> been performed.** Do not connect to a live pump until bench tests pass.

## What you need (no pump required)

- ESP32 with firmware flashed, `TEST_MODE 0` initially
- USB cable + Arduino Serial Monitor @ 115200
- For sensor simulation: a 10 kΩ potentiometer, a jumper wire, and (for
  the full script) nothing else — `TEST_MODE 1` synthesizes everything

## Test 1 — Safe boot (the most important test)

1. Flash firmware. Disconnect everything except USB.
2. Power on. **Listen: the relay must NOT click closed.** (No relay
   connected yet — watch GPIO27 with a multimeter: it must read HIGH,
   the safe/de-energized level for an active-LOW module.)
3. Serial shows `{"boot":...}` then `SELFTEST`.
4. With no sensors, self-test should hold (sensors invalid) — the relay
   stays open. **Expected: pump circuit can never energize with dead
   sensors.** This is the core fail-safe claim; verify it first.

## Test 2 — Scripted fault scenario (TEST_MODE 1)

1. Set `#define TEST_MODE 1` in `config.h`, reflash.
2. Open Serial Monitor. Send `START`.
3. Watch the 1 Hz JSON lines and the script timeline (~90 s loop):
   - 0–25 s: `state: RUNNING`, plausible values
   - 25–40 s: flow collapses to 0.5 L/min, current stays ~7.5 A
   - **≈ 35 s: expect `{"alert":"TRIP","trip":"DRY_RUN"}`** and relay opens
   - State latches `TRIPPED`; further script phases do nothing (correct —
     latched means latched)
4. Send `RESET` → self-test → `STANDBY`. Send `START` to re-run.

**Pass criteria:** dry-run trips within 10–12 s of flow collapse, relay
opens, trip latches until RESET. If the overcurrent/overtemp phases never
get reached in one loop, that's fine — reset mid-script to test them:
send `RESET`, `START` at t≈45 s (overcurrent: expect `TRIP/OVERCURRENT`
immediately) and at t≈60 s (overtemp ramp: expect `TRIP/OVERTEMP`).

## Test 3 — Sensor-fault shutdown (TEST_MODE 0, real sensors)

1. Wire the real sensors per `WIRING.md`. Boot, `START`.
2. Unplug the DS18B20 mid-run.
3. **Expected:** within ~5 s, `TRIP/SENSOR_FAULT`, relay opens, latched.
   The pump must not run blind on a dead sensor.
4. Repeat by shorting the pressure input to GND (implausible 0 V reading).

## Test 4 — Manual button paths

- Press START button in STANDBY → RUNNING (relay closes).
- Press RESET button in TRIPPED → SELFTEST → STANDBY.
- START pressed with a sensor unplugged → refused, stays STANDBY.

## Test 5 — Watchdog

Temporarily add `while(1){}` in `loop()` (then remove it!). Within 10 s
the ESP32 resets; on reboot the relay pin is driven safe before anything
else. **Expected: relay never energized across the reset.**

## Test 6 — Gateway (no ESP32 needed)

```bash
cd gateway/raspberry_pi
python3 telemetry.py --once     # parser self-test, no serial needed
python3 dashboard.py            # open http://localhost:8080/
python3 sync.py                 # expect "endpoint not configured (stub)"
```

Feed it a recorded serial log later by piping lines into stdin of a small
shim — left as an exercise; the `--once` path proves the parse/store path.

## Expected-response cheat sheet

| Stimulus | Expected response | Max time |
|---|---|---|
| Boot / reset / watchdog | Relay open, SELFTEST | immediate |
| Dry-run (flow→0, current stays) | TRIP/DRY_RUN, latched | 10–12 s |
| Current > 1.5× rated | TRIP/OVERCURRENT | < 2 s |
| Temp ≥ 85 °C | TRIP/OVERTEMP | < 2 s |
| Any sensor NaN/implausible ×5 | TRIP/SENSOR_FAULT | ~5 s |
| Current+flow collapse vs baseline | TRIP/CAVITATION | < 5 s (after baselines ready) |
| Phase imbalance > 15 % (3-ph) | TRIP/PHASE_IMBALANCE | < 2 s |
| RESET in TRIPPED | SELFTEST → STANDBY | < 3 s |
| START in STANDBY, sensors bad | Refused, stays STANDBY | immediate |

## What bench testing does NOT prove

- Real CT accuracy (calibrate against a clamp meter on the actual pump)
- Real flow/pressure calibration (verify against known references)
- Relay/contactor behavior under actual motor load and inrush
- Long-term baseline drift detection (needs days of real runtime)
- Enclosure thermal behavior, EMI, lightning/surge immunity

All of the above require the real installation. Bench tests prove the
**logic**; field commissioning proves the **system**.
