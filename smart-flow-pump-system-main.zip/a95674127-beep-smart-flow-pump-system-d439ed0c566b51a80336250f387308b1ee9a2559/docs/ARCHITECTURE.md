# SF-ITES System Architecture

## Block diagram

```
                        ┌─────────────────────────────────────────┐
                        │              PUMP (120/240 VAC)          │
                        └───────────────┬─────────────────────────┘
                                        │ hot conductor
                        ┌───────────────▼─────────────────────────┐
                        │  RELAY — normally-open contact in series │
                        │  coil de-energized  ==>  pump OFF        │
                        └───────────────▲─────────────────────────┘
                                        │ GPIO27 (active-LOW module)
┌──────────────┐   ┌────────────────────┴────────────────────────┐
│ CT sensor(s) │──▶│                   ESP32                      │
│ (non-invas.) │   │  ┌────────────┐  ┌────────────────────────┐  │
└──────────────┘   │  │  anomaly   │  │  safety controller     │  │
┌──────────────┐   │  │  baselines │─▶│  ST_SELFTEST/STANDBY/  │──┼── relay
│ YF-S201 flow │──▶│  │  (advisory)│  │  RUNNING/TRIPPED       │  │
│ (pulse ISR)  │   │  └────────────┘  └────────────────────────┘  │
└──────────────┘   │         │ 1 Hz JSON over USB serial          │
┌──────────────┐   └─────────┼────────────────────────────────────┘
│ pressure     │──▶──────────┘
│ 0.5–4.5 V    │
└──────────────┘
┌──────────────┐
│ DS18B20 temp │──▶ (1-Wire; NAN on disconnect => sensor fault)
└──────────────┘
                              │
                              ▼ USB serial, 115200 baud, newline JSON
                  ┌───────────────────────┐
                  │    Raspberry Pi 3     │
                  │  telemetry.py ──▶ SQLite (readings, alerts)  │
                  │  sync.py ──▶ Fernet-encrypted batches ──▶ cloud (stub) │
                  │  dashboard.py ──▶ http://pi:8080 (live status)       │
                  └───────────────────────┘
```

## Data flow

1. **Sense (ESP32, 1 Hz):** CT RMS current, flow pulses → L/min, pressure
   voltage → kPa, DS18B20 → °C. Every reading plausibility-checked.
2. **Learn (ESP32):** while RUNNING, current/flow feed dual-EMA baselines
   (fast ~1 h, slow ~7 d). Baselines never learn while idle.
3. **Decide (ESP32 safety controller):** state machine
   `SELFTEST → STANDBY → RUNNING ⇄ TRIPPED` (latched). Evaluates
   sensor-fault → overtemp → overcurrent (inrush-aware) → cavitation →
   dry-run (sustained) → phase imbalance. First fault wins and latches.
4. **Act (ESP32):** trip ⇒ relay coil de-energized immediately, buzzer on,
   alert line emitted. Manual RESET re-runs self-test; START re-engages.
5. **Report (serial):** 1 Hz JSON telemetry line + event lines on state
   transitions and trips.
6. **Store (Pi):** `telemetry.py` validates and appends to SQLite. TRIP
   alerts commit immediately (power-cut safe).
7. **Sync (Pi):** `sync.py` encrypts unsent rows (Fernet) and POSTs batches
   when a real endpoint is configured; otherwise buffers indefinitely.
8. **View (Pi):** `dashboard.py` serves live readings, alert history, and a
   derived health badge on the LAN.

## Component responsibilities

| Component | Owns | Does NOT own |
|---|---|---|
| `anomaly.*` | Baselines, drift/cavitation/imbalance math | Tripping (advisory only) |
| `safety.*` | Relay, states, trip evaluation & latching | Sensor drivers |
| `sf_ites_main.ino` | Sensor drivers, serial protocol, watchdog, UI (LED/buttons) | Threshold policy (in `config.h`) |
| `telemetry.py` | Ingest, validation, durable local storage | Uploading |
| `sync.py` | Encryption, batching, retry | Deciding what is "sent" (server ack does) |
| `dashboard.py` | Read-only presentation | Control (no relay commands from web) |

Note the deliberate one-way control flow: the dashboard can never energize
the relay. Pump control lives only on the ESP32, via its buttons or its
USB serial console.

## Failure modes and handling

| Failure | Detection | Response |
|---|---|---|
| Dry run (flow lost, motor turning) | flow < 2 L/min while I > 1 A, sustained 10 s | Trip DRY_RUN, relay opens, latched |
| Overcurrent (jam/stall) | I > 1.5× rated (4× allowed for 5 s at startup) | Trip OVERCURRENT, latched |
| Overtemperature | temp ≥ 85 °C | Trip OVERTEMP immediately, latched |
| Cavitation | current AND flow collapse vs baseline | Trip CAVITATION, latched |
| Phase imbalance (3-ph) | (max−min)/mean > 15 % | Trip PHASE_IMBALANCE, latched |
| Any sensor dead/implausible | NaN / out-of-range, 5 consecutive | Trip SENSOR_FAULT — never runs blind |
| Firmware hang | Task watchdog 10 s | ESP32 resets; `begin()` leaves relay open |
| Power loss | — | Relay coil de-energizes; NO contact opens |
| Relay contact welded shut | **NOT detectable in software** | Documented limitation — see WIRING.md for aux-contact option |
| Serial link to Pi down | Pi-side reconnect loop | ESP32 keeps protecting autonomously; Pi backfills on reconnect |
| Pi SD card / power loss | — | ESP32 unaffected (protection is local); TRIP alerts committed synchronously |
| Cloud unreachable | sync.py retry w/ backoff | Rows buffer in SQLite indefinitely |

## Design decisions (and alternatives rejected)

- **Protection lives on the ESP32, not the Pi.** The Pi is a logger and
  display. If the Pi crashes, the pump is still protected. Rejected: doing
  trip logic in Python (adds OS, SD card, and USB-serial latency to a
  safety function).
- **Relay in series, normally-open, ESP32 must actively hold it closed.**
  Rejected: relay that the ESP32 only opens on fault (a crashed ESP32 would
  leave the pump running forever).
- **Latched trips, manual reset.** Rejected: auto-restart after a trip
  (cycling a dry-running pump destroys it faster; a human should look).
- **Baselines learn only while running.** Rejected: continuous learning
  (standby zeros would drag baselines down and desensitize detection).
- **JSON lines, not a binary protocol.** Debuggable with any serial
  monitor; the 1 Hz rate makes the overhead irrelevant.
- **stdlib-only dashboard.** No Flask to install/maintain on the Pi.
