# SF-ITES Wiring Guide

> **Mains wiring can kill you and burn your building down.** The relay
> contact sits in series with the pump's mains supply. If you are not
> qualified to work on mains voltage, have an electrician do the
> high-voltage side. The low-voltage (ESP32/sensor) side is safe to DIY.

## ESP32 pin map (DevKit v1)

| ESP32 pin | Signal | Wire to | Notes |
|---|---|---|---|
| GPIO34 | CT1 analog | CT sensor output (via bias divider) | ADC1, input-only — fine |
| GPIO35 | CT2 analog | 2nd CT (3-phase only, optional) | leave unconnected if unused |
| GPIO32 | CT3 analog | 3rd CT (3-phase only, optional) | leave unconnected if unused |
| GPIO25 | FLOW pulse | YF-S201 yellow (signal) | interrupt pin |
| GPIO33 | PRESSURE analog | Transducer signal (0.5–4.5 V) | direct — already in range |
| GPIO26 | TEMP 1-Wire | DS18B20 data | 4.7 kΩ pull-up to 3V3 |
| GPIO27 | RELAY drive | Relay module IN | active-LOW module assumed |
| GPIO14 | START button | Pushbutton to GND | internal pull-up, active-LOW |
| GPIO4  | RESET button | Pushbutton to GND | internal pull-up, active-LOW |
| GPIO2  | STATUS LED | Onboard LED | — |
| GPIO13 | BUZZER | Piezo + to GPIO13, − to GND | active-HIGH |
| 3V3 | Sensor power | DS18B20 VDD, divider top | — |
| 5V | Flow meter power | YF-S201 red (+5 V) | YF-S201 needs 5 V |
| GND | Common ground | All sensor GNDs, relay GND | single star point |

## CT sensor (SCT-013-030V — voltage-output type)

The `-030V` variant outputs 0–1 VAC for 0–30 A and needs **no burden
resistor** — simpler and safer than the current-output `-000` variant.

The output is AC centered on 0 V, but the ESP32 ADC only reads 0–3.3 V,
so bias it to mid-rail:

```
3V3 ----[ 100k ]----+----[ 100k ]---- GND
                    |
              CT output (either lead)
                    |
                    +----> GPIO34 (through a 10k series resistor is fine)
              CT other lead ----> GND-side of divider (the midpoint node)
```

In practice: connect one CT lead to the divider midpoint, the other lead
to the same midpoint? No — correct hookup: CT leads go across the ADC
input: one lead to GPIO34, the other to the 1.65 V midpoint. Add a 10 nF
capacitor from GPIO34 to GND to shave noise. Clamp the CT around **one**
conductor of the pump supply (not both — they cancel).

Calibrate `CT_AMPS_PER_VOLT` in `config.h` against a clamp meter.

## Flow meter (YF-S201)

- Red → 5V, Black → GND, Yellow → GPIO25.
- Install in-line on the discharge side with flow arrow matching direction.
- The pulse output is open-collector; the ESP32's internal pull-up
  (`INPUT_PULLUP`) handles it.

## Pressure transducer (0.5–4.5 V type)

- Power per its datasheet (usually 5 V), signal → GPIO33, GND → GND.
- 0.5 V = 0 kPa, 4.5 V = full scale. Set `PRESS_KPA_MAX` in `config.h`
  to your transducer's range.
- Mount on the discharge line via a proper pressure-rated fitting.

## Temperature (DS18B20, waterproof)

- Red → 3V3, Black → GND, Data → GPIO26 with 4.7 kΩ pull-up to 3V3.
- Strap/clamp the probe to the motor casing with thermal paste for
  honest readings. Air-dangling reads room temperature, not the motor.

## Relay — the safety-critical part

1. **Size it:** relay/contactor contacts must exceed the pump's full-load
   amps with margin. A 10 A relay module is fine for small 120 V pumps;
   above that, use the module to drive a **contactor** rated for the motor.
2. **Wire the NORMALLY-OPEN contact in series** with the pump's hot
   conductor, downstream of the existing breaker/switch. Coil
   de-energized ⇒ contacts open ⇒ pump cannot run. Ever.
3. **Flyback diode:** relay *modules* include one. If you drive a bare
   relay or contactor coil from a transistor, put a 1N4007 diode
   reverse-biased across the coil (cathode to +). Without it, coil
   collapse spikes will eventually kill the ESP32 pin.
4. **Optoisolation:** keep the module's JD-VCC jumper as shipped unless
   you know why you're changing it; common ground between ESP32 and
   relay input side is required for the control signal.
5. **Fuse:** fuse the pump circuit per its nameplate, upstream of everything.
6. **Aux-contact option (recommended for critical installs):** if your
   contactor has an auxiliary NC/NO contact, wire it to a spare GPIO.
   Firmware can then *verify* the contacts actually opened on trip —
   this closes the one failure mode software alone cannot see
   (welded contacts). Not implemented in v1 firmware; wiring noted here
   for v2.

## Power supplies

- ESP32: 5 V USB supply (or buck converter), ≥ 1 A.
- Pi 3: official 5 V / 2.5 A supply. Undersized Pi supplies cause SD
  corruption — do not cheap out here.
- Keep mains and low-voltage wiring physically separated in the enclosure.
