# Key Management for SF-ITES Packet Signing

How to generate, provision, store, rotate, and (if necessary) revoke the
Ed25519 keys that sign telemetry packets. Read `SIGNING_CONTRACT.md` first
for the byte-level signing spec.

## Key generation (offline, trusted machine)

Generate each device's keypair on a machine that never touches the network
with the keys present. Any Ed25519 implementation works; the private key is
a 32-byte seed.

Using Python (no extra packages):
```python
import os
seed = os.urandom(32)
print("SIGNING_KEY_SEED { " + ",".join(f"0x{b:02x}" for b in seed) + " }")
# Derive the public key with any Ed25519 lib and record it:
#   pubkey hex -> register with the telemetry ingestor for this device_id
```

Using OpenSSL:
```bash
openssl genpkey -algorithm ed25519 -out device.key
openssl pkey -in device.key -pubout -outform DER | tail -c 32 | xxd -p -c 32
# (private seed extraction from PEM is fiddly; Python is easier)
```

**Record for each device:** `device_id` → 32-byte public key (hex). The
ingestor's `register_key(device_id, pubkey)` is what ties signatures to
devices. Lose this mapping and you can't tell which key signed what.

## Storage options (tradeoffs, honestly)

| Option | Security | Complexity | Notes |
|---|---|---|---|
| Compile-time `SIGNING_KEY_SEED` in `config.h` | Low | Trivial | Key in flash plaintext; anyone with physical access + a USB cable reads it. Fine for bench/pilot only. **Never commit a real key to git.** |
| ESP32 NVS with flash encryption | Medium | Moderate | Requires enabling flash encryption in eFuse (one-way; get it right the first time). Key at rest is encrypted; still in RAM at runtime. |
| ATECC608A secure element (I2C) | High | Higher | ~$1.50 part. Private key never leaves the chip; the ESP32 asks it to sign. Needs the `SparkFun_ATECCX8a` Arduino library and wiring (see BOM). This is the right answer for production. |

**Threat model if the private key is extracted:** an attacker can forge
telemetry that verifies correctly — fake "all normal" packets while the
pump runs dry, for example. Mitigations, in depth:

1. **Anomaly detection on the receiving end.** Forged "normal" data that
   contradicts physics (current draw vs flow vs pressure relationships) is
   flagged by the same baselines the firmware runs. A forger must forge
   *self-consistent* physics, which is much harder than replaying "OK".
2. **Ledger tamper-evidence.** The ingestor hash-chains every packet. Forged
   packets inserted *later* can't rewrite history; gaps and seq jumps are
   visible.
3. **Independent sensing.** The safety-critical cutoff lives on the ESP32
   itself (local sensors, local relay). Forged telemetry cannot *cause* a
   pump to run unsafely — it can only lie about what happened, and the
   local safety controller doesn't trust the network for trip decisions.
4. **Key rotation** (below) bounds the blast radius in time.

What key extraction does NOT give an attacker: control of the pump. The
signing key is authentication for *telemetry*, not authorization for
*actuation*. There is no remote actuation path.

## Provisioning a device

1. Generate the keypair offline. Record `device_id` → public key.
2. Register the public key with the ingestor: `ingestor.register_key("pump-01", pubkey_bytes)`.
3. Get the 32-byte seed onto the device via ONE of:
   - Flash it into `SIGNING_KEY_SEED` for a pilot build (then `git` must never see it — keep provisioning builds out of version control), or
   - Write it to encrypted NVS via a one-time provisioning sketch, or
   - Generate it *on* the ATECC608A (private key never exists outside the chip; export only the public key).
4. Boot the device. Expected serial output:
   ```
   {"boot":"SF-ITES edge firmware v1.0"}
   ```
   (no signing warnings = key provisioned, self-test passed)
   
   If you see `{"warn":"SIGNING_ENABLED=1 but no key provisioned;..."}`, the
   seed is still all zeros — packets go out with `"unsigned":true`.
5. Verify the first signed packets verify on the ingestor before deploying.

## Key rotation

1. Generate a new keypair offline.
2. Register the new public key with the ingestor *alongside* the old one
   (the ingestor supports key versioning per device — check your build).
3. Provision the new seed to the device (same channel as initial provisioning).
4. Reboot. Confirm signed packets verify with the new key.
5. After a grace period (e.g., 2× the max expected packet delay), deregister
   the old public key. Packets signed with it will then be rejected.

If the ingestor build does NOT support concurrent keys: schedule a
maintenance window. Stop the pump, rotate, reboot, verify, restart. The
safety controller does not depend on signing, so this is safe.

## Emergency revocation (suspected compromise)

1. Deregister the device's public key on the ingestor immediately. All
   packets from that device (signed or not) are then rejected per policy.
2. The pump itself keeps running safely — local safety logic never depended
   on the network or the signing key.
3. Investigate: compare the device's local logs (if any) against ingested
   telemetry for the compromise window. Seq gaps and hash-chain breaks mark
   where forged packets were inserted or real ones suppressed.
4. Re-provision with a fresh keypair (new `device_id` suffix, e.g.
   `pump-01b`, is cleaner than reusing the ID — it keeps the audit trail
   unambiguous about which key era a packet belongs to).

## What the firmware does NOT do

- It does not encrypt telemetry (signing ≠ encryption). The Pi gateway's
  encrypted cloud sync handles confidentiality.
- It does not authenticate the gateway or ingestor to the device. The trust
  direction is device → ingestor only.
- It does not protect the seed in RAM. Anyone who dumps RAM gets the key.
  The ATECC608A option exists precisely for this.
