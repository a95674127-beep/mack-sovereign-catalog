//! SF-ITES reference crypto module — ChaCha20Poly1305 AEAD.
//!
//! Fixed 2026-10-09: Result-based API (no panics on attacker-controlled
//! input), no deprecated `GenericArray::from_slice`, `OsRng` actually used.
//!
//! Two APIs:
//!   * `encrypt_det` / `decrypt_det` — caller supplies the nonce.
//!     DANGEROUS if misused: never reuse a (key, nonce) pair under the
//!     same key. Reuse enables full plaintext recovery.
//!   * `encrypt` / `decrypt` — misuse-resistant. A random 96-bit nonce is
//!     generated per message and prepended: wire format is
//!     `[ nonce (12 B) || ciphertext || tag (16 B) ]`.
//!
//! NOTE: 96-bit random nonces hit the birthday bound around 2^32 messages
//! under one key. For high-volume use, prefer XChaCha20Poly1305 (192-bit
//! nonce).
//!
//! Dependencies (add to Cargo.toml):
//!   chacha20poly1305 = "0.10"   # or 0.11
//!   rand = "0.8"
//!   thiserror = "1"

use chacha20poly1305::{
    aead::{Aead, KeyInit},
    ChaCha20Poly1305, Key, Nonce,
};
use rand::{rngs::OsRng, RngCore};

#[derive(Debug, thiserror::Error)]
pub enum CryptoError {
    #[error("decryption failed - wrong key or tampered data")]
    Decrypt,
    #[error("invalid key/nonce length")]
    InvalidLength,
    #[error("encryption failed")]
    Encrypt,
}

// --- Low-level: caller supplies nonce ---
// SAFETY NOTE: Never reuse a (key, nonce) pair. Reuse = full plaintext recovery.

pub fn encrypt_det(
    key_bytes: &[u8; 32],
    nonce_bytes: &[u8; 12],
    plaintext: &[u8],
) -> Result<Vec<u8>, CryptoError> {
    // GenericArray::from_slice is deprecated — From<[u8; N]> is the replacement.
    let key = Key::from(*key_bytes);
    let nonce = Nonce::from(*nonce_bytes);
    let cipher = ChaCha20Poly1305::new(&key);
    cipher.encrypt(&nonce, plaintext).map_err(|_| CryptoError::Encrypt)
}

pub fn decrypt_det(
    key_bytes: &[u8; 32],
    nonce_bytes: &[u8; 12],
    ciphertext: &[u8],
) -> Result<Vec<u8>, CryptoError> {
    let key = Key::from(*key_bytes);
    let nonce = Nonce::from(*nonce_bytes);
    let cipher = ChaCha20Poly1305::new(&key);
    // No .expect() — decryption failure is normal control flow, not a panic.
    cipher.decrypt(&nonce, ciphertext).map_err(|_| CryptoError::Decrypt)
}

// --- High-level: misuse-resistant, random nonce per message ---

pub fn encrypt(key_bytes: &[u8; 32], plaintext: &[u8]) -> Result<Vec<u8>, CryptoError> {
    let mut nonce_bytes = [0u8; 12];
    OsRng.fill_bytes(&mut nonce_bytes);

    let ciphertext = encrypt_det(key_bytes, &nonce_bytes, plaintext)?;
    // wire format: [ nonce || ciphertext+tag ]
    let mut out = Vec::with_capacity(12 + ciphertext.len());
    out.extend_from_slice(&nonce_bytes);
    out.extend_from_slice(&ciphertext);
    Ok(out)
}

pub fn decrypt(key_bytes: &[u8; 32], blob: &[u8]) -> Result<Vec<u8>, CryptoError> {
    // 12-byte nonce + minimum 16-byte Poly1305 tag.
    if blob.len() < 12 + 16 {
        return Err(CryptoError::InvalidLength);
    }
    let (nonce_bytes, ct) = blob.split_at(12);
    let nonce_arr: [u8; 12] = nonce_bytes
        .try_into()
        .map_err(|_| CryptoError::InvalidLength)?;
    decrypt_det(key_bytes, &nonce_arr, ct)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_high_level() {
        let key = [0x42u8; 32];
        let pt = b"SF-ITES telemetry";
        let blob = encrypt(&key, pt).expect("encrypt");
        // Nonce is random: two encryptions of the same plaintext differ.
        let blob2 = encrypt(&key, pt).expect("encrypt");
        assert_ne!(blob, blob2);
        let rt = decrypt(&key, &blob).expect("decrypt");
        assert_eq!(rt, pt);
    }

    #[test]
    fn roundtrip_deterministic() {
        let key = [0x42u8; 32];
        let nonce = [0x07u8; 12];
        let pt = b"deterministic";
        let ct = encrypt_det(&key, &nonce, pt).expect("encrypt_det");
        let rt = decrypt_det(&key, &nonce, &ct).expect("decrypt_det");
        assert_eq!(rt, pt);
    }

    #[test]
    fn tampered_ciphertext_fails_cleanly() {
        let key = [0x42u8; 32];
        let blob = encrypt(&key, b"secret").expect("encrypt");
        let mut bad = blob.clone();
        let last = bad.len() - 1;
        bad[last] ^= 0xff; // flip a tag bit
        let err = decrypt(&key, &bad).unwrap_err();
        assert!(matches!(err, CryptoError::Decrypt));
    }

    #[test]
    fn short_blob_rejected() {
        let key = [0x42u8; 32];
        let err = decrypt(&key, b"too short").unwrap_err();
        assert!(matches!(err, CryptoError::InvalidLength));
    }

    #[test]
    fn wrong_key_fails_cleanly() {
        let key = [0x42u8; 32];
        let wrong = [0x99u8; 32];
        let blob = encrypt(&key, b"secret").expect("encrypt");
        let err = decrypt(&wrong, &blob).unwrap_err();
        assert!(matches!(err, CryptoError::Decrypt));
    }
}
