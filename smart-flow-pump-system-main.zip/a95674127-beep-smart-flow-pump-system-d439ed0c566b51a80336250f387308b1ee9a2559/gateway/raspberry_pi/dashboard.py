#!/usr/bin/env python3
"""
dashboard.py — SF-ITES local status dashboard (runs on the Raspberry Pi).

Zero-dependency web UI (stdlib http.server only): shows the latest pump
readings, current safety state, recent alerts, and a derived pump-health
summary. Auto-refreshes every 5 seconds.

Run:  python3 dashboard.py
Then: open http://<pi-ip>:8080/ in a browser.

Endpoints:
  /            HTML status page
  /api/latest  JSON: most recent reading row
  /api/alerts  JSON: last 20 alerts (newest first)
"""
import datetime
import html
import json
import sqlite3
from http.server import BaseHTTPRequestHandler, HTTPServer

import config


def db():
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def latest_reading():
    with db() as conn:
        return conn.execute(
            "SELECT * FROM readings ORDER BY id DESC LIMIT 1"
        ).fetchone()


def recent_alerts(limit=20):
    with db() as conn:
        return conn.execute(
            "SELECT * FROM alerts ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()


def unsynced_count():
    with db() as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM readings WHERE synced = 0"
        ).fetchone()[0]


def health_of(row):
    """Derive a plain-language health summary from the latest row."""
    if row is None:
        return ("UNKNOWN", "No telemetry received yet.")
    state = row["state"] or "?"
    trip = row["trip"] or "NONE"
    if state == "TRIPPED":
        return ("TRIPPED", f"Pump shut down — latched trip: {trip}. "
                           "Investigate, then RESET from the ESP32.")
    if state == "RUNNING":
        warns = json.loads(row["warnings"] or "[]")
        if warns:
            return ("WARNING", "Running with advisories: " + ", ".join(warns))
        return ("OK", "Running normally. All sensors in range.")
    if state == "STANDBY":
        return ("IDLE", "Healthy, waiting for START.")
    if state == "SELFTEST":
        return ("CHECK", "Running sensor self-test…")
    return ("UNKNOWN", f"Unexpected state: {state}")


def fmt_ts(ts):
    if not ts:
        return "—"
    return datetime.datetime.fromtimestamp(ts).strftime("%H:%M:%S")


PAGE = """<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta http-equiv="refresh" content="5">
<title>SF-ITES Pump Monitor</title>
<style>
body{{font-family:system-ui,sans-serif;max-width:720px;margin:2em auto;padding:0 1em;color:#222}}
.badge{{display:inline-block;padding:.3em .8em;border-radius:1em;color:#fff;font-weight:bold}}
.OK{{background:#2a7}} .WARNING{{background:#d90}} .TRIPPED{{background:#c22}}
.IDLE,.CHECK,.UNKNOWN{{background:#666}}
table{{border-collapse:collapse;width:100%;margin:1em 0}}
td,th{{border:1px solid #ccc;padding:.4em .6em;text-align:left}}
th{{background:#f4f4f4}}
.alert{{background:#fee;border-left:4px solid #c22;padding:.4em .8em;margin:.4em 0}}
small{{color:#666}}
</style></head>
<body>
<h1>SF-ITES Pump Monitor</h1>
<p><small>Device {device} · auto-refresh 5 s · {now}</small></p>
<h2>Health: <span class="badge {hclass}">{health}</span></h2>
<p>{detail}</p>
<h2>Live readings</h2>
<table>
<tr><th>Current</th><td>{current} A</td></tr>
<tr><th>Flow</th><td>{flow} L/min</td></tr>
<tr><th>Pressure</th><td>{press} kPa</td></tr>
<tr><th>Motor temp</th><td>{temp} °C</td></tr>
<tr><th>Controller state</th><td>{state}</td></tr>
<tr><th>Last update</th><td>{ts}</td></tr>
<tr><th>Unsynced rows</th><td>{unsynced}</td></tr>
</table>
<h2>Recent alerts</h2>
{alerts}
</body></html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass  # quiet

    def _send(self, body: bytes, ctype="text/html"):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/api/latest":
            row = latest_reading()
            self._send(json.dumps(dict(row) if row else {}).encode(),
                       "application/json")
        elif self.path == "/api/alerts":
            rows = [dict(r) for r in recent_alerts()]
            self._send(json.dumps(rows).encode(), "application/json")
        else:
            row = latest_reading()
            health, detail = health_of(row)
            alerts = recent_alerts()
            if alerts:
                alert_html = "".join(
                    f'<div class="alert"><b>{html.escape(a["kind"])}</b> '
                    f'<small>{fmt_ts(a["ts"])}</small><br>'
                    f'<small>{html.escape(a["detail"][:200])}</small></div>'
                    for a in alerts
                )
            else:
                alert_html = "<p><small>No alerts recorded.</small></p>"
            body = PAGE.format(
                device=html.escape(config.DEVICE_ID),
                now=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                hclass=health, health=health, detail=html.escape(detail),
                current=f'{row["current_a"]:.2f}' if row else "—",
                flow=f'{row["flow_lpm"]:.1f}' if row else "—",
                press=f'{row["pressure_kpa"]:.0f}' if row else "—",
                temp=f'{row["temp_c"]:.1f}' if row else "—",
                state=html.escape(row["state"]) if row and row["state"] else "—",
                ts=fmt_ts(row["ts"]) if row else "—",
                unsynced=unsynced_count(),
                alerts=alert_html,
            )
            self._send(body.encode())


if __name__ == "__main__":
    srv = HTTPServer((config.DASHBOARD_HOST, config.DASHBOARD_PORT), Handler)
    print(f"Dashboard: http://{config.DASHBOARD_HOST}:{config.DASHBOARD_PORT}/")
    srv.serve_forever()
