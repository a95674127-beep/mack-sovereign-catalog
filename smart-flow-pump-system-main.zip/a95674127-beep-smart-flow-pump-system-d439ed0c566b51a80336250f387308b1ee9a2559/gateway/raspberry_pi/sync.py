#!/usr/bin/env python3
"""
sync.py — SF-ITES encrypted cloud sync (runs on the Raspberry Pi).

Uploads unsent telemetry rows to the cloud endpoint in encrypted batches.
Design principles:

  * Local-first: every reading is already safe in SQLite before sync runs.
    Sync failures never lose data; rows stay queued until acknowledged.
  * Encrypted in flight: the batch payload is Fernet-encrypted
    (AES-128-CBC + HMAC) with a key from SF_ITES_FERNET_KEY. The server
    never sees plaintext telemetry.
  * Stub endpoint: CLOUD_ENDPOINT defaults to https://example.com/api/v1,
    which is NOT a real server. With the stub configured, sync.py logs
    "endpoint not configured" and keeps buffering — it will NOT attempt
    network I/O to a placeholder. Set a real endpoint + token to enable.

Run:  python3 sync.py            (one sync pass, then exit — call from cron)
      python3 sync.py --gen-key  (print a new Fernet key for .env setup)
      python3 sync.py --daemon   (loop forever every SYNC_INTERVAL_S)
"""
import base64
import json
import os
import sqlite3
import sys
import time
import urllib.request
import urllib.error

import config

try:
    from cryptography.fernet import Fernet, InvalidToken
except ImportError:
    Fernet = None

STUB_MARKER = "example.com"


def gen_key():
    if Fernet is None:
        print("cryptography not installed: pip install -r requirements.txt")
        sys.exit(2)
    print(Fernet.generate_key().decode())


def fetch_unsent(conn, limit):
    rows = conn.execute(
        """SELECT id, ts, current_a, flow_lpm, pressure_kpa, temp_c,
                  state, trip, warnings, drift_pct, imbalance_pct
           FROM readings WHERE synced = 0 ORDER BY id LIMIT ?""",
        (limit,),
    ).fetchall()
    cols = ["id", "ts", "current_a", "flow_lpm", "pressure_kpa", "temp_c",
            "state", "trip", "warnings", "drift_pct", "imbalance_pct"]
    return [dict(zip(cols, r)) for r in rows]


def build_payload(batch):
    return {
        "device_id": config.DEVICE_ID,
        "sent_at": time.time(),
        "batch": batch,
    }


def encrypt_payload(payload: dict, key_b64: str) -> bytes:
    f = Fernet(key_b64.encode())
    return f.encrypt(json.dumps(payload).encode())


def post_batch(ciphertext: bytes) -> int:
    """POST one encrypted batch. Returns accepted count, raises on failure."""
    url = config.CLOUD_ENDPOINT.rstrip("/") + "/telemetry"
    req = urllib.request.Request(
        url,
        data=ciphertext,
        headers={
            "Authorization": f"Bearer {config.API_TOKEN}",
            "Content-Type": "application/octet-stream",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=config.REQUEST_TIMEOUT_S) as resp:
        body = json.loads(resp.read().decode())
        return int(body.get("accepted", 0))


def sync_once() -> str:
    if STUB_MARKER in config.CLOUD_ENDPOINT:
        return "endpoint not configured (stub) — buffering locally"
    if Fernet is None:
        return "cryptography lib missing — cannot encrypt; buffering locally"
    if not config.FERNET_KEY:
        return "SF_ITES_FERNET_KEY not set — cannot encrypt; buffering locally"
    if not config.API_TOKEN:
        return "SF_ITES_TOKEN not set — buffering locally"

    conn = sqlite3.connect(config.DB_PATH)
    try:
        batch = fetch_unsent(conn, config.SYNC_BATCH_SIZE)
        if not batch:
            return "nothing to sync"
        payload = build_payload(batch)
        ciphertext = encrypt_payload(payload, config.FERNET_KEY)
        try:
            accepted = post_batch(ciphertext)
        except (urllib.error.URLError, OSError) as e:
            return f"upload failed ({e}) — will retry next pass"
        ids = [r["id"] for r in batch[:accepted]]
        if ids:
            conn.execute(
                f"UPDATE readings SET synced = 1 WHERE id IN ({','.join('?' * len(ids))})",
                ids,
            )
            conn.commit()
        return f"uploaded {accepted}/{len(batch)} rows"
    finally:
        conn.close()


def main():
    if "--gen-key" in sys.argv:
        gen_key()
        return
    if "--daemon" in sys.argv:
        while True:
            print(f"[{time.strftime('%H:%M:%S')}] {sync_once()}", flush=True)
            time.sleep(config.SYNC_INTERVAL_S)
    else:
        print(sync_once())


if __name__ == "__main__":
    main()
