"""
SF-ITES gateway shared configuration.

Copy nothing, edit in place. Secrets (API token, Fernet key) come from
environment variables, never from this file.
"""
import os

# --- Serial link to the ESP32 -------------------------------------------------
SERIAL_PORT = os.environ.get("SF_ITES_SERIAL", "/dev/ttyUSB0")
BAUD_RATE = 115200

# --- Local storage ------------------------------------------------------------
DB_PATH = os.environ.get("SF_ITES_DB", "/home/pi/sf-ites/telemetry.db")

# --- Cloud sync (STUB — no real endpoint configured) --------------------------
# When you have a backend, point CLOUD_ENDPOINT at it and set SF_ITES_TOKEN.
# Interface contract (documented in docs/ARCHITECTURE.md):
#   POST {CLOUD_ENDPOINT}/telemetry
#   Headers: Authorization: Bearer <token>, Content-Type: application/octet-stream
#   Body:    Fernet-encrypted JSON: {"device_id": ..., "batch": [ {...}, ... ]}
#   Success: HTTP 200 with JSON {"accepted": <n>}
CLOUD_ENDPOINT = os.environ.get("SF_ITES_CLOUD", "https://example.com/api/v1")
API_TOKEN = os.environ.get("SF_ITES_TOKEN", "")
DEVICE_ID = os.environ.get("SF_ITES_DEVICE_ID", "pump-01")

# Fernet key for payload encryption (base64 urlsafe 32-byte key).
# Generate one:  python3 sync.py --gen-key
FERNET_KEY = os.environ.get("SF_ITES_FERNET_KEY", "")

# --- Sync behavior ------------------------------------------------------------
SYNC_INTERVAL_S = 300        # try to flush the outbox every 5 minutes
SYNC_BATCH_SIZE = 500        # rows per POST
REQUEST_TIMEOUT_S = 20

# --- Dashboard ----------------------------------------------------------------
DASHBOARD_HOST = "0.0.0.0"
DASHBOARD_PORT = 8080
