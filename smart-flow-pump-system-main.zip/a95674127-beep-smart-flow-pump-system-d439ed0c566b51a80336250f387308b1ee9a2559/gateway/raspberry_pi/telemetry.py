#!/usr/bin/env python3
"""
telemetry.py — SF-ITES serial ingestion daemon (runs on the Raspberry Pi).

Reads the ESP32's 1 Hz JSON telemetry lines over USB serial, validates them,
and appends them to a local SQLite database. Alert lines (state transitions,
trips) go to a separate alerts table.

Run:  python3 telemetry.py        (runs forever; log-rotate stdout yourself)
Test: python3 telemetry.py --once (reads one line, prints parsed row, exits)

Schema:
  readings(ts, current_a, flow_lpm, pressure_kpa, temp_c, state, trip,
           warnings, drift_pct, imbalance_pct, synced)
  alerts(ts, kind, detail)

`synced` marks rows already uploaded by sync.py (0 = pending).
"""
import json
import sqlite3
import sys
import time

import config

try:
    import serial
except ImportError:
    serial = None  # --once self-test still works without pyserial


SCHEMA = """
CREATE TABLE IF NOT EXISTS readings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    current_a REAL,
    flow_lpm REAL,
    pressure_kpa REAL,
    temp_c REAL,
    state TEXT,
    trip TEXT,
    warnings TEXT,          -- JSON array, e.g. ["OVERTEMP_WARN"]
    drift_pct REAL,
    imbalance_pct REAL,
    synced INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    kind TEXT NOT NULL,      -- STATE | TRIP | BOOT | WARN
    detail TEXT NOT NULL      -- JSON blob of the original line
);
CREATE INDEX IF NOT EXISTS idx_readings_ts ON readings(ts);
CREATE INDEX IF NOT EXISTS idx_readings_synced ON readings(synced);
"""


def open_db(path=config.DB_PATH):
    conn = sqlite3.connect(path)
    conn.executescript(SCHEMA)
    return conn


def parse_line(raw: str):
    """Parse one ESP32 line. Returns ('reading'|'alert'|'boot'|'status'|'error', dict|str)."""
    raw = raw.strip()
    if not raw:
        return ("empty", None)
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError as e:
        return ("error", f"bad JSON: {e}: {raw[:120]}")
    if "flow" in obj and "temp" in obj:
        return ("reading", obj)
    if obj.get("alert") in ("TRIP", "STATE"):
        return ("alert", obj)
    if "boot" in obj or "warn" in obj or "status" in obj or "error" in obj:
        return ("boot", obj)
    return ("error", f"unrecognized shape: {raw[:120]}")


def store_reading(conn, obj, ts):
    conn.execute(
        """INSERT INTO readings
           (ts, current_a, flow_lpm, pressure_kpa, temp_c, state, trip,
            warnings, drift_pct, imbalance_pct)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (
            ts,
            (obj.get("i") or [None])[0],
            obj.get("flow"),
            obj.get("press"),
            obj.get("temp"),
            obj.get("state"),
            obj.get("trip"),
            json.dumps(obj.get("warn", [])),
            obj.get("drift"),
            obj.get("imb"),
        ),
    )


def store_alert(conn, obj, ts):
    kind = obj.get("alert", "INFO")
    conn.execute(
        "INSERT INTO alerts (ts, kind, detail) VALUES (?,?,?)",
        (ts, kind, json.dumps(obj)),
    )


def ingest_line(conn, raw: str):
    kind, obj = parse_line(raw)
    ts = time.time()
    if kind == "reading":
        store_reading(conn, obj, ts)
    elif kind == "alert":
        store_alert(conn, obj, ts)
        # A TRIP alert is the most important row we will ever store —
        # commit immediately so a power cut can't lose it.
        conn.commit()
        print(f"[ALERT] {obj}", flush=True)
        return
    elif kind == "boot":
        store_alert(conn, {"alert": "BOOT", **obj}, ts)
    elif kind == "error":
        print(f"[WARN] {obj}", flush=True)
        return
    conn.commit()


def run_forever():
    if serial is None:
        print("pyserial not installed. Run: pip install -r requirements.txt")
        sys.exit(2)
    conn = open_db()
    print(f"Opening {config.SERIAL_PORT} @ {config.BAUD_RATE} ...", flush=True)
    while True:
        try:
            with serial.Serial(config.SERIAL_PORT, config.BAUD_RATE, timeout=5) as ser:
                print("Serial open. Ingesting.", flush=True)
                while True:
                    raw = ser.readline().decode("utf-8", errors="replace")
                    if raw:
                        ingest_line(conn, raw)
        except serial.SerialException as e:
            print(f"Serial error ({e}); retrying in 5 s ...", flush=True)
            time.sleep(5)
        except KeyboardInterrupt:
            break
    conn.close()


if __name__ == "__main__":
    if "--once" in sys.argv:
        # Offline self-test: parse a canned line, no serial needed.
        conn = open_db(":memory:")
        sample = ('{"t":123456,"i":[8.12,0,0],"flow":38.7,"press":312.5,'
                  '"temp":41.2,"state":"RUNNING","trip":"NONE",'
                  '"warn":[],"drift":2.1,"imb":-1}')
        ingest_line(conn, sample)
        row = conn.execute("SELECT current_a, flow_lpm, state FROM readings").fetchone()
        print("parsed OK:", row)
    else:
        run_forever()
