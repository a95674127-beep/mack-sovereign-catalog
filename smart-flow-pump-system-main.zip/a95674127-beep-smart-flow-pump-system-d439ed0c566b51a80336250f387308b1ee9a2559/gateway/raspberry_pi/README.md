# SF-ITES Gateway (Raspberry Pi 3)

Receives the ESP32's 1 Hz JSON telemetry over USB serial, stores it in
SQLite, syncs encrypted batches to the cloud when online, and serves a
local status dashboard.

## Files

| File | Purpose |
|---|---|
| `config.py` | Serial port, DB path, cloud endpoint, keys (from env) |
| `telemetry.py` | Serial ingestion daemon → SQLite |
| `sync.py` | Encrypted batch upload to cloud (stub endpoint by default) |
| `dashboard.py` | Local web UI on port 8080 (stdlib only) |
| `requirements.txt` | `pyserial`, `cryptography` |

## Quick start

```bash
pip install -r requirements.txt

# 1. Ingest (leave running, e.g. under systemd or tmux)
python3 telemetry.py

# 2. Dashboard (separate terminal)
python3 dashboard.py
# -> http://<pi-ip>:8080/

# 3. Cloud sync — one pass (add to cron every 5 min), or --daemon
python3 sync.py --gen-key     # once: put the key in SF_ITES_FERNET_KEY
SF_ITES_FERNET_KEY=<key> SF_ITES_TOKEN=<token> python3 sync.py
```

With the default stub endpoint, `sync.py` buffers locally and uploads
nothing — set `SF_ITES_CLOUD` to a real server to enable uploads.

## Environment variables

| Var | Purpose |
|---|---|
| `SF_ITES_SERIAL` | Serial port (default `/dev/ttyUSB0`) |
| `SF_ITES_DB` | SQLite path (default `/home/pi/sf-ites/telemetry.db`) |
| `SF_ITES_CLOUD` | Cloud base URL (default stub `https://example.com/api/v1`) |
| `SF_ITES_TOKEN` | Bearer token for the cloud API |
| `SF_ITES_FERNET_KEY` | Base64 Fernet key (`sync.py --gen-key`) |
| `SF_ITES_DEVICE_ID` | This unit's ID (default `pump-01`, same as firmware `DEVICE_ID`) |
