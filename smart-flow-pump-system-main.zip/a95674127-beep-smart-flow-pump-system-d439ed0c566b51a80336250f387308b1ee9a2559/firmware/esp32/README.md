# SF-ITES ESP32 Firmware

Edge safety controller for pump monitoring. Reads CT current, flow, pressure,
and temperature; runs anomaly baselines; trips a series-wired relay on
dry-run, overcurrent, overtemperature, cavitation, phase imbalance, or sensor
fault. Fail-safe: relay de-energized on boot, reset, and watchdog timeout.

## Files

| File | Purpose |
|---|---|
| `sf_ites_main.ino` | Main loop, sensor drivers, serial telemetry + commands, watchdog |
| `config.h` | ALL pins, thresholds, timing — edit this to fit your pump |
| `anomaly.h` / `.cpp` | Rolling current/flow baselines; cavitation, bearing-wear, imbalance |
| `safety.h` / `.cpp` | State machine + trip logic (the fail-safe core) |
| `signing.h` / `.cpp` | Ed25519 packet signing (audit-chained telemetry) |
| `SIGNING_CONTRACT.md` | Byte-level signing spec shared with the Rust ingestor |
| `host_test/` | Host-side verification (g++): canonical-JSON differential test + sign/verify chain |

## Build

1. Install Arduino IDE (or arduino-cli) with the **ESP32** board package.
2. Install libraries (Library Manager): `OneWire`, `DallasTemperature`,
   `Crypto` (by rweather — provides Ed25519).
3. Open `sf_ites_main.ino`. Select board **"ESP32 Dev Module"**.
4. Edit `config.h`: set `PUMP_RATED_CURRENT_A`, `MAINS_FREQ_HZ` (50/60),
   and verify pin assignments match your wiring (`docs/WIRING.md`).
5. **Bench-test first** with `#define TEST_MODE 1` (see `docs/TESTING.md`).
   Set back to `0` before connecting to a real pump.
6. Upload. Open Serial Monitor at 115200 — you should see the boot banner,
   then 1 Hz JSON telemetry lines.

## Packet signing

Each telemetry sample is also emitted as a signed audit packet
(`SIGNING_ENABLED=1` in `config.h`, default on). The packet follows the
contract in `SIGNING_CONTRACT.md` and verifies with the Rust ingestion
pipeline (`ai-infinity-force-one-vault`). Key provisioning: see
`docs/keymgmt.md`. Without a provisioned key the firmware emits an explicit
`"unsigned":true` marker — unsigned packets are never sent silently.

To verify the signing code on your workstation (no ESP32 needed):
```bash
cd firmware/esp32/host_test
g++ -o test_canonical test_canonical.cpp ../signing.cpp -I.. -lcrypto
./test_canonical   # byte-identical canonical JSON vs Rust ground truth
```

## First boot checklist

- [ ] Relay clicks OFF (de-energized) immediately on power-up — listen for it
- [ ] Serial shows `SELFTEST`, then `STANDBY` (or `RUNNING` if AUTO_START=1)
- [ ] `STATUS` command returns sane state
- [ ] DS18B20 found (no "not found at boot" warning)
- [ ] Telemetry line shows plausible values (not NaN)

## Serial commands

`START` — request pump start · `RESET` — clear latched trip · `STATUS` — state
