// ============================================================================
// signing.cpp — Ed25519 packet signing for SF-ITES telemetry.
//
// THE CRITICAL CONTRACT: build_canonical_json() must produce byte-identical
// output to Rust serde_json's serialization of telemetry::packet::CanonicalPacket.
// Verified empirically against 15+ ground-truth vectors from the actual Rust
// implementation (see host_test/). If you modify the float formatter, re-run
// the differential test.
//
// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// ============================================================================

#include "signing.h"

#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <string>

// ---------------------------------------------------------------------------
// Crypto backends
// ---------------------------------------------------------------------------
#ifdef ARDUINO
  // ESP32: rweather "Crypto" library (Arduino Library Manager), MIT license.
  #include <Crypto.h>
  #include <Ed25519.h>
  #include "mbedtls/sha256.h"
#else
  // Host test: OpenSSL for SHA-256. Ed25519 via tweetnacl (vendored in
  // host_test/, public domain). These NEVER ship in firmware.
  #include <openssl/sha.h>
#endif

// ============================================================================
// Float formatting — replicate Rust serde_json f32 Display byte-for-byte.
//
// serde_json rules (empirically derived from ground-truth vectors generated
// by the real Rust code — see host_test/test_canonical.cpp):
//   1. Shortest decimal digit string that round-trips to the same f32 bits.
//   2. Among equal-length candidates, the one closest to the true value.
//      (e.g. 1/3f -> "0.33333334", NOT "0.33333333" — both round-trip,
//      but "0.33333334" is closer. printf's %.Ne rounding gets this wrong.)
//   3. Decimal notation when -6 <= exp10 < 15, else scientific.
//      (1e-6 -> "0.000001", 1e-7 -> "1e-7", 1e10 -> "10000000000.0",
//       1e+15 -> "1e+15")
//   4. Output always contains '.' or 'e' (integers render as "5.0").
//   5. Negative zero renders as "-0.0" (signbit preserved).
//   6. Scientific format: Xe±Y with no leading zeros ("1e-7", "1e+15").
//
// Algorithm: for precision p = 1..9, take printf's %.*g candidate, generate
// decimal neighbors by adjusting the last digit ±2 (covers printf rounding
// vs. optimal-shortest discrepancies), lay each out per rules 3-6, and keep
// the first (shortest p) candidate whose strtof() bit-matches the input.
// Among same-p candidates, keep the closest to the true value (rule 2).
// Precision 9 always round-trips for f32, so termination is guaranteed.
// ============================================================================

namespace {

// Parse a printf %g-style float string into (digits, exp10).
// Input like "3.14159", "-0.001", "1e+10", "2.5e-07".
// Output: digits = significant digit string (no leading/trailing zeros,
//         at least "0"), exp10 = decimal exponent of the LEADING digit,
//         neg = sign. Value = neg ? -(0.digits × 10^(exp10+1)) : ...
// Actually: value = digits_as_integer × 10^(exp10 - (len(digits)-1)).
struct ParsedFloat {
    bool neg;
    std::string digits;  // no leading zeros (unless "0"), no trailing zeros
    int exp10;           // exponent of the leading digit
};

bool parse_float_str(const char *s, ParsedFloat &out) {
    out.neg = false;
    out.digits.clear();
    out.exp10 = 0;
    size_t i = 0;
    if (s[i] == '-') { out.neg = true; i++; }
    else if (s[i] == '+') { i++; }

    std::string intpart, fracpart;
    while (s[i] >= '0' && s[i] <= '9') intpart += s[i++];
    if (s[i] == '.') {
        i++;
        while (s[i] >= '0' && s[i] <= '9') fracpart += s[i++];
    }
    int exp = 0;
    if (s[i] == 'e' || s[i] == 'E') {
        i++;
        bool eneg = false;
        if (s[i] == '-') { eneg = true; i++; }
        else if (s[i] == '+') { i++; }
        while (s[i] >= '0' && s[i] <= '9') { exp = exp * 10 + (s[i] - '0'); i++; }
        if (eneg) exp = -exp;
    }
    if (s[i] != '\0') return false;  // trailing garbage

    // Combine: digits = intpart + fracpart, strip leading zeros.
    std::string all = intpart + fracpart;
    size_t nz = all.find_first_not_of('0');
    if (nz == std::string::npos) {
        out.digits = "0";
        out.exp10 = 0;
        return true;
    }
    all = all.substr(nz);
    // Strip trailing zeros (shortest form).
    while (all.size() > 1 && all.back() == '0') all.pop_back();
    out.digits = all;
    // Positional exponent: value = (digits as integer) × 10^E where
    // E = exp - len(fracpart). Stripping leading zeros does not change
    // the integer value, so it does not change E.
    int E = exp - (int)fracpart.size();
    out.exp10 = E + (int)all.size() - 1;
    return true;
}

// Lay out (digits, exp10, neg) per serde_json rules into out.
// Returns bytes written (excluding NUL) or 0 if out_len too small.
size_t layout_float(char *out, size_t out_len, bool neg,
                    const std::string &digits, int exp10) {
    std::string r;
    if (neg) r += '-';

    // serde_json: scientific iff exp10 < -6 or exp10 >= 13.
    // (Verified: 1e13 -> "1e+13", but 9.99e12 -> "9990000000000.0".)
    if (exp10 < -6 || exp10 >= 13) {
        r += digits[0];
        if (digits.size() > 1) {
            r += '.';
            r += digits.substr(1);
        }
        r += 'e';
        if (exp10 < 0) r += '-';
        else r += '+';
        r += std::to_string(exp10 < 0 ? -exp10 : exp10);
    } else {
        // Decimal notation.
        // value = digits × 10^(exp10 - (len-1)). Let P = exp10 - (len-1).
        int k = (int)digits.size();
        int P = exp10 - (k - 1);
        if (P >= 0) {
            r += digits;
            r.append((size_t)P, '0');
            r += ".0";
        } else {
            int point_at = k + P;  // digits before decimal point
            if (point_at > 0) {
                r += digits.substr(0, (size_t)point_at);
                r += '.';
                r += digits.substr((size_t)point_at);
            } else {
                r += "0.";
                r.append((size_t)(-point_at), '0');
                r += digits;
            }
        }
    }

    if (r.size() + 1 > out_len) return 0;
    memcpy(out, r.c_str(), r.size() + 1);
    return r.size();
}

// Adjust the last digit of a digit string by delta (can change length).
// e.g. ("129", +1) -> "130", ("1000", -1) -> "999", ("999", +1) -> "1000".
std::string digit_adjust(const std::string &digits, int delta) {
    // Convert to integer, add delta, convert back. Digit strings are
    // at most 9 chars, fits in 64-bit.
    unsigned long long v = 0;
    for (char c : digits) v = v * 10 + (unsigned)(c - '0');
    long long nv = (long long)v + delta;
    if (nv < 0) nv = 0;
    return std::to_string((unsigned long long)nv);
}

}  // namespace

// Format f32 to match serde_json. Returns bytes written excl. NUL, else 0.
static size_t format_f32_json(char *out, size_t out_len, float v) {
    bool neg = std::signbit(v);
    float av = neg ? -v : v;  // careful: -(-0.0) = 0.0, but neg flag kept

    // Special case: zero (either sign).
    if (av == 0.0f) {
        const char *s = neg ? "-0.0" : "0.0";
        size_t n = strlen(s);
        if (n + 1 > out_len) return 0;
        memcpy(out, s, n + 1);
        return n;
    }

    double v_true = (double)av;  // exact; NB: |v|, sign applied at the end

    // Try precisions 1..9 (shortest first).
    for (int prec = 1; prec <= 9; prec++) {
        char pbuf[48];
        snprintf(pbuf, sizeof(pbuf), "%.*g", prec, (double)av);

        ParsedFloat pf;
        if (!parse_float_str(pbuf, pf)) continue;
        // pf.digits should have <= prec digits; %g may give fewer.
        // Generate neighbors: the parsed digits ±2, to cover the gap
        // between printf rounding and optimal-shortest selection.
        std::string best;
        double best_dist = 1e300;
        bool found = false;

        for (int d = -2; d <= 2; d++) {
            std::string cand_digits = digit_adjust(pf.digits, d);
            // Recompute exp10 for adjusted digits. digit_adjust may change
            // the digit count (e.g. "999"+1="1000", "1000"-1="999").
            // The VALUE represented must stay anchored: we adjusted the
            // digit string, so we must adjust exp10 to compensate.
            //
            // Original: value ≈ D × 10^(exp10 - (len(D)-1)).
            // New digits D' with len k': to represent a nearby value we keep
            // the same positional weight: exp10' = exp10 + (len(D) - k').
            int k_orig = (int)pf.digits.size();
            int k_new = (int)cand_digits.size();
            int exp10_new = pf.exp10 + (k_orig - k_new);

            char cbuf[64];
            size_t cn = layout_float(cbuf, sizeof(cbuf), false,
                                     cand_digits, exp10_new);
            if (cn == 0) continue;

            // Round-trip check: strtof must bit-match the original float.
            float back = strtof(cbuf, nullptr);
            if (memcmp(&back, &av, sizeof(float)) != 0) continue;

            // Tie-break: closest to true value (serde_json rule 2).
            double cand_val = strtod(cbuf, nullptr);
            double dist = fabs(cand_val - v_true);
            if (!found || dist < best_dist) {
                best_dist = dist;
                best = cbuf;
                found = true;
            }
        }

        if (found) {
            // Prepend sign if needed.
            std::string result = best;
            if (neg) result = "-" + result;
            if (result.size() + 1 > out_len) return 0;
            memcpy(out, result.c_str(), result.size() + 1);
            return result.size();
        }
    }

    // Unreachable for finite f32 (prec=9 always round-trips), but be safe.
    return 0;
}

// ============================================================================
// Canonical JSON builder
// ============================================================================

size_t build_canonical_json(char *out, size_t out_len,
                            const char *device_id,
                            uint64_t seq,
                            int64_t timestamp_ms,
                            float current_rms,
                            float flow_rate,
                            float temp_c,
                            float pressure_kpa) {
    // Reject non-finite floats loudly — the Rust side rejects them at
    // validation, so signing them would produce unverifiable packets.
    // (We return 0 = failure, which the caller must handle fail-safe.)
    if (!std::isfinite(current_rms) || !std::isfinite(flow_rate) ||
        !std::isfinite(temp_c) || !std::isfinite(pressure_kpa)) {
        return 0;
    }

    char fbuf[4][48];
    if (!format_f32_json(fbuf[0], sizeof(fbuf[0]), current_rms)) return 0;
    if (!format_f32_json(fbuf[1], sizeof(fbuf[1]), flow_rate)) return 0;
    if (!format_f32_json(fbuf[2], sizeof(fbuf[2]), temp_c)) return 0;
    if (!format_f32_json(fbuf[3], sizeof(fbuf[3]), pressure_kpa)) return 0;

    // NOTE: device_id is emitted verbatim. The Rust side does not escape
    // (serde_json WOULD escape quotes/backslashes). Device IDs are
    // constrained to [a-z0-9-] by provisioning; a device_id containing
    // '"' or '\\' would break byte-parity. Enforced in keymgmt.md.
    // We defensively reject such IDs here.
    for (const char *p = device_id; *p; p++) {
        if (*p == '"' || *p == '\\' || (unsigned char)*p < 0x20) return 0;
    }

    int n = snprintf(out, out_len,
        "{\"schema_version\":1,\"device_id\":\"%s\",\"seq\":%llu,"
        "\"timestamp_ms\":%lld,\"current_rms\":%s,\"flow_rate\":%s,"
        "\"temp_c\":%s,\"pressure_kpa\":%s}",
        device_id,
        (unsigned long long)seq,
        (long long)timestamp_ms,
        fbuf[0], fbuf[1], fbuf[2], fbuf[3]);

    if (n < 0 || (size_t)n >= out_len) return 0;
    return (size_t)n;
}

// ============================================================================
// SHA-256
// ============================================================================

void sha256_digest(const uint8_t *data, size_t len, uint8_t digest_out[32]) {
#ifdef ARDUINO
    mbedtls_sha256_context ctx;
    mbedtls_sha256_init(&ctx);
    mbedtls_sha256_starts(&ctx, 0);  // 0 = SHA-256 (not 224)
    mbedtls_sha256_update(&ctx, data, len);
    mbedtls_sha256_finish(&ctx, digest_out);
    mbedtls_sha256_free(&ctx);
#else
    SHA256(data, len, digest_out);
#endif
}

// ============================================================================
// Ed25519
// ============================================================================

// Host-test Ed25519 backend declarations (tweetnacl-compatible API).
// On ESP32 these are unused (rweather Crypto is used instead).
#ifndef ARDUINO
extern "C" {
int crypto_sign_seed_keypair(unsigned char *pk, unsigned char *sk,
                              const unsigned char *seed);
int crypto_sign_detached(unsigned char *sig, unsigned long long *siglen,
                         const unsigned char *m, unsigned long long mlen,
                         const unsigned char *sk);
int crypto_sign_verify_detached(const unsigned char *sig,
                                const unsigned char *m,
                                unsigned long long mlen,
                                const unsigned char *pk);
}
#endif

void ed25519_derive_pubkey(const uint8_t privkey_seed[32],
                           uint8_t pubkey_out[32]) {
#ifdef ARDUINO
    Ed25519::derivePublicKey(pubkey_out, privkey_seed);
#else
    uint8_t sk[64];
    crypto_sign_seed_keypair(pubkey_out, sk, privkey_seed);
    memset(sk, 0, sizeof(sk));
#endif
}

bool ed25519_sign_digest(const uint8_t digest[32],
                         const uint8_t privkey_seed[32],
                         uint8_t sig_out[64]) {
#ifdef ARDUINO
    uint8_t pubkey[32];
    Ed25519::derivePublicKey(pubkey, privkey_seed);
    Ed25519::sign(sig_out, privkey_seed, pubkey, digest, 32);
    memset(pubkey, 0, sizeof(pubkey));
    return true;
#else
    uint8_t pk[32], sk[64];
    crypto_sign_seed_keypair(pk, sk, privkey_seed);
    unsigned long long siglen = 0;
    int rc = crypto_sign_detached(sig_out, &siglen, digest, 32, sk);
    memset(sk, 0, sizeof(sk));
    memset(pk, 0, sizeof(pk));
    return rc == 0 && siglen == 64;
#endif
}

bool ed25519_verify_digest(const uint8_t digest[32],
                           const uint8_t sig[64],
                           const uint8_t pubkey[32]) {
#ifdef ARDUINO
    return Ed25519::verify(sig, pubkey, digest, 32);
#else
    return crypto_sign_verify_detached(sig, digest, 32, pubkey) == 0;
#endif
}

// ============================================================================
// Full pipeline + self-test
// ============================================================================

bool sign_telemetry_packet(const char *device_id,
                           uint64_t seq,
                           int64_t timestamp_ms,
                           float current_rms,
                           float flow_rate,
                           float temp_c,
                           float pressure_kpa,
                           const uint8_t privkey_seed[32],
                           uint8_t sig_out[64],
                           char *json_out, size_t json_len) {
    size_t n = build_canonical_json(json_out, json_len, device_id, seq,
                                    timestamp_ms, current_rms, flow_rate,
                                    temp_c, pressure_kpa);
    if (n == 0) return false;

    uint8_t digest[32];
    sha256_digest((const uint8_t *)json_out, n, digest);

    bool ok = ed25519_sign_digest(digest, privkey_seed, sig_out);
    memset(digest, 0, sizeof(digest));
    return ok;
}

bool signing_self_test(void) {
    // Fixed test vector (not secret — just exercises the code path).
    // Private seed: 32 bytes of 0x42. Expected values were generated
    // with the host test and cross-checked against ed25519-dalek.
    static const uint8_t kTestSeed[32] = {
        0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,
        0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,
        0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,
        0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42
    };
    static const uint8_t kTestDigest[32] = {
        0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
        0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,
        0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,
        0x18,0x19,0x1a,0x1b,0x1c,0x1d,0x1e,0x1f
    };

    uint8_t pubkey[32];
    uint8_t sig[64];
    ed25519_derive_pubkey(kTestSeed, pubkey);
    if (!ed25519_sign_digest(kTestDigest, kTestSeed, sig)) {
        memset(pubkey, 0, sizeof(pubkey));
        return false;
    }
    bool ok = ed25519_verify_digest(kTestDigest, sig, pubkey);
    memset(pubkey, 0, sizeof(pubkey));
    memset(sig, 0, sizeof(sig));

    // Also verify the canonical JSON builder against a known vector.
    // This is the exact output of the Rust implementation for the sample packet.
    if (ok) {
        char json[512];
        size_t n = build_canonical_json(json, sizeof(json),
                                        "pump-01", 1, 1784000000000LL,
                                        5.0f, 2.5f, 42.0f, 310.0f);
        static const char kExpected[] =
            "{\"schema_version\":1,\"device_id\":\"pump-01\",\"seq\":1,"
            "\"timestamp_ms\":1784000000000,\"current_rms\":5.0,"
            "\"flow_rate\":2.5,\"temp_c\":42.0,\"pressure_kpa\":310.0}";
        if (n == 0 || strcmp(json, kExpected) != 0) ok = false;
    }
    return ok;
}
