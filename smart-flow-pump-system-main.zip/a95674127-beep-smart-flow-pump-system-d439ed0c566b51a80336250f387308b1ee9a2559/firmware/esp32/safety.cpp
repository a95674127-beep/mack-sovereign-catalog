// ============================================================================
// safety.cpp — fail-safe pump safety controller implementation.
// ============================================================================
#include "safety.h"
#include "anomaly.h"

const char* tripReasonName(TripReason r) {
  switch (r) {
    case TRIP_NONE:            return "NONE";
    case TRIP_DRY_RUN:         return "DRY_RUN";
    case TRIP_OVERCURRENT:     return "OVERCURRENT";
    case TRIP_OVERTEMP:        return "OVERTEMP";
    case TRIP_SENSOR_FAULT:    return "SENSOR_FAULT";
    case TRIP_PHASE_IMBALANCE: return "PHASE_IMBALANCE";
    case TRIP_CAVITATION:      return "CAVITATION";
    case TRIP_MANUAL_ESTOP:    return "MANUAL_ESTOP";
    default:                   return "UNKNOWN";
  }
}

const char* safetyStateName(SafetyState s) {
  switch (s) {
    case ST_BOOT:     return "BOOT";
    case ST_SELFTEST: return "SELFTEST";
    case ST_STANDBY:  return "STANDBY";
    case ST_RUNNING:  return "RUNNING";
    case ST_TRIPPED:  return "TRIPPED";
    default:          return "UNKNOWN";
  }
}

SafetyController::SafetyController()
  : state_(ST_BOOT), trip_reason_(TRIP_NONE), trip_time_ms_(0),
    run_start_ms_(0), relay_engaged_(false), start_requested_(false),
    bad_read_count_(0), dry_run_since_ms_(0) {}

void SafetyController::begin() {
  // FAIL-SAFE BOOT SEQUENCE — order matters:
  // 1. Drive relay pin to SAFE level while still an input (weak pull via
  //    the pin's default state won't energize most relay modules, but we
  //    don't rely on that).
  // 2. THEN set pinMode OUTPUT and re-assert SAFE.
  // 3. Only then touch sensors, serial, etc.
  digitalWrite(PIN_RELAY, RELAY_SAFE_LEVEL);
  pinMode(PIN_RELAY, OUTPUT);
  digitalWrite(PIN_RELAY, RELAY_SAFE_LEVEL);
  relay_engaged_ = false;

  pinMode(PIN_STATUS_LED, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);
  pinMode(PIN_START_BTN, INPUT_PULLUP);
  pinMode(PIN_RESET_BTN, INPUT_PULLUP);

  trip_reason_ = TRIP_NONE;
  bad_read_count_ = 0;
  dry_run_since_ms_ = 0;
  state_ = ST_SELFTEST;
}

void SafetyController::setRelay(bool engaged) {
  digitalWrite(PIN_RELAY, engaged ? RELAY_ENGAGED_LEVEL : RELAY_SAFE_LEVEL);
  relay_engaged_ = engaged;
}

void SafetyController::trip(TripReason reason, uint32_t now_ms) {
  setRelay(false);              // pump power cut FIRST, bookkeeping second
  digitalWrite(PIN_BUZZER, HIGH);
  state_ = ST_TRIPPED;
  trip_reason_ = reason;
  trip_time_ms_ = now_ms;
  dry_run_since_ms_ = 0;
}

void SafetyController::requestStart()  { start_requested_ = true; }

void SafetyController::requestReset() {
  if (state_ == ST_TRIPPED) {
    digitalWrite(PIN_BUZZER, LOW);
    trip_reason_ = TRIP_NONE;
    bad_read_count_ = 0;
    dry_run_since_ms_ = 0;
    start_requested_ = false;
    state_ = ST_SELFTEST;   // re-verify sensors before allowing a restart
  }
}

void SafetyController::requestEstop() {
  if (state_ == ST_RUNNING || state_ == ST_STANDBY) {
    trip(TRIP_MANUAL_ESTOP, millis());
  }
}

SafetyState SafetyController::update(const SensorSnapshot& snap, uint32_t now_ms) {
  // Physical buttons (debounced in the main loop by 1 Hz sampling; a
  // deliberate press is >> 1 s, a bounce is << 1 s).
  if (digitalRead(PIN_START_BTN) == LOW) requestStart();
  if (digitalRead(PIN_RESET_BTN) == LOW) requestReset();

  switch (state_) {
    case ST_SELFTEST: {
      // All sensors must read sane values before the pump may start.
      // A pump that cannot be observed must not run.
      TripReason f = checkSensorFault(snap);
      if (f == TRIP_NONE) {
        bad_read_count_ = 0;
        state_ = ST_STANDBY;
#if AUTO_START
        start_requested_ = true;  // auto-start only after passing self-test
#endif
      } else {
        // Stay in SELFTEST; do NOT trip-latch here — there is nothing
        // running to protect yet. The fault is reported via serial.
        if (++bad_read_count_ > 60) {
          // Sensors never came good after ~60 s: escalate to latched trip
          // so the dashboard shows a hard fault, not a silent wait.
          trip(TRIP_SENSOR_FAULT, now_ms);
        }
      }
      break;
    }

    case ST_STANDBY: {
      // Keep watching sensors while idle; a sensor that dies while we
      // wait must block the next start.
      checkSensorFault(snap);  // updates bad_read_count_
      if (start_requested_ && bad_read_count_ == 0 && snap.sensors_valid) {
        start_requested_ = false;
        setRelay(true);
        run_start_ms_ = now_ms;
        dry_run_since_ms_ = 0;
        state_ = ST_RUNNING;
      } else if (start_requested_ && !snap.sensors_valid) {
        start_requested_ = false;  // refuse start on bad sensors
      }
      break;
    }

    case ST_RUNNING: {
      TripReason r;
      // Evaluation order: cheapest/most-critical first. First fault wins;
      // the trip record keeps the first cause (root-cause friendly).
      if ((r = checkSensorFault(snap))    != TRIP_NONE) { trip(r, now_ms); break; }
      if ((r = checkOvertemp(snap))       != TRIP_NONE) { trip(r, now_ms); break; }
      if ((r = checkOvercurrent(snap, now_ms)) != TRIP_NONE) { trip(r, now_ms); break; }
      if ((r = checkCavitation(snap))     != TRIP_NONE) { trip(r, now_ms); break; }
      if ((r = checkDryRun(snap, now_ms)) != TRIP_NONE) { trip(r, now_ms); break; }
      if ((r = checkPhaseImbalance(snap)) != TRIP_NONE) { trip(r, now_ms); break; }
      break;
    }

    case ST_TRIPPED:
      // Latched. Only requestReset() exits. Relay stays open.
      setRelay(false);  // belt-and-braces: re-assert every cycle
      break;

    case ST_BOOT:
    default:
      // Should be unreachable (begin() moves to ST_SELFTEST), but if we
      // ever land here the only safe action is relay open.
      setRelay(false);
      state_ = ST_SELFTEST;
      break;
  }
  return state_;
}

// ---------------------------------------------------------------------------
// Fault evaluators
// ---------------------------------------------------------------------------

TripReason SafetyController::checkSensorFault(const SensorSnapshot& snap) {
  if (!snap.sensors_valid) {
    if (++bad_read_count_ >= SENSOR_BAD_READ_LIMIT) {
      return TRIP_SENSOR_FAULT;
    }
  } else {
    bad_read_count_ = 0;
  }
  return TRIP_NONE;
}

TripReason SafetyController::checkOvertemp(const SensorSnapshot& snap) {
  // Temperature is validated by checkSensorFault first, so a reading here
  // is real. Trip is immediate — thermal runaway does not get a grace
  // period.
  if (snap.temp_c >= OVERTEMP_TRIP_C) return TRIP_OVERTEMP;
  return TRIP_NONE;
}

TripReason SafetyController::checkOvercurrent(const SensorSnapshot& snap, uint32_t now_ms) {
  float limit = PUMP_RATED_CURRENT_A * OVERCURRENT_FACTOR;
  // Inrush grace: for STARTUP_GRACE_S after the relay closes, allow a
  // higher threshold so normal motor startup does not nuisance-trip.
  if (now_ms - run_start_ms_ < (uint32_t)STARTUP_GRACE_S * 1000UL) {
    limit = PUMP_RATED_CURRENT_A * INRUSH_FACTOR;
  }
  for (int i = 0; i < CT_CHANNELS; i++) {
    if (snap.current_a[i] > limit) return TRIP_OVERCURRENT;
  }
  return TRIP_NONE;
}

TripReason SafetyController::checkDryRun(const SensorSnapshot& snap, uint32_t now_ms) {
  // Dry-run signature: motor turning (current flowing) but no water moving.
  // Must SUSTAIN for DRY_RUN_TRIP_SECONDS — a brief flow dip when a
  // downstream valve closes is normal and must not trip.
  bool cond = (snap.flow_lpm < DRY_RUN_FLOW_LPM) &&
              (snap.current_a[0] > DRY_RUN_CURRENT_A);
  if (cond) {
    if (dry_run_since_ms_ == 0) dry_run_since_ms_ = now_ms;
    if (now_ms - dry_run_since_ms_ >= (uint32_t)DRY_RUN_TRIP_SECONDS * 1000UL) {
      return TRIP_DRY_RUN;
    }
  } else {
    dry_run_since_ms_ = 0;  // condition cleared; timer resets
  }
  return TRIP_NONE;
}

TripReason SafetyController::checkPhaseImbalance(const SensorSnapshot& snap) {
  float imb = anomaly::phaseImbalancePct(snap.current_a);
  if (imb < 0) return TRIP_NONE;  // single-phase: feature unavailable
  if (imb > PHASE_IMBALANCE_PCT) return TRIP_PHASE_IMBALANCE;
  return TRIP_NONE;
}

TripReason SafetyController::checkCavitation(const SensorSnapshot& snap) {
  if (!snap.baselines_ready) return TRIP_NONE;  // don't judge without history
  if (anomaly::isCavitation(snap.current_a[0], snap.current_baseline_a,
                            snap.flow_lpm,      snap.flow_baseline_lpm)) {
    return TRIP_CAVITATION;
  }
  return TRIP_NONE;
}
