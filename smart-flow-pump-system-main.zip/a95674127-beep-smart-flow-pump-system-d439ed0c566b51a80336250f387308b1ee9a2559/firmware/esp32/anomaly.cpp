// ============================================================================
// anomaly.cpp — implementation of rolling-baseline anomaly detection.
// ============================================================================
#include "anomaly.h"

// ---------------------------------------------------------------------------
CurrentBaseline::CurrentBaseline()
  : ema_fast_(0), ema_slow_(0), samples_(0) {}

void CurrentBaseline::begin(float initial_amps) {
  ema_fast_ = initial_amps;
  ema_slow_ = initial_amps;
  samples_  = 0;
}

void CurrentBaseline::update(float amps) {
  // Guard against garbage poisoning the baseline (e.g., a spike during a
  // sensor glitch). Clamp single-sample influence to +/-50 % of slow EMA.
  // Baselines are only updated while RUNNING; the caller enforces that.
  if (samples_ > 0 && ema_slow_ > 0.5f) {
    if (amps > ema_slow_ * 1.5f) amps = ema_slow_ * 1.5f;
    if (amps < ema_slow_ * 0.5f) amps = ema_slow_ * 0.5f;
  }
  ema_fast_ = BASELINE_ALPHA_FAST * amps + (1.0f - BASELINE_ALPHA_FAST) * ema_fast_;
  ema_slow_ = BASELINE_ALPHA_SLOW * amps + (1.0f - BASELINE_ALPHA_SLOW) * ema_slow_;
  samples_++;
}

float CurrentBaseline::driftPct() const {
  if (ema_slow_ < 0.5f) return 0.0f;  // avoid divide-by-tiny
  return (ema_fast_ - ema_slow_) / ema_slow_ * 100.0f;
}

// ---------------------------------------------------------------------------
FlowBaseline::FlowBaseline() : ema_(0), samples_(0) {}

void FlowBaseline::begin(float lpm) { ema_ = lpm; samples_ = 0; }

void FlowBaseline::update(float lpm) {
  ema_ = BASELINE_ALPHA_FAST * lpm + (1.0f - BASELINE_ALPHA_FAST) * ema_;
  samples_++;
}

// ---------------------------------------------------------------------------
namespace anomaly {

bool isCavitation(float current_a, float current_baseline_a,
                  float flow_lpm,  float flow_baseline_lpm) {
  if (current_baseline_a < 0.5f || flow_baseline_lpm < 1.0f) return false;
  float i_drop = (current_baseline_a - current_a) / current_baseline_a * 100.0f;
  float f_drop = (flow_baseline_lpm  - flow_lpm)  / flow_baseline_lpm  * 100.0f;
  // BOTH must collapse: a current drop alone could be a light load;
  // a flow drop alone could be a downstream valve closing.
  return (i_drop >= CAVITATION_I_DROP_PCT) && (f_drop >= CAVITATION_F_DROP_PCT);
}

bool isBearingWear(float drift_pct) {
  return drift_pct >= BEARING_WEAR_DRIFT_PCT;
}

float phaseImbalancePct(const float amps[3]) {
#if CT_CHANNELS != 3
  (void)amps;
  return -1.0f;  // single-phase install: feature unavailable by design
#else
  float mn = amps[0], mx = amps[0];
  for (int i = 1; i < 3; i++) {
    if (amps[i] < mn) mn = amps[i];
    if (amps[i] > mx) mx = amps[i];
  }
  float mean = (amps[0] + amps[1] + amps[2]) / 3.0f;
  if (mean < 0.5f) return 0.0f;  // pump essentially off; imbalance meaningless
  return (mx - mn) / mean * 100.0f;
#endif
}

} // namespace anomaly
