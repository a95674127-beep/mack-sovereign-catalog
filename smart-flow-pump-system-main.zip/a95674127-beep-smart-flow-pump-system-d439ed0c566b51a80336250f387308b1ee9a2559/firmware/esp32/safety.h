// ============================================================================
// safety.h — fail-safe pump safety controller for SF-ITES.
//
// This is the module that protects the pump. Every safety claim in the
// documentation maps to a code path here:
//
//  CLAIM                                    CODE PATH
//  -----                                    ---------
//  Relay de-energized on boot/reset     ->  SafetyController::begin()
//  Dry-run trips the pump               ->  checkDryRun()
//  Overcurrent trips (inrush-aware)     ->  checkOvercurrent()
//  Overtemperature trips                ->  checkOvertemp()
//  Dead sensor => shutdown, not blind   ->  checkSensorFault()
//  Trip latches until manual reset      ->  state_ = ST_TRIPPED
//  Watchdog reset => pump stays off     ->  begin() runs again on reboot
//
// HONEST LIMITATION: software cannot detect a WELDED relay contact (coil
// de-energized but contacts fused shut). If that failure mode matters for
// your installation, wire the relay's auxiliary contact back to a GPIO
// and verify it in self-test. See docs/WIRING.md.
// ============================================================================
#pragma once
#include <Arduino.h>
#include "config.h"

// Latched trip reasons. NONE = no trip.
enum TripReason {
  TRIP_NONE = 0,
  TRIP_DRY_RUN,
  TRIP_OVERCURRENT,
  TRIP_OVERTEMP,
  TRIP_SENSOR_FAULT,
  TRIP_PHASE_IMBALANCE,
  TRIP_CAVITATION,
  TRIP_MANUAL_ESTOP,   // reserved: wire an e-stop button to requestEstop()
  TRIP_COUNT
};

const char* tripReasonName(TripReason r);

// Controller states.
enum SafetyState {
  ST_BOOT = 0,   // begin() not yet called
  ST_SELFTEST,   // verifying sensors before allowing a start
  ST_STANDBY,    // relay open, healthy, waiting for start request
  ST_RUNNING,    // relay closed, monitoring
  ST_TRIPPED,    // relay open, latched on trip; requires reset
};

const char* safetyStateName(SafetyState s);

// One snapshot of all sensor inputs, produced by the main loop.
struct SensorSnapshot {
  float current_a[3];   // per-phase RMS amps (unused channels = 0)
  float flow_lpm;       // liters per minute
  float pressure_kpa;
  float temp_c;         // motor casing temperature
  bool  sensors_valid;  // false if ANY reading failed plausibility checks
  // Baselines (computed by anomaly module, fed in for cavitation check)
  float current_baseline_a;
  float flow_baseline_lpm;
  bool  baselines_ready;
};

class SafetyController {
public:
  SafetyController();

  // MUST be the first thing called in setup(). Drives the relay pin to
  // the safe (de-energized) level before configuring anything else.
  void begin();

  // Call at SENSOR_READ_MS while in ST_RUNNING (and ST_SELFTEST).
  // Returns the new state after evaluation.
  SafetyState update(const SensorSnapshot& snap, uint32_t now_ms);

  // Operator requests.
  void requestStart();   // ST_STANDBY -> close relay (if sensors healthy)
  void requestReset();   // ST_TRIPPED -> re-run self-test
  void requestEstop();   // any state -> immediate trip, latched

  SafetyState state() const { return state_; }
  TripReason  tripReason() const { return trip_reason_; }
  uint32_t    tripTimeMs() const { return trip_time_ms_; }
  uint32_t    runStartMs() const { return run_start_ms_; }

  // True while the relay coil is (supposed to be) energized.
  bool relayEngaged() const { return relay_engaged_; }

private:
  void setRelay(bool engaged);
  void trip(TripReason reason, uint32_t now_ms);

  // Individual fault evaluators; each returns a TripReason or TRIP_NONE.
  TripReason checkSensorFault(const SensorSnapshot& snap);
  TripReason checkOvertemp(const SensorSnapshot& snap);
  TripReason checkOvercurrent(const SensorSnapshot& snap, uint32_t now_ms);
  TripReason checkDryRun(const SensorSnapshot& snap, uint32_t now_ms);
  TripReason checkPhaseImbalance(const SensorSnapshot& snap);
  TripReason checkCavitation(const SensorSnapshot& snap);

  SafetyState state_;
  TripReason  trip_reason_;
  uint32_t    trip_time_ms_;
  uint32_t    run_start_ms_;      // when relay last closed
  bool        relay_engaged_;
  bool        start_requested_;

  // Debounce / sustain counters (persist across update() calls)
  uint8_t     bad_read_count_;
  uint32_t    dry_run_since_ms_;  // 0 = condition not currently met
};
