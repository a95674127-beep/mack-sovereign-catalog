// ============================================================================
// anomaly.h — rolling-baseline anomaly detection for SF-ITES.
//
// Pure logic, no hardware access: feed it one current sample per second and
// it maintains baselines and evaluates cavitation / bearing-wear / phase
// imbalance. Anomaly outputs are ADVISORY (logged, shown on dashboard);
// only the safety controller trips the relay. Cavitation is the exception:
// it is evaluated in the safety controller because it indicates the pump
// is actively destroying itself.
//
// Design notes:
//  - Exponential moving averages keep RAM constant (no history buffers).
//  - All thresholds come from config.h.
// ============================================================================
#pragma once
#include <Arduino.h>
#include "config.h"

// ---------------------------------------------------------------------------
// CurrentBaseline — dual-EMA tracker for one current channel.
// fast EMA  ~= 1 hour window  -> tracks "recent normal"
// slow EMA  ~= 7 day  window  -> tracks "long-term normal"
// A persistent gap between them means the pump's behavior drifted.
// ---------------------------------------------------------------------------
class CurrentBaseline {
public:
  CurrentBaseline();
  void begin(float initial_amps);
  void update(float amps);          // call at 1 Hz while pump is RUNNING only
  float fast() const { return ema_fast_; }
  float slow() const { return ema_slow_; }
  bool  ready() const { return samples_ >= 60; }  // need ~1 min before trust
  // Percent drift of recent behavior vs long-term: + = drawing more current.
  float driftPct() const;

private:
  float ema_fast_;
  float ema_slow_;
  uint32_t samples_;
};

// ---------------------------------------------------------------------------
// FlowBaseline — simple EMA of flow for cavitation comparison.
// ---------------------------------------------------------------------------
class FlowBaseline {
public:
  FlowBaseline();
  void begin(float lpm);
  void update(float lpm);           // 1 Hz while RUNNING
  float value() const { return ema_; }
  bool  ready() const { return samples_ >= 60; }

private:
  float ema_;
  uint32_t samples_;
};

// ---------------------------------------------------------------------------
// Static evaluators. Return true when the condition is met.
// ---------------------------------------------------------------------------
namespace anomaly {

// Cavitation signature: current AND flow both collapse relative to baseline
// (impeller churning vapor instead of water). Called by safety controller.
bool isCavitation(float current_a, float current_baseline_a,
                  float flow_lpm,  float flow_baseline_lpm);

// Bearing-wear signature: sustained upward drift of current baseline.
// Advisory only — schedule maintenance, do not trip.
bool isBearingWear(float drift_pct);

// Phase imbalance across 3 CT channels: (max - min) / mean * 100.
// Returns -1.0 if CT_CHANNELS != 3 (feature unavailable, not an error).
float phaseImbalancePct(const float amps[3]);

} // namespace anomaly
