// ============================================================================
// sf_ites_main.ino — SF-ITES edge firmware (ESP32)
//
// What this does, every SENSOR_READ_MS (1 s):
//   1. Read CT current (RMS over one mains cycle), flow pulses, pressure,
//      motor temperature.
//   2. Feed current/flow into the anomaly baselines (RUNNING only).
//   3. Run the safety controller (may trip the relay).
//   4. Emit one JSON telemetry line over USB serial for the Pi gateway.
//   5. Service serial commands: START / RESET / STATUS.
//   6. Feed the hardware watchdog.
//
// Required Arduino libraries (install via Library Manager):
//   - OneWire            (for DS18B20)
//   - DallasTemperature  (for DS18B20)
//
// Telemetry line format (one JSON object per line, 1 Hz):
//   {"t":123456,"i":[4.21,0,0],"flow":38.7,"press":312.5,"temp":41.2,
//    "state":"RUNNING","trip":"NONE","warn":["OVERTEMP_WARN"],
//    "drift":3.1,"imb":-1}
// Alert lines (emitted on transitions only):
//   {"alert":"TRIP","trip":"DRY_RUN","t":123456}
// ============================================================================

#include <Arduino.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <esp_task_wdt.h>
#include <Preferences.h>

#include "config.h"
#include "anomaly.h"
#include "safety.h"
#include "signing.h"

// ---------------------------------------------------------------------------
// Globals
// ---------------------------------------------------------------------------
OneWire oneWire(PIN_TEMP_ONEWIRE);
DallasTemperature tempSensor(&oneWire);

SafetyController safety;
CurrentBaseline  currentBaseline;
FlowBaseline     flowBaseline;
Preferences      nvs;   // seq counter persistence (replay protection)

volatile uint32_t flowPulses = 0;   // incremented by ISR
uint32_t lastFlowCalcMs = 0;
uint32_t lastSampleMs = 0;
uint32_t lastSignedMs = 0;

int  tempBadReads = 0;
bool tempPresent = false;

// Signing state.
uint64_t pktSeq = 0;          // persisted in NVS, survives reboot
bool     keyProvisioned = false;
uint8_t  signingSeed[32] = SIGNING_KEY_SEED;

// TEST_MODE script timeline (bench validation only — see config.h)
#if TEST_MODE
uint32_t testStartMs = 0;
#endif

// ---------------------------------------------------------------------------
// Interrupt: count YF-S201 hall pulses. Keep it minimal — just increment.
// ---------------------------------------------------------------------------
void IRAM_ATTR flowISR() { flowPulses++; }

// ---------------------------------------------------------------------------
// readCurrentRMS(channel_pin) — true-RMS current via the CT sensor.
//
// Samples the ADC for CT_RMS_WINDOW_MS (> one mains cycle), subtracts the
// DC bias midpoint, computes RMS of the AC component, converts to amps:
//   Vrms_adc = rms_counts * (ADC_VREF / ADC_MAX_COUNTS)
//   Irms     = Vrms_adc * CT_AMPS_PER_VOLT      (SCT-013-030V: 30 A/V)
//
// NOTE: the ESP32 ADC is nonlinear near the rails; for best accuracy,
// calibrate CT_AMPS_PER_VOLT against a clamp meter at your typical load.
// ---------------------------------------------------------------------------
float readCurrentRMS(uint8_t pin) {
  uint32_t start = millis();
  uint32_t n = 0;
  // mid-point of the bias divider; measure yours and set ADC_MIDPOINT here
  // if it differs. Nominal: 2048 for a 1.65 V bias on a 3.3 V, 12-bit ADC.
  const float MID = 2048.0f;
  double sumSq = 0;
  while (millis() - start < CT_RMS_WINDOW_MS) {
    float v = (float)analogRead(pin) - MID;
    sumSq += (double)(v * v);
    n++;
  }
  if (n == 0) return 0;
  float rmsCounts = sqrt(sumSq / (double)n);
  float vrms = rmsCounts * (ADC_VREF / ADC_MAX_COUNTS);
  return vrms * CT_AMPS_PER_VOLT;
}

// ---------------------------------------------------------------------------
// readFlowLPM() — convert counted pulses since last call into L/min.
// ---------------------------------------------------------------------------
float readFlowLPM(uint32_t nowMs) {
  uint32_t dt = nowMs - lastFlowCalcMs;
  if (dt == 0) return 0;
  noInterrupts();
  uint32_t pulses = flowPulses;
  flowPulses = 0;
  interrupts();
  lastFlowCalcMs = nowMs;
  float liters = (float)pulses / FLOW_PULSES_PER_LITER;
  return liters / ((float)dt / 60000.0f);
}

// ---------------------------------------------------------------------------
// readPressurekPa() — 0.5..4.5 V transducer -> 0..PRESS_KPA_MAX.
// ---------------------------------------------------------------------------
float readPressurekPa() {
  // Average a few reads to knock down ADC noise.
  long acc = 0;
  for (int i = 0; i < 8; i++) acc += analogRead(PIN_PRESSURE);
  float volts = ((float)acc / 8.0f) * (ADC_VREF / ADC_MAX_COUNTS);
  if (volts < PRESS_V_MIN - 0.2f || volts > PRESS_V_MAX + 0.5f) {
    return NAN;  // wire broken / shorted — plausibility failure
  }
  float kpa = (volts - PRESS_V_MIN) / (PRESS_V_MAX - PRESS_V_MIN) * PRESS_KPA_MAX;
  if (kpa < 0) kpa = 0;
  return kpa;
}

// ---------------------------------------------------------------------------
// readTempC() — DS18B20. Returns NAN on disconnect/failure.
// ---------------------------------------------------------------------------
float readTempC() {
  tempSensor.requestTemperatures();
  float t = tempSensor.getTempCByIndex(0);
  if (t <= -127.0f + 0.5f) return NAN;  // DEVICE_DISCONNECTED_C
  if (t < -40.0f || t > 150.0f) return NAN;  // outside sensor range
  return t;
}

// ---------------------------------------------------------------------------
// Plausibility: is this snapshot physically sane?
// ---------------------------------------------------------------------------
bool snapshotValid(float i0, float flow, float press, float temp) {
  if (isnan(temp) || isnan(press)) return false;
  if (i0 < 0 || i0 > PUMP_RATED_CURRENT_A * 8.0f) return false;  // absurd
  if (flow < 0 || flow > PUMP_RATED_FLOW_LPM * 3.0f) return false;
  return true;
}

#if TEST_MODE
// ---------------------------------------------------------------------------
// TEST_MODE: synthesize a scripted sensor scenario for bench validation.
// Timeline (loops every 90 s):
//   0-25 s : normal running      (8 A, 40 L/min, 300 kPa, 45 C)
//  25-40 s : DRY RUN             (flow -> 0.5, current stays 7.5 A)
//  40-55 s : OVERCURRENT spike   (18 A)
//  55-70 s : OVERTEMP ramp       (temp climbs past 85 C)
//  70-90 s : back to normal
// Expected: relay opens on dry-run at ~35 s, latches TRIPPED.
// Send RESET + START over serial to continue the script.
// ---------------------------------------------------------------------------
void testSynthesis(float &i0, float &flow, float &press, float &temp,
                   uint32_t nowMs) {
  uint32_t t = ((nowMs - testStartMs) / 1000) % 90;
  i0 = 8.0f; flow = 40.0f; press = 300.0f; temp = 45.0f;
  if (t >= 25 && t < 40)      { flow = 0.5f; i0 = 7.5f; }            // dry run
  else if (t >= 40 && t < 55) { i0 = 18.0f; }                        // overcurrent
  else if (t >= 55 && t < 70) { temp = 45.0f + (t - 55) * 3.0f; }    // overtemp
}
#endif

// ---------------------------------------------------------------------------
// Signing helpers
// ---------------------------------------------------------------------------
// True if every byte of the seed is zero (not provisioned).
bool signingKeyPresent() {
  for (int i = 0; i < 32; i++) {
    if (signingSeed[i] != 0) return true;
  }
  return false;
}

// Load/persist the packet sequence counter. The ingestor rejects replays
// (seq <= last seen) and large gaps (>1000), so on boot we jump forward by
// a safe margin and persist periodically (flash wear: not every packet).
void signingSeqBegin() {
  nvs.begin("sfites", false);
  pktSeq = nvs.getULong64("pktseq", 0);
  pktSeq += 512;  // reboot jump: within the ingestor's 1000-gap tolerance
  nvs.putULong64("pktseq", pktSeq);
}

void signingSeqPersist() {
  static uint64_t lastPersisted = 0;
  if (pktSeq - lastPersisted >= 64) {
    nvs.putULong64("pktseq", pktSeq);
    lastPersisted = pktSeq;
  }
}

// Values must satisfy the Rust ingestor's schema validation, else the
// packet is rejected on receipt. (NaN/inf are rejected explicitly.)
bool packetValuesValid(float i, float flow, float temp, float press) {
  if (!isfinite(i) || !isfinite(flow) || !isfinite(temp) || !isfinite(press))
    return false;
  if (i < 0.0f || i > 50.0f) return false;
  if (flow < 0.0f || flow > 100.0f) return false;
  if (temp < -20.0f || temp > 150.0f) return false;
  if (press < 0.0f || press > 2000.0f) return false;
  return true;
}

// Emit the signed audit packet (or explicit unsigned marker).
// Called at SIGNED_PACKET_INTERVAL_MS from loop().
//
// Wire format: the canonical packet JSON (exactly what was signed),
// plus a trailing field:
//   signed:   {...,"pressure_kpa":300.0,"signature":[192,207,...]}
//   unsigned: {...,"pressure_kpa":300.0,"unsigned":true}
// The "signature" array is serde_json's Vec<u8> format (64 ints 0-255),
// which is what the Rust TelemetryPacket deserializer expects.
// "unsigned" is ignored by the Rust deserializer (no deny_unknown_fields)
// but lets the gateway alert instead of silently missing signatures.
void emitSignedPacket(float i0, float flow, float press, float temp,
                      uint32_t nowMs) {
  // timestamp_ms: millis() uptime. PRODUCTION MUST USE NTP wall-clock:
  // the ingestor's future-skew check and audit trail assume Unix time.
  // (Schema validation only rejects >5min-future timestamps, so uptime
  // millis pass, but they are not meaningful audit timestamps.)
  int64_t timestamp_ms = (int64_t)nowMs;

  char canon[512];
  uint8_t sig[64];
  pktSeq++;

#if !SIGNING_ENABLED
  // Bench mode: explicitly unsigned, never silent.
  if (!build_canonical_json(canon, sizeof(canon), DEVICE_ID, pktSeq,
                            timestamp_ms, i0, flow, temp, press)) {
    return;
  }
  size_t clen = strlen(canon);
  for (size_t k = 0; k + 1 < clen; k++) Serial.print(canon[k]);
  Serial.println(",\"unsigned\":true,\"reason\":\"SIGNING_ENABLED=0\"}");
  signingSeqPersist();
  return;
#endif

  if (!packetValuesValid(i0, flow, temp, press)) {
    // Sensor fault or out-of-range: do not sign a packet the ingestor
    // would reject. Legacy telemetry already reported the raw values.
    pktSeq--;  // don't burn a seq number on a skipped packet
    return;
  }

  if (keyProvisioned) {
    if (!sign_telemetry_packet(DEVICE_ID, pktSeq, timestamp_ms,
                               i0, flow, temp, press,
                               signingSeed, sig, canon, sizeof(canon))) {
      Serial.println("{\"error\":\"signing failed\"}");
      return;
    }
    // Append the signature field to the canonical JSON.
    size_t clen = strlen(canon);
    for (size_t k = 0; k + 1 < clen; k++) Serial.print(canon[k]);
    Serial.print(",\"signature\":[");
    for (int k = 0; k < 64; k++) {
      if (k) Serial.print(",");
      Serial.print(sig[k]);
    }
    Serial.println("]}");
  } else {
    // FAIL-SAFE: signing enabled but no key provisioned. Emit the packet
    // bytes with an explicit unsigned marker — never a silent omission.
    // The ingestor (require_signatures=1) will reject these per policy.
    if (!build_canonical_json(canon, sizeof(canon), DEVICE_ID, pktSeq,
                              timestamp_ms, i0, flow, temp, press)) {
      return;
    }
    size_t clen = strlen(canon);
    for (size_t k = 0; k + 1 < clen; k++) Serial.print(canon[k]);
    Serial.println(",\"unsigned\":true}");
  }

  signingSeqPersist();
}

// ---------------------------------------------------------------------------
// Serial command service (non-blocking).
// ---------------------------------------------------------------------------
void serviceSerial() {
  static char buf[32];
  static uint8_t idx = 0;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      buf[idx] = '\0'; idx = 0;
      if (!strcmp(buf, "START"))      safety.requestStart();
      else if (!strcmp(buf, "RESET")) safety.requestReset();
      else if (!strcmp(buf, "STATUS")) printStatus();
      else if (idx > 0) { Serial.print("{\"error\":\"unknown cmd\"}\n"); }
    } else if (idx < sizeof(buf) - 1) {
      buf[idx++] = c;
    }
  }
}

void printStatus() {
  Serial.print("{\"status\":\"");
  Serial.print(safetyStateName(safety.state()));
  Serial.print("\",\"trip\":\"");
  Serial.print(tripReasonName(safety.tripReason()));
  Serial.println("\"}");
}

// ---------------------------------------------------------------------------
// Status LED: blink pattern encodes state (visible diagnostics, no tools).
//   STANDBY : slow blink (1 Hz)    RUNNING : solid on
//   TRIPPED : fast blink (4 Hz)    SELFTEST: double-blink
// ---------------------------------------------------------------------------
void updateLED(uint32_t nowMs) {
  SafetyState s = safety.state();
  bool on = false;
  if (s == ST_RUNNING) on = true;
  else if (s == ST_STANDBY) on = (nowMs % 1000) < 500;
  else if (s == ST_TRIPPED) on = (nowMs % 250) < 125;
  else if (s == ST_SELFTEST) on = ((nowMs % 1000) < 150) || ((nowMs % 1000) > 300 && (nowMs % 1000) < 450);
  digitalWrite(PIN_STATUS_LED, on ? HIGH : LOW);
}

// ---------------------------------------------------------------------------
// setup() — ORDER IS SAFETY-CRITICAL. safety.begin() FIRST.
// ---------------------------------------------------------------------------
void setup() {
  // 1. Relay to safe state before ANYTHING else (see safety.h).
  safety.begin();

  // 2. Serial for telemetry + commands.
  Serial.begin(SERIAL_BAUD);
  while (!Serial) { /* wait for USB serial */ }
  Serial.println("{\"boot\":\"SF-ITES edge firmware v1.0\"}");

  // 3. ADC + flow interrupt.
  analogReadResolution(12);
  pinMode(PIN_FLOW, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_FLOW), flowISR, FALLING);

  // 4. Temperature sensor.
  tempSensor.begin();
  tempPresent = (tempSensor.getDeviceCount() > 0);
  if (!tempPresent) {
    Serial.println("{\"warn\":\"DS18B20 not found at boot\"}");
  }

  // 5. Baselines seeded on first RUNNING samples (see loop).
  lastFlowCalcMs = millis();
  lastSampleMs = millis();
  lastSignedMs = millis();
#if TEST_MODE
  testStartMs = millis();
  Serial.println("{\"warn\":\"TEST_MODE=1 bench synthesis active\"}");
#endif

  // 5b. Signing subsystem: self-test the crypto, load seq, check key.
  // This runs AFTER the relay is safe but BEFORE any telemetry.
  if (!signing_self_test()) {
    // Crypto misconfiguration. The safety controller still runs, but we
    // must not emit signatures from a broken implementation. Force the
    // unsigned fail-safe path for this boot.
    Serial.println("{\"error\":\"signing self-test FAILED; signatures disabled this boot\"}");
    keyProvisioned = false;
  } else {
    keyProvisioned = signingKeyPresent();
#if SIGNING_ENABLED
    if (!keyProvisioned) {
      Serial.println("{\"warn\":\"SIGNING_ENABLED=1 but no key provisioned; emitting unsigned markers\"}");
    }
#else
    Serial.println("{\"warn\":\"SIGNING_ENABLED=0; emitting unsigned markers (bench mode)\"}");
#endif
  }
  signingSeqBegin();

  // 6. Hardware watchdog: if loop() hangs > WATCHDOG_TIMEOUT_S the ESP32
  //    resets, setup() runs again, relay stays open. Fail-safe by reboot.
  esp_task_wdt_init(WATCHDOG_TIMEOUT_S, true);
  esp_task_wdt_add(NULL);

  Serial.println("{\"state\":\"SELFTEST\"}");
}

// ---------------------------------------------------------------------------
// loop()
// ---------------------------------------------------------------------------
void loop() {
  uint32_t nowMs = millis();
  serviceSerial();

  if (nowMs - lastSampleMs >= SENSOR_READ_MS) {
    lastSampleMs = nowMs;

    float i0, flow, press, temp;
    float amps[3] = {0, 0, 0};
#if TEST_MODE
    testSynthesis(i0, flow, press, temp, nowMs);
    amps[0] = i0;
#else
    // Read current channels (CT_RMS_WINDOW_MS each — keep CT_CHANNELS=1
    // unless you need 3-phase; each channel costs a sampling window).
    for (int c = 0; c < CT_CHANNELS; c++) {
      uint8_t pin = (c == 0) ? PIN_CT1 : (c == 1) ? PIN_CT2 : PIN_CT3;
      amps[c] = readCurrentRMS(pin);
    }
    i0 = amps[0];
    flow  = readFlowLPM(nowMs);
    press = readPressurekPa();
    temp  = readTempC();
#endif

    bool valid = snapshotValid(i0, flow, press, temp);

    // Baselines learn ONLY while actually running (current > 1 A and the
    // controller agrees). Learning during standby would poison them.
    bool running = (safety.state() == ST_RUNNING);
    static bool baselinesSeeded = false;
    if (running && valid) {
      if (!baselinesSeeded) {
        currentBaseline.begin(i0);
        flowBaseline.begin(flow);
        baselinesSeeded = true;
      } else {
        currentBaseline.update(i0);
        flowBaseline.update(flow);
      }
    }
    if (!running) baselinesSeeded = false;  // re-seed on next run

    SensorSnapshot snap;
    snap.current_a[0] = i0;
    snap.current_a[1] = amps[1];
    snap.current_a[2] = amps[2];
    snap.flow_lpm = flow;
    snap.pressure_kpa = press;
    snap.temp_c = temp;
    snap.sensors_valid = valid;
    snap.current_baseline_a = currentBaseline.ready() ? currentBaseline.fast() : 0;
    snap.flow_baseline_lpm  = flowBaseline.ready() ? flowBaseline.value() : 0;
    snap.baselines_ready = currentBaseline.ready() && flowBaseline.ready();

    SafetyState prev = safety.state();
    SafetyState cur  = safety.update(snap, nowMs);
    if (cur != prev) {
      // Emit alert line on every state transition (gateway logs these).
      Serial.print("{\"alert\":\"STATE\",\"from\":\"");
      Serial.print(safetyStateName(prev));
      Serial.print("\",\"to\":\"");
      Serial.print(safetyStateName(cur));
      Serial.print("\",\"t\":");
      Serial.print(nowMs);
      Serial.println("}");
      if (cur == ST_TRIPPED) {
        Serial.print("{\"alert\":\"TRIP\",\"trip\":\"");
        Serial.print(tripReasonName(safety.tripReason()));
        Serial.print("\",\"t\":");
        Serial.print(nowMs);
        Serial.println("}");
      }
    }

    // Advisory warnings (do not trip).
    char warnBuf[64] = "";
    if (valid && temp >= OVERTEMP_WARN_C && temp < OVERTEMP_TRIP_C)
      strcat(warnBuf, "\"OVERTEMP_WARN\"");
    if (snap.baselines_ready &&
        anomaly::isBearingWear(currentBaseline.driftPct())) {
      if (warnBuf[0]) strcat(warnBuf, ",");
      strcat(warnBuf, "\"BEARING_WEAR\"");
    }

    // 1 Hz telemetry line.
    Serial.print("{\"t\":");            Serial.print(nowMs);
    Serial.print(",\"i\":[");          Serial.print(i0, 2);
    Serial.print(",");                 Serial.print(amps[1], 2);
    Serial.print(",");                 Serial.print(amps[2], 2);
    Serial.print("],\"flow\":");       Serial.print(flow, 1);
    Serial.print(",\"press\":");       Serial.print(press, 1);
    Serial.print(",\"temp\":");        Serial.print(temp, 1);
    Serial.print(",\"state\":\"");     Serial.print(safetyStateName(cur));
    Serial.print("\",\"trip\":\"");    Serial.print(tripReasonName(safety.tripReason()));
    Serial.print("\",\"warn\":[");     Serial.print(warnBuf);
    Serial.print("],\"drift\":");      Serial.print(currentBaseline.driftPct(), 1);
    Serial.print(",\"imb\":");         Serial.print(anomaly::phaseImbalancePct(amps), 1);
    Serial.println("}");

    // Signed audit packet (Rust ingestion contract). Emitted on its own
    // interval; the legacy line above is untouched for the Pi gateway.
    if (nowMs - lastSignedMs >= SIGNED_PACKET_INTERVAL_MS) {
      lastSignedMs = nowMs;
      emitSignedPacket(i0, flow, press, temp, nowMs);
    }
  }

  updateLED(nowMs);
  esp_task_wdt_reset();  // prove we're alive
}
