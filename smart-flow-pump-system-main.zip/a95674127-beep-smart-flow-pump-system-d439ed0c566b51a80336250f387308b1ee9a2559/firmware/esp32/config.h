// ============================================================================
// SF-ITES — Smart-Flow Integrated Thermal Extraction System
// config.h — ALL tunable parameters, pin assignments, and timing constants.
//
// Edit ONLY this file to adapt SF-ITES to a different pump. Everything else
// reads from here. Values marked EXAMPLE must be calibrated to your pump.
// ============================================================================
#pragma once

// ---------------------------------------------------------------------------
// OPERATING MODES
// ---------------------------------------------------------------------------
// TEST_MODE: when 1, sensor readings are SYNTHESIZED in firmware following a
// scripted scenario (normal -> dry-run -> overcurrent -> overtemp). Use this
// to validate safety logic on the bench with NO pump connected. NEVER deploy
// with TEST_MODE 1 on a real pump.
#define TEST_MODE 0

// AUTO_START: when 1, the pump relay closes automatically after a passing
// self-test on boot. When 0 (default, safer), an operator must press the
// START button (or send "START" over serial) after every boot/reset.
#define AUTO_START 0

// ---------------------------------------------------------------------------
// PIN ASSIGNMENTS (ESP32 DevKit v1 / WROOM-32)
// Avoid strapping pins (0, 2, 5, 12, 15) for anything critical at boot.
// ---------------------------------------------------------------------------
#define PIN_CT1          34   // ADC1 Ch6 — phase A CT sensor (input-only pin, OK)
#define PIN_CT2          35   // ADC1 Ch7 — phase B CT sensor (optional, 3-phase)
#define PIN_CT3          32   // ADC1 Ch4 — phase C CT sensor (optional, 3-phase)
#define PIN_FLOW         25   // interrupt-capable — YF-S201 pulse output
#define PIN_PRESSURE     33   // ADC1 Ch5 — 0.5..4.5 V pressure transducer
#define PIN_TEMP_ONEWIRE 26   // DS18B20 data line (4.7k pull-up to 3.3V)
#define PIN_RELAY        27   // relay driver input
#define PIN_START_BTN    14   // active-LOW pushbutton, internal pull-up
#define PIN_RESET_BTN    4    // active-LOW pushbutton, internal pull-up
#define PIN_STATUS_LED   2    // onboard blue LED (blinks by state)
#define PIN_BUZZER       13   // optional piezo alarm, active-HIGH

// How many CT channels are actually wired: 1 or 3.
// Phase-imbalance detection REQUIRES 3. With 1 channel it is compiled out
// and reported as unavailable — single-phase installs cannot detect it.
#define CT_CHANNELS 1

// ---------------------------------------------------------------------------
// RELAY FAIL-SAFE DEFINITION
// ---------------------------------------------------------------------------
// Most relay modules are ACTIVE-LOW: GPIO LOW energizes the coil.
// RELAY_ENGAGED_LEVEL = the level that CLOSES the pump power circuit.
// The firmware drives the pin to the OPPOSITE level FIRST THING in setup(),
// before any sensor init, so a brown-out or watchdog reset can never leave
// the pump energized through a reboot.
//
// Wire the relay's NORMALLY-OPEN (NO) contact in series with the pump's
// hot conductor. De-energized coil = open contact = pump OFF, always.
#define RELAY_ENGAGED_LEVEL   LOW
#define RELAY_SAFE_LEVEL      HIGH   // de-energized

// ---------------------------------------------------------------------------
// CT CURRENT SENSOR (SCT-013-030V voltage-output type recommended)
// Output: 0..1 VAC proportional to 0..30 A. Biased to mid-rail (1.65 V)
// with a resistor divider — see docs/WIRING.md.
// ---------------------------------------------------------------------------
#define MAINS_FREQ_HZ        60      // 50 or 60 — sets RMS sampling window
#define CT_AMPS_PER_VOLT     30.0f   // SCT-013-030V: 30 A per 1 V RMS
#define ADC_VREF             3.3f    // ESP32 ADC reference (calibrate!)
#define ADC_MAX_COUNTS       4095.0f // 12-bit ADC
#define CT_RMS_WINDOW_MS     25      // sampling window (> 1 mains cycle)

// ---------------------------------------------------------------------------
// FLOW METER (YF-S201 hall-effect)
// ---------------------------------------------------------------------------
#define FLOW_PULSES_PER_LITER 450.0f  // YF-S201 nominal
#define FLOW_READ_INTERVAL_MS 1000    // recompute L/min every 1 s

// ---------------------------------------------------------------------------
// PRESSURE TRANSDUCER (0.5..4.5 V  ->  0..1200 kPa, typical 0-1.2 MPa unit)
// ---------------------------------------------------------------------------
#define PRESS_V_MIN      0.5f     // volts at 0 kPa
#define PRESS_V_MAX      4.5f     // volts at full scale
#define PRESS_KPA_MAX    1200.0f

// ---------------------------------------------------------------------------
// PUMP RATINGS  *** EXAMPLE VALUES — CALIBRATE TO YOUR PUMP ***
// ---------------------------------------------------------------------------
#define PUMP_RATED_CURRENT_A  8.0f   // nameplate full-load amps
#define PUMP_RATED_FLOW_LPM   40.0f  // nominal flow, liters/min

// ---------------------------------------------------------------------------
// SAFETY TRIP THRESHOLDS
// ---------------------------------------------------------------------------
// Dry-run: flow collapsed but motor still drawing current (impeller
// spinning in air/water-vapor). Destroys seals and impellers in minutes.
#define DRY_RUN_FLOW_LPM        2.0f  // flow below this = "no flow"
#define DRY_RUN_CURRENT_A       1.0f  // current above this = "motor turning"
#define DRY_RUN_TRIP_SECONDS    10    // sustain time before trip

// Overcurrent: instantaneous-ish trip, but motor INRUSH at startup is
// 4-7x running current for a few seconds. STARTUP_GRACE_S + INRUSH_A
// keep normal starts from tripping while still catching real faults.
#define OVERCURRENT_FACTOR      1.5f  // x rated current => trip
#define STARTUP_GRACE_S         5     // inrush window after relay closes
#define INRUSH_FACTOR           4.0f  // x rated current allowed during grace

// Overtemperature: motor casing / winding temperature.
#define OVERTEMP_TRIP_C         85.0f // trip above this
#define OVERTEMP_WARN_C         70.0f // warning only (no trip)

// Phase imbalance (3-phase only): (max-min)/avg across CT channels.
#define PHASE_IMBALANCE_PCT     15.0f // trip above this %

// Sensor plausibility: N consecutive bad reads => SENSOR_FAULT trip.
// (A single glitch should not kill the pump; a dead sensor must not
//  let it run blind.)
#define SENSOR_BAD_READ_LIMIT   5

// ---------------------------------------------------------------------------
// ANOMALY DETECTION (advisory — flags, does not trip, except cavitation)
// ---------------------------------------------------------------------------
// Cavitation: current AND flow both collapse vs baseline (vapor in pump).
#define CAVITATION_I_DROP_PCT   20.0f
#define CAVITATION_F_DROP_PCT   30.0f

// Bearing wear: slow upward drift of current baseline. Compares a fast
// (~1 h) EMA against a slow (~7 day) EMA of running current.
#define BEARING_WEAR_DRIFT_PCT  15.0f

// Baseline EMA smoothing: smaller alpha = slower adaptation.
#define BASELINE_ALPHA_FAST     0.02f   // ~1 h at 1 Hz samples
#define BASELINE_ALPHA_SLOW     0.0002f // ~7 days at 1 Hz samples

// ---------------------------------------------------------------------------
// TIMING
// ---------------------------------------------------------------------------
#define SENSOR_READ_MS        1000  // main loop sample period
#define SERIAL_BAUD           115200
#define WATCHDOG_TIMEOUT_S    10    // task watchdog; reset => relay safe

// Serial command interface (USB serial, newline-terminated):
//   START   - request pump start (from STANDBY)
//   RESET   - clear latched trip, re-run self-test
//   STATUS  - print one-line state summary

// ---------------------------------------------------------------------------
// ED25519 PACKET SIGNING (audit-chained telemetry)
// ---------------------------------------------------------------------------
// SIGNING_ENABLED: when 1 (default), each 1 Hz telemetry sample is ALSO
// emitted as a signed packet (Rust ingestion contract: canonical JSON ->
// SHA-256 -> Ed25519 over the 32 raw digest bytes). When 0, the signed
// packet line is emitted with "unsigned":true and no signature — for bench
// testing without keys. The legacy telemetry line is always emitted.
//
// If SIGNING_ENABLED=1 but no key is provisioned (seed all zeros), the
// firmware emits "unsigned":true rather than failing silently. The safety
// controller is NEVER gated on signing; only the audit packet is affected.
//
// Library: rweather "Crypto" (Arduino Library Manager) for Ed25519,
// ESP32 mbedTLS for SHA-256. See signing.h for the byte-level contract.
#define SIGNING_ENABLED 1

// DEVICE_ID: stable identifier for this pump. MUST match the device_id
// registered with the telemetry ingestor (it keys replay protection and
// signature verification per device).
#define DEVICE_ID "pump-01"

// SIGNING_KEY_SEED: 32-byte Ed25519 private key seed. ALL ZEROS = not
// provisioned (fail-safe unsigned mode). Generate OFFLINE on a trusted
// machine (see docs/keymgmt.md). NEVER commit a real key to source control.
// Production: store in encrypted NVS or an ATECC608A secure element and
// leave this as zeros.
#define SIGNING_KEY_SEED { \
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, \
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, \
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, \
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 }

// SIGNED_PACKET_INTERVAL_MS: how often to emit the signed audit packet.
// 1000 = every sample (matches SENSOR_READ_MS). Increase to reduce bandwidth.
#define SIGNED_PACKET_INTERVAL_MS 1000
