# SF-ITES Signing Contract (v1)

Byte-level specification of the Ed25519 telemetry signing scheme shared by
the ESP32 firmware (`firmware/esp32/signing.cpp`) and the Rust ingestion
verifier (`ai-infinity-force-one-vault/src/telemetry/`).

**Status:** Verified by differential test — 1,522 vectors, 100% byte-identical
canonical JSON between the C++ and Rust implementations, plus a live
C++-sign → Rust-verify cross-check (see Verification below).

## What is signed

The signature covers the **32 raw bytes of SHA-256(canonical JSON)** — NOT
the hex string, NOT the JSON itself.

```
signature = Ed25519_sign(seed, SHA256(canonical_json_bytes))
```

The Rust verifier (`ingest.rs`) does:
```rust
verifying_key.verify(&packet.packet_hash(), &signature)
```
where `packet_hash()` returns the 32-byte SHA-256 digest. The firmware MUST
sign exactly those 32 bytes.

## Canonical JSON (the bytes that are hashed)

The canonical form is defined by Rust `serde_json` serialization of:

```rust
struct CanonicalPacket<'a> {
    schema_version: u32,    // 1
    device_id: &'a str,     // e.g. "pump-01"
    seq: u64,               // monotonic per device, persisted across reboots
    timestamp_ms: i64,       // Unix ms (firmware: millis() until NTP lands)
    current_rms: f32,
    flow_rate: f32,
    temp_c: f32,
    pressure_kpa: f32,
}
```

Serialized with **no whitespace**, fields in **declaration order**:

```json
{"schema_version":1,"device_id":"pump-01","seq":42,"timestamp_ms":1784000001234,"current_rms":7.5,"flow_rate":12.25,"temp_c":45.0,"pressure_kpa":300.0}
```

Integers (`schema_version`, `seq`, `timestamp_ms`) are plain decimal.
`device_id` is a JSON string (firmware assumes alphanumeric; no escaping
implemented — see Limitations).

### Float formatting (the hard part)

Rust `serde_json` formats `f32` with the **shortest string that round-trips**,
using the **closest** such string on ties, then:

- Decimal notation if `-6 <= exp10 <= 12` (exp10 = exponent of leading digit)
- Scientific notation otherwise: `1e-7`, `1e+13` (note: `e+`, no leading zero)
- Always contains `.` or `e`: `45.0`, `300.0`, never `45`
- `-0.0` is preserved as `-0.0`

The firmware replicates this with a **neighbor-trial algorithm**
(`format_f32_json` in `signing.cpp`), NOT printf:

1. For precision p = 1..9: format with `%.*g`, parse the decimal digits.
2. Try digit strings ±2 around the parsed value (catches printf rounding
   picking the wrong neighbor — e.g. `%.9g` gives `0.33333333` where
   serde_json wants `0.33333334`).
3. For each candidate: re-layout per the decimal/scientific rule, check
   `strtof(candidate)` bit-equals the original float.
4. Among all round-tripping candidates at the shortest precision, keep the
   **numerically closest** to the true value (serde_json tie-break rule).
5. If no candidate round-trips at any precision (should not happen for
   finite f32), fail loudly — never emit a guess.

Empirically discovered serde_json rules (do not assume — these were measured):
- `1/3f` → `"0.33333334"` (printf `%.*g` gives `"0.33333333"` — WRONG)
- `1e13` → `"1e+13"` but `9.99e12` → `"9990000000000.0"` (threshold at exp10=13)
- `1e-6` → `"0.000001"` but `1e-7` → `"1e-7"` (threshold at exp10=-7)

## Wire format (firmware → gateway)

The signed packet line is the canonical JSON plus a trailing field:

```json
{"schema_version":1,"device_id":"pump-01","seq":42,...,"pressure_kpa":300.0,"signature":[192,207,218,...,16]}
```

- `"signature"` is a JSON array of 64 integers (0–255) — this is serde_json's
  `Vec<u8>` format, exactly what the Rust `TelemetryPacket` deserializer expects.
- The signature field is NOT part of the canonical bytes (it covers them).

Fail-safe unsigned mode (no key provisioned, or `SIGNING_ENABLED=0`):

```json
{"schema_version":1,...,"pressure_kpa":300.0,"unsigned":true}
```

- `"unsigned"` is ignored by the Rust deserializer (no `deny_unknown_fields`)
  but lets the gateway alert. The ingestor with `require_signatures=1` rejects
  these per policy. **Unsigned packets are never emitted silently.**

## Test vectors

### Vector 1 — full chain (C++ → Rust verified)

Produced by `firmware/esp32/host_test/test_sign_chain`:

```
device seed:  01 08 0f 16 1d 24 2b 32 39 40 47 4e 55 5c 63 6a ...
              (bytes i*7+1 for i in 0..32; NOT a deployment key)
pubkey:       e4030998cfd5ad1723c169f956aa0b9eb8619b5992bd612c2af428ebc79f8df0
canonical:    {"schema_version":1,"device_id":"pump-01","seq":42,"timestamp_ms":1784000001234,"current_rms":7.5,"flow_rate":12.25,"temp_c":45.0,"pressure_kpa":300.0}
digest:       1a42d884b5974054926155a6236ed0f2f5f22d9ca15d4cef019993ad8c98202b
signature:    c0cfda3243b0efbbce4ed17605c2b062a0ca29977ac490fa4017196f5150b5f08f78015bfa4a9b2636bab70058591c4f0ab40c6a39e81ccfb99177d284427108
```

The Rust test `tests/test_cross_verify.rs` verifies:
1. `SHA256(canonical)` (Rust) == digest (C++) — pins "what is signed"
2. `ed25519_dalek` verifies signature over the 32 raw digest bytes
3. The canonical JSON parses as `TelemetryPacket` and re-serializes identically

### Vector 2 — RFC 8032 (Ed25519 sanity)

`signing_self_test()` (runs on every ESP32 boot) uses RFC 8032 §7.1 TEST 1:
seed `9d61b19d...cae7f60`, empty message, expects signature
`e5564300...7f34d`. This catches library misconfiguration before deployment.
(This seed is a published test vector, not a secret.)

## Verification performed (host-side, 2026-10-10)

| Check | Result |
|---|---|
| C++ canonical JSON vs Rust ground truth (15 vectors) | 15/15 byte-identical |
| Differential fuzz: 1,507 random/edge f32 values | 1,507/1,507 byte-identical |
| C++ self-test (RFC 8032 vector) | PASS |
| C++ sign → C++ verify round-trip | PASS |
| C++ digest == Rust SHA-256(canonical) | PASS |
| C++ signature verifies with `ed25519_dalek` | PASS |
| C++ canonical JSON parses as Rust `TelemetryPacket` | PASS |
| ESP32 hardware test | **NOT DONE** — no hardware available; host-only |

## Limitations (honest)

1. **No ESP32 hardware test.** The Ed25519 backend on-device is the rweather
   `Crypto` Arduino library (MIT), which is widely used and RFC 8032-compliant
   per its test suite, but I have not executed it on silicon. The host test
   uses OpenSSL as a stand-in behind the same API boundary.
2. **`device_id` escaping.** The firmware does not JSON-escape `device_id`;
   it must be alphanumeric. A hostile or malformed device ID could break
   canonicalization. (Mitigation: `DEVICE_ID` is a compile-time constant.)
3. **Timestamp source.** Firmware uses `millis()` (uptime), not Unix wall-clock.
   Schema validation passes (only >5min-future is rejected), but audit
   timestamps are meaningless until NTP is integrated. See `keymgmt.md`.
4. **Float NaN/inf.** The Rust side rejects non-finite floats. The firmware
   skips signing when any sensor reads NaN/inf or out of range — the legacy
   telemetry line still reports raw values, but no signed packet is emitted.
5. **Sequence persistence.** `seq` is kept in NVS with a +512 reboot jump
   (within the ingestor's 1000-gap tolerance) and persisted every 64 packets.
   A power loss within 64 packets of boot could theoretically reuse seq
   values — the ingestor's replay check is the backstop.
