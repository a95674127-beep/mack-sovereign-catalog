// ============================================================================
// signing.h — Ed25519 packet signing for SF-ITES telemetry.
//
// Signs the 32-byte SHA-256 digest of the canonical telemetry JSON, matching
// the Rust verifier in the MACK repo (src/telemetry/packet.rs + ingest.rs)
// byte-for-byte. See SIGNING_CONTRACT.md for the full specification.
//
// Library choice:
//   ESP32 (Arduino): rweather "Crypto" library (Arduino Library Manager).
//     - Ed25519::sign / Ed25519::verify / Ed25519::derivePublicKey
//     - MIT licensed. Pure C++, no dependencies.
//     - SHA-256 via ESP32 mbedTLS (built into the Arduino core).
//   Host test (g++): OpenSSL for both SHA-256 and Ed25519
//     (host_test/openssl_shim.c). TEST-ONLY; not shipped in firmware.
//     OpenSSL is used as a stand-in behind the same API boundary — the
//     cross-verification that matters is C++ -> Rust ed25519-dalek.
//
// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// ============================================================================
#pragma once

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// ---------------------------------------------------------------------------
// Canonical JSON
// ---------------------------------------------------------------------------
// Builds the canonical telemetry JSON, byte-identical to the Rust
// serde_json serialization in telemetry::packet::canonical_bytes():
//
//   {"schema_version":1,"device_id":"...","seq":N,"timestamp_ms":N,
//    "current_rms":F,"flow_rate":F,"temp_c":F,"pressure_kpa":F}
//
// Field order is FIXED (matches Rust struct declaration order).
// Float formatting replicates serde_json's f32 Display exactly — see
// signing.cpp for the algorithm and SIGNING_CONTRACT.md for the proof.
//
// Returns bytes written (excluding NUL terminator), or 0 if out_len is
// too small. The JSON is NUL-terminated on success.
// ---------------------------------------------------------------------------
size_t build_canonical_json(char *out, size_t out_len,
                            const char *device_id,
                            uint64_t seq,
                            int64_t timestamp_ms,
                            float current_rms,
                            float flow_rate,
                            float temp_c,
                            float pressure_kpa);

// ---------------------------------------------------------------------------
// SHA-256
// ---------------------------------------------------------------------------
// Computes SHA-256 digest of data. Backend: mbedTLS on ESP32, OpenSSL on host.
void sha256_digest(const uint8_t *data, size_t len, uint8_t digest_out[32]);

// ---------------------------------------------------------------------------
// Ed25519
// ---------------------------------------------------------------------------
// Signs the 32-byte digest with the 32-byte private key SEED.
// Produces a 64-byte signature. Returns true on success.
//
// Backend: rweather Crypto on ESP32, tweetnacl on host test.
// The public key is derived internally from the seed.
bool ed25519_sign_digest(const uint8_t digest[32],
                         const uint8_t privkey_seed[32],
                         uint8_t sig_out[64]);

// Verifies a signature (used by signing_self_test).
bool ed25519_verify_digest(const uint8_t digest[32],
                           const uint8_t sig[64],
                           const uint8_t pubkey[32]);

// Derives the 32-byte public key from the 32-byte private key seed.
// The public key is what gets registered with the ingestion server.
void ed25519_derive_pubkey(const uint8_t privkey_seed[32],
                           uint8_t pubkey_out[32]);

// ---------------------------------------------------------------------------
// Full pipeline
// ---------------------------------------------------------------------------
// Builds canonical JSON, hashes it, and signs the digest.
//   json_out/json_len : receives the canonical JSON (for transmission)
//   sig_out           : receives the 64-byte signature
// Returns true on success, false if any step fails (buffer too small, etc).
bool sign_telemetry_packet(const char *device_id,
                           uint64_t seq,
                           int64_t timestamp_ms,
                           float current_rms,
                           float flow_rate,
                           float temp_c,
                           float pressure_kpa,
                           const uint8_t privkey_seed[32],
                           uint8_t sig_out[64],
                           char *json_out, size_t json_len);

// ---------------------------------------------------------------------------
// Self-test
// ---------------------------------------------------------------------------
// Signs a fixed test vector with a fixed test key and verifies the
// signature. Call at boot when SIGNING_ENABLED=1, BEFORE sending any
// telemetry. Returns true if the crypto backend is working correctly.
// A false return means the crypto library is misconfigured — do NOT
// operate; the device cannot produce verifiable signatures.
bool signing_self_test(void);

#ifdef __cplusplus
}
#endif
