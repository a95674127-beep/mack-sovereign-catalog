// host_test/openssl_shim.c — Ed25519 backend for host testing signing.cpp.
//
// Implements the tweetnacl-compatible crypto_sign_* API using OpenSSL EVP.
// This is ONLY for host-side verification. On ESP32, signing.cpp uses the
// rweather Crypto library instead. The API boundary is identical, so a
// signature produced here is byte-identical to what a correct Ed25519
// implementation produces from the same (seed, message).

#include <openssl/evp.h>
#include <string.h>

int crypto_sign_seed_keypair(unsigned char *pk, unsigned char *sk,
                              const unsigned char *seed) {
    EVP_PKEY *pkey = EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, NULL,
                                                  seed, 32);
    if (!pkey) return -1;
    size_t pklen = 32;
    if (EVP_PKEY_get_raw_public_key(pkey, pk, &pklen) != 1 || pklen != 32) {
        EVP_PKEY_free(pkey);
        return -1;
    }
    memcpy(sk, seed, 32);
    memcpy(sk + 32, pk, 32);
    EVP_PKEY_free(pkey);
    return 0;
}

int crypto_sign_detached(unsigned char *sig, unsigned long long *siglen,
                         const unsigned char *m, unsigned long long mlen,
                         const unsigned char *sk) {
    // sk = seed || pubkey (64 bytes); Ed25519 uses the 32-byte seed.
    EVP_PKEY *pkey = EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, NULL,
                                                  sk, 32);
    if (!pkey) return -1;
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    if (!ctx) { EVP_PKEY_free(pkey); return -1; }
    size_t outlen = 64;
    int rc = -1;
    if (EVP_DigestSignInit(ctx, NULL, NULL, NULL, pkey) == 1 &&
        EVP_DigestSign(ctx, sig, &outlen, m, (size_t)mlen) == 1 &&
        outlen == 64) {
        *siglen = 64;
        rc = 0;
    }
    EVP_MD_CTX_free(ctx);
    EVP_PKEY_free(pkey);
    return rc;
}

int crypto_sign_verify_detached(const unsigned char *sig,
                                const unsigned char *m,
                                unsigned long long mlen,
                                const unsigned char *pk) {
    EVP_PKEY *pkey = EVP_PKEY_new_raw_public_key(EVP_PKEY_ED25519, NULL,
                                                 pk, 32);
    if (!pkey) return -1;
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    if (!ctx) { EVP_PKEY_free(pkey); return -1; }
    int rc = -1;
    if (EVP_DigestVerifyInit(ctx, NULL, NULL, NULL, pkey) == 1 &&
        EVP_DigestVerify(ctx, sig, 64, m, (size_t)mlen) == 1) {
        rc = 0;
    }
    EVP_MD_CTX_free(ctx);
    EVP_PKEY_free(pkey);
    return rc;
}
