// host_test/test_sign_chain.cpp — End-to-end signing chain verification.
//
// 1. Builds a canonical telemetry packet with signing.cpp
// 2. Hashes it (SHA-256) with signing.cpp
// 3. Signs the digest with Ed25519 (OpenSSL backend on host)
// 4. Prints pubkey, signature, and canonical JSON as hex for Rust verification
// 5. Also runs signing_self_test() (RFC 8032 vector)
//
// The Rust side (ed25519-dalek) verifies these outputs in
// test_cross_verify.rs. If that passes, the C++ -> Rust chain is proven.

#include <cstdio>
#include <cstdint>
#include <cstring>
#include "signing.h"

static void print_hex(const char *label, const uint8_t *data, size_t len) {
    printf("%s:", label);
    for (size_t i = 0; i < len; i++) printf("%02x", data[i]);
    printf("\n");
}

int main() {
    // 1. On-device self-test (RFC 8032 vector via the same code path).
    printf("self-test: %s\n", signing_self_test() ? "PASS" : "FAIL");
    if (!signing_self_test()) return 1;

    // 2. Full chain with a fresh key.
    // (Fixed seed for reproducibility; NOT a real deployment key.)
    uint8_t seed[32];
    for (int i = 0; i < 32; i++) seed[i] = (uint8_t)(i * 7 + 1);

    uint8_t pubkey[32];
    ed25519_derive_pubkey(seed, pubkey);
    print_hex("pubkey", pubkey, 32);

    // 3. Build + sign a realistic packet.
    char json[1024];
    uint8_t sig[64];
    bool ok = sign_telemetry_packet("pump-01", 42, 1784000001234LL,
                                    7.5f, 12.25f, 45.0f, 300.0f,
                                    seed, sig, json, sizeof(json));
    if (!ok) { printf("sign_telemetry_packet FAILED\n"); return 1; }
    printf("json:%s\n", json);
    print_hex("sig", sig, 64);

    // 4. Verify the signature with the C++ verifier too.
    uint8_t digest[32];
    sha256_digest((const uint8_t *)json, strlen(json), digest);
    print_hex("digest", digest, 32);
    printf("cpp-verify: %s\n",
           ed25519_verify_digest(digest, sig, pubkey) ? "PASS" : "FAIL");

    return 0;
}
