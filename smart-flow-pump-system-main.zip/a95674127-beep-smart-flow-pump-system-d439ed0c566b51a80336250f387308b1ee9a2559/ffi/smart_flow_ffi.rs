//! Smart Flow FFI — PyO3 Python extension module.
//!
//! Source: provided by Allen Mack 2026-10-09 (from parallel project).
//! SAFETY REVIEW 2026-10-09 — see notes below. This file is the ORIGINAL
//! as received; fixes are tracked separately.

use pyo3::prelude::*;
use pyo3::types::PyBytes;

/// Telemetry packet structure for pump flow, current, and temperature.
#[pyclass]
#[derive(Clone, Debug)]
pub struct SensorTelemetryPacket {
    #[pyo3(get, set)]
    pub device_id: u32,
    #[pyo3(get, set)]
    pub flow_rate_gpm: f32,
    #[pyo3(get, set)]
    pub motor_current_amps: f32,
    #[pyo3(get, set)]
    pub internal_temp_c: f32,
    #[pyo3(get, set)]
    pub timestamp_epoch: u64,
}

#[pymethods]
impl SensorTelemetryPacket {
    #[new]
    fn new(
        device_id: u32,
        flow_rate_gpm: f32,
        motor_current_amps: f32,
        internal_temp_c: f32,
        timestamp_epoch: u64,
    ) -> Self {
        SensorTelemetryPacket {
            device_id,
            flow_rate_gpm,
            motor_current_amps,
            internal_temp_c,
            timestamp_epoch,
        }
    }

    /// Evaluates dry-run and thermal overload conditions deterministically.
    fn evaluate_safety_status(&self) -> PyResult<bool> {
        // Dry-run protection: flow drops below threshold while motor is drawing current
        let is_dry_running = self.flow_rate_gpm < 1.5 && self.motor_current_amps > 2.0;

        // Thermal overload check
        let is_overheated = self.internal_temp_c > 85.0;

        if is_dry_running || is_overheated {
            Ok(false) // Trigger emergency cutoff
        } else {
            Ok(true) // Operating within safe parameters
        }
    }
}

/// Zero-copy byte buffer parser for encrypted telemetry chunks coming from the Mack stack.
#[pyfunction]
fn ingest_encrypted_telemetry(
    py: Python<'_>,
    encrypted_payload: &PyBytes,
    expected_nonce: &[u8],
) -> PyResult<Vec<u8>> {
    let payload_bytes = encrypted_payload.as_bytes();

    // Placeholder for Argon2id / XChaCha20-Poly1305 decryption pipeline
    if payload_bytes.is_empty() {
        return Err(pyo3::exceptions::PyValueError::new_err(
            "Payload buffer is empty.",
        ));
    }

    // Return decrypted bytes back to the Python control loop
    let decrypted_output = payload_bytes.to_vec();
    Ok(decrypted_output)
}

/// Python extension module registration for Smart-Flow FFI
#[pymodule]
fn smart_flow_ffi(_py: Python<'_>, m: &PyModule) -> PyResult<()> {
    m.add_class::<SensorTelemetryPacket>()?;
    m.add_function(wrap_pyfunction!(ingest_encrypted_telemetry, m)?)?;
    Ok(())
}
