//! Smart Flow FFI — PyO3 Python extension module (FIXED 2026-10-09).
//!
//! Fixes vs `smart_flow_ffi.rs` (original as received):
//!   1. CRITICAL: `ingest_encrypted_telemetry` now performs REAL
//!      ChaCha20Poly1305 decryption. Previously returned input bytes
//!      unchanged (plaintext passthrough mislabeled as decryption).
//!      Wire format: [ nonce (12 B) || ciphertext || tag (16 B) ].
//!   2. HIGH: NaN / infinite / out-of-range sensor readings no longer
//!      evaluate as "safe". `evaluate_safety_status` returns False
//!      (cutoff) on invalid data — fail-safe, matching the simulator.
//!   3. MEDIUM: Units standardized to L/min across the project.
//!      `flow_rate_gpm` renamed to `flow_rate_lpm`; dry-run threshold
//!      converted 1.5 GPM -> 5.7 L/min to preserve original intent.
//!
//! BREAKING CHANGES vs original:
//!   - Field `flow_rate_gpm` -> `flow_rate_lpm`
//!   - `ingest_encrypted_telemetry(key, encrypted_payload)`:
//!     `expected_nonce` removed (was unused dead parameter).
//!
//! Dependencies (add to Cargo.toml):
//!   pyo3 = { version = "0.20", features = ["extension-module"] }
//!   chacha20poly1305 = "0.10"   # or 0.11

use pyo3::prelude::*;
use pyo3::types::PyBytes;

use chacha20poly1305::{
    aead::{Aead, KeyInit},
    ChaCha20Poly1305, Key, Nonce,
};

// ---- Sensor validation ranges (must match sim + firmware) ----------------
const CURRENT_RANGE: (f32, f32) = (0.0, 50.0); // amps
const FLOW_RANGE: (f32, f32) = (0.0, 100.0); // L/min
const TEMP_RANGE: (f32, f32) = (-20.0, 150.0); // deg C

// ---- Safety thresholds ---------------------------------------------------
// Dry-run: flow < 5.7 L/min (== 1.5 GPM, converted) while motor draws current.
const DRY_RUN_FLOW_LPM: f32 = 5.7;
const DRY_RUN_CURRENT_MIN_A: f32 = 2.0;
const OVERTEMP_C: f32 = 85.0;

fn valid_sensor(v: f32, range: (f32, f32)) -> bool {
    // is_finite() rejects both NaN and +/-infinity.
    v.is_finite() && v >= range.0 && v <= range.1
}

/// Telemetry packet structure for pump flow, current, and temperature.
/// Units: flow in L/min, current in amps, temperature in deg C.
#[pyclass]
#[derive(Clone, Debug)]
pub struct SensorTelemetryPacket {
    #[pyo3(get, set)]
    pub device_id: u32,
    #[pyo3(get, set)]
    pub flow_rate_lpm: f32,
    #[pyo3(get, set)]
    pub motor_current_amps: f32,
    #[pyo3(get, set)]
    pub internal_temp_c: f32,
    #[pyo3(get, set)]
    pub timestamp_epoch: u64,
}

#[pymethods]
impl SensorTelemetryPacket {
    #[new]
    fn new(
        device_id: u32,
        flow_rate_lpm: f32,
        motor_current_amps: f32,
        internal_temp_c: f32,
        timestamp_epoch: u64,
    ) -> Self {
        SensorTelemetryPacket {
            device_id,
            flow_rate_lpm,
            motor_current_amps,
            internal_temp_c,
            timestamp_epoch,
        }
    }

    /// True if all sensor readings are finite and within plausible ranges.
    fn sensors_valid(&self) -> bool {
        valid_sensor(self.motor_current_amps, CURRENT_RANGE)
            && valid_sensor(self.flow_rate_lpm, FLOW_RANGE)
            && valid_sensor(self.internal_temp_c, TEMP_RANGE)
    }

    /// Evaluates dry-run and thermal overload conditions.
    ///
    /// Returns False (cutoff) if ANY sensor reading is invalid — a dead
    /// sensor must never read as "safe". NaN comparisons are always false,
    /// so without this guard a NaN flow would silently pass the dry-run check.
    fn evaluate_safety_status(&self) -> PyResult<bool> {
        if !self.sensors_valid() {
            // Fail-safe: invalid data -> unsafe -> cutoff.
            return Ok(false);
        }

        // Dry-run: flow collapsed while motor still drawing current.
        let is_dry_running =
            self.flow_rate_lpm < DRY_RUN_FLOW_LPM && self.motor_current_amps > DRY_RUN_CURRENT_MIN_A;

        // Thermal overload.
        let is_overheated = self.internal_temp_c > OVERTEMP_C;

        Ok(!(is_dry_running || is_overheated))
    }
}

// ---- Real decryption (ChaCha20Poly1305, nonce-prepended wire format) -----

#[derive(Debug)]
enum DecryptError {
    BadKey,
    TooShort,
    Failed,
}

fn decrypt_blob(key_bytes: &[u8; 32], blob: &[u8]) -> Result<Vec<u8>, DecryptError> {
    // 12-byte nonce + minimum 16-byte Poly1305 tag.
    if blob.len() < 12 + 16 {
        return Err(DecryptError::TooShort);
    }
    let (nonce_bytes, ct) = blob.split_at(12);
    let nonce_arr: [u8; 12] = nonce_bytes
        .try_into()
        .map_err(|_| DecryptError::TooShort)?;
    let key = Key::from(*key_bytes);
    let nonce = Nonce::from(nonce_arr);
    let cipher = ChaCha20Poly1305::new(&key);
    // No .expect(): authentication failure is normal control flow.
    cipher.decrypt(&nonce, ct).map_err(|_| DecryptError::Failed)
}

/// Decrypt a telemetry blob produced by `vault_core::encrypt`.
/// Wire format: [ nonce (12 B) || ciphertext || tag (16 B) ].
/// Returns the plaintext bytes, or raises ValueError on any failure —
/// wrong key, truncated blob, or tampered data all fail closed.
#[pyfunction]
fn ingest_encrypted_telemetry(
    _py: Python<'_>,
    key: &[u8],
    encrypted_payload: &PyBytes,
) -> PyResult<Vec<u8>> {
    if key.len() != 32 {
        return Err(pyo3::exceptions::PyValueError::new_err(
            "Key must be exactly 32 bytes.",
        ));
    }
    // Length checked above; this cannot panic.
    let mut key_arr = [0u8; 32];
    key_arr.copy_from_slice(key);

    let payload_bytes = encrypted_payload.as_bytes();
    if payload_bytes.is_empty() {
        return Err(pyo3::exceptions::PyValueError::new_err(
            "Payload buffer is empty.",
        ));
    }

    decrypt_blob(&key_arr, payload_bytes).map_err(|e| {
        pyo3::exceptions::PyValueError::new_err(format!(
            "Telemetry decryption failed ({:?}): wrong key or tampered data.",
            e
        ))
    })
}

/// Python extension module registration for Smart-Flow FFI.
#[pymodule]
fn smart_flow_ffi(_py: Python<'_>, m: &PyModule) -> PyResult<()> {
    m.add_class::<SensorTelemetryPacket>()?;
    m.add_function(wrap_pyfunction!(ingest_encrypted_telemetry, m)?)?;
    Ok(())
}
