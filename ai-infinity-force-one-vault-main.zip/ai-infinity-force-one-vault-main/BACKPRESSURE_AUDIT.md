# Backpressure Audit — Elevation A4 (2026-11-10)

Scope: every channel and queue in `src/` that can accumulate
messages between a producer and a consumer. Method: grep for
`mpsc`, `sync_channel`, `broadcast`, `watch`, `flume`, `crossbeam`,
and `VecDeque` across `src/`, plus a read of each hit. One change was
made; everything else is bounded by construction, with the reasoning
recorded per item.

## Inventory

| # | Site | Type | Verdict |
|---|------|------|---------|
| 1 | `src/sandbox/process.rs` — response pump channel | std `mpsc` | **CHANGED** — was unbounded; now `sync_channel(1)`. See below. |
| 2 | `src/sandbox/process.rs` — handshake channel | std `mpsc` (unbounded) | OK — bounded by construction. |
| 3 | `src/ingest/pipeline.rs` — `IngestPipeline.queue` | `VecDeque` | OK — producer is the host itself. See below. |
| 4 | Everything else in `src/` | — | No other channels exist: no tokio `mpsc`/`broadcast`/`watch`, no flume/crossbeam (grep-verified). The HTTP layer (axum) does not hand application code an internal queue; pipeline execution (`src/pipeline.rs`, `src/sandbox/pipeline.rs`) is synchronous call-and-return, not queued. |

## 1. Response pump channel — CHANGED to `sync_channel(1)`

Before: `mpsc::channel()` (unbounded). The pump thread forwards every
framed response the worker emits. Requests are serialized per backend
(the backend mutex admits one in-flight request), so a well-behaved
worker fills exactly one slot per request — but a broken or hostile
worker could emit well-formed frames continuously, and each one would
queue in host memory until the backend consumed or dropped the
worker. Frames are individually capped at 64 MiB by `read_frame`,
which bounds the rate, not the total.

After: `mpsc::sync_channel(1)`. One slot is all a well-behaved worker
can ever use (one request in flight, one response per request). A
flooding worker now blocks its own pump thread on the full channel,
its stdout pipe fills, and the worker itself blocks on write — real
backpressure to the producer, and a hard ceiling of one queued frame
in host memory. Error paths are unchanged: a dead pump still surfaces
as `WorkerCrashed`, and dropping the `WorkerProc` drops the queue.

## 2. Handshake channel — bounded by construction

The handshake thread sends exactly one message in its lifetime (the
handshake line or an error) and then exits; the receiver consumes it
or times out after 10 s and kills the worker. Maximum occupancy: 1.
No bound needs configuring because the producer cannot produce a
second message.

## 3. `IngestPipeline` queue — producer is the host itself

`submit()` pushes onto a `VecDeque` with no cap. This is an
in-process, synchronous API: the only producer is the embedding
application calling `submit` from its own code — there is no async,
network, or cross-process producer that could flood it without the
host's own participation, and each queued record is data the host
itself created. Downstream, payload sizes are enforced at execution
time by the lanes' `max_bytes`. Bounding this queue would change the
API's contract (silently dropping or rejecting the host's own
submissions) to defend against the host itself, which is out of the
threat model. Documented as audited; no change.

## Companion change in this stage

Per-lane rlimits (`src/sandbox/limits.rs`): every worker (re)spawn
applies `RLIMIT_CPU` (300 s), `RLIMIT_AS` (1 GiB), and `RLIMIT_NOFILE`
(256) in `pre_exec`, configurable via `MACK_LANE_CPU_SECONDS`,
`MACK_LANE_ADDRESS_SPACE_BYTES`, `MACK_LANE_OPEN_FILES`. A failing
`setrlimit` fails the spawn — no unlimited worker ever runs. Proven
end-to-end by `worker_runs_under_lane_rlimits`, which reads the live
worker's `/proc/<pid>/limits`.

No new dependencies in this stage (the `libc` edge is A3's).
