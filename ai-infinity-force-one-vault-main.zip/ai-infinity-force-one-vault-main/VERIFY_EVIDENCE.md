# Independent Evidence & Invariant Verifier Guide

**Docket Reference:** `MACK-STACK-01`  
**Author / Inventor:** Allen Mack (`a95674127@gmail.com`)  
**Specification:** Tamper-Evident Multi-Stage Zero-Trust Security Engine  

---

## Overview

This guide provides prospective investors, acquirers, enterprise clients, and technical due-diligence auditors with an undeniable, 1-command verification suite.

The verifier executes **5 cryptographic and operational gates**:
1. **Source Artifact Cryptographic Digest Verification:** Evaluates SHA-256 digests of all 35 source files, manifests, tests, and fuzzing harnesses against `EVIDENCE_BUNDLE.json`.
2. **Live Test Suite Execution & Parity Check:** Executes `cargo test` in real time, counts passed/failed test cases across all 8 suites (71 tests total), and fails immediately on any mismatch or dropped assertion.
3. **DePIN Stress Benchmark & Performance Gate:** Validates multi-node task throughput against the regression threshold (`>= 500.0 tasks/sec`), verifying the `gate_verdict == "PASS"`.
4. **Deterministic Execution Transcript Verification:** Verifies the cryptographic digest of the 5-flow execution transcript (`DEMO_TRANSCRIPT.txt`).
5. **Ed25519 Authorship & Ownership Signature:** Validates the cryptographic signature binding author Allen Mack, docket `MACK-STACK-01`, and the head of the provenance attestation ledger.

---

## 1-Step Independent Verification

Run the verifier executable directly from the repository root:

```bash
cargo run --example verify_evidence
```

### Deterministic Demo Runner (Generates DEMO_TRANSCRIPT.txt)

```bash
cargo run --example deterministic_demo
```

---

## Comprehensive Suite Verification

### 1. Full Backend Test & Lint Verification (226 Automated Tests)

Run the full locked test suite and linter checks across all crates, modules, and target architectures:

```bash
# Execute all 226 automated unit, integration, and adversarial tests
cargo test --locked

# Verify strict compiler and clippy invariants with zero warnings
cargo clippy --locked --all-targets -- -D warnings

# Verify canonical code formatting
cargo fmt --check
```

### 2. Frontend Dashboard Build & Dependency Audit

Verify the React 18 + TypeScript + Vite 8 frontend dashboard:

```bash
cd frontend
npm install
npm run build
npm audit
```

**Expected Verifications:**
- Clean typecheck (`tsc`) and Vite production bundle generation in ~115ms (`dist/index.html`, `dist/assets/index-*.js`).
- `npm audit` reports **0 vulnerabilities**, confirming the remediation of Dependabot alerts #1–#3 and #16–#20 (including high-severity CVE-2026-112942).

### 3. Cargo Dependency Audit & Security Advisories

```bash
cargo audit
```

**Known Advisories & Buyer Disclosure:**
- **Cleared Advisories:** `ctutils` 0.4.6 resolves RUSTSEC-2026-0385; `yara-x` 1.22.1 resolves transitive `wasmtime` and `zip` advisories.
- **RUSTSEC-2023-0071 (RSA Marvin Attack timing side-channel):**
  - **Status:** Unpatched upstream in `rsa` 0.9.10 crate.
  - **Path:** Transitive dependency pulled via `yara-x`.
  - **Exposure:** **Zero impact**. MACK Stack uses Ed25519 and ChaCha20/AES exclusively; RSA is neither compiled into public interfaces nor executed in any operational path.
- **Informational Warnings:** `bincode` 2.0.1 unmaintained (RUSTSEC-2025-0141, transitive via `yara-x`) and `tokio` `AsyncFd` (RUSTSEC-2026-0386).
