# Threat Model — ai-infinity-force-one-vault (MACK)

> Consolidated 2026-11-06 from the repository's own security documentation:
> `SECURITY_ARCHITECTURE.md` (§3–§6), `STATUS.md` (§3, Explicit Architectural
> Limitations & Deferrals), and `docs/THREAT_MODEL_DDIL.md`. This page states
> no guarantee that is not already documented in those sources; where they
> record a limitation, the limitation is recorded here too.

## 1. What is being protected

Every payload entering or leaving the vault passes through one mandatory
pipeline — sandbox containment, threat detection, zero-trust policy,
Proof-of-Verification (PoV) verification, and authenticated encryption — and
every stage outcome, accepted or denied, is appended to a SHA-256
hash-chained, tamper-evident audit ledger. The pipeline is the only ingress;
no stage can be bypassed from application code (`SECURITY_ARCHITECTURE.md`
§1–§2).

## 2. Attacker model

**Trusted components** (assumed uncompromised):

- The Rust runtime and its compiled dependency tree.
- The local filesystem holding the audit ledger.
- The OS entropy source used for key/nonce generation.

**Untrusted by default:**

- Every payload, regardless of origin.
- Every principal, including authenticated operators.
- Every PoV claim, including claims signed by worker nodes — claims are
  assertions to be independently re-verified, never facts.

**Operational profile** (`docs/THREAT_MODEL_DDIL.md`): tactical edge /
D-DIL environments (denied, degraded, intermittent, low-bandwidth; no
internet or cloud access), with adversary vectors including malicious
maintenance laptops and poisoned USB/firmware media, tactical
spear-phishing, weaponized documents (VBA macros, PDF exploits), and C2
callbacks attempting beaconing or exfiltration. Mitigations documented
there: offline deterministic scoring with no cloud telemetry or phone-home,
encryption at rest that stays unreadable if hardware is captured, and 12
independent containment lanes preventing cross-contamination.

**Explicitly out of scope** (`SECURITY_ARCHITECTURE.md` §3):

- Physical or hypervisor-level compromise of the host.
- Denial of service through resource exhaustion at the network edge
  (rate limiting is expected to be enforced upstream).
- Side-channel attacks against the CPU (e.g., speculative-execution
  leakage).

## 3. Adversary capabilities and controls

From `SECURITY_ARCHITECTURE.md` §4 (T1–T11):

| # | Adversary capability | Control | Where enforced |
|---|----------------------|---------|----------------|
| T1 | Submit oversized or empty payloads to stress the service | Containment gate rejects size 0 and payloads over the configured byte limit | Stage 1 — SandboxContainment |
| T2 | Store known-malicious content (e.g., EICAR, blocklisted hashes) | SHA-256 hash blocklist match rejects before any storage | Stage 2 — ThreatDetection |
| T3 | Evade blocklist with novel encrypted/packed malware | Shannon entropy scan flags high-entropy blobs (> 7.2 bits/byte) | Stage 2 — ThreatDetection |
| T4 | Unauthorized principal reads or writes vault data | Default-deny capability policy; access only with an explicit grant for the exact (principal, resource, action) tuple | Stage 3 — ZeroTrustPolicy |
| T5 | Privilege escalation by an operator holding only read access | Action-level enforcement: a write requires `Action::Write`; read-only grants are rejected | Stage 3 — ZeroTrustPolicy |
| T6 | Worker node forges a "verified" PoV claim to collect settlement | Independent re-verification: `hash_match` claims with identical input/output hashes are rejected regardless of the `verified` flag | Stage 4 — PoVVerification |
| T7 | Replay of a claimed-but-false PoV with mutated JSON | Strict schema parsing: malformed or missing required fields are rejected before evaluation | Stage 4 — PoVVerification |
| T8 | Ciphertext tampering (bit-flip, truncation) of stored payloads | ChaCha20-Poly1305 AEAD authentication tag; any modification fails decryption | Stage 5 — Encryption, `decrypt` |
| T9 | Offline brute-force of stolen ciphertext | Argon2id key derivation (memory-hard) from the passphrase before AEAD | Stage 5 — Encryption |
| T10 | Retroactive mutation or deletion of audit history | SHA-256 hash chain: each entry hashes sequence, timestamp, actor, action, and previous entry hash; `verify()` walks the chain | AuditLedger |
| T11 | Repudiation of a pipeline decision | Every accepted and denied request is appended to the same ledger | AuditLedger |

Additional documented detection behaviour (`SECURITY_ARCHITECTURE.md` §5,
crate documentation): YARA-X rule scanning (a labeled heuristic *starter*
ruleset; every match is a triage signal, not a conviction — `STATUS.md`
§3.2), C2-callback, phishing, malicious-document and PE/shellcode
detectors, and STIX 2.1 bundle export of scan results.

Detection limits, as documented: an entropy scan cannot distinguish
encrypted malware from legitimately encrypted user data (payloads enter
the pipeline as plaintext by contract; ciphertext is produced only at
Stage 5, inside the vault).

## 4. Stated limitations (honest disclosures)

These are the repository's own words, consolidated from `STATUS.md` §3 and
`SECURITY_ARCHITECTURE.md` §6. They bound every claim above.

1. **Tamper-evident, not tamper-proof.** The ledger's hash chain makes
   edits to any historical field break verification, and `verify_anchored`
   catches truncation against a previously saved head hash. But an
   attacker with filesystem write access can truncate the entire ledger
   and rebuild a consistent chain from a forged history. Stronger
   guarantees require periodically anchoring the head hash to external
   infrastructure (a transparency log or write-once storage). The
   mechanism for doing this with the owner's release key is prepared in
   `ANCHORING.md`; until anchors are published, no external-anchoring
   claim is made.
2. **Transitive cryptographic advisory — RSA Marvin (RUSTSEC-2023-0071).**
   The `rsa` crate arrives strictly as an indirect transitive dependency
   via `yara-x` (via `crypto-bigint` and `rsa`); `Cargo.lock` currently
   resolves it as 0.10.0-rc.19. The repository's documented exposure
   assessment is **zero operational exposure**: MACK cryptographic
   operations (PoV attestations, zero-trust tokens, ledger signatures)
   exclusively use Ed25519 (`ed25519-dalek`) and symmetric encryption
   (ChaCha20-Poly1305 / AES-GCM); the `rsa` crate is never invoked in any
   execution path. The advisory is tracked openly (it is on the CI
   `cargo audit` ignore list with the other unpatched-upstream
   advisories) rather than hidden. The ignore must be removed in the same
   change that takes a fixed `rsa`, if one is ever published.
3. **Sibling Mesh is in-process only.** Leased execution
   (`sandbox::sibling`) is an in-process leasing engine with
   capability-based token checks, lease acquisition, heartbeat renewal,
   and automatic TTL expiration. It is not a distributed cross-host mesh;
   distributed lease coordination and gossip networking are planned
   future architecture, not current behaviour.
4. **Lane isolation has two levels, reported honestly.** The 12 lanes are
   in-process Rust threads/tasks by default. Opt-in real isolation is
   available via `LaneContainmentEngine::new_isolated()`: each lane's
   containment check runs in a separate OS worker process (`lane_worker`
   binary), Landlock-confined with zero filesystem access on Linux,
   fail-closed on crash/timeout with transparent respawn;
   `lane_isolation_level()` reports the actual level from the worker
   handshake rather than assuming it. Hardware-enforced microVM/container
   boundaries (e.g., Firecracker) are planned, not present.
5. **Ledger storage.** `AuditLog`/`ConcurrentLedger` are memory-backed
   with verifiable export snapshots; `vault::persistent::PersistentLedger`
   persists the hash chain to an embedded `redb` database, re-verifies
   the chain on open, and refuses to open a tampered database.
   Distributed storage with remote consensus replication is planned,
   not present.
6. **No patent claim.** No patent application is on record for this work
   (see `PATENT_STATUS.md`); nothing in this document should be read as
   claiming one.
