//! TWIN DEMO — real lane_worker, real signed checkpoint; demo key
//! generated locally; not a production pipeline.
//!
//! The honest counterpart to a simulated "twin" integration: every
//! stage below uses the real machinery of this crate and of
//! Aegis-Seal, and every stage fails closed rather than degrading.
//!
//! In one run, this demo:
//! 1. Generates a throwaway Ed25519 checkpoint key in a temp dir
//!    (never in the repo) and points `MACK_CHECKPOINT_KEY_FILE` at it.
//! 2. Executes a task through a real `lane_worker` child process
//!    (Landlock + seccomp on Linux). If confinement cannot be
//!    established, the demo exits nonzero — it never falls back to an
//!    unconfined run and still prints success.
//! 3. Appends the execution event to a persistent ledger.
//! 4. Creates a signed chain-tip checkpoint (Elevation B0) and prints
//!    the checkpoint block — the cross-repo handoff artifact that
//!    Aegis-Seal's `verify-checkpoint` command checks independently.
//! 5. Verifies chain + checkpoints in-process.
//! 6. Copies the ledger, truncates it past the checkpoint, and shows
//!    checkpoint verification failing on the copy.
//!
//! Run it with: `cargo run --example twin_demo`

use std::io::Read;
use std::path::{Path, PathBuf};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use ai_infinity_force_one_vault::ingest::{IngestRecord, IngestStatus};
use ai_infinity_force_one_vault::sandbox::{IsolationLevel, ProcessLaneBackend};
use ai_infinity_force_one_vault::vault::checkpoint::CHECKPOINT_KEY_FILE_ENV;
use ai_infinity_force_one_vault::{CheckpointSigner, PersistentLedger};
use redb::{Database, TableDefinition};
use zeroize::Zeroize;

/// The ledger entries table, redeclared to match
/// `src/vault/persistent.rs` (same convention as the crate's own
/// checkpoint tests). Used only to truncate the *copy* of the ledger
/// in the tamper demonstration.
const ENTRIES_TABLE: TableDefinition<u64, String> = TableDefinition::new("audit_entries");

fn main() {
    println!("==============================================================");
    println!("TWIN DEMO — real lane_worker, real signed checkpoint; demo key");
    println!("generated locally; not a production pipeline.");
    println!("==============================================================\n");

    match run() {
        Ok(()) => println!("\nTWIN DEMO: PASS"),
        Err(e) => {
            eprintln!("\nTWIN DEMO: FAIL — {e}");
            std::process::exit(1);
        }
    }
}

fn temp_root() -> Result<PathBuf, String> {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let dir = std::env::temp_dir().join(format!("mack_twin_demo_{}_{}", std::process::id(), nanos));
    std::fs::create_dir_all(&dir).map_err(|e| format!("create temp dir: {e}"))?;
    Ok(dir)
}

/// Writes a fresh 32-byte Ed25519 seed from OS entropy to `path`
/// (owner-only on Unix) and returns a signer loaded through the
/// production env-var path, exactly as a deployment would load it.
fn generate_demo_signer(key_path: &Path) -> Result<CheckpointSigner, String> {
    let mut seed = [0u8; 32];
    std::fs::File::open("/dev/urandom")
        .and_then(|mut f| f.read_exact(&mut seed))
        .map_err(|e| format!("read OS entropy for demo key: {e}"))?;
    std::fs::write(key_path, seed).map_err(|e| format!("write demo key file: {e}"))?;
    seed.zeroize();
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = std::fs::set_permissions(key_path, std::fs::Permissions::from_mode(0o600));
    }
    std::env::set_var(CHECKPOINT_KEY_FILE_ENV, key_path);
    match CheckpointSigner::from_env() {
        Ok(Some(signer)) => Ok(signer),
        Ok(None) => Err("checkpoint signer did not load from MACK_CHECKPOINT_KEY_FILE".into()),
        Err(e) => Err(format!("load checkpoint signer: {e}")),
    }
}

fn run() -> Result<(), String> {
    let root = temp_root()?;
    let result = run_in(&root);
    let _ = std::fs::remove_dir_all(&root);
    result
}

fn run_in(root: &Path) -> Result<(), String> {
    // 1. Throwaway checkpoint key + persistent ledger, both in temp.
    let key_path = root.join("checkpoint-key.bin");
    let signer = generate_demo_signer(&key_path)?;
    println!(
        "[setup] demo checkpoint key generated in temp dir; pubkey {}",
        signer.public_key_hex()
    );

    let ledger_path = root.join("ledger").join("ledger.redb");
    let ledger = PersistentLedger::open(&ledger_path).map_err(|e| format!("open ledger: {e}"))?;
    println!(
        "[setup] persistent ledger open at {}",
        ledger_path.display()
    );

    // 2. Real task through the real lane machinery. The worker is a
    // separate OS process; on Linux it must report Landlock
    // confinement and an installed seccomp profile. Anything less is
    // a fail-closed stop, never a quiet downgrade.
    let backend = ProcessLaneBackend::spawn(1_048_576, Duration::from_secs(10))
        .map_err(|e| format!("lane worker spawn failed (fail-closed): {e:?}"))?;
    let level = backend.isolation_level();
    let seccomp = backend.seccomp_active();
    let pid = backend.worker_pid().unwrap_or(0);
    println!("[lane] worker pid {pid}, isolation level {level:?}, seccomp_active {seccomp}");
    #[cfg(target_os = "linux")]
    if level != IsolationLevel::ProcessWithLandlock || !seccomp {
        return Err(format!(
            "FAIL-CLOSED: lane worker confinement not established (isolation {level:?}, \
             seccomp_active {seccomp}); refusing to run unconfined"
        ));
    }

    let task_id = "TWIN-001";
    let executed = backend
        .execute(IngestRecord::new(
            "TWIN-DEMO",
            b"twin demo task: confined execution sample".to_vec(),
        ))
        .map_err(|e| format!("lane execution failed: {e:?}"))?;
    let verdict = format!("{:?}", executed.status);
    println!("[lane] task {task_id} executed by worker pid {pid}: verdict {verdict}");
    if executed.status != IngestStatus::Accepted {
        return Err(format!(
            "benign demo task was not accepted by the lane (verdict {verdict})"
        ));
    }
    drop(backend);

    // 3. The execution event (plus two bookkeeping entries, so the
    // checkpoint binds a non-trivial chain tip) goes into the ledger.
    ledger
        .append(
            "twin-demo",
            &format!("task {task_id} executed in lane worker pid {pid}: verdict {verdict}"),
        )
        .map_err(|e| format!("append execution event: {e}"))?;
    ledger
        .append("twin-demo", "post-execution bookkeeping entry 1")
        .map_err(|e| format!("append bookkeeping entry: {e}"))?;
    ledger
        .append("twin-demo", "post-execution bookkeeping entry 2")
        .map_err(|e| format!("append bookkeeping entry: {e}"))?;
    println!("[ledger] {} entries appended", ledger.len());

    // 4. Signed checkpoint — the cross-repo handoff artifact.
    let record = ledger
        .checkpoint(&signer)
        .map_err(|e| format!("create checkpoint: {e}"))?;
    println!("\n----- TWIN CHECKPOINT -----");
    println!("seq: {}", record.seq);
    println!("head_hash: {}", record.head_hash);
    println!("signature: {}", record.signature);
    println!("pubkey: {}", record.pubkey);
    println!("----- END TWIN CHECKPOINT -----\n");

    // 5. In-process verification of chain + checkpoints.
    ledger
        .verify_checkpoints(Some(&record.pubkey))
        .map_err(|e| format!("in-process checkpoint verification failed: {e}"))?;
    println!("[verify] hash chain + signed checkpoints: PASS");
    drop(ledger);

    // 6. Tamper demonstration on a copy: cut the newest entry so the
    // chain no longer reaches the checkpoint. The truncated chain is
    // still internally consistent — plain chain verification passes —
    // but checkpoint verification must fail.
    let copy_path = root.join("ledger-copy").join("ledger.redb");
    if let Some(parent) = copy_path.parent() {
        std::fs::create_dir_all(parent).map_err(|e| format!("create copy dir: {e}"))?;
    }
    std::fs::copy(&ledger_path, &copy_path).map_err(|e| format!("copy ledger: {e}"))?;
    {
        let db = Database::create(&copy_path).map_err(|e| format!("open copy raw: {e}"))?;
        let write_txn = db
            .begin_write()
            .map_err(|e| format!("copy write txn: {e}"))?;
        {
            let mut table = write_txn
                .open_table(ENTRIES_TABLE)
                .map_err(|e| format!("open copy entries table: {e}"))?;
            table
                .remove(2u64)
                .map_err(|e| format!("truncate copy: {e}"))?;
        }
        write_txn
            .commit()
            .map_err(|e| format!("commit truncation: {e}"))?;
    }
    let tampered = PersistentLedger::open(&copy_path).map_err(|e| format!("reopen copy: {e}"))?;
    println!(
        "[tamper] copy truncated to {} entries (checkpoint binds seq {})",
        tampered.len(),
        record.seq
    );
    if tampered.verify().is_err() {
        return Err("truncated copy should still pass plain chain verification".into());
    }
    println!("[tamper] plain chain verification on truncated copy: PASS (chain alone cannot see the cut)");
    match tampered.verify_checkpoints(None) {
        Ok(()) => Err(
            "checkpoint verification did NOT detect the truncation — the demo itself fails".into(),
        ),
        Err(e) => {
            println!(
                "[tamper] checkpoint verification on truncated copy: FAILED as expected — {e}"
            );
            Ok(())
        }
    }
}
