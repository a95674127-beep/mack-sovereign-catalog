//! One-command demo of the MACK vault path, end to end:
//!
//! 1. A benign payload is granted, scanned, encrypted and stored.
//! 2. A known-bad payload (hash on the built-in blocklist) is rejected
//!    before storage — fail-closed, and the rejection is itself logged.
//! 3. The stored payload is retrieved and decrypted intact.
//! 4. The audit ledger — which recorded every step, including the
//!    rejection — is verified link by link.
//!
//! Run it via `./demo.sh` or directly:
//! `cargo run --example one_command_demo`

use ai_infinity_force_one_vault::vault::policy::{Action, Effect, Principal, Resource, Rule};
use ai_infinity_force_one_vault::vault::VaultError;
use ai_infinity_force_one_vault::Vault;

fn main() {
    println!("=== AI Infinity Force One — one-command demo ===\n");

    let mut vault = Vault::new();
    let alice = Principal("demo_operator".to_string());
    let doc = Resource("demo_document".to_string());

    vault.grant(Rule {
        effect: Effect::Allow,
        principal: alice.clone(),
        resource: doc.clone(),
        actions: vec![Action::Write, Action::Read],
    });

    // 1. Benign sample: accepted, encrypted at rest.
    let benign: &[u8] = b"Quarterly field report: all systems nominal.";
    let envelope = match vault.store(&alice, &doc, benign, b"demo-passphrase") {
        Ok(envelope) => {
            println!(
                "[1] BENIGN payload accepted and encrypted ({} bytes at rest).",
                envelope.len()
            );
            envelope
        }
        Err(e) => {
            println!("[1] BENIGN payload unexpectedly rejected: {e:?}");
            std::process::exit(1);
        }
    };

    // 2. Malicious sample: this payload's hash is on the built-in
    //    blocklist (src/detection/known_bad_hashes.txt). It must be
    //    rejected before storage.
    let malicious: &[u8] = b"malicious_test_payload";
    match vault.store(&alice, &doc, malicious, b"demo-passphrase") {
        Err(VaultError::DetectionBlocked(reason)) => {
            println!("[2] MALICIOUS payload REJECTED before storage ({reason}).");
        }
        other => {
            println!("[2] MALICIOUS payload was NOT rejected: {other:?}");
            std::process::exit(1);
        }
    }

    // 3. Round-trip: the benign payload decrypts back to itself.
    match vault.retrieve(&alice, &doc, &envelope, b"demo-passphrase") {
        Ok(plaintext) if plaintext.as_slice() == benign => {
            println!("[3] Stored payload retrieved and decrypted intact.");
        }
        other => {
            println!("[3] Retrieval failed or content mismatch: {other:?}");
            std::process::exit(1);
        }
    }

    // 4. The ledger recorded all of it — store, rejection, retrieval —
    //    and the hash chain verifies end to end.
    println!("\nAudit ledger: {} entries recorded.", vault.audit_len());
    match vault.verify_audit() {
        Ok(()) => println!("Ledger verification: OK — hash chain intact, 0 broken links."),
        Err(idx) => {
            println!("Ledger verification: BROKEN at entry index {idx}.");
            std::process::exit(1);
        }
    }

    println!("\nDemo complete: benign accepted, malicious rejected, ledger verified.");
}
