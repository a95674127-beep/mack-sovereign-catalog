//! Deterministic Demo Runner
//! Exercises the engine's 5 core flows deterministically and emits a transcript
//! that can be hashed and verified independently.

use ai_infinity_force_one_vault::ingest::IngestRecord;
use ai_infinity_force_one_vault::pipeline::UnifiedPipeline;
use ai_infinity_force_one_vault::sandbox::lanes::{LaneContainmentEngine, LaneId};
use ai_infinity_force_one_vault::vault::audit::{AuditLog, GENESIS_EVT_1041};
use ai_infinity_force_one_vault::vault::policy::{Principal, Resource};
use ai_infinity_force_one_vault::vault::provenance::{AttestationAction, ProvenanceLedger};
use ed25519_dalek::SigningKey;
use sha2::{Digest, Sha256};
use std::fs;

pub fn run_deterministic_demo() -> String {
    let mut out = String::new();
    out.push_str("=== AI INFINITY FORCE ONE DETERMINISTIC EXECUTION TRANSCRIPT ===\n");
    out.push_str("DOCKET: MACK-STACK-01 | INVENTOR: Allen Mack\n");
    out.push_str("SPECIFICATION: Tamper-Evident Multi-Stage Zero-Trust Engine\n\n");

    // Flow 1: Deterministic Ed25519 Provenance Attestation
    out.push_str("[FLOW 1/5] DETERMINISTIC PROVENANCE & AUTHORSHIP ATTESTATION\n");
    let seed: [u8; 32] = [42u8; 32];
    let signing_key = SigningKey::from_bytes(&seed);
    let verifying_key = signing_key.verifying_key();
    let mut prov_ledger = ProvenanceLedger::new(verifying_key);
    let dummy_artifact_hash = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

    let attestation = prov_ledger
        .attest(
            "Allen Mack",
            "MACK-STACK-01",
            AttestationAction::Authorship,
            dummy_artifact_hash,
            &signing_key,
        )
        .expect("Attestation creation");

    out.push_str(&format!("  -> Author: {}\n", attestation.actor));
    out.push_str(&format!("  -> Docket: {}\n", attestation.docket));
    out.push_str(&format!(
        "  -> Ed25519 PubKey: {}\n",
        hex::encode(verifying_key.as_bytes())
    ));
    out.push_str(&format!(
        "  -> Attestation Action: {:?}\n",
        attestation.action
    ));
    out.push_str(&format!(
        "  -> Provenance Valid: {}\n",
        prov_ledger.verify_chain().is_ok()
    ));

    // Flow 2: 12-Lane Containment & Autonomous Quarantine
    out.push_str("\n[FLOW 2/5] 12-LANE CONTAINMENT & AUTONOMOUS QUARANTINE\n");
    let lane_engine = LaneContainmentEngine::new(1024);
    for idx in 0..12 {
        let lane_id = LaneId::from_index(idx).unwrap();
        let record = IngestRecord::new(
            lane_id.code(),
            format!("Payload for lane {}", lane_id.code()).into_bytes(),
        );
        let res = lane_engine.execute_lane(lane_id, record);
        assert!(res.is_ok());
    }
    out.push_str("  -> Executed canonical lanes: L-01 through L-12\n");

    let test_lane = LaneId::from_index(8).unwrap();
    let bad_record = IngestRecord::new(test_lane.code(), vec![]);
    let _ = lane_engine.execute_lane(test_lane, bad_record);
    out.push_str(&format!(
        "  -> Autonomous quarantine on empty payload: {:?}\n",
        lane_engine.lane_status(test_lane)
    ));
    // Clear the quarantine to demonstrate administrative reset capability
    lane_engine.clear_lane_quarantine(test_lane);
    out.push_str(&format!(
        "  -> Authorized quarantine recovery: {:?}\n",
        lane_engine.lane_status(test_lane)
    ));

    // Flow 3: Genesis-Bound Hash-Chained Audit Ledger
    out.push_str("\n[FLOW 3/5] GENESIS-BOUND HASH-CHAINED AUDIT LEDGER\n");
    let mut audit_log = AuditLog::new();
    audit_log.append("system", "BOOTSTRAP");
    audit_log.append("operator", "INGEST_POV");
    audit_log.append("security", "ENCRYPT_VAULT");
    out.push_str(&format!("  -> Genesis Binding: {}\n", GENESIS_EVT_1041));
    out.push_str(&format!(
        "  -> Chain Entries: {}\n",
        audit_log.entries().len()
    ));
    out.push_str(&format!(
        "  -> Audit Ledger Verified: {}\n",
        audit_log.verify().is_ok()
    ));

    // Flow 4: Real-Time Adversarial Tamper Rejection
    out.push_str("\n[FLOW 4/5] REAL-TIME ADVERSARIAL TAMPER REJECTION\n");
    let mut tamper_log = AuditLog::new();
    tamper_log.append("system", "AUTHORIZED_INIT");
    tamper_log.append("operator", "VALID_PAYLOAD");
    assert!(tamper_log.verify().is_ok());
    tamper_log.entries_mut()[0].action = "MALICIOUS_TAMPERED_ACTION".to_string();
    let tamper_caught = tamper_log.verify().is_err();
    out.push_str("  -> Baseline Log Status: VALID\n");
    out.push_str(&format!(
        "  -> Tampered Entry Detection: Detected={} [REJECTED]\n",
        tamper_caught
    ));

    // Flow 5: Multi-Stage Zero-Trust Execution Pipeline
    out.push_str("\n[FLOW 5/5] MULTI-STAGE ZERO-TRUST PIPELINE EXECUTION\n");
    let mut pipeline = UnifiedPipeline::new();
    let alice = Principal("alice".into());
    let res = Resource("vault_data".into());
    let (pipe_res, report) = pipeline.process_payload(
        &alice,
        &res,
        "L-01",
        b"Verified encrypted payload for MACK-STACK-01 core evaluation".to_vec(),
        Some(b"Enterprise-Secret-Passphrase-2026!"),
    );
    out.push_str(&format!("  -> Pipeline Success: {}\n", pipe_res.is_ok()));
    out.push_str(&format!("  -> Evaluated Stages: {}\n", report.stages.len()));
    out.push_str(&format!(
        "  -> Audit Chain Intact: {}\n",
        report.audit_chain_intact
    ));

    out.push_str("\n=== END OF DETERMINISTIC TRANSCRIPT ===\n");
    out
}

fn main() {
    let transcript = run_deterministic_demo();
    let mut hasher = Sha256::new();
    hasher.update(transcript.as_bytes());
    let transcript_sha256 = hex::encode(hasher.finalize());

    fs::write("DEMO_TRANSCRIPT.txt", &transcript).expect("Failed to write DEMO_TRANSCRIPT.txt");
    print!("{}", transcript);
    println!("\nTranscript SHA-256: {}", transcript_sha256);
    println!("Saved transcript to DEMO_TRANSCRIPT.txt");
}
