use ai_infinity_force_one_vault::vault::audit::AuditLog;

fn main() {
    let mut log = AuditLog::new();

    log.append("allen_mack", "system_start");
    log.append("allen_mack", "pov_task_0001_ingested");
    log.append("allen_mack", "pov_task_0002_ingested");
    log.append("sentry_rf", "threat_scan_clean");
    log.append("allen_mack", "vault_store_event");

    println!("Ledger demo run");
    println!("Total entries appended: {}", log.len());

    match log.verify() {
        Ok(()) => println!("Chain verification: OK (0 broken links)"),
        Err(idx) => println!("Chain verification: BROKEN at entry index {}", idx),
    }
}
