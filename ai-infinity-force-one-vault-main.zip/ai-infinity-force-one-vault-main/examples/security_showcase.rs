//! examples/security_showcase.rs — Full MACK Stack Security Showcase.
//!
//! Interactive demonstration of all 5 security stages:
//! 1. Sandbox Containment (Quarantine & Bounds)
//! 2. Threat Detection (Shannon Entropy & Blocklist Scanning)
//! 3. Zero-Trust Access Control (Fail-Closed Default Deny)
//! 4. Proof-of-Verification (Cryptographic Hash Re-Derivation)
//! 5. Cryptographic Storage & Tamper-Evident Chained Audit Ledger

use ai_infinity_force_one_vault::pipeline::UnifiedPipeline;
use ai_infinity_force_one_vault::vault::policy::{Action, Effect, Principal, Resource, Rule};

fn main() {
    println!("===============================================================================");
    println!("         AI INFINITY FORCE ONE — MACK STACK ZERO-TRUST SECURITY ENGINE         ");
    println!("===============================================================================\n");

    let mut pipeline = UnifiedPipeline::new();

    let admin = Principal("operator_admin".into());
    let rogue = Principal("rogue_actor".into());
    let neural_res = Resource("neural_core_weights".into());
    let pov_res = Resource("pov_verification_ledger".into());

    // Authorize admin operator only
    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: admin.clone(),
        resource: neural_res.clone(),
        actions: vec![Action::Write, Action::Read],
    });
    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: admin.clone(),
        resource: pov_res.clone(),
        actions: vec![Action::Write],
    });

    println!("[Scenario 1] Unauthorized Actor (Zero-Trust Default Deny)");
    let payload = b"unauthorized write payload attempt".to_vec();
    let (res, rep) = pipeline.process_payload(&rogue, &neural_res, "lane_alpha", payload, None);
    println!("  Execution status: {:?}", res.is_ok());
    for s in &rep.stages {
        println!(
            "  - [{}] {:?}: {}",
            if s.passed { "PASS" } else { "FAIL" },
            s.stage,
            s.details
        );
    }
    println!();

    println!("[Scenario 2] High-Entropy Shellcode / Packer Detection (Shannon Entropy Scan)");
    let high_entropy: Vec<u8> = (0..512).map(|i| ((i * 137 + 73) % 256) as u8).collect();
    let (res, rep) =
        pipeline.process_payload(&admin, &neural_res, "lane_threat", high_entropy, None);
    println!("  Execution status: {:?}", res.is_ok());
    for s in &rep.stages {
        println!(
            "  - [{}] {:?}: {}",
            if s.passed { "PASS" } else { "FAIL" },
            s.stage,
            s.details
        );
    }
    println!();

    println!("[Scenario 3] Known Malicious Signature Blocklist (SHA-256 Blocklist)");
    let malicious = b"malicious_test_payload".to_vec();
    let (res, rep) = pipeline.process_payload(&admin, &neural_res, "lane_threat", malicious, None);
    println!("  Execution status: {:?}", res.is_ok());
    for s in &rep.stages {
        println!(
            "  - [{}] {:?}: {}",
            if s.passed { "PASS" } else { "FAIL" },
            s.stage,
            s.details
        );
    }
    println!();

    println!("[Scenario 4] Proof of Verification — Spoofed Worker Proof Detection");
    let spoofed_pov = r#"{
        "pov_version": "1.0",
        "task_id": "task_spoofed_demo",
        "operator_id": "untrusted_worker_09",
        "timestamp_start": "2026-09-29T12:00:00Z",
        "timestamp_end": "2026-09-29T12:00:01Z",
        "task_type": "deep_compute",
        "input_hash": "payload_hash_123",
        "output_hash": "payload_hash_123",
        "verification_method": "hash_match",
        "verified": true,
        "signature": "fake_signature"
    }"#;
    let (res, rep) = pipeline.process_pov(&admin, &pov_res, "pov_lane", spoofed_pov);
    println!("  PoV Validated: {:?}", res);
    for s in &rep.stages {
        println!(
            "  - [{}] {:?}: {}",
            if s.passed { "PASS" } else { "FAIL" },
            s.stage,
            s.details
        );
    }
    println!();

    println!("[Scenario 5] Verified Clean Ingest + ChaCha20-Poly1305 AEAD + Chained Audit");
    let clean_payload = b"Authorized neural weight update vector v4.2.0".to_vec();
    let passphrase = b"master_secure_passphrase_2026";
    let (res, rep) = pipeline.process_payload(
        &admin,
        &neural_res,
        "lane_primary",
        clean_payload,
        Some(passphrase),
    );
    println!("  Execution status: {:?}", res.is_ok());
    for s in &rep.stages {
        println!(
            "  - [{}] {:?}: {}",
            if s.passed { "PASS" } else { "FAIL" },
            s.stage,
            s.details
        );
    }
    println!();

    println!("===============================================================================");
    println!("                     CRYPTOGRAPHIC AUDIT LEDGER REPORT                         ");
    println!("===============================================================================");
    println!("Total audit entries committed: {}", pipeline.audit_len());
    match pipeline.verify_audit() {
        Ok(()) => println!("Audit Ledger Verification: PASSED (SHA-256 Hash Chain 100% Intact)."),
        Err(idx) => println!("Audit Ledger Verification: FAILED at index {}", idx),
    }
    println!("===============================================================================");
}
