//! bastion_bench — measured benchmarks for the Agent Bastion runner path.
//!
//! Drives the REAL `ContainmentPipeline` (detect → decide → contain) with
//! representative payloads and reports submit→outcome latency and throughput.
//! No mocks: every number comes from timing `ContainmentPipeline::process`
//! on this machine, in this build. Payload classes are chosen by a
//! calibration pass against the real detector, and the measured threat
//! score + decision for each class is printed alongside the timings — if a
//! payload does not land in the band its name suggests, the report says so.
//!
//! Run (from the repo root, after `cargo build --release`):
//!   LANE_WORKER_PATH=$PWD/target/release/lane_worker \
//!     cargo run --release --example bastion_bench

use ai_infinity_force_one_vault::sandbox::{ContainmentDecision, ContainmentPipeline, LaneId};
use std::sync::Arc;
use std::time::{Duration, Instant};

fn entropy_blob(size: usize) -> Vec<u8> {
    // Same construction the pipeline's own tests use for the quarantine band.
    let mut payload = vec![0u8; size];
    for (i, b) in payload.iter_mut().enumerate() {
        *b = ((i.wrapping_mul(2654435761)) % 256) as u8;
    }
    payload
}

fn decision_name(d: &ContainmentDecision) -> &'static str {
    match d {
        ContainmentDecision::ExecuteStandard { .. } => "ExecuteStandard",
        ContainmentDecision::ExecuteIsolated { .. } => "ExecuteIsolated",
        ContainmentDecision::SealedHold { .. } => "SealedHold",
    }
}

struct ClassBench {
    name: String,
    lane: LaneId,
    payload: Vec<u8>,
    score: u32,
    decision: String,
    iterations: usize,
}

fn percentile(sorted: &[Duration], p: f64) -> Duration {
    if sorted.is_empty() {
        return Duration::ZERO;
    }
    let idx = ((sorted.len() as f64 - 1.0) * p).round() as usize;
    sorted[idx.min(sorted.len() - 1)]
}

fn bench_class(
    pipeline: &ContainmentPipeline,
    class: &ClassBench,
) -> (Duration, Duration, Duration, f64) {
    // Warmup (also proves the class still lands where calibration put it).
    for _ in 0..3 {
        let _ = pipeline.process(class.lane, class.payload.clone());
    }
    let mut samples = Vec::with_capacity(class.iterations);
    for _ in 0..class.iterations {
        let start = Instant::now();
        let _ = pipeline.process(class.lane, class.payload.clone());
        samples.push(start.elapsed());
    }
    samples.sort();
    let total: Duration = samples.iter().sum();
    let mean = total / samples.len() as u32;
    let median = percentile(&samples, 0.50);
    let p95 = percentile(&samples, 0.95);
    let ops = samples.len() as f64 / total.as_secs_f64();
    (mean, median, p95, ops)
}

fn main() {
    let max_payload = 1_048_576;
    let pipeline = ContainmentPipeline::new(max_payload);
    println!("=== Agent Bastion — ContainmentPipeline benchmark ===");
    println!(
        "isolated containment available: {}",
        pipeline.has_isolated_containment()
    );
    let cores = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1);
    let cpu = std::fs::read_to_string("/proc/cpuinfo")
        .ok()
        .and_then(|s| {
            s.lines()
                .find(|l| l.starts_with("model name"))
                .map(|l| l.split(':').nth(1).unwrap_or("").trim().to_string())
        })
        .unwrap_or_else(|| "unknown CPU".to_string());
    println!("machine: {cpu} | logical cores visible: {cores}");

    // ---- Calibration: pick payloads by the band they ACTUALLY land in. ----
    let candidates: Vec<(String, LaneId, Vec<u8>)> = vec![
        (
            "clean-text".into(),
            LaneId::Mack04AiCore,
            b"hello, this is a benign test payload".to_vec(),
        ),
        (
            "entropy-512".into(),
            LaneId::Mack10Payload,
            entropy_blob(512),
        ),
        (
            "entropy-256".into(),
            LaneId::Mack10Payload,
            entropy_blob(256),
        ),
        (
            "entropy-4096".into(),
            LaneId::Mack10Payload,
            entropy_blob(4096),
        ),
        (
            "c2-beacon".into(),
            LaneId::Mack06Comms,
            b"POST /c2/beacon HTTP/1.1\r\nHost: evil.example.com\r\n".to_vec(),
        ),
        ("empty".into(), LaneId::Mack04AiCore, Vec::new()),
    ];

    println!("\n--- calibration (one pass per candidate) ---");
    let mut chosen: Vec<ClassBench> = Vec::new();
    let mut have_standard = false;
    let mut have_isolated = false;
    let mut have_sealed = false;
    for (name, lane, payload) in candidates {
        let r = pipeline.process(lane, payload.clone());
        let score = r.scan.triage.threat_score;
        let dname = decision_name(&r.decision).to_string();
        println!("{name:<14} score={score:<3} decision={dname}");
        let iterations = match r.decision {
            ContainmentDecision::ExecuteStandard { .. } if !have_standard => {
                have_standard = true;
                300
            }
            ContainmentDecision::ExecuteIsolated { .. } if !have_isolated => {
                have_isolated = true;
                60
            }
            ContainmentDecision::SealedHold { .. } if !have_sealed => {
                have_sealed = true;
                300
            }
            _ => continue,
        };
        chosen.push(ClassBench {
            name,
            lane,
            payload,
            score,
            decision: dname,
            iterations,
        });
    }
    if !have_isolated {
        println!("NOTE: no candidate landed in the isolated band on this run; isolated timing skipped, not estimated.");
    }

    // ---- Sequential latency / throughput per class. ----
    println!("\n--- sequential: submit -> outcome (scan + decision + execution) ---");
    let mut json_rows = Vec::new();
    for class in &chosen {
        let (mean, median, p95, ops) = bench_class(&pipeline, class);
        println!(
            "{:<14} score={:<3} {:<16} n={:<3} mean={:>8.3} ms  median={:>8.3} ms  p95={:>8.3} ms  {:>7.1} ops/s",
            class.name,
            class.score,
            class.decision,
            class.iterations,
            mean.as_secs_f64() * 1e3,
            median.as_secs_f64() * 1e3,
            p95.as_secs_f64() * 1e3,
            ops
        );
        json_rows.push(format!(
            "{{\"class\":\"{}\",\"score\":{},\"decision\":\"{}\",\"n\":{},\"mean_ms\":{:.3},\"median_ms\":{:.3},\"p95_ms\":{:.3},\"ops_per_sec\":{:.1}}}",
            class.name,
            class.score,
            class.decision,
            class.iterations,
            mean.as_secs_f64() * 1e3,
            median.as_secs_f64() * 1e3,
            p95.as_secs_f64() * 1e3,
            ops
        ));
    }

    // ---- Concurrent throughput: one shared pipeline, 4 threads, clean class. ----
    if let Some(class) = chosen.iter().find(|c| c.decision == "ExecuteStandard") {
        let shared = Arc::new(ContainmentPipeline::new(max_payload));
        let threads = 4usize;
        let per_thread = 150usize;
        let start = Instant::now();
        let mut handles = Vec::new();
        for _ in 0..threads {
            let p = Arc::clone(&shared);
            let lane = class.lane;
            let payload = class.payload.clone();
            handles.push(std::thread::spawn(move || {
                for _ in 0..per_thread {
                    let _ = p.process(lane, payload.clone());
                }
            }));
        }
        for h in handles {
            let _ = h.join();
        }
        let elapsed = start.elapsed().as_secs_f64();
        let total_ops = (threads * per_thread) as f64;
        println!(
            "\n--- concurrent: {} threads x {} clean submits on one shared pipeline: {:.1} ops/s aggregate ({:.2} s wall) ---",
            threads,
            per_thread,
            total_ops / elapsed,
            elapsed
        );
        json_rows.push(format!(
            "{{\"class\":\"concurrent-clean\",\"threads\":{},\"total_ops\":{},\"ops_per_sec\":{:.1}}}",
            threads,
            total_ops as u64,
            total_ops / elapsed
        ));
    }

    println!("\nJSON: [{}]", json_rows.join(","));
}
