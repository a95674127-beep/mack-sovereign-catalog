//! Offline D-DIL benchmark harness for the Mack Stack.
//!
//! Measures, fully offline with zero cloud exfiltration:
//!  1. Detection throughput — per-payload scan latency of [`OfflineThreatEngine`]
//!     across every fixture in `tests/fixtures/`, over many iterations.
//!  2. 12-lane detonation — [`ContainmentPipeline`] detect → decide → contain
//!     routing across all 12 MACK lanes (clean executes in-lane, suspicious is
//!     isolated, sealed never executes).
//!  3. Ledger integrity — [`ConcurrentLedger`] append throughput plus a full
//!     hash-chain verification.
//!
//! Writes `ddil_benchmark_results.json` and `ddil_benchmark_results.csv`
//! to the current working directory.
//!
//! Run with: `cargo run --example offline_ddil_benchmark`

use ai_infinity_force_one_vault::detection::OfflineThreatEngine;
use ai_infinity_force_one_vault::sandbox::{ContainmentPipeline, LaneId};
use ai_infinity_force_one_vault::vault::audit::ConcurrentLedger;

use std::fs;
use std::path::{Path, PathBuf};
use std::time::Instant;

/// Scans per fixture file for the detection-throughput benchmark.
const ITERATIONS_PER_PAYLOAD: usize = 100;
/// Max payload the benchmark pipeline will accept (10 MiB).
const MAX_PAYLOAD_BYTES: usize = 10 * 1024 * 1024;

struct PayloadProfile {
    name: String,
    bytes: usize,
    expected: &'static str,
    verdict: String,
    threat_score: u32,
    avg_latency_micros: f64,
    scans: usize,
}

struct LaneRun {
    lane: String,
    payload: String,
    decision: String,
    executed: String,
    latency_micros: u128,
}

fn collect_fixtures(dir: &Path, out: &mut Vec<PathBuf>) {
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            collect_fixtures(&path, out);
        } else if path.is_file() {
            out.push(path);
        }
    }
}

fn decision_name(
    decision: &ai_infinity_force_one_vault::sandbox::ContainmentDecision,
) -> &'static str {
    match decision {
        ai_infinity_force_one_vault::sandbox::ContainmentDecision::ExecuteStandard { .. } => {
            "ExecuteStandard"
        }
        ai_infinity_force_one_vault::sandbox::ContainmentDecision::ExecuteIsolated { .. } => {
            "ExecuteIsolated"
        }
        ai_infinity_force_one_vault::sandbox::ContainmentDecision::SealedHold { .. } => {
            "SealedHold"
        }
    }
}

fn main() {
    let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let fixture_root = manifest_dir.join("tests").join("fixtures");

    let mut fixture_paths: Vec<PathBuf> = Vec::new();
    collect_fixtures(&fixture_root, &mut fixture_paths);
    fixture_paths.sort();
    assert!(
        !fixture_paths.is_empty(),
        "no fixture files found under {}",
        fixture_root.display()
    );

    let engine = OfflineThreatEngine::default();

    // ---- 1. Detection throughput benchmark ----
    println!(
        "Scanning {} fixture payloads x {} iterations...",
        fixture_paths.len(),
        ITERATIONS_PER_PAYLOAD
    );
    let mut profiles: Vec<PayloadProfile> = Vec::new();
    let mut total_scans: usize = 0;
    let detect_start = Instant::now();
    for path in &fixture_paths {
        let data = fs::read(path).expect("fixture must be readable");
        let name = path
            .file_name()
            .map(|s| s.to_string_lossy().into_owned())
            .unwrap_or_else(|| "?".to_string());
        let expected = if name.starts_with("benign_") {
            "benign"
        } else if name.starts_with("malicious_") {
            "malicious"
        } else {
            "unknown"
        };

        // First scan drives the recorded verdict/score.
        let first = engine.scan_payload(&data);
        let verdict = first.triage.outcome.as_str().to_string();
        let threat_score = first.triage.threat_score;

        let t0 = Instant::now();
        for _ in 0..ITERATIONS_PER_PAYLOAD {
            let _ = engine.scan_payload(&data);
        }
        let elapsed = t0.elapsed();
        total_scans += ITERATIONS_PER_PAYLOAD;

        profiles.push(PayloadProfile {
            name,
            bytes: data.len(),
            expected,
            verdict,
            threat_score,
            avg_latency_micros: elapsed.as_micros() as f64 / ITERATIONS_PER_PAYLOAD as f64,
            scans: ITERATIONS_PER_PAYLOAD,
        });
    }
    let detect_elapsed = detect_start.elapsed();
    let detect_elapsed_secs = detect_elapsed.as_secs_f64();
    let avg_latency_micros = detect_elapsed.as_micros() as f64 / total_scans.max(1) as f64;
    let throughput = total_scans as f64 / detect_elapsed_secs.max(f64::EPSILON);

    let clean = profiles.iter().filter(|p| p.verdict == "CLEAN").count();
    let quarantined = profiles
        .iter()
        .filter(|p| p.verdict == "QUARANTINE")
        .count();
    let sealed = profiles.iter().filter(|p| p.verdict == "SEALED").count();
    println!(
        "  verdicts: {} CLEAN / {} QUARANTINE / {} SEALED | {:.1} scans/sec",
        clean, quarantined, sealed, throughput
    );

    // ---- 2. 12-lane detonation batch ----
    println!("Running 12-lane containment batch...");
    let benign_path = fixture_paths
        .iter()
        .find(|p| {
            p.file_name()
                .map(|s| s.to_string_lossy().starts_with("benign_"))
                .unwrap_or(false)
        })
        .expect("at least one benign fixture");
    let malicious_path = fixture_paths
        .iter()
        .find(|p| {
            p.file_name()
                .map(|s| s.to_string_lossy().starts_with("malicious_"))
                .unwrap_or(false)
        })
        .expect("at least one malicious fixture");
    let benign_bytes = fs::read(benign_path).expect("benign fixture readable");
    let malicious_bytes = fs::read(malicious_path).expect("malicious fixture readable");

    let pipeline = ContainmentPipeline::new(MAX_PAYLOAD_BYTES);
    let mut lane_runs: Vec<LaneRun> = Vec::new();
    let lane_start = Instant::now();
    for (i, lane) in LaneId::ALL_LANES.iter().enumerate() {
        let lane_name = format!("MACK-{:02}", i + 1);
        // Alternate benign / malicious across lanes so every lane sees both
        // classes over the batch.
        for (tag, bytes) in [("benign", &benign_bytes), ("malicious", &malicious_bytes)] {
            let t0 = Instant::now();
            let result = pipeline.process(*lane, bytes.clone());
            let micros = t0.elapsed().as_micros();
            let executed = match &result.execution {
                None => "not-executed(sealed)",
                Some(Ok(_)) => "ok",
                Some(Err(_)) => "rejected(fail-closed)",
            }
            .to_string();
            lane_runs.push(LaneRun {
                lane: lane_name.clone(),
                payload: tag.to_string(),
                decision: decision_name(&result.decision).to_string(),
                executed,
                latency_micros: micros,
            });
        }
    }
    let lane_elapsed_secs = lane_start.elapsed().as_secs_f64();
    let detonations_run = lane_runs.len();
    println!(
        "  {} lane executions in {:.2}s",
        detonations_run, lane_elapsed_secs
    );

    // ---- 3. Ledger chain-of-custody benchmark ----
    println!("Benchmarking ledger append + verification...");
    let ledger = ConcurrentLedger::new();
    let ledger_start = Instant::now();
    for p in &profiles {
        ledger.append(
            "ddil-benchmark",
            &format!(
                "scan {} -> {} (score {})",
                p.name, p.verdict, p.threat_score
            ),
        );
    }
    for r in &lane_runs {
        ledger.append(
            "ddil-benchmark",
            &format!("lane {} {} -> {}", r.lane, r.payload, r.decision),
        );
    }
    let ledger_append_secs = ledger_start.elapsed().as_secs_f64();
    let ledger_records = ledger.len();
    let integrity_validated = ledger.verify().is_ok();
    let head_hash = ledger.head_hash();
    println!(
        "  {} records chained, integrity valid: {}",
        ledger_records, integrity_validated
    );

    // ---- Write JSON report ----
    let timestamp = chrono::Utc::now().to_rfc3339();
    let payload_json: Vec<serde_json::Value> = profiles
        .iter()
        .map(|p| {
            serde_json::json!({
                "payload_name": p.name,
                "payload_bytes": p.bytes,
                "expected_class": p.expected,
                "triage_verdict": p.verdict,
                "threat_score": p.threat_score,
                "scans": p.scans,
                "avg_latency_micros": p.avg_latency_micros,
            })
        })
        .collect();
    let lane_json: Vec<serde_json::Value> = lane_runs
        .iter()
        .map(|r| {
            serde_json::json!({
                "lane": r.lane,
                "payload": r.payload,
                "containment_decision": r.decision,
                "execution": r.executed,
                "latency_micros": r.latency_micros,
            })
        })
        .collect();
    let report = serde_json::json!({
        "metadata": {
            "timestamp_utc": timestamp,
            "environment": "D-DIL Offline Edge (12-Lane Mack Stack)",
            "iterations_per_payload": ITERATIONS_PER_PAYLOAD,
        },
        "detection": {
            "total_scans": total_scans,
            "elapsed_detection_secs": detect_elapsed_secs,
            "avg_latency_micros": avg_latency_micros,
            "throughput_scans_per_sec": throughput,
            "verdicts": {"clean": clean, "quarantine": quarantined, "sealed": sealed},
        },
        "lanes": {
            "detonations_run": detonations_run,
            "detonation_duration_secs": lane_elapsed_secs,
            "runs": lane_json,
        },
        "chain_of_custody": {
            "ledger_records_chained": ledger_records,
            "ledger_integrity_validated": integrity_validated,
            "ledger_head_hash": head_hash,
            "ledger_append_secs": ledger_append_secs,
        },
        "payloads": payload_json,
    });
    fs::write(
        "ddil_benchmark_results.json",
        serde_json::to_string_pretty(&report).expect("json serializes"),
    )
    .expect("json report writable");
    println!("Wrote ddil_benchmark_results.json");

    // ---- Write CSV report ----
    let mut csv = String::new();
    csv.push_str("metric,value,unit\n");
    let kv = [
        ("timestamp_utc", timestamp.clone(), ""),
        (
            "iterations_per_payload",
            ITERATIONS_PER_PAYLOAD.to_string(),
            "count",
        ),
        ("total_scans", total_scans.to_string(), "count"),
        (
            "elapsed_detection_secs",
            format!("{:.3}", detect_elapsed_secs),
            "seconds",
        ),
        (
            "avg_latency_micros",
            format!("{:.1}", avg_latency_micros),
            "microseconds",
        ),
        (
            "throughput_scans_per_sec",
            format!("{:.1}", throughput),
            "scans_per_second",
        ),
        ("verdicts_clean", clean.to_string(), "count"),
        ("verdicts_quarantine", quarantined.to_string(), "count"),
        ("verdicts_sealed", sealed.to_string(), "count"),
        ("detonations_run", detonations_run.to_string(), "count"),
        (
            "detonation_duration_secs",
            format!("{:.3}", lane_elapsed_secs),
            "seconds",
        ),
        ("lanes_executed", "12".to_string(), "count"),
        (
            "ledger_records_chained",
            ledger_records.to_string(),
            "count",
        ),
        (
            "ledger_integrity_validated",
            integrity_validated.to_string(),
            "boolean",
        ),
        (
            "ledger_append_secs",
            format!("{:.3}", ledger_append_secs),
            "seconds",
        ),
    ];
    for (k, v, u) in kv {
        csv.push_str(&format!("{},{},{}\n", k, v, u));
    }
    csv.push_str("\n# per-payload detection matrix\n");
    csv.push_str("payload_name,payload_bytes,expected_class,triage_verdict,threat_score,scans,avg_latency_micros\n");
    for p in &profiles {
        csv.push_str(&format!(
            "{},{},{},{},{},{},{:.1}\n",
            p.name, p.bytes, p.expected, p.verdict, p.threat_score, p.scans, p.avg_latency_micros
        ));
    }
    csv.push_str("\n# per-lane containment matrix\n");
    csv.push_str("lane,payload,containment_decision,execution,latency_micros\n");
    for r in &lane_runs {
        csv.push_str(&format!(
            "{},{},{},{},{}\n",
            r.lane, r.payload, r.decision, r.executed, r.latency_micros
        ));
    }
    fs::write("ddil_benchmark_results.csv", csv).expect("csv report writable");
    println!("Wrote ddil_benchmark_results.csv");

    println!(
        "\nDone. Throughput: {:.1} scans/sec | Ledger integrity: {} | Lanes: {}/12",
        throughput,
        integrity_validated,
        LaneId::ALL_LANES.len()
    );
}
