use ai_infinity_force_one_vault::vault::audit::AuditLog;
use std::fs::File;
use std::io::Write;

fn main() {
    let mut log = AuditLog::new();
    log.append("system", "system_start");
    log.append("mack_01", "lane_execute");
    log.append("mack_02", "lane_execute");
    log.append("system", "threat_scan_clean");

    let mut file = File::create("ledger.jsonl").expect("create ledger.jsonl");
    for entry in log.entries() {
        let line = serde_json::to_string(entry).expect("serialize entry");
        writeln!(file, "{}", line).expect("write line");
        println!("{}", line);
    }

    match log.verify() {
        Ok(()) => println!("chain verified: {} entries", log.len()),
        Err(i) => println!("CHAIN BROKEN at entry {}", i),
    }
}
