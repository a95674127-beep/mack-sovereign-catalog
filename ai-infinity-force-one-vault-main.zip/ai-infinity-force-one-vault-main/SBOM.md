# SBOM — Dependency Inventory (from Cargo.lock)

> Generated 2026-11-06 from `Cargo.lock` of ai-infinity-force-one-vault 0.1.0
> (413 locked packages, including this crate itself). License strings are
> the `license` field of each package's own published manifest, resolved from the
> local Cargo registry cache (409 of 413 resolved; the rest are marked
> "not resolved locally" rather than guessed).

## Relationship to docs/CYCLONEDX_SBOM.json

The repository also carries `docs/CYCLONEDX_SBOM.json` (CycloneDX 1.5). It is
**stale and partial**: it lists only 5 components, at versions older than the
current lock (e.g. chacha20poly1305 0.10.1 there vs 0.11 in `Cargo.toml`).
This inventory supersedes it as the current dependency record until a fresh
CycloneDX SBOM is generated with `cargo cyclonedx` (not installed on the build
machine used for this change).

| Package | Version | License | Source |
|---|---|---|---|
| addr2line | 0.26.1 | Apache-2.0 OR MIT | crates.io |
| adler2 | 2.0.1 | 0BSD OR MIT OR Apache-2.0 | crates.io |
| aead | 0.6.1 | MIT OR Apache-2.0 | crates.io |
| aho-corasick | 1.1.5 | Unlicense OR MIT | crates.io |
| ai-infinity-force-one-vault | 0.1.0 | not resolved locally | workspace |
| allocator-api2 | 0.2.21 | MIT OR Apache-2.0 | crates.io |
| android_system_properties | 0.1.6 | MIT OR Apache-2.0 | crates.io |
| anes | 0.1.6 | MIT OR Apache-2.0 | crates.io |
| annotate-snippets | 0.12.17 | MIT OR Apache-2.0 | crates.io |
| anstyle | 1.0.14 | MIT OR Apache-2.0 | crates.io |
| anyhow | 1.0.104 | MIT OR Apache-2.0 | crates.io |
| arbitrary | 1.5.0 | MIT OR Apache-2.0 | crates.io |
| argon2 | 0.6.0 | MIT OR Apache-2.0 | crates.io |
| ascii_tree | 0.1.1 | MIT | crates.io |
| asn1-rs | 0.7.2 | MIT OR Apache-2.0 | crates.io |
| asn1-rs-derive | 0.6.0 | MIT OR Apache-2.0 | crates.io |
| asn1-rs-impl | 0.2.0 | MIT/Apache-2.0 | crates.io |
| async-trait | 0.1.92 | MIT OR Apache-2.0 | crates.io |
| atomic-waker | 1.1.2 | Apache-2.0 OR MIT | crates.io |
| autocfg | 1.5.1 | Apache-2.0 OR MIT | crates.io |
| axum | 0.7.9 | MIT | crates.io |
| axum-core | 0.4.5 | MIT | crates.io |
| base16ct | 1.0.0 | Apache-2.0 OR MIT | crates.io |
| base64 | 0.23.1 | MIT OR Apache-2.0 | crates.io |
| base64ct | 1.8.3 | Apache-2.0 OR MIT | crates.io |
| bincode | 2.0.1 | MIT | crates.io |
| bincode_derive | 2.0.1 | MIT | crates.io |
| bit-set | 0.8.0 | Apache-2.0 OR MIT | crates.io |
| bit-vec | 0.8.0 | Apache-2.0 OR MIT | crates.io |
| bitflags | 2.13.2 | MIT OR Apache-2.0 | crates.io |
| bitvec | 1.1.1 | MIT | crates.io |
| blake2 | 0.11.0 | MIT OR Apache-2.0 | crates.io |
| block-buffer | 0.10.4 | MIT OR Apache-2.0 | crates.io |
| block-buffer | 0.12.1 | MIT OR Apache-2.0 | crates.io |
| bstr | 1.13.1 | MIT OR Apache-2.0 | crates.io |
| bumpalo | 3.20.3 | MIT OR Apache-2.0 | crates.io |
| bytes | 1.12.1 | MIT | crates.io |
| cast | 0.3.0 | MIT OR Apache-2.0 | crates.io |
| cc | 1.6.0 | MIT OR Apache-2.0 | crates.io |
| cfg-if | 1.0.5 | MIT OR Apache-2.0 | crates.io |
| cfg_aliases | 0.2.2 | MIT | crates.io |
| chacha20 | 0.10.2 | MIT OR Apache-2.0 | crates.io |
| chacha20poly1305 | 0.11.0 | Apache-2.0 OR MIT | crates.io |
| chrono | 0.4.45 | MIT OR Apache-2.0 | crates.io |
| ciborium | 0.2.2 | Apache-2.0 | crates.io |
| ciborium-io | 0.2.2 | Apache-2.0 | crates.io |
| ciborium-ll | 0.2.2 | Apache-2.0 | crates.io |
| cipher | 0.5.2 | MIT OR Apache-2.0 | crates.io |
| clap | 4.6.7 | MIT OR Apache-2.0 | crates.io |
| clap_builder | 4.6.7 | MIT OR Apache-2.0 | crates.io |
| clap_lex | 1.1.1 | MIT OR Apache-2.0 | crates.io |
| cmov | 0.5.4 | Apache-2.0 OR MIT | crates.io |
| cobs | 0.3.0 | MIT OR Apache-2.0 | crates.io |
| const-oid | 0.10.2 | Apache-2.0 OR MIT | crates.io |
| const-oid | 0.9.6 | Apache-2.0 OR MIT | crates.io |
| core-foundation-sys | 0.8.7 | MIT OR Apache-2.0 | crates.io |
| countme | 3.0.1 | MIT OR Apache-2.0 | crates.io |
| cpp_demangle | 0.5.1 | MIT OR Apache-2.0 | crates.io |
| cpubits | 0.1.1 | MIT OR Apache-2.0 | crates.io |
| cpufeatures | 0.2.17 | MIT OR Apache-2.0 | crates.io |
| cpufeatures | 0.3.1 | MIT OR Apache-2.0 | crates.io |
| cranelift-assembler-x64 | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-assembler-x64-meta | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-bforest | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-bitset | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-codegen | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-codegen-meta | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-codegen-shared | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-control | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-entity | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-frontend | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-isle | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-native | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| cranelift-srcgen | 0.135.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| crc32fast | 1.5.2 | MIT OR Apache-2.0 | crates.io |
| criterion | 0.5.1 | Apache-2.0 OR MIT | crates.io |
| criterion-plot | 0.5.0 | MIT/Apache-2.0 | crates.io |
| crossbeam-deque | 0.8.8 | MIT OR Apache-2.0 | crates.io |
| crossbeam-epoch | 0.9.21 | MIT OR Apache-2.0 | crates.io |
| crossbeam-utils | 0.8.23 | MIT OR Apache-2.0 | crates.io |
| crunchy | 0.2.4 | not resolved locally | crates.io |
| crypto-bigint | 0.7.10 | Apache-2.0 OR MIT | crates.io |
| crypto-common | 0.1.7 | MIT OR Apache-2.0 | crates.io |
| crypto-common | 0.2.2 | MIT OR Apache-2.0 | crates.io |
| crypto-primes | 0.7.2 | Apache-2.0 OR MIT | crates.io |
| ctutils | 0.4.6 | Apache-2.0 OR MIT | crates.io |
| curve25519-dalek | 4.1.3 | BSD-3-Clause | crates.io |
| curve25519-dalek-derive | 0.1.1 | MIT/Apache-2.0 | crates.io |
| daachorse | 5.1.0 | MIT OR Apache-2.0 | crates.io |
| darling | 0.24.1 | MIT | crates.io |
| darling_core | 0.24.1 | MIT | crates.io |
| darling_macro | 0.24.1 | MIT | crates.io |
| data-encoding | 2.11.1 | MIT | crates.io |
| der | 0.7.10 | Apache-2.0 OR MIT | crates.io |
| der | 0.8.3 | Apache-2.0 OR MIT | crates.io |
| der-parser | 10.0.0 | MIT OR Apache-2.0 | crates.io |
| deranged | 0.5.8 | MIT OR Apache-2.0 | crates.io |
| digest | 0.10.7 | MIT OR Apache-2.0 | crates.io |
| digest | 0.11.3 | MIT OR Apache-2.0 | crates.io |
| displaydoc | 0.2.7 | MIT OR Apache-2.0 | crates.io |
| dsa | 0.7.0 | Apache-2.0 OR MIT | crates.io |
| ecdsa | 0.17.0 | Apache-2.0 OR MIT | crates.io |
| ed25519 | 2.2.3 | Apache-2.0 OR MIT | crates.io |
| ed25519-dalek | 2.2.0 | BSD-3-Clause | crates.io |
| either | 1.19.0 | MIT OR Apache-2.0 | crates.io |
| elliptic-curve | 0.14.3 | Apache-2.0 OR MIT | crates.io |
| embedded-io | 0.4.0 | MIT OR Apache-2.0 | crates.io |
| embedded-io | 0.6.1 | MIT OR Apache-2.0 | crates.io |
| enumflags2 | 0.7.12 | MIT OR Apache-2.0 | crates.io |
| enumflags2_derive | 0.7.12 | MIT OR Apache-2.0 | crates.io |
| equivalent | 1.0.2 | Apache-2.0 OR MIT | crates.io |
| errno | 0.3.14 | MIT OR Apache-2.0 | crates.io |
| fallible-iterator | 0.3.0 | MIT/Apache-2.0 | crates.io |
| fastrand | 2.5.0 | Apache-2.0 OR MIT | crates.io |
| ff | 0.14.0 | MIT/Apache-2.0 | crates.io |
| fiat-crypto | 0.2.9 | MIT OR Apache-2.0 OR BSD-1-Clause | crates.io |
| fiat-crypto | 0.3.0 | MIT OR Apache-2.0 OR BSD-1-Clause | crates.io |
| find-msvc-tools | 0.1.14 | MIT OR Apache-2.0 | crates.io |
| flate2 | 1.1.10 | MIT OR Apache-2.0 | crates.io |
| fnv | 1.0.7 | Apache-2.0 / MIT | crates.io |
| foldhash | 0.2.0 | Zlib | crates.io |
| form_urlencoded | 1.2.2 | MIT OR Apache-2.0 | crates.io |
| funty | 2.0.0 | MIT | crates.io |
| futures | 0.3.34 | MIT OR Apache-2.0 | crates.io |
| futures-channel | 0.3.34 | MIT OR Apache-2.0 | crates.io |
| futures-core | 0.3.34 | MIT OR Apache-2.0 | crates.io |
| futures-io | 0.3.34 | MIT OR Apache-2.0 | crates.io |
| futures-sink | 0.3.34 | MIT OR Apache-2.0 | crates.io |
| futures-task | 0.3.34 | MIT OR Apache-2.0 | crates.io |
| futures-util | 0.3.34 | MIT OR Apache-2.0 | crates.io |
| generator | 0.8.11 | MIT/Apache-2.0 | crates.io |
| generic-array | 0.14.7 | MIT | crates.io |
| getrandom | 0.2.17 | MIT OR Apache-2.0 | crates.io |
| getrandom | 0.3.4 | MIT OR Apache-2.0 | crates.io |
| getrandom | 0.4.3 | MIT OR Apache-2.0 | crates.io |
| gimli | 0.32.3 | MIT OR Apache-2.0 | crates.io |
| gimli | 0.33.0 | MIT OR Apache-2.0 | crates.io |
| globset | 0.4.20 | Unlicense OR MIT | crates.io |
| globwalk | 0.9.1 | MIT | crates.io |
| group | 0.14.0 | MIT/Apache-2.0 | crates.io |
| half | 2.7.1 | MIT OR Apache-2.0 | crates.io |
| hashbrown | 0.14.5 | MIT OR Apache-2.0 | crates.io |
| hashbrown | 0.16.1 | MIT OR Apache-2.0 | crates.io |
| hashbrown | 0.17.1 | MIT OR Apache-2.0 | crates.io |
| heck | 0.5.0 | MIT OR Apache-2.0 | crates.io |
| hermit-abi | 0.5.3 | not resolved locally | crates.io |
| hex | 0.4.3 | MIT OR Apache-2.0 | crates.io |
| hmac | 0.13.0 | MIT OR Apache-2.0 | crates.io |
| home | 0.5.12 | MIT OR Apache-2.0 | crates.io |
| http | 1.5.0 | MIT OR Apache-2.0 | crates.io |
| http-body | 1.1.0 | MIT | crates.io |
| http-body-util | 0.1.5 | MIT | crates.io |
| httparse | 1.10.1 | MIT OR Apache-2.0 | crates.io |
| httpdate | 1.0.3 | MIT OR Apache-2.0 | crates.io |
| hybrid-array | 0.4.15 | MIT OR Apache-2.0 | crates.io |
| hyper | 1.12.0 | MIT | crates.io |
| hyper-util | 0.1.21 | MIT | crates.io |
| iana-time-zone | 0.1.65 | MIT OR Apache-2.0 | crates.io |
| iana-time-zone-haiku | 0.1.2 | MIT OR Apache-2.0 | crates.io |
| id-arena | 2.3.0 | MIT/Apache-2.0 | crates.io |
| ident_case | 1.0.1 | MIT/Apache-2.0 | crates.io |
| ignore | 0.4.33 | Unlicense OR MIT | crates.io |
| indexmap | 2.14.2 | Apache-2.0 OR MIT | crates.io |
| inout | 0.2.2 | MIT OR Apache-2.0 | crates.io |
| intaglio | 1.15.1 | Apache-2.0 OR MIT | crates.io |
| inventory | 0.3.25 | MIT OR Apache-2.0 | crates.io |
| ipnet | 2.12.2 | MIT OR Apache-2.0 | crates.io |
| is-terminal | 0.4.17 | MIT | crates.io |
| itertools | 0.10.5 | MIT/Apache-2.0 | crates.io |
| itertools | 0.14.0 | MIT OR Apache-2.0 | crates.io |
| itertools | 0.15.0 | MIT OR Apache-2.0 | crates.io |
| itoa | 1.0.18 | MIT OR Apache-2.0 | crates.io |
| js-sys | 0.3.106 | MIT OR Apache-2.0 | crates.io |
| landlock | 0.4.7 | MIT OR Apache-2.0 | crates.io |
| lazy_static | 1.5.1 | MIT OR Apache-2.0 | crates.io |
| leb128 | 0.2.7 | MIT OR Apache-2.0 | crates.io |
| leb128fmt | 0.1.0 | MIT OR Apache-2.0 | crates.io |
| libc | 0.2.190 | MIT OR Apache-2.0 | crates.io |
| libm | 0.2.16 | MIT | crates.io |
| linux-raw-sys | 0.12.1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| linux-raw-sys | 0.4.15 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| lock_api | 0.4.14 | MIT OR Apache-2.0 | crates.io |
| log | 0.4.34 | MIT OR Apache-2.0 | crates.io |
| logos | 0.16.1 | MIT OR Apache-2.0 | crates.io |
| logos-codegen | 0.16.1 | MIT OR Apache-2.0 | crates.io |
| logos-derive | 0.16.1 | MIT OR Apache-2.0 | crates.io |
| loom | 0.7.2 | MIT | crates.io |
| mach2 | 0.6.0 | BSD-2-Clause OR MIT OR Apache-2.0 | crates.io |
| matchers | 0.2.0 | MIT | crates.io |
| matchit | 0.7.3 | MIT AND BSD-3-Clause | crates.io |
| md-5 | 0.11.0 | MIT OR Apache-2.0 | crates.io |
| md2 | 0.11.0 | MIT OR Apache-2.0 | crates.io |
| memchr | 2.8.3 | Unlicense OR MIT | crates.io |
| memfd | 0.6.6 | MIT OR Apache-2.0 | crates.io |
| memmap2 | 0.9.11 | MIT OR Apache-2.0 | crates.io |
| memoffset | 0.9.1 | MIT | crates.io |
| mime | 0.3.17 | MIT OR Apache-2.0 | crates.io |
| minimal-lexical | 0.2.1 | MIT/Apache-2.0 | crates.io |
| miniz_oxide | 0.9.1 | MIT OR Zlib OR Apache-2.0 | crates.io |
| mio | 1.2.4 | MIT | crates.io |
| nix | 0.31.3 | MIT | crates.io |
| nom | 7.1.3 | MIT | crates.io |
| nom | 8.0.0 | MIT | crates.io |
| nu-ansi-term | 0.50.3 | MIT | crates.io |
| num-bigint | 0.4.8 | MIT OR Apache-2.0 | crates.io |
| num-conv | 0.2.2 | MIT OR Apache-2.0 | crates.io |
| num-derive | 0.5.1 | MIT OR Apache-2.0 | crates.io |
| num-integer | 0.1.47 | MIT OR Apache-2.0 | crates.io |
| num-traits | 0.2.19 | MIT OR Apache-2.0 | crates.io |
| object | 0.39.1 | Apache-2.0 OR MIT | crates.io |
| oid-registry | 0.8.1 | MIT OR Apache-2.0 | crates.io |
| once_cell | 1.21.4 | MIT OR Apache-2.0 | crates.io |
| oorandom | 11.1.5 | MIT | crates.io |
| p256 | 0.14.0 | Apache-2.0 OR MIT | crates.io |
| p384 | 0.14.0 | Apache-2.0 OR MIT | crates.io |
| parking_lot | 0.12.5 | MIT OR Apache-2.0 | crates.io |
| parking_lot_core | 0.9.12 | MIT OR Apache-2.0 | crates.io |
| password-hash | 0.6.1 | MIT OR Apache-2.0 | crates.io |
| pem-rfc7468 | 1.0.0 | Apache-2.0 OR MIT | crates.io |
| percent-encoding | 2.3.2 | MIT OR Apache-2.0 | crates.io |
| phc | 0.6.1 | Apache-2.0 OR MIT | crates.io |
| pin-project-lite | 0.2.17 | Apache-2.0 OR MIT | crates.io |
| pkcs1 | 0.8.0-rc.5 | Apache-2.0 OR MIT | crates.io |
| pkcs8 | 0.10.2 | Apache-2.0 OR MIT | crates.io |
| pkcs8 | 0.11.0 | Apache-2.0 OR MIT | crates.io |
| plotters | 0.3.7 | MIT | crates.io |
| plotters-backend | 0.3.7 | MIT | crates.io |
| plotters-svg | 0.3.7 | MIT | crates.io |
| poly1305 | 0.9.1 | Apache-2.0 OR MIT | crates.io |
| postcard | 1.1.3 | MIT OR Apache-2.0 | crates.io |
| powerfmt | 0.2.1 | MIT OR Apache-2.0 | crates.io |
| ppv-lite86 | 0.2.21 | MIT OR Apache-2.0 | crates.io |
| primefield | 0.14.0 | Apache-2.0 OR MIT | crates.io |
| primeorder | 0.14.0 | Apache-2.0 OR MIT | crates.io |
| proc-macro2 | 1.0.107 | MIT OR Apache-2.0 | crates.io |
| proptest | 1.11.0 | MIT OR Apache-2.0 | crates.io |
| protobuf | 3.7.2 | MIT | crates.io |
| protobuf-codegen | 3.7.2 | MIT | crates.io |
| protobuf-parse | 3.7.2 | MIT | crates.io |
| protobuf-support | 3.7.2 | MIT | crates.io |
| psl | 2.1.245 | MIT/Apache-2.0 | crates.io |
| psl-types | 2.0.11 | MIT/Apache-2.0 | crates.io |
| pulley-interpreter | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| pulley-macros | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| quick-error | 1.2.3 | MIT/Apache-2.0 | crates.io |
| quote | 1.0.47 | MIT OR Apache-2.0 | crates.io |
| r-efi | 5.3.0 | MIT OR Apache-2.0 OR LGPL-2.1-or-later | crates.io |
| r-efi | 6.0.0 | MIT OR Apache-2.0 OR LGPL-2.1-or-later | crates.io |
| radium | 0.7.0 | MIT | crates.io |
| rand | 0.8.8 | MIT OR Apache-2.0 | crates.io |
| rand | 0.9.5 | MIT OR Apache-2.0 | crates.io |
| rand_chacha | 0.3.1 | MIT OR Apache-2.0 | crates.io |
| rand_chacha | 0.9.0 | MIT OR Apache-2.0 | crates.io |
| rand_core | 0.10.1 | MIT OR Apache-2.0 | crates.io |
| rand_core | 0.6.4 | MIT OR Apache-2.0 | crates.io |
| rand_core | 0.9.5 | MIT OR Apache-2.0 | crates.io |
| rand_xorshift | 0.4.0 | MIT OR Apache-2.0 | crates.io |
| rayon | 1.12.0 | MIT OR Apache-2.0 | crates.io |
| rayon-core | 1.13.0 | MIT OR Apache-2.0 | crates.io |
| redb | 2.6.4 | MIT OR Apache-2.0 | crates.io |
| redox_syscall | 0.5.18 | MIT | crates.io |
| regalloc2 | 0.15.2 | Apache-2.0 WITH LLVM-exception | crates.io |
| regex | 1.13.1 | MIT OR Apache-2.0 | crates.io |
| regex-automata | 0.4.18 | MIT OR Apache-2.0 | crates.io |
| regex-syntax | 0.8.11 | MIT OR Apache-2.0 | crates.io |
| rfc6979 | 0.6.0 | Apache-2.0 OR MIT | crates.io |
| rowan | 0.17.0 | MIT OR Apache-2.0 | crates.io |
| roxmltree | 0.21.1 | MIT OR Apache-2.0 | crates.io |
| rsa | 0.10.0-rc.19 | MIT OR Apache-2.0 | crates.io |
| rustc-demangle | 0.1.28 | MIT/Apache-2.0 | crates.io |
| rustc-hash | 1.1.0 | Apache-2.0/MIT | crates.io |
| rustc-hash | 2.1.3 | Apache-2.0 OR MIT | crates.io |
| rustc_version | 0.4.1 | MIT OR Apache-2.0 | crates.io |
| rusticata-macros | 4.1.0 | MIT/Apache-2.0 | crates.io |
| rustix | 0.38.44 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| rustix | 1.1.5 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| rustversion | 1.0.23 | MIT OR Apache-2.0 | crates.io |
| rusty-fork | 0.3.1 | MIT/Apache-2.0 | crates.io |
| ryu | 1.0.23 | Apache-2.0 OR BSL-1.0 | crates.io |
| same-file | 1.0.6 | Unlicense/MIT | crates.io |
| scoped-tls | 1.0.1 | MIT/Apache-2.0 | crates.io |
| scopeguard | 1.2.0 | MIT OR Apache-2.0 | crates.io |
| sec1 | 0.8.1 | Apache-2.0 OR MIT | crates.io |
| semver | 1.0.28 | MIT OR Apache-2.0 | crates.io |
| serde | 1.0.229 | MIT OR Apache-2.0 | crates.io |
| serde_core | 1.0.229 | MIT OR Apache-2.0 | crates.io |
| serde_derive | 1.0.229 | MIT OR Apache-2.0 | crates.io |
| serde_json | 1.0.154 | MIT OR Apache-2.0 | crates.io |
| serde_path_to_error | 0.1.20 | MIT OR Apache-2.0 | crates.io |
| serde_urlencoded | 0.7.1 | MIT/Apache-2.0 | crates.io |
| serdect | 0.4.3 | Apache-2.0 OR MIT | crates.io |
| sha1 | 0.11.0 | MIT OR Apache-2.0 | crates.io |
| sha2 | 0.10.9 | MIT OR Apache-2.0 | crates.io |
| sha2 | 0.11.1 | MIT OR Apache-2.0 | crates.io |
| sharded-slab | 0.1.7 | MIT | crates.io |
| shlex | 2.0.1 | MIT OR Apache-2.0 | crates.io |
| signal-hook-registry | 1.4.8 | MIT OR Apache-2.0 | crates.io |
| signature | 2.2.0 | Apache-2.0 OR MIT | crates.io |
| signature | 3.0.0 | Apache-2.0 OR MIT | crates.io |
| simd-adler32 | 0.3.10 | MIT | crates.io |
| simd_cesu8 | 1.2.0 | Apache-2.0 OR MIT | crates.io |
| simdutf8 | 0.1.5 | MIT OR Apache-2.0 | crates.io |
| slab | 0.4.12 | MIT | crates.io |
| smallvec | 1.16.2 | MIT OR Apache-2.0 | crates.io |
| socket2 | 0.6.5 | MIT OR Apache-2.0 | crates.io |
| spki | 0.7.3 | Apache-2.0 OR MIT | crates.io |
| spki | 0.8.1 | Apache-2.0 OR MIT | crates.io |
| stable_deref_trait | 1.2.1 | MIT OR Apache-2.0 | crates.io |
| strsim | 0.11.1 | MIT | crates.io |
| strum_macros | 0.28.0 | MIT | crates.io |
| subtle | 2.6.1 | BSD-3-Clause | crates.io |
| syn | 2.0.119 | MIT OR Apache-2.0 | crates.io |
| syn | 3.0.6 | MIT OR Apache-2.0 | crates.io |
| sync_wrapper | 1.0.2 | Apache-2.0 | crates.io |
| synstructure | 0.13.2 | MIT | crates.io |
| tap | 1.0.1 | MIT | crates.io |
| target-lexicon | 0.13.5 | Apache-2.0 WITH LLVM-exception | crates.io |
| tempfile | 3.27.0 | MIT OR Apache-2.0 | crates.io |
| termcolor | 1.4.1 | Unlicense OR MIT | crates.io |
| text-size | 1.1.1 | MIT OR Apache-2.0 | crates.io |
| thiserror | 1.0.69 | MIT OR Apache-2.0 | crates.io |
| thiserror | 2.0.21 | MIT OR Apache-2.0 | crates.io |
| thiserror-impl | 1.0.69 | MIT OR Apache-2.0 | crates.io |
| thiserror-impl | 2.0.21 | MIT OR Apache-2.0 | crates.io |
| thread_local | 1.1.10 | MIT OR Apache-2.0 | crates.io |
| time | 0.3.55 | MIT OR Apache-2.0 | crates.io |
| time-core | 0.1.9 | MIT OR Apache-2.0 | crates.io |
| time-macros | 0.2.32 | MIT OR Apache-2.0 | crates.io |
| tinytemplate | 1.2.1 | Apache-2.0 OR MIT | crates.io |
| tinyzip | 0.4.0 | MIT | crates.io |
| tokio | 1.54.1 | MIT | crates.io |
| tokio-macros | 2.7.2 | MIT | crates.io |
| tower | 0.5.3 | MIT | crates.io |
| tower-http | 0.5.2 | MIT | crates.io |
| tower-layer | 0.3.3 | MIT | crates.io |
| tower-service | 0.3.3 | MIT | crates.io |
| tracing | 0.1.44 | MIT | crates.io |
| tracing-core | 0.1.36 | MIT | crates.io |
| tracing-log | 0.2.0 | MIT | crates.io |
| tracing-subscriber | 0.3.23 | MIT | crates.io |
| typed-path | 0.13.0 | MIT OR Apache-2.0 | crates.io |
| typenum | 1.20.1 | MIT OR Apache-2.0 | crates.io |
| unarray | 0.1.4 | MIT OR Apache-2.0 | crates.io |
| unicode-ident | 1.0.26 | (MIT OR Apache-2.0) AND Unicode-3.0 | crates.io |
| unicode-width | 0.2.2 | MIT OR Apache-2.0 | crates.io |
| universal-hash | 0.6.1 | MIT OR Apache-2.0 | crates.io |
| unty | 0.0.4 | MIT OR Apache-2.0 | crates.io |
| uuid | 1.29.0 | Apache-2.0 OR MIT | crates.io |
| valuable | 0.1.1 | MIT | crates.io |
| version_check | 0.9.5 | MIT/Apache-2.0 | crates.io |
| virtue | 0.0.18 | MIT | crates.io |
| wait-timeout | 0.2.1 | MIT/Apache-2.0 | crates.io |
| walkdir | 2.5.0 | Unlicense/MIT | crates.io |
| walrus | 0.27.2 | MIT/Apache-2.0 | crates.io |
| walrus-macro | 0.26.0 | MIT/Apache-2.0 | crates.io |
| wasi | 0.11.1+wasi-snapshot-preview1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| wasip2 | 1.0.4+wasi-0.2.12 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| wasm-bindgen | 0.2.129 | MIT OR Apache-2.0 | crates.io |
| wasm-bindgen-macro | 0.2.129 | MIT OR Apache-2.0 | crates.io |
| wasm-bindgen-macro-support | 0.2.129 | MIT OR Apache-2.0 | crates.io |
| wasm-bindgen-shared | 0.2.129 | MIT OR Apache-2.0 | crates.io |
| wasm-encoder | 0.245.1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| wasm-encoder | 0.254.2 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| wasmparser | 0.245.1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| wasmparser | 0.254.2 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| wasmprinter | 0.254.2 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| wasmtime | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| wasmtime-environ | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| wasmtime-internal-component-util | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| wasmtime-internal-core | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| wasmtime-internal-cranelift | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| wasmtime-internal-fiber | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| wasmtime-internal-jit-debug | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| wasmtime-internal-jit-icache-coherence | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| wasmtime-internal-unwinder | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| wasmtime-internal-versioned-export-macros | 48.0.8 | Apache-2.0 WITH LLVM-exception | crates.io |
| web-sys | 0.3.106 | not resolved locally | crates.io |
| which | 4.4.2 | MIT | crates.io |
| winapi-util | 0.1.11 | Unlicense OR MIT | crates.io |
| windows-core | 0.62.2 | MIT OR Apache-2.0 | crates.io |
| windows-implement | 0.60.2 | MIT OR Apache-2.0 | crates.io |
| windows-interface | 0.59.3 | MIT OR Apache-2.0 | crates.io |
| windows-link | 0.2.1 | MIT OR Apache-2.0 | crates.io |
| windows-result | 0.4.1 | MIT OR Apache-2.0 | crates.io |
| windows-strings | 0.5.1 | MIT OR Apache-2.0 | crates.io |
| windows-sys | 0.59.0 | MIT OR Apache-2.0 | crates.io |
| windows-sys | 0.61.2 | MIT OR Apache-2.0 | crates.io |
| windows-targets | 0.52.6 | MIT OR Apache-2.0 | crates.io |
| windows_aarch64_gnullvm | 0.52.6 | MIT OR Apache-2.0 | crates.io |
| windows_aarch64_msvc | 0.52.6 | MIT OR Apache-2.0 | crates.io |
| windows_i686_gnu | 0.52.6 | MIT OR Apache-2.0 | crates.io |
| windows_i686_gnullvm | 0.52.6 | MIT OR Apache-2.0 | crates.io |
| windows_i686_msvc | 0.52.6 | MIT OR Apache-2.0 | crates.io |
| windows_x86_64_gnu | 0.52.6 | MIT OR Apache-2.0 | crates.io |
| windows_x86_64_gnullvm | 0.52.6 | MIT OR Apache-2.0 | crates.io |
| windows_x86_64_msvc | 0.52.6 | MIT OR Apache-2.0 | crates.io |
| wit-bindgen | 0.57.1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | crates.io |
| wnaf | 0.14.1 | Apache-2.0 OR MIT | crates.io |
| wyz | 0.5.1 | MIT | crates.io |
| x509-parser | 0.18.1 | MIT OR Apache-2.0 | crates.io |
| yansi | 1.0.1 | MIT OR Apache-2.0 | crates.io |
| yara-x | 1.22.1 | BSD-3-Clause | crates.io |
| yara-x-macros | 1.22.1 | BSD-3-Clause | crates.io |
| yara-x-parser | 1.22.1 | BSD-3-Clause | crates.io |
| yara-x-proto | 1.22.1 | BSD-3-Clause | crates.io |
| zerocopy | 0.8.60 | BSD-2-Clause OR Apache-2.0 OR MIT | crates.io |
| zerocopy-derive | 0.8.60 | BSD-2-Clause OR Apache-2.0 OR MIT | crates.io |
| zeroize | 1.9.1 | Apache-2.0 OR MIT | crates.io |
| zeroize_derive | 1.5.0 | Apache-2.0 OR MIT | crates.io |
| zip | 9.1.2 | MIT | crates.io |
| zlib-rs | 0.6.8 | Zlib | crates.io |
| zmij | 1.0.23 | MIT | crates.io |
| zopfli | 0.8.3 | Apache-2.0 | crates.io |
