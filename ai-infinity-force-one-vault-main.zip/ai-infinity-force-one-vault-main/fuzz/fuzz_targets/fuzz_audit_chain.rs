#![no_main]
use libfuzzer_sys::fuzz_target;
use ai_infinity_force_one_vault::vault::audit::AuditLog;

fuzz_target!(|data: &[u8]| {
    if data.is_empty() {
        return;
    }
    let mut log = AuditLog::new();
    for chunk in data.chunks(32) {
        let action = format!("fuzz_action_{}", chunk.len());
        log.append("fuzz_actor", &action);
    }
    // A sequentially-built log must always verify; any failure is a bug.
    assert!(log.verify().is_ok(), "Sequential untampered log must verify");
    // Segment verification must not panic on any input.
    let _ = log.verify_segments();
});
