#![no_main]
use libfuzzer_sys::fuzz_target;
use ai_infinity_force_one_vault::detection::entropy_scan::{shannon_entropy, scan_payload};

fuzz_target!(|data: &[u8]| {
    // Must never panic, on any input including empty.
    let entropy = shannon_entropy(data);
    // Entropy is always in [0, 8] for byte data.
    assert!((0.0..=8.0).contains(&entropy), "entropy out of range: {entropy}");
    let _ = scan_payload(data);
});
