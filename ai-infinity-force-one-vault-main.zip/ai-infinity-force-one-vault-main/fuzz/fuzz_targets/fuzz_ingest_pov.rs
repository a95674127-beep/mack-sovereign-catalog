#![no_main]
use libfuzzer_sys::fuzz_target;
use ai_infinity_force_one_vault::vault::policy::Principal;
use ai_infinity_force_one_vault::Vault;

fuzz_target!(|data: &[u8]| {
    if let Ok(s) = std::str::from_utf8(data) {
        let mut vault = Vault::new();
        let principal = Principal("fuzz_operator".to_string());
        // Must not panic on any input; errors are expected for malformed JSON.
        let _ = vault.ingest_pov_json(&principal, s);
    }
});
