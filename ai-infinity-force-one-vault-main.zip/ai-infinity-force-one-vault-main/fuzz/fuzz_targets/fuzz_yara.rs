#![no_main]
use libfuzzer_sys::fuzz_target;
use ai_infinity_force_one_vault::detection::yara::YaraScanner;

fuzz_target!(|data: &[u8]| {
    if data.is_empty() {
        return;
    }
    // Split input: first half as a rule source, second half as scan payload.
    let mid = data.len() / 2;
    let (rule_bytes, payload) = data.split_at(mid);
    if let Ok(rule_src) = std::str::from_utf8(rule_bytes) {
        // The compiler must not panic on any input; errors are fine.
        if let Ok(engine) = YaraScanner::compile(rule_src) {
            // Scanning must not panic on any payload.
            let _ = engine.scan(payload);
        }
    }
    // The default ruleset must handle arbitrary bytes without panicking.
    if let Ok(engine) = YaraScanner::with_default_rules() {
        let _ = engine.scan(data);
    }
});
