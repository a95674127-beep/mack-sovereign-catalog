#![no_main]
use libfuzzer_sys::fuzz_target;
use ai_infinity_force_one_vault::sandbox::lanes::{LaneContainmentEngine, LaneId, LaneStatus};
use ai_infinity_force_one_vault::ingest::IngestRecord;

fuzz_target!(|data: &[u8]| {
    let mut engine = LaneContainmentEngine::new(4096);
    
    for chunk in data.chunks(8) {
        if chunk.is_empty() {
            continue;
        }
        let lane_idx = (chunk[0] as usize) % 12;
        let lane_id = match LaneId::from_index(lane_idx) {
            Some(id) => id,
            None => continue,
        };

        let action = chunk.get(1).copied().unwrap_or(0) % 3;
        match action {
            0 => {
                let payload = chunk.get(2..).unwrap_or(&[]).to_vec();
                let record = IngestRecord::new(lane_id.code(), payload);
                let _ = engine.execute_lane(lane_id, record);
            }
            1 => {
                let _ = engine.lane_status(lane_id);
            }
            2 => {
                engine.clear_lane_quarantine(lane_id);
                assert!(matches!(engine.lane_status(lane_id), LaneStatus::Green));
            }
            _ => unreachable!(),
        }
    }
});
