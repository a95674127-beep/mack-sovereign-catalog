#![no_main]
use libfuzzer_sys::fuzz_target;
use std::sync::OnceLock;

use ai_infinity_force_one_vault::detection::{
    scan_result_to_stix_bundle, ComprehensiveScanResult, OfflineThreatEngine,
};

fn engine() -> &'static OfflineThreatEngine {
    static ENGINE: OnceLock<OfflineThreatEngine> = OnceLock::new();
    ENGINE.get_or_init(OfflineThreatEngine::default)
}

fuzz_target!(|data: &[u8]| {
    // Path 1 (structure-aware): run the real detection engine over the
    // fuzz bytes so the scan result has realistic structure, then export.
    let result = engine().scan_payload(data);
    assert_bundle_invariants(&result, data);

    // Path 2: if the fuzz bytes happen to deserialize into a scan result,
    // export that attacker-shaped structure too.
    if let Ok(parsed) = serde_json::from_slice::<ComprehensiveScanResult>(data) {
        assert_bundle_invariants(&parsed, data);
    }
});

fn assert_bundle_invariants(result: &ComprehensiveScanResult, payload: &[u8]) {
    let bundle = scan_result_to_stix_bundle(result, payload);

    // The export must always be a STIX 2.1 bundle object.
    assert_eq!(bundle["type"], "bundle");
    let objects = bundle["objects"].as_array().expect("bundle objects array");
    // Minimum content, even for a clean scan: identity + file SCO +
    // observed-data + report.
    assert!(
        objects.len() >= 4,
        "bundle must carry at least identity/file/observed-data/report"
    );
    for obj in objects {
        assert!(obj["type"].is_string(), "every STIX object has a type");
        assert_eq!(
            obj["spec_version"], "2.1",
            "every STIX object must declare spec_version 2.1"
        );
    }
    // The bundle must round-trip through JSON serialization.
    let _ = serde_json::to_string(&bundle).expect("bundle must serialize");
}
