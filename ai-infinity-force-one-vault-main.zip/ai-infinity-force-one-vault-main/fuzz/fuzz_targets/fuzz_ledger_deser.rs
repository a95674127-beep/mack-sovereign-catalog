#![no_main]
use libfuzzer_sys::fuzz_target;

use ai_infinity_force_one_vault::vault::audit::{AuditEntry, AuditLog};

fuzz_target!(|data: &[u8]| {
    // Path 1: whole-log JSON deserialization (the AuditLog serde shape).
    // Attacker-controlled bytes must never panic the loader; whatever the
    // outcome, verification calls on a loaded log must not panic either.
    if let Ok(log) = serde_json::from_slice::<AuditLog>(data) {
        let _ = log.verify();
        let _ = log.verify_segments();
        let _ = log.head_hash();
    }

    // Path 2: the persistent-ledger rebuild path — JSONL lines parsed as
    // entries, then AuditLog::from_entries (which verifies on rebuild).
    // Any log this path ACCEPTS must verify cleanly.
    if let Ok(text) = std::str::from_utf8(data) {
        let mut entries: Vec<AuditEntry> = Vec::new();
        for line in text.lines() {
            if let Ok(entry) = serde_json::from_str::<AuditEntry>(line) {
                entries.push(entry);
            }
        }
        if let Ok(log) = AuditLog::from_entries("fuzz-genesis".to_string(), entries) {
            assert!(
                log.verify().is_ok(),
                "a log accepted by from_entries must verify"
            );
        }
    }
});
