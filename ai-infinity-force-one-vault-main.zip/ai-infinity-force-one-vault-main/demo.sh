#!/usr/bin/env bash
# One-command demo for ai-infinity-force-one-vault.
#
# Ingests a benign sample (accepted + encrypted), presents a
# blocklisted sample (rejected before storage), retrieves the stored
# sample intact, and prints verification of the audit ledger that
# recorded every step.
#
# Usage: ./demo.sh
set -euo pipefail
cd "$(dirname "$0")"
cargo run --quiet --example one_command_demo
