# Zeroize Coverage Audit — Elevation A2 (2026-11-10)

Scope: every path in the vault where key material or decrypted plaintext
sits in memory. Method: grep + manual read of `src/crypto.rs`,
`src/vault/crypto.rs`, `src/vault/keyring.rs`, `src/vault/provenance.rs`,
`src/vault/mod.rs`, `src/sandbox/sealed_log.rs`, `src/api/mod.rs`,
`src/pov/mod.rs`, and the decrypt call sites. Status per path below;
changes made in this stage are marked CHANGED, everything else was
verified as-is.

## Findings

| # | Path | Status |
|---|------|--------|
| 1 | `src/vault/crypto.rs` — Argon2id derived keys (encrypt + decrypt) | OK — derived into `Zeroizing<[u8; 32]>`; cipher built via `new_from_slice`, no owned `Key` copy. |
| 2 | `src/vault/crypto.rs::decrypt` | OK — returns `Zeroizing<Vec<u8>>` (harvest stage 4a, 2026-11-10). |
| 3 | `src/vault/crypto.rs` — cipher internal state | RESIDUAL — XChaCha20Poly1305's internal key state lives inside the cipher object for the call's duration and cannot be wiped through the crate's API. Already documented in the code. No change possible at this layer. |
| 4 | `src/vault/keyring.rs` — `SecretKey` storage | OK — key held in `Zeroizing<[u8; KEY_LEN]>`, `zeroize_now()` on revoke, not `Clone`. |
| 5 | `src/vault/keyring.rs` — `SecretKey::decrypt` | **CHANGED** — previously returned plain `Vec<u8>`; now returns `Zeroizing<Vec<u8>>` (`.map(Zeroizing::new)` on the cipher output). |
| 6 | `src/vault/keyring.rs` — `KeyRing::decrypt` | **CHANGED** — same fix, propagated through the facade. |
| 7 | `src/vault/keyring.rs` — `KeyRing::re_encrypt` | OK (simplified) — previously re-wrapped the decrypt output by hand; now consumes the `Zeroizing` return directly, so plaintext is wrapped for its whole lifetime. |
| 8 | `src/vault/mod.rs` — `Vault::retrieve` / `Vault::store` | OK — retrieve returns `Zeroizing<Vec<u8>>`; store takes borrowed `&[u8]` (caller-owned lifetime). |
| 9 | `src/sandbox/sealed_log.rs` — `retained_payload` | OK — returns `Zeroizing<Vec<u8>>` (harvest stage 4a). |
| 10 | `src/vault/provenance.rs` — authorship keys | OK with note — the secret is generated into `Zeroizing<[u8; 32]>` and returned wrapped. Callers construct an `ed25519_dalek::SigningKey` from those bytes; that copy is caller-owned and transient. ed25519-dalek's `zeroize` feature is NOT enabled in Cargo.toml, so `SigningKey` does not self-wipe on drop. Residual, documented here; enabling the feature is a dependency-flag change for a future stage. |
| 11 | `src/api/mod.rs` — server tokens | RESIDUAL (accepted) — `admin_token` / `dashboard_token` are held as `Arc<String>` for the process lifetime: they must be compared against per-request headers and seed the outbound redactor (harvest stage 2), so they cannot be consumed or dropped early. Same accepted class as VaultLane's session-token residual. The values are never returned to clients, and the redactor scrubs them from error echoes. |
| 12 | `src/crypto.rs` (crate root) | ORPHANED — this file is not declared in `src/lib.rs` or any binary target and is not compiled. Its `decrypt` returns a plain `Vec<u8>`, but it is dead code, so no change was spent on it. Flagged for a future decision (delete it or wire it in deliberately). |
| 13 | Passphrases generally | OK — passphrases arrive as `&[u8]` / `&str` borrows everywhere; the vault never takes an owned copy, so there is no vault-side buffer to scrub. The borrow's owner controls its lifetime. |
| 14 | Tests / examples / `src/pov` signing | OUT OF SCOPE — `SigningKey`s there are ephemeral test/demo keys passed by reference; no production secret persists. |

## Changes made in this stage

- `src/vault/keyring.rs`: `SecretKey::decrypt` and `KeyRing::decrypt`
  now return `Result<Zeroizing<Vec<u8>>, KeyError>`; `re_encrypt`
  simplified to consume the wrapped value. Two new unit tests pin the
  wrapped round-trip on both paths (the drop-wipe itself is the
  `zeroize` crate's guarantee).
- `tests/key_lifecycle_tests.rs`: three comparison sites adapted to
  `.as_slice()` (no behavior change).

No new dependencies. Cargo.toml untouched.
