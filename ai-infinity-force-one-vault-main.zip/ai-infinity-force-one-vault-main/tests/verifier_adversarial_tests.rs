//! Adversarial tests for the independent evidence verifier.
//! Proves that the verification logic strictly rejects:
//! 1. Modified source artifacts (hash mismatch)
//! 2. Altered test counts or forged pass rates
//! 3. Invalid or tampered Ed25519 digital signatures
//! 4. Regressed or tampered DePIN benchmark outcomes

use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use sha2::{Digest, Sha256};

fn verify_artifact_hash(expected_hash: &str, content: &[u8]) -> bool {
    let mut hasher = Sha256::new();
    hasher.update(content);
    let actual_hash = hex::encode(hasher.finalize());
    actual_hash == expected_hash
}

fn verify_test_count_parity(
    actual_passed: usize,
    bundle_reported: usize,
    any_failed: bool,
) -> bool {
    !any_failed && actual_passed == bundle_reported
}

fn verify_ed25519_signature(pubkey_hex: &str, payload: &str, sig_hex: &str) -> bool {
    let Ok(pub_bytes) = hex::decode(pubkey_hex) else {
        return false;
    };
    let Ok(pub_arr): Result<[u8; 32], _> = pub_bytes.try_into() else {
        return false;
    };
    let Ok(verifying_key) = VerifyingKey::from_bytes(&pub_arr) else {
        return false;
    };
    let Ok(sig_bytes) = hex::decode(sig_hex) else {
        return false;
    };
    let Ok(signature) = Signature::from_slice(&sig_bytes) else {
        return false;
    };
    verifying_key.verify(payload.as_bytes(), &signature).is_ok()
}

fn verify_benchmark_gate(measured_tps: f64, min_gate_tps: f64, verdict: &str) -> bool {
    verdict == "PASS" && measured_tps >= min_gate_tps
}

#[test]
fn test_verifier_rejects_modified_artifact() {
    let original_content = b"pub fn secure_pipeline() -> bool { true }";
    let mut hasher = Sha256::new();
    hasher.update(original_content);
    let original_hash = hex::encode(hasher.finalize());

    // Valid content passes
    assert!(verify_artifact_hash(&original_hash, original_content));

    // Attacker modifies a single byte
    let tampered_content = b"pub fn secure_pipeline() -> bool { false}";
    assert!(
        !verify_artifact_hash(&original_hash, tampered_content),
        "Must reject modified artifact!"
    );
}

#[test]
fn test_verifier_rejects_altered_test_counts() {
    let actual_passed = 67;

    // Normal parity passes
    assert!(verify_test_count_parity(actual_passed, 67, false));

    // Attacker artificially inflates test count in metadata
    assert!(
        !verify_test_count_parity(actual_passed, 75, false),
        "Must reject inflated test count!"
    );

    // Attacker deflates or skips tests
    assert!(
        !verify_test_count_parity(actual_passed, 60, false),
        "Must reject missing tests!"
    );

    // Any failing test must fail verification regardless of count
    assert!(
        !verify_test_count_parity(actual_passed, 67, true),
        "Must fail if any test failed!"
    );
}

#[test]
fn test_verifier_rejects_invalid_ed25519_signature() {
    let secret = [7u8; 32];
    let signing_key = SigningKey::from_bytes(&secret);
    let verifying_key = signing_key.verifying_key();
    let pubkey_hex = hex::encode(verifying_key.as_bytes());

    let payload = "DOCKET:MACK-STACK-01;AUTHOR:Allen Mack;TOTAL_PASSED:67";
    let signature = signing_key.sign(payload.as_bytes());
    let sig_hex = hex::encode(signature.to_bytes());

    // Untampered signature passes
    assert!(verify_ed25519_signature(&pubkey_hex, payload, &sig_hex));

    // 1. Bit flip in payload
    let tampered_payload = "DOCKET:MACK-STACK-01;AUTHOR:Attacker;TOTAL_PASSED:67";
    assert!(
        !verify_ed25519_signature(&pubkey_hex, tampered_payload, &sig_hex),
        "Must reject tampered payload!"
    );

    // 2. Bit flip in signature bytes
    let mut bad_sig_bytes = signature.to_bytes();
    bad_sig_bytes[0] ^= 0xFF;
    let bad_sig_hex = hex::encode(bad_sig_bytes);
    assert!(
        !verify_ed25519_signature(&pubkey_hex, payload, &bad_sig_hex),
        "Must reject mutated signature bytes!"
    );

    // 3. Spoofed public key
    let rogue_secret = [9u8; 32];
    let rogue_signing = SigningKey::from_bytes(&rogue_secret);
    let rogue_pub_hex = hex::encode(rogue_signing.verifying_key().as_bytes());
    assert!(
        !verify_ed25519_signature(&rogue_pub_hex, payload, &sig_hex),
        "Must reject signature verified against forged key!"
    );
}

#[test]
fn test_verifier_rejects_benchmark_regression() {
    let min_gate_tps = 500.0;

    // High throughput passes
    assert!(verify_benchmark_gate(5600.0, min_gate_tps, "PASS"));

    // Regressed throughput below gate fails
    assert!(
        !verify_benchmark_gate(420.0, min_gate_tps, "PASS"),
        "Must reject regressed TPS!"
    );

    // Failed gate verdict fails
    assert!(
        !verify_benchmark_gate(5600.0, min_gate_tps, "FAIL"),
        "Must reject failed gate verdict!"
    );
}
