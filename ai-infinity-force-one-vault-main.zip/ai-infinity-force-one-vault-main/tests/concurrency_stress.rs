//! Phase 2 — Concurrency stress tests for `ConcurrentLedger`, plus a
//! bounded soak test (#[ignore]d; run explicitly).
//!
//! The soak is a FIVE-MINUTE bounded local run — it is not, and does not
//! claim to be, a 24–72h soak. It exists to catch slow leaks/deadlocks in
//! the append/verify loop under sustained contention on this machine.

use ai_infinity_force_one_vault::vault::audit::ConcurrentLedger;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

/// Many threads appending concurrently: no append is lost, sequences come
/// out exactly 0..n in order, and the chain verifies at the end.
#[test]
fn concurrent_appends_preserve_chain_integrity() {
    const THREADS: usize = 8;
    const PER_THREAD: usize = 250;

    let ledger = ConcurrentLedger::with_genesis("stress-genesis");
    let mut handles = Vec::new();
    for t in 0..THREADS {
        let l = ledger.clone();
        handles.push(thread::spawn(move || {
            for i in 0..PER_THREAD {
                let entry = l
                    .append(&format!("thread-{t}"), &format!("action-{i}"))
                    .expect("append under contention must succeed");
                assert_eq!(entry.actor, format!("thread-{t}"));
            }
        }));
    }
    for h in handles {
        h.join().expect("appender thread panicked");
    }

    assert_eq!(ledger.len(), THREADS * PER_THREAD);
    let entries = ledger.entries();
    for (i, e) in entries.iter().enumerate() {
        assert_eq!(e.sequence, i, "sequence order broken at {i}");
        if i == 0 {
            assert_eq!(e.prev_hash, "stress-genesis");
        } else {
            assert_eq!(e.prev_hash, entries[i - 1].hash);
        }
    }
    assert!(ledger.verify().is_ok());
    assert_eq!(ledger.head_hash(), entries.last().unwrap().hash);
}

/// Readers verifying while writers append must never observe a broken
/// chain: every intermediate state of an append-only locked ledger is a
/// valid prefix chain.
#[test]
fn concurrent_verify_never_observes_broken_chain() {
    let ledger = ConcurrentLedger::with_genesis("stress-genesis");
    let stop = Arc::new(AtomicBool::new(false));
    let verify_failures = Arc::new(AtomicUsize::new(0));

    let mut readers = Vec::new();
    for _ in 0..3 {
        let l = ledger.clone();
        let s = stop.clone();
        let f = verify_failures.clone();
        readers.push(thread::spawn(move || {
            while !s.load(Ordering::Relaxed) {
                if l.verify().is_err() {
                    f.fetch_add(1, Ordering::Relaxed);
                }
                thread::yield_now();
            }
        }));
    }

    let mut writers = Vec::new();
    for t in 0..4 {
        let l = ledger.clone();
        writers.push(thread::spawn(move || {
            for i in 0..200 {
                l.append(&format!("writer-{t}"), &format!("op-{i}"));
            }
        }));
    }
    for w in writers {
        w.join().expect("writer thread panicked");
    }
    stop.store(true, Ordering::Relaxed);
    for r in readers {
        r.join().expect("reader thread panicked");
    }

    assert_eq!(verify_failures.load(Ordering::Relaxed), 0);
    assert_eq!(ledger.len(), 800);
    assert!(ledger.verify().is_ok());
}

/// Bounded soak: sustained concurrent append/verify for ~5 minutes.
/// Ignored by default (it takes real wall-clock time); run with
/// `cargo test --test concurrency_stress -- --ignored soak`.
/// Honest label: a 5-minute bounded soak on this VM — NOT a 24–72h soak.
#[test]
#[ignore = "bounded 5-minute soak; run explicitly with --ignored"]
fn soak_concurrent_append_verify_five_minutes() {
    let ledger = ConcurrentLedger::with_genesis("soak-genesis");
    let deadline = Instant::now() + Duration::from_secs(300);
    let appends = Arc::new(AtomicUsize::new(0));
    let verify_failures = Arc::new(AtomicUsize::new(0));

    let mut handles = Vec::new();
    for t in 0..6 {
        let l = ledger.clone();
        let a = appends.clone();
        handles.push(thread::spawn(move || {
            let mut i = 0usize;
            while Instant::now() < deadline {
                l.append(&format!("soak-{t}"), &format!("tick-{i}"));
                a.fetch_add(1, Ordering::Relaxed);
                i += 1;
            }
        }));
    }
    for _ in 0..2 {
        let l = ledger.clone();
        let f = verify_failures.clone();
        handles.push(thread::spawn(move || {
            while Instant::now() < deadline {
                if l.verify().is_err() {
                    f.fetch_add(1, Ordering::Relaxed);
                }
            }
        }));
    }
    for h in handles {
        h.join().expect("soak thread panicked");
    }

    let total = appends.load(Ordering::Relaxed);
    assert_eq!(ledger.len(), total);
    assert_eq!(verify_failures.load(Ordering::Relaxed), 0);
    assert!(ledger.verify().is_ok());
    eprintln!(
        "soak complete: {total} appends over ~300s, 0 verify failures, final len {}",
        ledger.len()
    );
}
