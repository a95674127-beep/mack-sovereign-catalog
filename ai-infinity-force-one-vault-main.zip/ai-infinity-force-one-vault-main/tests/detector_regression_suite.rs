use std::fs;
use std::path::{Path, PathBuf};

use ai_infinity_force_one_vault::detection::{
    C2Detector, ExecutableInspector, MaliciousDocScanner, OfflineThreatEngine, PhishingDetector,
    TriageOutcome,
};

fn fixtures_path(category: &str) -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("fixtures")
        .join(category)
}

fn load_fixture(category: &str, filename: &str) -> Vec<u8> {
    let p = fixtures_path(category).join(filename);
    fs::read(&p).unwrap_or_else(|e| panic!("Failed to read fixture {}: {}", p.display(), e))
}

#[test]
fn test_phishing_detector_regression_fixtures() {
    // 1. Malicious phishing fixtures
    let cac = String::from_utf8(load_fixture("phishing", "malicious_cac_harvest.txt")).unwrap();
    let cac_finds = PhishingDetector::scan(&cac);
    assert!(!cac_finds.is_empty(), "Should detect CAC harvest");
    assert!(cac_finds
        .iter()
        .any(|f| f.description.contains("Common Access Card")));
    assert!(cac_finds
        .iter()
        .any(|f| f.description.contains("High-abuse TLD")));

    let sipr = String::from_utf8(load_fixture("phishing", "malicious_sipr_harvest.txt")).unwrap();
    let sipr_finds = PhishingDetector::scan(&sipr);
    assert!(
        !sipr_finds.is_empty(),
        "Should detect SIPR/NIPR credential harvesting"
    );
    assert!(sipr_finds.iter().any(|f| f.description.contains("SIPRNet")));
    assert!(sipr_finds.iter().any(|f| f.description.contains("NIPRNet")));

    let orders =
        String::from_utf8(load_fixture("phishing", "malicious_orders_urgency.txt")).unwrap();
    let orders_finds = PhishingDetector::scan(&orders);
    assert!(!orders_finds.is_empty(), "Should detect orders lure");
    assert!(orders_finds
        .iter()
        .any(|f| f.description.contains("military personnel orders")));
    assert!(orders_finds
        .iter()
        .any(|f| f.description.contains("Urgency pressure")));

    let ip = String::from_utf8(load_fixture("phishing", "malicious_ip_link.txt")).unwrap();
    let ip_finds = PhishingDetector::scan(&ip);
    assert!(!ip_finds.is_empty(), "Should detect direct IP link lure");
    assert!(ip_finds.iter().any(|f| f.pattern_type == "Direct IP Link"));

    let punycode =
        String::from_utf8(load_fixture("phishing", "malicious_punycode_host.txt")).unwrap();
    let puny_finds = PhishingDetector::scan(&punycode);
    assert!(!puny_finds.is_empty(), "Should detect punycode spoofing");
    assert!(puny_finds
        .iter()
        .any(|f| f.description.contains("Punycode")));

    // 2. Benign phishing fixtures (must not trigger any alerts)
    let benign_files = [
        "benign_daily_sitrep.txt",
        "benign_maintenance_bulletin.txt",
        "benign_radar_telemetry_msg.txt",
    ];

    for file in benign_files {
        let content = String::from_utf8(load_fixture("phishing", file)).unwrap();
        let finds = PhishingDetector::scan(&content);
        assert!(
            finds.is_empty(),
            "Benign phishing fixture '{}' triggered unexpected alerts: {:?}",
            file,
            finds
        );
    }
}

#[test]
fn test_malicious_doc_detector_regression_fixtures() {
    // 1. Malicious document fixtures
    let vba_auto = load_fixture("malicious_doc", "malicious_vba_autoopen.vba");
    let auto_ind = MaliciousDocScanner::scan(&vba_auto);
    assert!(!auto_ind.is_empty());
    assert!(auto_ind.iter().any(|i| i.pattern == "AutoOpen"));
    assert!(auto_ind.iter().any(|i| i.pattern == "WScript.Shell"));
    assert!(auto_ind.iter().any(|i| i.pattern == "powershell"));

    let doc_open = load_fixture(
        "malicious_doc",
        "malicious_vba_document_open_powershell.docm",
    );
    let doc_ind = MaliciousDocScanner::scan(&doc_open);
    assert!(!doc_ind.is_empty());
    assert!(doc_ind.iter().any(|i| i.pattern == "Document_Open"));
    assert!(doc_ind.iter().any(|i| i.pattern == "ShellExecute"));

    let excel = load_fixture("malicious_doc", "malicious_excel_workbook_cmd.xlsm");
    let excel_ind = MaliciousDocScanner::scan(&excel);
    assert!(!excel_ind.is_empty());
    assert!(excel_ind.iter().any(|i| i.pattern == "Workbook_Open"));
    assert!(excel_ind.iter().any(|i| i.pattern == "cmd.exe"));

    let pdf = load_fixture("malicious_doc", "malicious_pdf_js_launch.pdf");
    let pdf_ind = MaliciousDocScanner::scan(&pdf);
    assert!(!pdf_ind.is_empty());
    assert!(pdf_ind.iter().any(|i| i.pattern == "/JavaScript"));
    assert!(pdf_ind.iter().any(|i| i.pattern == "/Launch"));
    assert!(pdf_ind.iter().any(|i| i.pattern == "/OpenAction"));

    let rtf = load_fixture("malicious_doc", "malicious_rtf_objupdate_cve.rtf");
    let rtf_ind = MaliciousDocScanner::scan(&rtf);
    assert!(!rtf_ind.is_empty());
    assert!(rtf_ind.iter().any(|i| i.pattern == "\\objdata"));
    assert!(rtf_ind.iter().any(|i| i.pattern == "\\objupdate"));

    // 2. Benign document fixtures (must not trigger any alerts)
    let benign_docs = [
        "benign_tactical_standard_operating_procedure.txt",
        "benign_safe_document.pdf",
        "benign_equipment_manifest.rtf",
    ];

    for file in benign_docs {
        let content = load_fixture("malicious_doc", file);
        let ind = MaliciousDocScanner::scan(&content);
        assert!(
            ind.is_empty(),
            "Benign doc fixture '{}' triggered unexpected indicators: {:?}",
            file,
            ind
        );
    }
}

#[test]
fn test_c2_detector_regression_fixtures() {
    // 1. Malicious C2 fixtures
    let meterpreter = load_fixture("c2", "malicious_meterpreter_reverse_stage.sh");
    let met_ind = C2Detector::scan(&meterpreter);
    assert!(!met_ind.is_empty());
    assert!(met_ind
        .iter()
        .any(|i| i.description.contains("Meterpreter")));
    assert!(met_ind.iter().any(|i| i
        .description
        .contains("pseudo-device socket network redirection")));

    let beacon = load_fixture("c2", "malicious_cobalt_beacon_egress.txt");
    let beacon_ind = C2Detector::scan(&beacon);
    assert!(!beacon_ind.is_empty());
    assert!(beacon_ind.iter().any(|i| i.description.contains("beacon")));
    assert!(beacon_ind
        .iter()
        .any(|i| i.description.contains("exfiltration")));

    let revshell = load_fixture("c2", "malicious_netcat_reverse_shell.sh");
    let rev_ind = C2Detector::scan(&revshell);
    assert!(!rev_ind.is_empty());
    assert!(rev_ind
        .iter()
        .any(|i| i.description.contains("Netcat reverse shell")));

    let cradle = load_fixture("c2", "malicious_powershell_iex_cradle.ps1");
    let cradle_ind = C2Detector::scan(&cradle);
    assert!(!cradle_ind.is_empty());
    assert!(cradle_ind
        .iter()
        .any(|i| i.description.contains("PowerShell cradle")));
    assert!(cradle_ind
        .iter()
        .any(|i| i.description.contains("dynamic string execution")));

    // 2. Benign C2 fixtures (must not trigger any alerts)
    let benign_c2 = [
        "benign_network_health_check.sh",
        "benign_firewall_status.json",
        "benign_host_metrics.sh",
    ];

    for file in benign_c2 {
        let content = load_fixture("c2", file);
        let ind = C2Detector::scan(&content);
        assert!(
            ind.is_empty(),
            "Benign C2 fixture '{}' triggered unexpected indicators: {:?}",
            file,
            ind
        );
    }
}

#[test]
fn test_binary_detector_regression_fixtures() {
    // 1. Malicious / executable fixtures
    let pe = load_fixture("binary", "malicious_pe_header.bin");
    let pe_finds = ExecutableInspector::inspect(&pe);
    assert!(!pe_finds.is_empty());
    assert!(pe_finds.iter().any(|f| f.classification == "Windows PE"));

    let elf = load_fixture("binary", "malicious_elf_header.bin");
    let elf_finds = ExecutableInspector::inspect(&elf);
    assert!(!elf_finds.is_empty());
    assert!(elf_finds.iter().any(|f| f.classification == "Linux ELF"));

    let macho = load_fixture("binary", "malicious_macho_header.bin");
    let macho_finds = ExecutableInspector::inspect(&macho);
    assert!(!macho_finds.is_empty());
    assert!(macho_finds
        .iter()
        .any(|f| f.classification == "macOS Mach-O"));

    let nop = load_fixture("binary", "malicious_nop_sled.bin");
    let nop_finds = ExecutableInspector::inspect(&nop);
    assert!(!nop_finds.is_empty());
    assert!(nop_finds
        .iter()
        .any(|f| f.classification == "Shellcode NOP Sled"));

    // 2. Benign binary / data fixtures (must not trigger any alerts)
    let benign_bins = [
        "benign_system_config.ini",
        "benign_sensor_readings.csv",
        "benign_telemetry_stream.dat",
    ];

    for file in benign_bins {
        let content = load_fixture("binary", file);
        let finds = ExecutableInspector::inspect(&content);
        assert!(
            finds.is_empty(),
            "Benign binary fixture '{}' triggered unexpected findings: {:?}",
            file,
            finds
        );
    }
}

#[test]
fn test_unified_engine_triage_regression_all_fixtures() {
    let engine = OfflineThreatEngine::default();
    let categories = ["phishing", "malicious_doc", "c2", "binary"];

    let mut total_tested = 0;
    let mut benign_tested = 0;
    let mut malicious_tested = 0;

    for &category in &categories {
        let dir = fixtures_path(category);
        let entries = fs::read_dir(&dir).unwrap_or_else(|e| {
            panic!("Failed to read fixture directory {}: {}", dir.display(), e)
        });

        for entry in entries {
            let entry = entry.unwrap();
            let path = entry.path();
            if !path.is_file() {
                continue;
            }

            let filename = path.file_name().unwrap().to_str().unwrap().to_string();
            let data = fs::read(&path).unwrap();
            total_tested += 1;

            let result = engine.scan_payload(&data);

            if filename.starts_with("benign_") {
                benign_tested += 1;
                assert_eq!(
                    result.triage.outcome,
                    TriageOutcome::Clean,
                    "Benign fixture [{}/{}] must be classified Clean, got {:?}. Reasons: {:?}",
                    category,
                    filename,
                    result.triage.outcome,
                    result.triage.reasons
                );
                assert_eq!(
                    result.triage.threat_score, 0,
                    "Benign fixture [{}/{}] threat score must be 0, got {}",
                    category, filename, result.triage.threat_score
                );
                assert!(
                    result.triage.reasons.is_empty(),
                    "Benign fixture [{}/{}] reasons must be empty, got: {:?}",
                    category,
                    filename,
                    result.triage.reasons
                );
                assert!(
                    !result.triage.requires_jag_s2_escalation,
                    "Benign fixture [{}/{}] must not require JAG/S2 escalation",
                    category, filename
                );
            } else if filename.starts_with("malicious_") {
                malicious_tested += 1;
                assert_ne!(
                    result.triage.outcome,
                    TriageOutcome::Clean,
                    "Malicious fixture [{}/{}] must not be Clean! Reasons: {:?}",
                    category,
                    filename,
                    result.triage.reasons
                );
                assert!(
                    result.triage.threat_score > 0,
                    "Malicious fixture [{}/{}] must have positive threat score",
                    category,
                    filename
                );
                assert!(
                    !result.triage.reasons.is_empty(),
                    "Malicious fixture [{}/{}] must record triage reasons",
                    category,
                    filename
                );
            }
        }
    }

    assert!(
        total_tested >= 20,
        "Total fixtures tested was {}, expected >= 20",
        total_tested
    );
    assert!(
        benign_tested >= 10,
        "Benign fixtures tested was {}, expected >= 10",
        benign_tested
    );
    assert!(
        malicious_tested >= 10,
        "Malicious fixtures tested was {}, expected >= 10",
        malicious_tested
    );
}
