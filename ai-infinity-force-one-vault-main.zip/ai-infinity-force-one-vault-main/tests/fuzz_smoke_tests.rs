use ai_infinity_force_one_vault::ingest::IngestRecord;
use ai_infinity_force_one_vault::pov::ProofOfVerification;
use ai_infinity_force_one_vault::sandbox::lanes::{LaneContainmentEngine, LaneId, LaneStatus};
use ai_infinity_force_one_vault::vault::audit::AuditLog;
use ai_infinity_force_one_vault::vault::policy::Principal;
use ai_infinity_force_one_vault::Vault;

#[test]
fn test_fuzz_smoke_pov_batch_adversarial_strings() {
    let corpus = [
        "",
        "{}",
        "[]",
        "null",
        "{\"proofs\": null}",
        "{\"proofs\": [\"not_an_object\"]}",
        "{\"proofs\": [{\"claim\": 123}]}",
        "{\"claim\": \"unclosed json",
        "{\"claim\": \"val\", \"independent_check\": true, \"payload_hash\": \"abc\"}",
        "{\"proofs\": [{\"claim\":\"01\",\"independent_check\":true,\"payload_hash\":\"01\",\"signature\":null,\"operator_id\":null}]}",
    ];

    let principal = Principal("smoke_tester".into());
    for input in corpus {
        let _ = ProofOfVerification::from_json(input);
        let mut vault = Vault::new();
        let _ = vault.ingest_pov_batch_json(&principal, input);
    }
}

#[test]
fn test_fuzz_smoke_audit_chain_mutations() {
    let mut log = AuditLog::new();
    for i in 0..50 {
        log.append(&format!("actor_{}", i), &format!("action_{}", i));
    }
    assert!(
        log.verify().is_ok(),
        "Generated sequential audit log must verify"
    );

    let mut fresh_log = AuditLog::new();
    fresh_log.append("actor1", "action1");
    assert!(fresh_log.verify().is_ok());
}

#[test]
fn test_fuzz_smoke_lane_transitions_adversarial_inputs() {
    let engine = LaneContainmentEngine::new(256);

    for lane_idx in 0..12 {
        let lane_id = LaneId::from_index(lane_idx).expect("Valid lane index");
        assert!(matches!(engine.lane_status(lane_id), LaneStatus::Green));

        // Empty payload -> triggers quarantine
        let empty_record = IngestRecord::new(lane_id.code(), vec![]);
        let res = engine.execute_lane(lane_id, empty_record);
        assert!(res.is_err());
        assert!(matches!(
            engine.lane_status(lane_id),
            LaneStatus::Quarantined { .. }
        ));

        // Clearing returns to Green
        engine.clear_lane_quarantine(lane_id);
        assert!(matches!(engine.lane_status(lane_id), LaneStatus::Green));

        // Valid payload
        let valid_record =
            IngestRecord::new(lane_id.code(), b"secure payload within 256 bytes".to_vec());
        let valid = engine.execute_lane(lane_id, valid_record);
        assert!(valid.is_ok());
    }
}
