use axum::{
    body::Body,
    http::{header, Method, Request, StatusCode},
};
use http_body_util::BodyExt;
use std::sync::Arc;
use tower::ServiceExt;

use ai_infinity_force_one_vault::api::{
    create_router, AppState, HealthResponse, LanesResponse, OperatorReputationResponse,
    PovVerifyResponse, ResetResponse, SnapshotResponse, VerificationResponse,
};
use ai_infinity_force_one_vault::pov::ProofOfVerification;
use ai_infinity_force_one_vault::sandbox::lanes::{LaneContainmentEngine, LaneId, LaneStatus};
use ai_infinity_force_one_vault::vault::audit::ConcurrentLedger;

fn setup_test_app() -> (axum::Router, AppState) {
    let lanes = Arc::new(LaneContainmentEngine::default());
    let ledger = Arc::new(ConcurrentLedger::new());
    let mut state = AppState::with_admin_token(lanes, ledger, "test-secret-token-1234");
    // Dashboard auth is now fail-closed; tests must set an explicit token.
    state.dashboard_token = Arc::new("test-dashboard-token-xyz".to_string());
    let router = create_router(state.clone());
    (router, state)
}

#[tokio::test]
async fn test_health_endpoint() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/health")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::GET)
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    let health: HealthResponse = serde_json::from_slice(&body).unwrap();
    assert_eq!(health.status, "operational");
    assert_eq!(health.engine, "MACK-Stack-Vault-Engine");
    assert_eq!(health.version, "0.1.0");
}

#[tokio::test]
async fn test_lanes_endpoint_returns_all_twelve_lanes() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/lanes")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::GET)
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    let lanes: LanesResponse = serde_json::from_slice(&body).unwrap();
    assert_eq!(lanes.total, 12);
    assert_eq!(lanes.lanes.len(), 12);

    let codes: Vec<String> = lanes.lanes.into_iter().map(|l| l.code).collect();
    assert!(codes.contains(&"MACK-01".to_string()));
    assert!(codes.contains(&"MACK-12".to_string()));
}

#[tokio::test]
async fn test_reset_lane_unauthorized_without_token() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/lanes/MACK-01/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn test_reset_lane_forbidden_with_invalid_token() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/lanes/MACK-01/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::AUTHORIZATION, "Bearer wrong-token")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::FORBIDDEN);
}

#[tokio::test]
async fn test_reset_lane_success_with_valid_token() {
    let (app, state) = setup_test_app();

    let lane = LaneId::Mack01Propulsion;
    state.lanes.clear_lane_quarantine(lane);
    assert_eq!(state.lanes.lane_status(lane), LaneStatus::Green);

    let request = Request::builder()
        .uri("/api/v1/lanes/MACK-01/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::AUTHORIZATION, "Bearer test-secret-token-1234")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    let reset: ResetResponse = serde_json::from_slice(&body).unwrap();
    assert_eq!(reset.lane, "MACK-01");
    assert_eq!(reset.status, "quarantine_cleared");

    assert_eq!(state.lanes.lane_status(lane), LaneStatus::Green);
}

#[tokio::test]
async fn test_reset_unknown_lane_returns_not_found() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/lanes/INVALID-99/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::AUTHORIZATION, "Bearer test-secret-token-1234")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::NOT_FOUND);
}

#[tokio::test]
async fn test_ledger_verify_endpoint() {
    let (app, state) = setup_test_app();

    for i in 1..=5 {
        state
            .ledger
            .append("api-test-actor", &format!("audit-action-{}", i));
    }

    let request = Request::builder()
        .uri("/api/v1/ledger/verify")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    let res: VerificationResponse = serde_json::from_slice(&body).unwrap();
    assert!(res.valid);
    assert_eq!(res.entries_checked, 5);
    assert!(res.broken_segments.is_empty());
}

#[tokio::test]
async fn test_pov_verify_and_reputation_pipeline() {
    let (app, _) = setup_test_app();

    let tasks = vec![
        ProofOfVerification {
            pov_version: "1.0".to_string(),
            task_id: "task-valid-01".to_string(),
            operator_id: "operator-alpha".to_string(),
            timestamp_start: "2026-10-02T02:10:00Z".to_string(),
            timestamp_end: "2026-10-02T02:10:01Z".to_string(),
            task_type: "verification".to_string(),
            input_hash: "hash-in-1".to_string(),
            output_hash: "hash-out-1".to_string(),
            verification_method: "hash_match".to_string(),
            verified: true,
            signature: "sig-01".to_string(),
        },
        ProofOfVerification {
            pov_version: "1.0".to_string(),
            task_id: "task-invalid-02".to_string(),
            operator_id: "operator-beta".to_string(),
            timestamp_start: "2026-10-02T02:10:00Z".to_string(),
            timestamp_end: "2026-10-02T02:10:01Z".to_string(),
            task_type: "verification".to_string(),
            input_hash: "hash-match-same".to_string(),
            output_hash: "hash-match-same".to_string(),
            verification_method: "hash_match".to_string(),
            verified: true,
            signature: "sig-02".to_string(),
        },
    ];

    let request = Request::builder()
        .uri("/api/v1/pov/verify")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::CONTENT_TYPE, "application/json")
        .body(Body::from(serde_json::to_vec(&tasks).unwrap()))
        .unwrap();

    let response = app.clone().oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    let verify_res: PovVerifyResponse = serde_json::from_slice(&body).unwrap();
    assert_eq!(verify_res.total_tasks, 2);
    assert_eq!(verify_res.passed_tasks, 1);
    assert_eq!(verify_res.rejected_tasks, 1);
    assert_eq!(verify_res.pass_rate, 0.5);

    let rep_request = Request::builder()
        .uri("/api/v1/pov/reputation")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::GET)
        .body(Body::empty())
        .unwrap();

    let rep_response = app.oneshot(rep_request).await.unwrap();
    assert_eq!(rep_response.status(), StatusCode::OK);

    let rep_body = rep_response.into_body().collect().await.unwrap().to_bytes();
    let rep: OperatorReputationResponse = serde_json::from_slice(&rep_body).unwrap();
    assert_eq!(rep.total_operators, 2);

    let alpha = rep
        .operators
        .iter()
        .find(|o| o.operator_id == "operator-alpha")
        .unwrap();
    assert_eq!(alpha.total_submitted, 1);
    assert_eq!(alpha.verified_valid, 1);
    assert_eq!(alpha.rejected, 0);
    assert_eq!(alpha.status, "trusted");

    let beta = rep
        .operators
        .iter()
        .find(|o| o.operator_id == "operator-beta")
        .unwrap();
    assert_eq!(beta.total_submitted, 1);
    assert_eq!(beta.verified_valid, 0);
    assert_eq!(beta.rejected, 1);
    assert_eq!(beta.status, "suspended");
}

// ─── Security tests: authentication, input validation, error leakage ───

fn setup_dashboard_app() -> (axum::Router, AppState) {
    let lanes = Arc::new(LaneContainmentEngine::default());
    let ledger = Arc::new(ConcurrentLedger::new());
    let state = AppState::with_dashboard_token(lanes, ledger, "dashboard-secret-xyz");
    let router = create_router(state.clone());
    (router, state)
}

#[tokio::test]
async fn test_reset_requires_bearer_token() {
    // with_admin_token leaves dashboard_token empty (fail-open), so this
    // isolates the Bearer check.
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/lanes/L-01/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    // Missing Authorization header → 401
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn test_reset_rejects_wrong_bearer_token() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/lanes/L-01/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::AUTHORIZATION, "Bearer test-dashboard-token-xyz")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::FORBIDDEN);
}

#[tokio::test]
async fn test_reset_rejects_wrongly_cased_bearer_scheme() {
    let (app, _) = setup_test_app();

    // "bearer" (lowercase) must not be accepted; the scheme is case-sensitive
    // per RFC 6750 and the server strips only "Bearer ".
    let request = Request::builder()
        .uri("/api/v1/lanes/L-01/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::AUTHORIZATION, "bearer test-secret-token-1234")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert!(
        response.status() == StatusCode::UNAUTHORIZED || response.status() == StatusCode::FORBIDDEN,
        "lowercase bearer scheme must not authenticate"
    );
}

#[tokio::test]
async fn test_reset_accepts_correct_bearer_token() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/lanes/MACK-01/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::AUTHORIZATION, "Bearer test-secret-token-1234")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);
}

#[tokio::test]
async fn test_dashboard_token_required_when_set() {
    let (app, _) = setup_dashboard_app();

    // No X-Dashboard-Token header → 401
    let request = Request::builder()
        .uri("/api/v1/lanes")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::GET)
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn test_dashboard_token_wrong_value_rejected() {
    let (app, _) = setup_dashboard_app();

    let request = Request::builder()
        .uri("/api/v1/lanes")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::GET)
        .header("X-Dashboard-Token", "wrong-token")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn test_dashboard_token_correct_value_accepted() {
    let (app, _) = setup_dashboard_app();

    let request = Request::builder()
        .uri("/api/v1/lanes")
        .header("X-Dashboard-Token", "dashboard-secret-xyz")
        .method(Method::GET)
        .header("X-Dashboard-Token", "dashboard-secret-xyz")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);
}

#[tokio::test]
async fn test_malformed_json_does_not_panic() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/pov/verify")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::CONTENT_TYPE, "application/json")
        .body(Body::from("{not valid json!!!"))
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    // Must be a client error, not a 500 and not a panic.
    assert!(
        response.status().is_client_error(),
        "malformed JSON should be 4xx, got {}",
        response.status()
    );
}

#[tokio::test]
async fn test_error_responses_do_not_leak_internals() {
    // Trigger a 401 and a 404, then inspect the bodies.
    for uri in ["/api/v1/lanes/L-01/reset", "/api/v1/nonexistent"] {
        let (app, _) = setup_test_app();
        let request = Request::builder()
            .uri(uri)
            .method(Method::POST)
            .body(Body::empty())
            .unwrap();

        let response = app.oneshot(request).await.unwrap();
        let status = response.status();
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let text = String::from_utf8_lossy(&body).to_lowercase();

        // Error bodies must not contain stack traces, file paths, or
        // internal type names.
        for leak in ["panicked", "stack backtrace", ".rs:", "src/", "thread '"] {
            assert!(
                !text.contains(leak),
                "error response for {uri} ({status}) leaks internals: {leak}"
            );
        }
    }
}

#[tokio::test]
async fn test_token_comparison_is_not_prefix_bypassable() {
    let (app, _) = setup_test_app();

    // A token that is a prefix of the real one must not authenticate.
    let request = Request::builder()
        .uri("/api/v1/lanes/L-01/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::AUTHORIZATION, "Bearer test-secret-token")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::FORBIDDEN);

    // A token with extra trailing data must not authenticate either.
    let (app, _) = setup_test_app();
    let request = Request::builder()
        .uri("/api/v1/lanes/L-01/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::AUTHORIZATION, "Bearer test-secret-token-1234-extra")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::FORBIDDEN);
}

// ---------------------------------------------------------------------------
// /api/v1/ingest/submit — detection-gated ingress tests
// ---------------------------------------------------------------------------

use ai_infinity_force_one_vault::api::{IngestSubmitRequest, IngestSubmitResponse, RateLimiter};
use ai_infinity_force_one_vault::sandbox::pipeline::ContainmentPipeline;

fn setup_ingest_app(rate_capacity: u64, rate_per_sec: u64) -> axum::Router {
    let lanes = Arc::new(LaneContainmentEngine::default());
    let ledger = Arc::new(ConcurrentLedger::new());
    let pipeline = Arc::new(ContainmentPipeline::new(1_048_576));
    let limiter = Arc::new(RateLimiter::new(rate_capacity, rate_per_sec));
    let state =
        AppState::with_pipeline(lanes, ledger, "test-dashboard-token-xyz", pipeline, limiter);
    create_router(state)
}

fn ingest_request(payload_hex: &str, lane: &str) -> Request<Body> {
    let body = serde_json::to_string(&IngestSubmitRequest {
        lane: lane.to_string(),
        payload_hex: payload_hex.to_string(),
    })
    .unwrap();
    Request::builder()
        .uri("/api/v1/ingest/submit")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .header(header::CONTENT_TYPE, "application/json")
        .method(Method::POST)
        .body(Body::from(body))
        .unwrap()
}

async fn submit_and_parse(app: axum::Router, req: Request<Body>) -> (StatusCode, Vec<u8>) {
    let response = app.oneshot(req).await.unwrap();
    let status = response.status();
    let body = response
        .into_body()
        .collect()
        .await
        .unwrap()
        .to_bytes()
        .to_vec();
    (status, body)
}

#[tokio::test]
async fn test_ingest_sealed_payload_is_not_executed() {
    let app = setup_ingest_app(60, 10);
    // Empty payload → fail-closed → Sealed.
    let (status, body) = submit_and_parse(app, ingest_request("", "MACK-04")).await;
    assert_eq!(status, StatusCode::OK);
    let resp: IngestSubmitResponse = serde_json::from_slice(&body).unwrap();
    assert_eq!(resp.decision, "sealed_hold");
    assert_eq!(resp.triage_outcome, "Sealed");
    assert!(!resp.executed, "sealed payload must not execute via API");
    assert!(resp.execution_ok.is_none());
}

#[tokio::test]
async fn test_ingest_quarantine_does_not_use_standard_containment() {
    let app = setup_ingest_app(60, 10);
    // High-entropy blob → Quarantine or Sealed, never standard.
    let mut raw = vec![0u8; 512];
    for (i, b) in raw.iter_mut().enumerate() {
        *b = ((i * 2654435761) % 256) as u8;
    }
    let payload_hex = hex::encode(&raw);
    let (status, body) = submit_and_parse(app, ingest_request(&payload_hex, "MACK-10")).await;
    assert_eq!(status, StatusCode::OK);
    let resp: IngestSubmitResponse = serde_json::from_slice(&body).unwrap();
    assert_ne!(
        resp.decision, "execute_standard",
        "suspicious payload must not use standard containment via API"
    );
    assert_ne!(resp.triage_outcome, "Clean");
}

#[tokio::test]
async fn test_ingest_clean_payload_executes_standard() {
    let app = setup_ingest_app(60, 10);
    let payload_hex = hex::encode(b"hello, this is a benign test payload");
    let (status, body) = submit_and_parse(app, ingest_request(&payload_hex, "MACK-04")).await;
    assert_eq!(status, StatusCode::OK);
    let resp: IngestSubmitResponse = serde_json::from_slice(&body).unwrap();
    assert_eq!(resp.decision, "execute_standard");
    assert_eq!(resp.triage_outcome, "Clean");
    assert!(resp.executed);
    assert_eq!(resp.execution_ok, Some(true));
}

#[tokio::test]
async fn test_ingest_requires_dashboard_token() {
    let app = setup_ingest_app(60, 10);
    let body = serde_json::to_string(&IngestSubmitRequest {
        lane: "MACK-04".to_string(),
        payload_hex: hex::encode(b"test"),
    })
    .unwrap();
    // No token header at all.
    let req = Request::builder()
        .uri("/api/v1/ingest/submit")
        .header(header::CONTENT_TYPE, "application/json")
        .method(Method::POST)
        .body(Body::from(body))
        .unwrap();
    let (status, _) = submit_and_parse(app, req).await;
    assert_eq!(status, StatusCode::UNAUTHORIZED);

    // Wrong token (constant-time comparison must reject).
    let app = setup_ingest_app(60, 10);
    let body = serde_json::to_string(&IngestSubmitRequest {
        lane: "MACK-04".to_string(),
        payload_hex: hex::encode(b"test"),
    })
    .unwrap();
    let req = Request::builder()
        .uri("/api/v1/ingest/submit")
        .header("X-Dashboard-Token", "wrong-token")
        .header(header::CONTENT_TYPE, "application/json")
        .method(Method::POST)
        .body(Body::from(body))
        .unwrap();
    let (status, _) = submit_and_parse(app, req).await;
    assert_eq!(status, StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn test_ingest_rejects_bad_hex_and_unknown_lane() {
    let app = setup_ingest_app(60, 10);
    let (status, _) = submit_and_parse(app, ingest_request("not-hex!!", "MACK-04")).await;
    assert_eq!(status, StatusCode::BAD_REQUEST);

    let app = setup_ingest_app(60, 10);
    let (status, _) = submit_and_parse(app, ingest_request("deadbeef", "MACK-99")).await;
    assert_eq!(status, StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn test_ingest_rate_limiting_enforced() {
    let payload_hex = hex::encode(b"hello, this is a benign test payload");

    // 1 burst token, slow refill: first request passes, second immediate
    // request must 429.
    let make_tight_app = || {
        let lanes = Arc::new(LaneContainmentEngine::default());
        let ledger = Arc::new(ConcurrentLedger::new());
        let pipeline = Arc::new(ContainmentPipeline::new(1_048_576));
        let limiter = Arc::new(RateLimiter::new(1, 1));
        let state =
            AppState::with_pipeline(lanes, ledger, "test-dashboard-token-xyz", pipeline, limiter);
        create_router(state)
    };
    let (s1, _) = submit_and_parse(make_tight_app(), ingest_request(&payload_hex, "MACK-04")).await;
    assert_eq!(s1, StatusCode::OK);

    // Pre-consume the single token so the next request is over budget.
    let over_budget_app = {
        let lanes = Arc::new(LaneContainmentEngine::default());
        let ledger = Arc::new(ConcurrentLedger::new());
        let pipeline = Arc::new(ContainmentPipeline::new(1_048_576));
        let limiter = Arc::new(RateLimiter::new(1, 1));
        assert!(limiter.check(), "pre-consume the only token");
        let state =
            AppState::with_pipeline(lanes, ledger, "test-dashboard-token-xyz", pipeline, limiter);
        create_router(state)
    };
    let (s2, _) = submit_and_parse(over_budget_app, ingest_request(&payload_hex, "MACK-04")).await;
    assert_eq!(
        s2,
        StatusCode::TOO_MANY_REQUESTS,
        "exhausted bucket must return 429"
    );

    // Sanity: the limiter refills over time (unit-level).
    let limiter = RateLimiter::new(1, 1000);
    assert!(limiter.check());
    assert!(!limiter.check(), "second immediate check must fail");
    assert_eq!(limiter.available(), 0);
}

#[tokio::test]
async fn test_snapshot_unauthorized_without_token() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/ledger/snapshot")
        .method(Method::GET)
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn test_snapshot_rejects_wrong_token_on_both_headers() {
    let (app, _) = setup_test_app();

    // Wrong token via Authorization: Bearer
    let request = Request::builder()
        .uri("/api/v1/ledger/snapshot")
        .header(header::AUTHORIZATION, "Bearer definitely-wrong-token")
        .method(Method::GET)
        .body(Body::empty())
        .unwrap();
    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);

    // Wrong token via X-Dashboard-Token
    let (app, _) = setup_test_app();
    let request = Request::builder()
        .uri("/api/v1/ledger/snapshot")
        .header("X-Dashboard-Token", "wrong-token")
        .method(Method::GET)
        .body(Body::empty())
        .unwrap();
    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
}

#[tokio::test]
async fn test_snapshot_accepts_bearer_header() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/ledger/snapshot")
        .header(header::AUTHORIZATION, "Bearer test-dashboard-token-xyz")
        .method(Method::GET)
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    let snapshot: SnapshotResponse = serde_json::from_slice(&body).unwrap();
    assert!(!snapshot.engine_version.is_empty());
    assert!(!snapshot.timestamp.is_empty());
    assert!(!snapshot.ledger.head_hash.is_empty());
    assert_eq!(snapshot.lanes.len(), 12);
    let codes: Vec<String> = snapshot.lanes.iter().map(|l| l.code.clone()).collect();
    assert!(codes.contains(&"MACK-01".to_string()));
    assert!(codes.contains(&"MACK-12".to_string()));
}

#[tokio::test]
async fn test_snapshot_accepts_legacy_dashboard_token_header() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/ledger/snapshot")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::GET)
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    let snapshot: SnapshotResponse = serde_json::from_slice(&body).unwrap();
    assert_eq!(snapshot.lanes.len(), 12);
}

#[tokio::test]
async fn test_lanes_accepts_bearer_header_too() {
    // Dual-auth must apply to every dashboard route, not just snapshot.
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/lanes")
        .header(header::AUTHORIZATION, "Bearer test-dashboard-token-xyz")
        .method(Method::GET)
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    let lanes: LanesResponse = serde_json::from_slice(&body).unwrap();
    assert_eq!(lanes.total, 12);
}

/// Harvest (2026-11-10, audit row 3): outbound API text is scrubbed
/// with the server's token set. A client that replays the admin token
/// as a lane code must get the 404 with the token replaced, never
/// echoed back verbatim.
#[tokio::test]
async fn test_error_response_does_not_echo_server_token() {
    let (app, _) = setup_test_app();

    let request = Request::builder()
        .uri("/api/v1/lanes/test-secret-token-1234/reset")
        .header("X-Dashboard-Token", "test-dashboard-token-xyz")
        .method(Method::POST)
        .header(header::AUTHORIZATION, "Bearer test-secret-token-1234")
        .body(Body::empty())
        .unwrap();

    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::NOT_FOUND);

    let body = response.into_body().collect().await.unwrap().to_bytes();
    let text = String::from_utf8(body.to_vec()).unwrap();
    assert!(
        !text.contains("test-secret-token-1234"),
        "response must not echo the admin token: {text}"
    );
    assert!(
        text.contains("[REDACTED]"),
        "echoed token must be replaced by the redaction marker: {text}"
    );
}
