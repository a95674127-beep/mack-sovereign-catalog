//! Phase 2 — Failure-injection tests: hostile and broken inputs pushed
//! through the real end-to-end routes (the same `Vault` route the
//! one-command demo exercises, and the lane containment engine), asserting
//! fail-closed behavior — explicit errors, nothing stored, every rejection
//! written to the tamper-evident ledger, and other lanes unaffected.

use ai_infinity_force_one_vault::ingest::IngestRecord;
use ai_infinity_force_one_vault::sandbox::{LaneContainmentEngine, LaneExecutionError, LaneId};
use ai_infinity_force_one_vault::vault::policy::{Action, Effect, Principal, Resource, Rule};
use ai_infinity_force_one_vault::vault::VaultError;
use ai_infinity_force_one_vault::Vault;

fn granted_vault() -> (Vault, Principal, Resource) {
    let mut vault = Vault::new();
    let alice = Principal("operator".to_string());
    let doc = Resource("vault-document".to_string());
    vault.grant(Rule {
        effect: Effect::Allow,
        principal: alice.clone(),
        resource: doc.clone(),
        actions: vec![Action::Write, Action::Read],
    });
    (vault, alice, doc)
}

/// Injection 1: a payload whose hash is on the built-in blocklist must be
/// rejected before storage, the rejection must be ledgered, and the ledger
/// must still verify.
#[test]
fn injected_blocklisted_payload_rejected_fail_closed() {
    let (mut vault, alice, doc) = granted_vault();
    let before = vault.audit_len();

    let result = vault.store(&alice, &doc, b"malicious_test_payload", b"passphrase");
    assert!(
        matches!(result, Err(VaultError::DetectionBlocked(_))),
        "blocklisted payload must be DetectionBlocked, got: {result:?}"
    );
    assert!(
        vault.audit_len() > before,
        "the rejection itself is ledgered"
    );
    assert!(vault.verify_audit().is_ok());
}

/// Injection 2: an ungranted principal attempts a store — deny by default,
/// nothing stored, denial ledgered.
#[test]
fn injected_unauthorized_store_denied_fail_closed() {
    let (mut vault, _alice, doc) = granted_vault();
    let mallory = Principal("mallory".to_string());

    let result = vault.store(&mallory, &doc, b"innocent-looking notes", b"passphrase");
    assert!(matches!(result, Err(VaultError::AccessDenied)));
    assert!(vault.verify_audit().is_ok());
}

/// Injection 3: retrieval with a wrong passphrase and with a corrupted
/// envelope must both fail closed with a crypto error — never a panic,
/// never partial plaintext.
#[test]
fn injected_bad_retrieval_fails_closed() {
    let (mut vault, alice, doc) = granted_vault();
    let envelope = vault
        .store(&alice, &doc, b"quarterly field report", b"right-passphrase")
        .expect("benign store must succeed");

    let wrong_pass = vault.retrieve(&alice, &doc, &envelope, b"wrong-passphrase");
    assert!(matches!(wrong_pass, Err(VaultError::Crypto(_))));

    let mut corrupted = envelope.clone();
    let last = corrupted.len() - 1;
    corrupted[last] ^= 0x01;
    let corrupted_res = vault.retrieve(&alice, &doc, &corrupted, b"right-passphrase");
    assert!(matches!(corrupted_res, Err(VaultError::Crypto(_))));

    // The genuine path still works after the injected failures.
    let roundtrip = vault
        .retrieve(&alice, &doc, &envelope, b"right-passphrase")
        .expect("genuine retrieve must still succeed");
    assert_eq!(roundtrip.as_slice(), &b"quarterly field report"[..]);
    assert!(vault.verify_audit().is_ok());
}

/// Injection 4 (lane engine): a sandbox-violating payload (empty) trips
/// the lane into quarantine; a subsequent VALID payload is then refused
/// with LaneQuarantined (fail-closed, not executed); a different lane is
/// completely unaffected.
#[test]
fn injected_lane_violation_quarantines_and_isolates() {
    let engine = LaneContainmentEngine::default();
    let lane = LaneId::Mack03FlightController;

    let bad = IngestRecord::new(lane.code(), Vec::new());
    let res = engine.execute_lane(lane, bad);
    assert!(matches!(
        res,
        Err(LaneExecutionError::SandboxViolation { .. })
    ));

    let valid = IngestRecord::new(lane.code(), b"valid payload".to_vec());
    let blocked = engine.execute_lane(lane, valid);
    assert!(matches!(
        blocked,
        Err(LaneExecutionError::LaneQuarantined { .. })
    ));

    let other = LaneId::Mack06Comms;
    let ok = IngestRecord::new(other.code(), b"telemetry bytes".to_vec());
    assert!(
        engine.execute_lane(other, ok).is_ok(),
        "quarantine must not leak across lanes"
    );
}
