//! Phase 2 — Property-based tests for audit-ledger invariants (proptest).
//!
//! Invariants under arbitrary append sequences:
//!  1. Append-only growth: len increases by exactly one per append, and the
//!     pre-existing prefix is never altered by an append.
//!  2. Chain linkage: entry 0 links to the genesis hash; every later entry
//!     links to its predecessor's hash; sequences are 0..n in order.
//!  3. verify() succeeds after any valid append sequence.
//!  4. verify() fails — at exactly the mutated index — after any
//!     single-entry mutation at any position.

use ai_infinity_force_one_vault::vault::audit::AuditLog;
use proptest::prelude::*;

fn actions_strategy() -> impl Strategy<Value = Vec<String>> {
    prop::collection::vec("[a-z0-9 _\\-]{1,24}", 0..40)
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(64))]

    #[test]
    fn ledger_invariants_hold_for_any_append_sequence(
        actions in actions_strategy(),
    ) {
        let mut log = AuditLog::with_genesis("prop-genesis");
        let genesis = log.genesis_hash().to_string();

        let mut prefix_snapshot: Vec<(usize, String, String)> = Vec::new();
        for action in &actions {
            let before_len = log.len();
            log.append("prop-actor", action);
            // Invariant 1a: growth by exactly one.
            prop_assert_eq!(log.len(), before_len + 1);
            // Invariant 1b: the existing prefix is untouched by the append.
            for (i, (seq, hash, prev)) in prefix_snapshot.iter().enumerate() {
                let e = &log.entries()[i];
                prop_assert_eq!(e.sequence, *seq);
                prop_assert_eq!(&e.hash, hash);
                prop_assert_eq!(&e.prev_hash, prev);
            }
            let newest = log.entries()[log.len() - 1].clone();
            prefix_snapshot.push((newest.sequence, newest.hash, newest.prev_hash));
        }

        // Invariant 2: linkage and sequence numbering.
        for (i, entry) in log.entries().iter().enumerate() {
            prop_assert_eq!(entry.sequence, i);
            if i == 0 {
                prop_assert_eq!(&entry.prev_hash, &genesis);
            } else {
                prop_assert_eq!(&entry.prev_hash, &log.entries()[i - 1].hash);
            }
        }
        prop_assert_eq!(log.head_hash(),
            log.entries().last().map(|e| e.hash.clone()).unwrap_or(genesis));

        // Invariant 3: a validly built chain always verifies.
        prop_assert!(log.verify().is_ok());
        prop_assert!(log.verify_anchored(&log.head_hash()).is_ok());
    }

    #[test]
    fn ledger_verify_fails_after_any_single_mutation(
        actions in actions_strategy(),
        mutation_seed in 0usize..1_000_000,
    ) {
        prop_assume!(!actions.is_empty());
        let mut log = AuditLog::with_genesis("prop-genesis");
        for action in &actions {
            log.append("prop-actor", action);
        }
        prop_assert!(log.verify().is_ok());

        let pos = mutation_seed % log.len();
        match mutation_seed % 3 {
            // Mutate the payload (action) of one entry.
            0 => log.entries_mut()[pos].action.push_str("-tampered"),
            // Mutate the actor of one entry.
            1 => log.entries_mut()[pos].actor = "mallory".to_string(),
            // Mutate the stored hash of one entry.
            _ => log.entries_mut()[pos].hash =
                "0000000000000000000000000000000000000000000000000000000000000000".to_string(),
        }

        // Invariant 4: detection, at exactly the mutated index, as an Err —
        // never a panic, never silent acceptance.
        prop_assert_eq!(log.verify(), Err(pos));
    }
}
