use ai_infinity_force_one_vault::{
    generate_authorship_keypair, AttestationAction, ProvenanceError, ProvenanceLedger,
};
use ed25519_dalek::SigningKey;

#[test]
fn test_authorship_attestation_and_chain_verification() {
    let (secret, verifying_key) = generate_authorship_keypair().unwrap();
    let signing_key = SigningKey::from_bytes(&secret);

    let mut ledger = ProvenanceLedger::new(verifying_key);

    // Initial declaration of authorship by inventor
    let att1_hash = {
        let att1 = ledger
            .attest(
                "Allen Mack <a95674127@gmail.com>",
                "MACK-STACK-01",
                AttestationAction::Authorship,
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                &signing_key,
            )
            .expect("Authorship attestation must succeed");
        assert_eq!(att1.sequence, 0);
        assert_eq!(att1.docket, "MACK-STACK-01");
        att1.attestation_hash.clone()
    };

    // Subsequent filing event
    let att2 = ledger
        .attest(
            "Allen Mack <a95674127@gmail.com>",
            "MACK-STACK-01",
            AttestationAction::Filing,
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            &signing_key,
        )
        .expect("Filing attestation must succeed");

    assert_eq!(att2.sequence, 1);
    assert_eq!(att2.prev_hash, att1_hash);

    // Chain integrity passes
    assert!(ledger.verify_chain().is_ok());
}

#[test]
fn test_spoofed_signing_key_rejected_by_ledger() {
    let (_, verifying_key) = generate_authorship_keypair().unwrap();
    let mut ledger = ProvenanceLedger::new(verifying_key);

    // Adversary generates their own keypair
    let (impostor_secret, _) = generate_authorship_keypair().unwrap();
    let impostor_signing_key = SigningKey::from_bytes(&impostor_secret);

    // Attempt to forge an authorship record with impostor key
    let result = ledger.attest(
        "Adversary",
        "MACK-STACK-01",
        AttestationAction::Authorship,
        "deadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef",
        &impostor_signing_key,
    );

    assert!(matches!(result, Err(ProvenanceError::BadSignature)));
}

#[test]
fn test_tampered_attestation_breaks_verification() {
    let (secret, verifying_key) = generate_authorship_keypair().unwrap();
    let signing_key = SigningKey::from_bytes(&secret);

    let mut ledger = ProvenanceLedger::new(verifying_key);
    ledger
        .attest(
            "Allen Mack <a95674127@gmail.com>",
            "MACK-STACK-01",
            AttestationAction::Authorship,
            "sha256_placeholder_digest",
            &signing_key,
        )
        .unwrap();

    let json = ledger.to_json().unwrap();
    // Tamper with the actor name in the serialized record
    let tampered_json = json.replace("Allen Mack", "Malicious Actor");

    let restored = ProvenanceLedger::from_json(&tampered_json, verifying_key);
    assert!(
        restored.is_err(),
        "Tampered attestation must fail cryptographic verification"
    );
}
