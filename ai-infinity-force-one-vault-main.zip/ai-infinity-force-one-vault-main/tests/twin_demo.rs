//! Twin demo integration test: the full honest-twin flow against the
//! public API — a real `lane_worker` child process executes a task
//! under Landlock + seccomp, the event is appended to a persistent
//! ledger, the chain tip is signed (Elevation B0), verification
//! passes, and a truncated copy of the ledger is caught by
//! checkpoint verification.
//!
//! Lane execution is environment-sensitive in principle, but the
//! existing lane tests in this suite spawn the worker unconditionally
//! in this environment, so this test does too: a worker that cannot
//! establish confinement fails the test rather than being skipped.

use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;

use ai_infinity_force_one_vault::ingest::{IngestRecord, IngestStatus};
use ai_infinity_force_one_vault::sandbox::{IsolationLevel, ProcessLaneBackend};
use ai_infinity_force_one_vault::vault::checkpoint::{CheckpointError, CHECKPOINT_KEY_FILE_ENV};
use ai_infinity_force_one_vault::{CheckpointSigner, PersistentLedger};
use redb::{Database, TableDefinition};
use zeroize::Zeroize;

/// Matches `ENTRIES_TABLE` in `src/vault/persistent.rs` (same
/// convention as the crate's checkpoint tests).
const ENTRIES_TABLE: TableDefinition<u64, String> = TableDefinition::new("audit_entries");

static TEST_COUNTER: AtomicU64 = AtomicU64::new(0);

fn temp_root() -> PathBuf {
    let id = TEST_COUNTER.fetch_add(1, Ordering::SeqCst);
    let dir = std::env::temp_dir().join(format!(
        "vault_twin_demo_test_{}_{}",
        std::process::id(),
        id
    ));
    std::fs::create_dir_all(&dir).expect("create temp dir");
    dir
}

fn cleanup(dir: &Path) {
    let _ = std::fs::remove_dir_all(dir);
}

fn write_demo_key(key_path: &Path) {
    let mut seed = [0u8; 32];
    std::fs::File::open("/dev/urandom")
        .and_then(|mut f| f.read_exact(&mut seed))
        .expect("read OS entropy");
    std::fs::write(key_path, seed).expect("write demo key file");
    seed.zeroize();
}

#[test]
fn twin_demo_flow_end_to_end() {
    let root = temp_root();
    let key_path = root.join("checkpoint-key.bin");
    write_demo_key(&key_path);
    std::env::set_var(CHECKPOINT_KEY_FILE_ENV, &key_path);
    let signer = CheckpointSigner::from_env()
        .expect("load signer from env")
        .expect("signer configured");
    std::env::remove_var(CHECKPOINT_KEY_FILE_ENV);

    let ledger_path = root.join("ledger").join("ledger.redb");
    let ledger = PersistentLedger::open(&ledger_path).expect("open ledger");

    // Real lane execution: an actual lane_worker child process. On
    // Linux it must report Landlock confinement and an active seccomp
    // profile — asserted, not assumed.
    let backend = ProcessLaneBackend::spawn(1_048_576, Duration::from_secs(10))
        .expect("lane worker should spawn in tests");
    #[cfg(target_os = "linux")]
    {
        assert_eq!(
            backend.isolation_level(),
            IsolationLevel::ProcessWithLandlock
        );
        assert!(backend.seccomp_active(), "worker must report seccomp on");
    }
    let executed = backend
        .execute(IngestRecord::new(
            "TWIN-DEMO",
            b"twin demo task: confined execution sample".to_vec(),
        ))
        .expect("lane execution");
    assert_eq!(executed.status, IngestStatus::Accepted);
    drop(backend);

    ledger
        .append(
            "twin-demo",
            "task TWIN-001 executed in lane worker: verdict Accepted",
        )
        .expect("append execution event");
    ledger
        .append("twin-demo", "post-execution bookkeeping entry 1")
        .expect("append bookkeeping 1");
    ledger
        .append("twin-demo", "post-execution bookkeeping entry 2")
        .expect("append bookkeeping 2");
    assert_eq!(ledger.len(), 3);

    let record = ledger.checkpoint(&signer).expect("create checkpoint");
    assert_eq!(record.seq, 3);
    assert_eq!(record.head_hash, ledger.head_hash());
    assert_eq!(record.pubkey, signer.public_key_hex());

    ledger
        .verify_checkpoints(Some(&signer.public_key_hex()))
        .expect("chain + checkpoints verify");
    drop(ledger);

    // Tamper on a copy: remove the newest entry so the chain no
    // longer reaches the checkpoint. The truncated chain still
    // verifies on its own; checkpoint verification must refuse it.
    let copy_path = root.join("ledger-copy").join("ledger.redb");
    std::fs::create_dir_all(copy_path.parent().expect("copy parent")).expect("create copy dir");
    std::fs::copy(&ledger_path, &copy_path).expect("copy ledger");
    {
        let db = Database::create(&copy_path).expect("raw open copy");
        let write_txn = db.begin_write().expect("copy write txn");
        {
            let mut table = write_txn.open_table(ENTRIES_TABLE).expect("entries table");
            table.remove(2u64).expect("truncate newest entry");
        }
        write_txn.commit().expect("commit truncation");
    }
    let tampered = PersistentLedger::open(&copy_path).expect("reopen copy");
    assert_eq!(tampered.len(), 2);
    assert!(
        tampered.verify().is_ok(),
        "truncated chain is internally valid"
    );
    match tampered.verify_checkpoints(None) {
        Err(CheckpointError::Truncated {
            checkpoint_seq: 3,
            ledger_entries: 2,
        }) => {}
        other => panic!("expected Truncated(3, 2), got: {other:?}"),
    }
    cleanup(&root);
}
