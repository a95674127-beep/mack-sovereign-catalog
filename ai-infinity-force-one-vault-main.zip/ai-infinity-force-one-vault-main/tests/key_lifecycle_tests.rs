use ai_infinity_force_one_vault::{decrypt, encrypt, rotate_key, KeyError, KeyRing, SecretKey};

#[test]
fn test_secret_key_zeroization_on_wipe() {
    let mut key = SecretKey::random().unwrap();
    assert!(!key.is_zeroed());

    // Explicit zeroization
    key.zeroize_now();
    assert!(key.is_zeroed());

    // Once zeroized, cryptographic operations fail closed
    let encrypt_res = key.encrypt(1, b"classified asset");
    assert!(matches!(encrypt_res, Err(KeyError::EncryptionFailed)));
}

#[test]
fn test_key_rotation_passphrase_envelope() {
    let original_payload = b"sensitive proprietary algorithm weights 2026";
    let old_passphrase = b"initial_master_key_v1";
    let new_passphrase = b"rotated_master_key_v2";

    // Encrypt under initial key
    let envelope_v1 = encrypt(original_payload, old_passphrase).expect("Initial encryption");

    // Old key decrypts successfully
    assert_eq!(
        decrypt(&envelope_v1, old_passphrase).unwrap().as_slice(),
        &original_payload[..]
    );

    // Rotate to new passphrase
    let envelope_v2 =
        rotate_key(&envelope_v1, old_passphrase, new_passphrase).expect("Rotation should succeed");

    // Old passphrase MUST fail on the rotated envelope
    let old_attempt = decrypt(&envelope_v2, old_passphrase);
    assert!(
        old_attempt.is_err(),
        "Old passphrase must not decrypt rotated envelope"
    );

    // New passphrase decrypts with perfect integrity
    let recovered = decrypt(&envelope_v2, new_passphrase).expect("Decryption with new passphrase");
    assert_eq!(recovered.as_slice(), &original_payload[..]);
}

#[test]
fn test_key_rotation_fails_with_invalid_old_passphrase() {
    let payload = b"classified data";
    let correct_passphrase = b"correct_pass";
    let bad_passphrase = b"wrong_pass";
    let new_passphrase = b"new_pass";

    let envelope = encrypt(payload, correct_passphrase).unwrap();

    let rotation_result = rotate_key(&envelope, bad_passphrase, new_passphrase);
    assert!(
        rotation_result.is_err(),
        "Rotation with invalid source credentials must fail"
    );
}

#[test]
fn test_keyring_multi_version_lifecycle_and_grace_period() {
    let mut keyring = KeyRing::new().unwrap();
    let v1_id = keyring.active_key_id();

    // Data encrypted at epoch 1
    let payload = b"critical financial ledger entry";
    let v1_envelope = keyring.encrypt(payload).unwrap();

    // Rotate to epoch 2
    let v2_id = keyring.rotate().unwrap();
    assert_ne!(v1_id, v2_id);
    assert_eq!(keyring.active_key_id(), v2_id);
    assert_eq!(keyring.len(), 2);

    // Epoch 1 envelope still decrypts seamlessly during grace window
    let recovered_v1 = keyring.decrypt(&v1_envelope).unwrap();
    assert_eq!(recovered_v1.as_slice(), payload);

    // Re-encrypt (migrate) envelope to epoch 2
    let migrated_envelope = keyring.re_encrypt(&v1_envelope).unwrap();
    assert_eq!(
        keyring.decrypt(&migrated_envelope).unwrap().as_slice(),
        payload
    );

    // Revoke epoch 1 key permanently
    keyring.revoke_key(v1_id).unwrap();
    assert!(!keyring.contains_key(v1_id));

    // Old unmigrated envelope is now permanently unreadable
    let fail_v1 = keyring.decrypt(&v1_envelope);
    assert!(matches!(fail_v1, Err(KeyError::UnknownKeyId(id)) if id == v1_id));

    // Migrated envelope remains decryptable under active epoch 2 key
    assert_eq!(
        keyring.decrypt(&migrated_envelope).unwrap().as_slice(),
        payload
    );
}

#[test]
fn test_keyring_cannot_revoke_active_key() {
    let mut keyring = KeyRing::new().unwrap();
    let active_id = keyring.active_key_id();

    let revoke_res = keyring.revoke_key(active_id);
    assert!(matches!(revoke_res, Err(KeyError::CannotRevokeActiveKey)));
}
