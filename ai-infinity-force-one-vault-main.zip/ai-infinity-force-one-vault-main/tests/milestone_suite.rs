use ai_infinity_force_one_vault::ingest::IngestRecord;
use ai_infinity_force_one_vault::pov::{DePinStressEngine, ProofOfVerification};
use ai_infinity_force_one_vault::sandbox::{
    LaneContainmentEngine, LaneExecutionError, LaneId, LaneStatus,
};
use ai_infinity_force_one_vault::vault::audit::{AuditLog, ConcurrentLedger, GENESIS_EVT_1041};
use ai_infinity_force_one_vault::Vault;
use std::thread;
use std::time::Duration;

#[test]
fn test_milestone_1_twelve_lanes_initialized_and_isolated() {
    let engine = LaneContainmentEngine::default();
    assert_eq!(engine.lane_count(), 12);

    for lane in LaneId::ALL_LANES.iter() {
        assert_eq!(engine.lane_status(*lane), LaneStatus::Green);
    }
}

#[test]
fn test_milestone_1_quarantine_exponential_backoff() {
    let engine = LaneContainmentEngine::default();
    let lane = LaneId::Mack01Propulsion;

    // 1. Submit an empty payload (sandbox violation)
    let bad_rec = IngestRecord::new(lane.code(), Vec::new());

    let res = engine.execute_lane(lane, bad_rec);
    assert!(res.is_err());
    match res.unwrap_err() {
        LaneExecutionError::SandboxViolation {
            lane: l,
            backoff_applied,
            ..
        } => {
            assert_eq!(l, lane);
            assert_eq!(backoff_applied, Duration::from_secs(1));
        }
        other => panic!("Unexpected result: {:?}", other),
    }

    // 2. Lane should now be in quarantine
    match engine.lane_status(lane) {
        LaneStatus::Quarantined { backoff_level, .. } => {
            assert_eq!(backoff_level, 1);
        }
        other => panic!("Expected Quarantined, got {:?}", other),
    }

    // 3. Subsequent execution while quarantined is blocked
    let test_rec = IngestRecord::new(lane.code(), b"valid payload".to_vec());
    let blocked_res = engine.execute_lane(lane, test_rec);
    assert!(matches!(
        blocked_res,
        Err(LaneExecutionError::LaneQuarantined { .. })
    ));

    // 4. Zero cross-contamination: other lanes remain GREEN!
    let other_lane = LaneId::Mack02NavLidar;
    assert_eq!(engine.lane_status(other_lane), LaneStatus::Green);
    let ok_rec = IngestRecord::new(other_lane.code(), b"telemetry bytes".to_vec());
    assert!(engine.execute_lane(other_lane, ok_rec).is_ok());
}

#[test]
fn test_milestone_2_genesis_binding_and_segment_integrity() {
    let mut log = AuditLog::with_genesis(GENESIS_EVT_1041);
    assert_eq!(log.genesis(), GENESIS_EVT_1041);

    log.append("operator_1", "task_executed_lane_1");
    log.append("operator_2", "task_executed_lane_2");
    log.append("operator_3", "task_executed_lane_3");

    let report = log.verify_segment(0, log.len());
    assert!(report.is_valid);
    assert_eq!(report.total_entries, 3);
    assert_eq!(report.broken_segments.len(), 0);
    assert_eq!(report.genesis_hash, GENESIS_EVT_1041);
}

#[test]
fn test_milestone_2_concurrent_12_lane_ledger_appends() {
    let ledger = ConcurrentLedger::new();
    let mut handles = Vec::new();

    for lane in LaneId::ALL_LANES.iter() {
        let l = ledger.clone();
        let code = lane.code().to_string();
        handles.push(thread::spawn(move || {
            l.append(&code, "lane_checkpoint");
        }));
    }

    for h in handles {
        h.join().unwrap();
    }

    assert_eq!(ledger.len(), 12);
    let report = ledger.verify_segments();
    assert!(report.is_valid);
    assert_eq!(report.broken_segments.len(), 0);
}

#[test]
fn test_milestone_3_batch_pov_ingest_and_depin_stress() {
    let batch_json = include_str!("../pov/pov_batch_003_009.json");
    let batch = ProofOfVerification::batch_from_json(batch_json).expect("parses batch JSON");
    assert_eq!(batch.len(), 7);

    let stress_engine = DePinStressEngine::new(4);
    let report = stress_engine.run_stress_test(batch);

    assert_eq!(report.total_tasks, 7);
    assert_eq!(report.passed_tasks + report.rejected_tasks, 7);
    assert!(report.operator_stats.contains_key("node_A"));
    assert!(report.operator_stats.contains_key("node_B"));
    assert!(report.operator_stats.contains_key("node_C"));
    assert!(report.operator_stats.contains_key("node_D"));

    // Verify node_A stats (task_0003 valid, task_0006 invalid)
    let node_a = &report.operator_stats["node_A"];
    assert_eq!(node_a.total_submitted, 2);
    assert_eq!(node_a.verified_valid, 1);
    assert_eq!(node_a.rejected, 1);
}

#[test]
fn test_milestone_3_vault_ingest_batch_json() {
    let mut vault = Vault::new();
    let batch_json = include_str!("../pov/pov_batch_003_009.json");
    let principal = ai_infinity_force_one_vault::Principal("depin_operator".to_string());
    let results = vault
        .ingest_pov_batch_json(&principal, batch_json)
        .expect("valid batch");

    assert_eq!(results.len(), 7);
    assert_eq!(results.len(), 7);
}
