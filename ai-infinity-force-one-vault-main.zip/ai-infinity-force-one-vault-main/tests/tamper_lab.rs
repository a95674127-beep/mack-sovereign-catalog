//! Phase 2 — Ledger Tamper Laboratory.
//!
//! Adversarial tests against the real `AuditLog` API: each case mutates a
//! valid hash-chained ledger the way a storage-level attacker would, and
//! asserts the documented expected behavior — `verify()` /
//! `verify_anchored()` return an `Err` (never a panic, never silent
//! acceptance), or the case is honestly recorded as a KNOWN LIMITATION of
//! internal verification that only external anchoring (see ANCHORING.md)
//! can close.
//!
//! Per-case outcome summary (also in the Phase 2 report):
//!   (a) modify payload      — DETECTED by verify()
//!   (b) delete middle entry — DETECTED by verify()/from_entries()
//!   (c) reorder entries     — DETECTED by verify()
//!   (d) insert forged entry — DETECTED by verify()/from_entries()
//!   (e) replay old entry    — DETECTED by verify()
//!   (f) truncate tail       — NOT visible to verify() alone (a valid prefix
//!                             is internally consistent); DETECTED by
//!                             verify_anchored(saved_head). By design: the
//!                             head_hash() docs state the head must be
//!                             stored outside the log to detect truncation.
//!   (g) snapshot rollback   — KNOWN LIMITATION, same shape as (f): a
//!                             rolled-back prefix verifies internally;
//!                             verify_anchored() detects it. External
//!                             anchoring (ANCHORING.md) is the fix.
//!   (h) corrupt stored hash — DETECTED by verify()

use ai_infinity_force_one_vault::vault::audit::{AuditEntry, AuditLog};

const GENESIS: &str = "tamper-lab-genesis";

fn build_log(n: usize) -> AuditLog {
    let mut log = AuditLog::with_genesis(GENESIS);
    for i in 0..n {
        log.append("operator", &format!("action-{i}"));
    }
    assert!(log.verify().is_ok(), "freshly built log must verify");
    log
}

/// (a) Modify an entry's payload after append.
#[test]
fn tamper_a_modify_entry_payload_detected() {
    let mut log = build_log(6);
    log.entries_mut()[2].action = "forged-action".to_string();
    assert_eq!(
        log.verify(),
        Err(2),
        "mutated payload must break the chain at the mutated entry"
    );
}

/// (b) Delete a middle entry (rebuild path: from_entries, the same path the
/// persistent ledger uses on open).
#[test]
fn tamper_b_delete_middle_entry_detected() {
    let log = build_log(6);
    let mut entries: Vec<AuditEntry> = log.entries().to_vec();
    entries.remove(2);
    let result = AuditLog::from_entries(GENESIS.to_string(), entries);
    assert_eq!(
        result.unwrap_err(),
        2,
        "deleting a middle entry must be detected at the gap"
    );
}

/// (c) Reorder two entries in place.
#[test]
fn tamper_c_reorder_entries_detected() {
    let mut log = build_log(6);
    log.entries_mut().swap(1, 2);
    assert_eq!(
        log.verify(),
        Err(1),
        "swapped entries must break sequence/linkage at the first swap site"
    );
}

/// (d) Insert a forged entry into the middle of the chain.
#[test]
fn tamper_d_insert_forged_entry_detected() {
    let log = build_log(6);
    let mut entries: Vec<AuditEntry> = log.entries().to_vec();
    // Forge: clone a real entry and relabel it; its hash cannot match the
    // recomputed hash for its new position, and its prev_hash points at the
    // wrong predecessor.
    let mut forged = entries[1].clone();
    forged.sequence = 2;
    forged.action = "forged-insert".to_string();
    entries.insert(2, forged);
    let result = AuditLog::from_entries(GENESIS.to_string(), entries);
    assert_eq!(
        result.unwrap_err(),
        2,
        "a forged insertion must be detected at the insertion point"
    );
}

/// (e) Replay a valid older entry over a later position.
#[test]
fn tamper_e_replay_old_entry_detected() {
    let mut log = build_log(6);
    let replayed = log.entries()[1].clone();
    log.entries_mut()[3] = replayed;
    assert_eq!(
        log.verify(),
        Err(3),
        "a replayed entry carries the wrong sequence/prev_hash for its slot"
    );
}

/// (f) Truncate the tail. Plain verify() cannot see this — a truncated log
/// is a perfectly valid prefix chain. Detection requires the externally
/// saved head hash (verify_anchored), exactly as head_hash() documents.
#[test]
fn tamper_f_truncate_tail_detected_only_with_anchor() {
    let mut log = build_log(6);
    let saved_head = log.head_hash();

    log.pop_last();
    log.pop_last();
    assert_eq!(log.len(), 4);

    // Documented design behavior: internal verification passes on a prefix.
    assert!(
        log.verify().is_ok(),
        "a truncated prefix is internally consistent — this is why anchoring exists"
    );
    // The anchored check must catch it.
    assert_eq!(
        log.verify_anchored(&saved_head),
        Err(4),
        "anchored verification must reject a truncated tail"
    );
}

/// (g) KNOWN LIMITATION — snapshot rollback: replace the current chain with
/// an older, shorter snapshot of itself. Internally the snapshot is a valid
/// chain, so verify() passes; only an externally anchored head detects the
/// rollback. This test pins the current behavior honestly; the fix is the
/// external anchoring mechanism documented in ANCHORING.md (Phase 1), which
/// requires the owner's signing key and is not yet in force.
#[test]
fn tamper_g_snapshot_rollback_known_limitation() {
    let log = build_log(6);
    let saved_head = log.head_hash();

    // Attacker restores the first 3 entries as the whole log.
    let snapshot: Vec<AuditEntry> = log.entries()[..3].to_vec();
    let restored = AuditLog::from_entries(GENESIS.to_string(), snapshot)
        .expect("a genuine prefix snapshot is internally valid and loads");

    // KNOWN LIMITATION: internal verification alone cannot detect rollback.
    assert!(restored.verify().is_ok());
    assert_eq!(restored.len(), 3);
    // Anchored verification detects it immediately.
    assert!(
        restored.verify_anchored(&saved_head).is_err(),
        "anchored verification must reject a rolled-back snapshot"
    );
}

/// (h) Corrupt a stored hash field (the per-entry checkpoint value).
#[test]
fn tamper_h_corrupt_stored_hash_detected() {
    let mut log = build_log(6);
    log.entries_mut()[1].hash =
        "0000000000000000000000000000000000000000000000000000000000000000".to_string();
    assert_eq!(
        log.verify(),
        Err(1),
        "a corrupted stored hash must fail recomputation at that entry"
    );
}

/// (h2) Corrupt a stored prev_hash link field.
#[test]
fn tamper_h2_corrupt_prev_hash_link_detected() {
    let mut log = build_log(6);
    log.entries_mut()[3].prev_hash =
        "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff".to_string();
    assert_eq!(
        log.verify(),
        Err(3),
        "a corrupted linkage field must be detected at that entry"
    );
}
