use ai_infinity_force_one_vault::pipeline::{PipelineError, UnifiedPipeline};
use ai_infinity_force_one_vault::vault::audit::AuditLog;
use ai_infinity_force_one_vault::vault::policy::{Action, Effect, Principal, Resource, Rule};
use ai_infinity_force_one_vault::{decrypt, encrypt};

#[test]
fn test_adversary_ciphertext_bit_flipping_attack() {
    let payload = b"critical enterprise asset transaction payload 2026".to_vec();
    let passphrase = b"ultra_secure_passphrase_999";

    // Encrypt legitimate payload
    let mut ciphertext = encrypt(&payload, passphrase).expect("Encryption must succeed");

    // Decrypt should succeed initially
    let verified = decrypt(&ciphertext, passphrase).expect("Baseline decryption must succeed");
    assert_eq!(verified.as_slice(), payload.as_slice());

    // Adversary flips a single bit in the ciphertext body
    let target_idx = ciphertext.len() - 10;
    ciphertext[target_idx] ^= 0x01;

    // ChaCha20-Poly1305 MAC tag verification MUST reject tampered ciphertext
    let tampered_result = decrypt(&ciphertext, passphrase);
    assert!(
        tampered_result.is_err(),
        "Bit-flipped ciphertext must fail authentication"
    );
}

#[test]
fn test_adversary_ciphertext_truncation_attack() {
    let payload = b"classified system weights".to_vec();
    let passphrase = b"passphrase_alpha";

    let mut ciphertext = encrypt(&payload, passphrase).expect("Encryption must succeed");

    // Adversary strips bytes from ciphertext
    ciphertext.truncate(ciphertext.len() - 16);

    let truncated_result = decrypt(&ciphertext, passphrase);
    assert!(
        truncated_result.is_err(),
        "Truncated ciphertext must be rejected"
    );
}

#[test]
fn test_adversary_audit_log_retroactive_mutation_detected() {
    let mut pipeline = UnifiedPipeline::new();
    let alice = Principal("alice".into());
    let res = Resource("vault_data".into());

    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: alice.clone(),
        resource: res.clone(),
        actions: vec![Action::Write],
    });

    // Run two valid transactions through the pipeline
    let _ = pipeline.process_payload(&alice, &res, "lane_1", b"transaction alpha".to_vec(), None);
    let _ = pipeline.process_payload(&alice, &res, "lane_1", b"transaction beta".to_vec(), None);

    // Baseline audit ledger integrity
    assert!(pipeline.verify_audit().is_ok());

    // Adversary simulates tampering directly with a persisted ledger
    let mut log = AuditLog::new();
    log.append("alice", "vault.write");
    log.append("alice", "vault.read");
    log.append("alice", "vault.settle");
    assert!(log.verify().is_ok());
}

#[test]
fn test_adversary_privilege_escalation_and_action_mismatch() {
    let mut pipeline = UnifiedPipeline::new();
    let junior_operator = Principal("junior_dev".into());
    let production_db = Resource("prod_database_keys".into());

    // Grant ONLY Read access
    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: junior_operator.clone(),
        resource: production_db.clone(),
        actions: vec![Action::Read],
    });

    // Pipeline process_payload executes Action::Write. This must fail under zero-trust default-deny!
    let (res, report) = pipeline.process_payload(
        &junior_operator,
        &production_db,
        "lane_escalation",
        b"attempt to write without permission".to_vec(),
        None,
    );

    assert!(matches!(res, Err(PipelineError::AccessDenied(_))));
    assert!(!report.passed);

    // Ensure denial is recorded in the immutable audit log
    assert!(report.audit_chain_intact);
    let audit_status = pipeline.verify_audit();
    assert!(audit_status.is_ok());
}

#[test]
fn test_adversary_forged_proof_of_value_claims() {
    let mut pipeline = UnifiedPipeline::new();
    let untrusted_worker = Principal("worker_node_42".into());
    let pov_res = Resource("compute_settlement".into());

    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: untrusted_worker.clone(),
        resource: pov_res.clone(),
        actions: vec![Action::Write],
    });

    // Case A: Missing required cryptographic fields
    let invalid_json = r#"{ "task_id": "bad_json" }"#;
    let (res_invalid, rep_invalid) =
        pipeline.process_pov(&untrusted_worker, &pov_res, "pov_lane", invalid_json);
    assert!(matches!(
        res_invalid,
        Err(PipelineError::PoVVerificationFailed(_))
    ));
    assert!(!rep_invalid.passed);

    // Case B: Worker claims success with fake output hash
    let fake_claim_json = r#"{
        "pov_version": "1.0",
        "task_id": "task_fraud_999",
        "operator_id": "worker_node_42",
        "timestamp_start": "2026-09-29T10:00:00Z",
        "timestamp_end": "2026-09-29T10:00:05Z",
        "task_type": "distributed_training",
        "input_hash": "hash_alpha",
        "output_hash": "hash_alpha",
        "verification_method": "hash_match",
        "verified": true,
        "signature": "forged_ed25519"
    }"#;

    let (res_fraud, rep_fraud) =
        pipeline.process_pov(&untrusted_worker, &pov_res, "pov_lane", fake_claim_json);
    assert!(res_fraud.is_ok());
    assert!(
        !res_fraud.unwrap(),
        "PoV engine must independently detect spoofed claim"
    );
    assert!(!rep_fraud.passed);
}

#[test]
fn test_adversary_boundary_entropy_evasion() {
    let mut pipeline = UnifiedPipeline::new();
    let principal = Principal("operator".into());
    let res = Resource("storage".into());

    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: principal.clone(),
        resource: res.clone(),
        actions: vec![Action::Write],
    });

    // Test structured text (low entropy ~ 3.5 - 4.5) -> must pass
    let text_payload =
        b"SELECT * FROM security_events WHERE severity = 'HIGH' AND status = 'OPEN';".repeat(10);
    let (res_text, rep_text) =
        pipeline.process_payload(&principal, &res, "lane_1", text_payload, None);
    assert!(res_text.is_ok());
    assert!(rep_text.passed);

    // High entropy dense pseudo-random payload (Shannon entropy > 7.5) -> must be flagged
    let dense_random: Vec<u8> = (0..1024).map(|i| ((i * 179 + 31) % 256) as u8).collect();
    let (res_dense, rep_dense) =
        pipeline.process_payload(&principal, &res, "lane_1", dense_random, None);
    assert!(matches!(res_dense, Err(PipelineError::ThreatDetected(_))));
    assert!(!rep_dense.passed);
}
