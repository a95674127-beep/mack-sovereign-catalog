//! Property-based tests using proptest.
//!
//! These verify invariants that must hold for ALL inputs, not just examples.

use ai_infinity_force_one_vault::pov::ProofOfVerification;
use ai_infinity_force_one_vault::vault::policy::{
    AccessPolicy, Action, Decision, Effect, Principal, Resource, Rule,
};
use ai_infinity_force_one_vault::Vault;
use proptest::prelude::*;
use proptest::test_runner::Config as ProptestConfig;

proptest! {
    /// Deny-by-default: a principal/resource/action that was not explicitly
    /// granted must always be denied, no matter what strings are used.
    #[test]
    fn policy_deny_by_default(
        granted_principal in "[a-z]{1,20}",
        granted_resource in "[a-z]{1,20}",
        other_principal in "[a-z]{1,20}",
        other_resource in "[a-z]{1,20}",
        action in prop_oneof![
            Just(Action::Read),
            Just(Action::Write),
            Just(Action::Delete),
        ],
    ) {
        let mut policy = AccessPolicy::new();
        policy.grant(Rule {
            effect: Effect::Allow,
            principal: Principal(granted_principal.clone()),
            resource: Resource(granted_resource.clone()),
            actions: vec![Action::Read],
        });

        // A different principal must be denied, even for the granted resource.
        if other_principal != granted_principal {
            let d = policy.evaluate(
                &Principal(other_principal),
                &Resource(granted_resource.clone()),
                action.clone(),
            );
            prop_assert_eq!(d, Decision::Deny);
        }

        // A different resource must be denied, even for the granted principal.
        if other_resource != granted_resource {
            let d = policy.evaluate(
                &Principal(granted_principal.clone()),
                &Resource(other_resource),
                action,
            );
            prop_assert_eq!(d, Decision::Deny);
        }
    }

    /// An empty policy denies everything.
    #[test]
    fn empty_policy_denies_all(
        principal in "[a-z]{1,20}",
        resource in "[a-z]{1,20}",
        action in prop_oneof![
            Just(Action::Read),
            Just(Action::Write),
            Just(Action::Delete),
        ],
    ) {
        let policy = AccessPolicy::new();
        let d = policy.evaluate(&Principal(principal), &Resource(resource), action);
        prop_assert_eq!(d, Decision::Deny);
    }
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(16))]
    /// Store-then-retrieve roundtrip: for any low-entropy plaintext, storing
    /// and retrieving with the same passphrase returns the exact bytes.
    /// (Low-entropy data avoids the entropy blocker; the crypto roundtrip
    /// is what's under test.)
    #[test]
    fn store_retrieve_roundtrip(
        plaintext in "[a-z ]{1,200}",
        passphrase in "[a-z0-9]{8,32}",
    ) {
        let mut vault = Vault::new();
        let alice = Principal("alice".into());
        let secret = Resource("prop_secret".into());
        vault.grant(Rule {
            effect: Effect::Allow,
            principal: alice.clone(),
            resource: secret.clone(),
            actions: vec![Action::Write, Action::Read],
        });

        let envelope = vault
            .store(&alice, &secret, plaintext.as_bytes(), passphrase.as_bytes())
            .expect("store should succeed for low-entropy text");
        let recovered = vault
            .retrieve(&alice, &secret, &envelope, passphrase.as_bytes())
            .expect("retrieve should succeed");
        prop_assert_eq!(recovered.as_slice(), plaintext.as_bytes());
    }
}

proptest! {
    /// The caller's `verified` claim is never trusted: `log_pov` returns the
    /// independently computed result, not the claimed flag. A PoV that fails
    /// independent verification is logged as unverified, whatever the caller
    /// claimed.
    #[test]
    fn pov_claim_never_trusted(
        input_hash in "[a-f0-9]{1,64}",
        output_hash in "[a-f0-9]{1,64}",
        claimed_verified in any::<bool>(),
        method in prop_oneof![
            Just("hash_match".to_string()),
            Just("merkle_proof".to_string()),
            Just("unsupported_xyz".to_string()),
        ],
    ) {
        let pov = ProofOfVerification {
            pov_version: "1.0".to_string(),
            task_id: "task_prop".to_string(),
            operator_id: "op_prop".to_string(),
            timestamp_start: "2026-01-01T00:00:00Z".to_string(),
            timestamp_end: "2026-01-01T00:00:01Z".to_string(),
            task_type: "compute".to_string(),
            input_hash: input_hash.clone(),
            output_hash: output_hash.clone(),
            verification_method: method.clone(),
            verified: claimed_verified, // the attacker's claim
            signature: String::new(),
        };

        let mut vault = Vault::new();
        let alice = Principal("alice".into());
        let result = vault.log_pov(&alice, &pov);

        // The result must equal the independent verification, not the claim.
        prop_assert_eq!(result, pov.independently_verify());

        // Specifically: if independent verification fails, the result is
        // false even when the caller claimed true.
        if !pov.independently_verify() {
            prop_assert!(!result, "caller claim of verified=true was trusted!");
        }
    }
}
