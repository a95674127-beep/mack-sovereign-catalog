#!/bin/bash
# Routine node telemetry collection
UPTIME=$(cat /proc/uptime)
MEM_FREE=$(cat /proc/meminfo | grep MemFree)
echo "Tactical node telemetry logged successfully"
