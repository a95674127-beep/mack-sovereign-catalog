#!/bin/bash
# Standard tactical health check script
echo "Verifying primary router reachability..."
ping -c 3 -W 2 10.0.1.1
logger -t network_health "Gateway ping verification completed successfully"
exit 0
