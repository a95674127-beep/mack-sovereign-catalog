use ai_infinity_force_one_vault::pipeline::{PipelineError, PipelineStage, UnifiedPipeline};
use ai_infinity_force_one_vault::vault::policy::{Action, Effect, Principal, Resource, Rule};

#[test]
fn test_stage_1_sandbox_containment_empty_payload() {
    let mut pipeline = UnifiedPipeline::new();
    let alice = Principal("alice".into());
    let res = Resource("vault_data".into());

    let (result, report) = pipeline.process_payload(&alice, &res, "lane_1", vec![], None);
    assert!(matches!(result, Err(PipelineError::Sandbox(_))));
    assert!(!report.passed);
    assert_eq!(report.stages[0].stage, PipelineStage::SandboxContainment);
    assert!(!report.stages[0].passed);
    assert!(report.audit_chain_intact);
}

#[test]
fn test_stage_1_sandbox_containment_oversized_payload() {
    let mut pipeline = UnifiedPipeline::with_containment_limit(16);
    let alice = Principal("alice".into());
    let res = Resource("vault_data".into());

    let oversized = vec![0x41; 32];
    let (result, report) = pipeline.process_payload(&alice, &res, "lane_1", oversized, None);
    assert!(matches!(result, Err(PipelineError::Sandbox(_))));
    assert!(!report.passed);
    assert_eq!(report.stages[0].stage, PipelineStage::SandboxContainment);
    assert!(!report.stages[0].passed);
}

#[test]
fn test_stage_2_threat_detection_blocklisted_hash() {
    let mut pipeline = UnifiedPipeline::new();
    let alice = Principal("alice".into());
    let res = Resource("vault_data".into());

    // Grant access so it passes policy check if it got there
    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: alice.clone(),
        resource: res.clone(),
        actions: vec![Action::Write],
    });

    // Known malicious test string present in known_bad_hashes.txt
    let malicious = b"malicious_test_payload".to_vec();
    let (result, report) = pipeline.process_payload(&alice, &res, "lane_threat", malicious, None);
    assert!(matches!(result, Err(PipelineError::ThreatDetected(_))));
    assert!(!report.passed);

    let threat_stage = report
        .stages
        .iter()
        .find(|s| s.stage == PipelineStage::ThreatDetection)
        .expect("Threat detection stage must be evaluated");
    assert!(!threat_stage.passed);
    assert!(threat_stage.details.contains("known-bad threat hash"));
    assert!(report.audit_chain_intact);
}

#[test]
fn test_stage_2_threat_detection_high_entropy_shellcode() {
    let mut pipeline = UnifiedPipeline::new();
    let alice = Principal("alice".into());
    let res = Resource("vault_data".into());

    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: alice.clone(),
        resource: res.clone(),
        actions: vec![Action::Write],
    });

    // Create high-entropy pseudo-random bytes (shannon entropy > 7.2)
    let high_entropy_payload: Vec<u8> = (0..512).map(|i| ((i * 137 + 73) % 256) as u8).collect();
    let (result, report) =
        pipeline.process_payload(&alice, &res, "lane_entropy", high_entropy_payload, None);

    assert!(matches!(result, Err(PipelineError::ThreatDetected(_))));
    assert!(!report.passed);

    let threat_stage = report
        .stages
        .iter()
        .find(|s| s.stage == PipelineStage::ThreatDetection)
        .expect("Threat detection stage must be evaluated");
    assert!(!threat_stage.passed);
    assert!(threat_stage.details.contains("Suspicious high entropy"));
    assert!(report.audit_chain_intact);
}

#[test]
fn test_stage_3_zero_trust_default_deny() {
    let mut pipeline = UnifiedPipeline::new();
    let bob = Principal("unauthorized_operator".into());
    let secret_res = Resource("classified_asset".into());

    // Safe low-entropy clean text
    let clean_payload = b"clean unclassified message".to_vec();
    let (result, report) =
        pipeline.process_payload(&bob, &secret_res, "lane_auth", clean_payload, None);

    assert!(matches!(result, Err(PipelineError::AccessDenied(_))));
    assert!(!report.passed);

    let policy_stage = report
        .stages
        .iter()
        .find(|s| s.stage == PipelineStage::ZeroTrustPolicy)
        .expect("Policy stage must be evaluated");
    assert!(!policy_stage.passed);
    assert!(policy_stage.details.contains("unauthorized"));
    assert!(report.audit_chain_intact);
}

#[test]
fn test_stage_4_pov_verification_and_spoof_detection() {
    let mut pipeline = UnifiedPipeline::new();
    let operator = Principal("operator_alpha".into());
    let pov_res = Resource("pov_ledger".into());

    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: operator.clone(),
        resource: pov_res.clone(),
        actions: vec![Action::Write],
    });

    // Valid PoV JSON where input and output hashes match the required hash_match method
    let valid_pov_json = r#"{
        "pov_version": "1.0",
        "task_id": "task_valid_100",
        "operator_id": "operator_alpha",
        "timestamp_start": "2026-09-29T12:00:00Z",
        "timestamp_end": "2026-09-29T12:00:01Z",
        "task_type": "deep_compute",
        "input_hash": "a1b2c3d4",
        "output_hash": "e5f6g7h8",
        "verification_method": "hash_match",
        "verified": true,
        "signature": "valid_sig"
    }"#;

    let (res_valid, report_valid) =
        pipeline.process_pov(&operator, &pov_res, "pov_lane", valid_pov_json);
    assert!(res_valid.is_ok());
    assert!(res_valid.unwrap());
    assert!(report_valid.passed);

    // Spoofed PoV where operator claimed verified=true, but hashes are identical under hash_match
    let spoofed_pov_json = r#"{
        "pov_version": "1.0",
        "task_id": "task_spoofed_101",
        "operator_id": "operator_alpha",
        "timestamp_start": "2026-09-29T12:00:00Z",
        "timestamp_end": "2026-09-29T12:00:01Z",
        "task_type": "deep_compute",
        "input_hash": "same_hash_payload",
        "output_hash": "same_hash_payload",
        "verification_method": "hash_match",
        "verified": true,
        "signature": "fake_sig"
    }"#;

    let (res_spoof, report_spoof) =
        pipeline.process_pov(&operator, &pov_res, "pov_lane", spoofed_pov_json);
    assert!(res_spoof.is_ok());
    // Independent verification caught the spoofed claim
    assert!(!res_spoof.unwrap());
    assert!(!report_spoof.passed);
    assert!(report_spoof.audit_chain_intact);
}

#[test]
fn test_stage_5_full_authorized_encrypted_pipeline_execution() {
    let mut pipeline = UnifiedPipeline::new();
    let alice = Principal("alice".into());
    let secure_res = Resource("critical_weights".into());

    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: alice.clone(),
        resource: secure_res.clone(),
        actions: vec![Action::Write, Action::Read],
    });

    let payload = b"critical system parameter configuration block".to_vec();
    let passphrase = b"master_secure_passphrase_2026";

    let (result, report) = pipeline.process_payload(
        &alice,
        &secure_res,
        "secure_lane",
        payload.clone(),
        Some(passphrase),
    );

    assert!(result.is_ok());
    let ciphertext = result.unwrap();
    assert_ne!(ciphertext, payload);
    assert!(report.passed);
    assert_eq!(report.stages.len(), 4);
    assert!(report.audit_chain_intact);
    assert!(pipeline.verify_audit().is_ok());

    // Decrypt directly to verify ChaCha20-Poly1305 + Argon2 integrity
    let decrypted = ai_infinity_force_one_vault::decrypt(&ciphertext, passphrase)
        .expect("Decryption must succeed");
    assert_eq!(decrypted.as_slice(), payload.as_slice());
}

/// Harvest (2026-11-10, audit row 5): the pipeline refuses runs once
/// the operation budget is spent, even for a granted principal, and
/// the refusal is reported at the policy stage with an intact audit
/// chain.
#[test]
fn test_operation_budget_blocks_pipeline_after_limit() {
    let mut pipeline = UnifiedPipeline::new();
    let alice = Principal("alice".into());
    let res = Resource("vault_data".into());
    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: alice.clone(),
        resource: res.clone(),
        actions: vec![Action::Write],
    });
    pipeline.set_ops_budget(Some(1));

    let (result, report) = pipeline.process_payload(
        &alice,
        &res,
        "lane_budget",
        b"hello vault pipeline".to_vec(),
        None,
    );
    assert!(result.is_ok(), "first run within budget: {result:?}");
    assert!(report.passed);
    assert_eq!(pipeline.ops_used(), 1);
    assert_eq!(pipeline.ops_remaining(), Some(0));

    let (result, report) = pipeline.process_payload(
        &alice,
        &res,
        "lane_budget",
        b"hello vault pipeline".to_vec(),
        None,
    );
    assert!(
        matches!(result, Err(PipelineError::BudgetExhausted(_))),
        "second run must be refused: {result:?}"
    );
    assert!(!report.passed);
    let policy_stage = report
        .stages
        .iter()
        .find(|s| s.stage == PipelineStage::ZeroTrustPolicy)
        .expect("policy stage must be evaluated");
    assert!(!policy_stage.passed);
    assert!(report.audit_chain_intact);
    assert_eq!(pipeline.ops_used(), 1, "refused runs do not consume budget");
}

/// The default (no budget set) is unlimited — pre-harvest behavior
/// is unchanged, and allowed runs are counted.
#[test]
fn test_operation_budget_default_unlimited() {
    let mut pipeline = UnifiedPipeline::new();
    let alice = Principal("alice".into());
    let res = Resource("vault_data".into());
    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: alice.clone(),
        resource: res.clone(),
        actions: vec![Action::Write],
    });
    assert_eq!(pipeline.ops_remaining(), None);

    for _ in 0..2 {
        let (result, report) = pipeline.process_payload(
            &alice,
            &res,
            "lane_budget",
            b"hello vault pipeline".to_vec(),
            None,
        );
        assert!(result.is_ok());
        assert!(report.passed);
    }
    assert_eq!(pipeline.ops_used(), 2);
    assert_eq!(pipeline.ops_remaining(), None);
}
