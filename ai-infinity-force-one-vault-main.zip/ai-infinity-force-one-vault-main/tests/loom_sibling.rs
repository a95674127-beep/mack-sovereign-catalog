#![cfg(loom_models)]
//! Loom concurrency models for the sibling-ring ownership state machine
//! (`src/sandbox/sibling.rs`), exercised through its real public API.
//!
//! `SiblingOwnership` is a plain struct with no internal synchronization:
//! the lane engine serializes access with a single mutex
//! (`LaneContainmentEngine.ownership`). These models reproduce that exact
//! deployment shape — the real state machine behind one mutex — and let
//! loom explore every lock-acquisition ordering of racing threads.
//!
//! Time is an explicit `now_ms` argument in the API, so lease expiry is a
//! model action, never a wall clock. Invariants checked in EVERY
//! interleaving loom generates:
//!
//! 1. Exclusivity: two rings racing for one task's lease produce exactly
//!    one winner; the loser fails closed with `OwnershipConflict`, and
//!    exactly one fencing token is ever issued for the lease.
//! 2. Fencing after takeover: once a lease has expired, the stale owner's
//!    commit is rejected in every interleaving (expired-lease conflict or
//!    stale-token rejection), while the new owner's commit is accepted.
//! 3. Idempotency cannot fork a token: concurrent replays of one logical
//!    request can never mint two distinct leases — all successful results
//!    are the identical lease, and the fencing counter advances by one.
//!
//! Run with: `RUSTFLAGS="--cfg loom_models" cargo test --test loom_sibling`
//! Without `--cfg loom_models` this file compiles to an empty test target, so the
//! normal suite (and CI) is unaffected. `authorize_commit` is a pure
//! validation in this design, so "no double commit" means: at most one
//! (owner, fencing_token) pair can ever validate for a task — models 1
//! and 3 together exclude a second valid pair existing.

use ai_infinity_force_one_vault::sandbox::sibling::{
    CapacityLease, LeaseError, RingId, SiblingOwnership,
};
use loom::sync::atomic::{AtomicUsize, Ordering};
use loom::sync::{Arc, Mutex};

fn shared_ring() -> Arc<Mutex<SiblingOwnership>> {
    Arc::new(Mutex::new(SiblingOwnership::default()))
}

/// Model 1 — exclusivity: Alpha and Beta race for the same task's lease.
#[test]
fn loom_exclusive_lease_single_winner() {
    loom::model(|| {
        let ring = shared_ring();
        let wins = Arc::new(AtomicUsize::new(0));
        let mut handles = Vec::new();
        for (ring_id, key) in [(RingId::Alpha, "idem-a"), (RingId::Beta, "idem-b")] {
            let ring = Arc::clone(&ring);
            let wins = Arc::clone(&wins);
            handles.push(loom::thread::spawn(move || {
                let mut guard = ring.lock().unwrap();
                match guard.request_lease(ring_id, "task-1", key, 1, 100, 500) {
                    Ok(lease) => {
                        wins.fetch_add(1, Ordering::SeqCst);
                        // The winner's own commit validates under the
                        // same critical section that granted the lease.
                        assert_eq!(
                            guard.authorize_commit("task-1", ring_id, lease.fencing_token, 200),
                            Ok(())
                        );
                    }
                    Err(LeaseError::OwnershipConflict { .. }) => {}
                    Err(other) => panic!("unexpected lease error: {other:?}"),
                }
            }));
        }
        for handle in handles {
            handle.join().unwrap();
        }
        assert_eq!(wins.load(Ordering::SeqCst), 1, "exactly one lease winner");
        let guard = ring.lock().unwrap();
        let stored = guard.lease("task-1").expect("a lease is stored");
        assert_eq!(
            stored.fencing_token, 1,
            "exactly one fencing token was issued"
        );
    });
}

/// Model 2 — fencing: after expiry, Alpha's stale commit must fail in
/// every interleaving against Beta's takeover, and Beta's commit passes.
#[test]
fn loom_stale_commit_rejected_after_takeover() {
    loom::model(|| {
        let ring = shared_ring();
        // Pre-phase: Alpha holds the lease; it expires at t=200.
        let stale_token = {
            let mut guard = ring.lock().unwrap();
            guard
                .request_lease(RingId::Alpha, "task-1", "idem-a", 1, 100, 100)
                .expect("initial lease")
                .fencing_token
        };
        let stale_commits = Arc::new(AtomicUsize::new(0));

        let stale_ring = Arc::clone(&ring);
        let stale_counter = Arc::clone(&stale_commits);
        let stale = loom::thread::spawn(move || {
            let guard = stale_ring.lock().unwrap();
            // At t=250 the lease is expired. Before Beta's takeover this
            // fails as an expired-lease conflict; after it, as a stale
            // fencing token. It must never succeed.
            if guard
                .authorize_commit("task-1", RingId::Alpha, stale_token, 250)
                .is_ok()
            {
                stale_counter.fetch_add(1, Ordering::SeqCst);
            }
        });

        let takeover_ring = Arc::clone(&ring);
        let takeover = loom::thread::spawn(move || {
            let mut guard = takeover_ring.lock().unwrap();
            let lease = guard
                .request_lease(RingId::Beta, "task-1", "idem-b", 1, 250, 100)
                .expect("takeover of an expired lease succeeds");
            assert!(lease.fencing_token > stale_token);
            assert_eq!(
                guard.authorize_commit("task-1", RingId::Beta, lease.fencing_token, 260),
                Ok(())
            );
            lease.fencing_token
        });

        stale.join().unwrap();
        let new_token = takeover.join().unwrap();
        assert_eq!(
            stale_commits.load(Ordering::SeqCst),
            0,
            "a stale owner must never commit"
        );
        assert_eq!(new_token, 2, "the takeover issued the second token");
        let guard = ring.lock().unwrap();
        assert_eq!(guard.lease("task-1").map(|l| l.owner), Some(RingId::Beta));
    });
}

/// Model 3 — idempotency: two replays of Alpha's identical request race
/// a conflicting request from Beta. No interleaving may mint two distinct
/// leases for the task, and the fencing counter advances exactly once.
#[test]
fn loom_idempotent_replay_cannot_fork_token() {
    loom::model(|| {
        let ring = shared_ring();
        let mut handles = Vec::new();
        for (ring_id, key) in [
            (RingId::Alpha, "idem-a"),
            (RingId::Alpha, "idem-a"),
            (RingId::Beta, "idem-b"),
        ] {
            let ring = Arc::clone(&ring);
            handles.push(loom::thread::spawn(move || {
                let mut guard = ring.lock().unwrap();
                guard.request_lease(ring_id, "task-1", key, 1, 100, 500)
            }));
        }
        let mut granted: Vec<CapacityLease> = Vec::new();
        for handle in handles {
            match handle.join().unwrap() {
                Ok(lease) => granted.push(lease),
                Err(LeaseError::OwnershipConflict { .. }) => {}
                Err(other) => panic!("unexpected lease error: {other:?}"),
            }
        }
        assert!(!granted.is_empty(), "someone must win the lease");
        let first = granted[0].clone();
        assert!(
            granted.iter().all(|lease| *lease == first),
            "every successful result is the identical lease: {granted:?}"
        );
        // The fencing counter advanced exactly once for task-1: the next
        // lease issued (for any task) carries token 2.
        let mut guard = ring.lock().unwrap();
        let next = guard
            .request_lease(RingId::Alpha, "task-2", "idem-t2", 1, 100, 500)
            .expect("a fresh task can be leased");
        assert_eq!(next.fencing_token, 2);
        assert_eq!(guard.lease("task-1"), Some(&first));
    });
}
