//! Negative and failure tests for the detection layer.

use ai_infinity_force_one_vault::detection::engine::OfflineThreatEngine;
use ai_infinity_force_one_vault::detection::entropy_scan::{
    scan_payload, shannon_entropy, EntropyVerdict,
};
use ai_infinity_force_one_vault::detection::hash_blocklist::{BlocklistVerdict, HashBlocklist};
use ai_infinity_force_one_vault::detection::triage::TriageOutcome;

#[test]
fn blocklisted_hash_is_always_blocked() {
    // A payload whose SHA-256 is on the blocklist must be Sealed,
    // regardless of any other signals.
    let bad_payload = b"known-malicious-payload-for-testing";
    let mut hasher = sha2::Sha256::new();
    use sha2::Digest;
    hasher.update(bad_payload);
    let hash = hex::encode(hasher.finalize());

    let blocklist = HashBlocklist::load_from_str(&hash);

    // Direct blocklist check
    assert!(matches!(
        blocklist.scan_payload(bad_payload),
        BlocklistVerdict::Match(_)
    ));

    // A tiny variation must NOT match (no fuzzy matching)
    let mut varied = bad_payload.to_vec();
    varied[0] ^= 0x01;
    assert!(matches!(
        blocklist.scan_payload(&varied),
        BlocklistVerdict::Clean
    ));
}

#[test]
fn empty_payload_is_rejected_fail_closed() {
    let engine = OfflineThreatEngine::new(HashBlocklist::load_from_str(""), 7.2);
    let result = engine.scan_payload(b"");
    // Empty payload must not be Clean
    assert_ne!(
        result.triage.outcome,
        TriageOutcome::Clean,
        "empty payload must fail closed"
    );
}

#[test]
fn entropy_threshold_edges() {
    // Exactly at threshold (7.2) must be Suspicious (>= is suspicious)
    // We can't craft exact-entropy bytes easily, so we test the boundary
    // logic via the threshold comparison directly.

    // High-entropy random-like data should be suspicious
    let high_entropy: Vec<u8> = (0..256).flat_map(|i| [i as u8, (i * 7) as u8]).collect();
    let verdict = scan_payload(&high_entropy);
    assert!(
        matches!(verdict, EntropyVerdict::Suspicious(_)),
        "high-entropy data should be suspicious"
    );

    // Low-entropy repeated data should be normal
    let low_entropy = vec![b'a'; 1000];
    let verdict = scan_payload(&low_entropy);
    assert!(
        matches!(verdict, EntropyVerdict::Normal(_)),
        "low-entropy data should be normal"
    );

    // Entropy is bounded [0, 8]
    for data in [&[][..], &low_entropy[..], &high_entropy[..]] {
        let e = shannon_entropy(data);
        assert!((0.0..=8.0).contains(&e), "entropy {e} out of range");
    }
}

#[test]
fn yara_invalid_rules_fail_at_construction() {
    // Invalid YARA source must fail at compile time, not silently
    // produce an engine with no rules.
    let result = OfflineThreatEngine::new(HashBlocklist::load_from_str(""), 7.2)
        .with_yara_rules("this is not valid yara {{{");
    assert!(result.is_err(), "invalid YARA rules must fail to compile");
}

#[test]
fn engine_without_yara_still_functions() {
    // Disabling YARA must not break the engine or panic.
    let engine = OfflineThreatEngine::new(HashBlocklist::load_from_str(""), 7.2).without_yara();
    let result = engine.scan_payload(b"hello world, this is a test payload");
    // Should complete without panic; outcome depends on other signals.
    let _ = result.triage.outcome;
}

#[test]
fn blocklist_error_does_not_panic() {
    // Empty payload to blocklist returns Error verdict, not panic.
    let blocklist = HashBlocklist::load_from_str("");
    let verdict = blocklist.scan_payload_checked(b"");
    assert!(matches!(verdict, BlocklistVerdict::Error(_)));
}
