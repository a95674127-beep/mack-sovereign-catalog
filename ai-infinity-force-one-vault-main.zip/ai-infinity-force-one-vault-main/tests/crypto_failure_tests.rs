//! Phase 2 — Cryptographic failure tests.
//!
//! Negative-path tests against the crate's real crypto APIs:
//! `vault::crypto::{encrypt, decrypt}` (Argon2id KDF + XChaCha20-Poly1305
//! AEAD, envelope = [version 1][salt 16][nonce 24][ciphertext+tag]) and the
//! Ed25519 provenance ledger (`ProvenanceLedger`).
//!
//! N/A note (Argon2id parameter validation): the vault crypto API takes no
//! caller-supplied KDF parameters — m/t/p are fixed in `encrypt`/`decrypt`
//! (19 MiB, 2 iterations, 1 lane), so there is no external parameter
//! surface to validate. The externally testable parameter-adjacent case is
//! covered instead: a tampered salt inside the envelope changes the derived
//! key and decryption fails (see `corrupted_salt_fails`).

use ai_infinity_force_one_vault::vault::crypto::CryptoError;
use ai_infinity_force_one_vault::{
    decrypt, encrypt, generate_authorship_keypair, AttestationAction, ProvenanceError,
    ProvenanceLedger,
};
use ed25519_dalek::{SigningKey, VerifyingKey};

const PASSPHRASE: &[u8] = b"phase2-correct-passphrase";
const PLAINTEXT: &[u8] = b"phase-2 crypto failure lab payload";
const EMPTY_SHA256: &str = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

/// (a1) Decrypt with the wrong key. In this API the AEAD key is derived
/// from the passphrase via Argon2id, so a wrong passphrase IS the wrong key.
#[test]
fn wrong_key_decryption_fails() {
    let envelope = encrypt(PLAINTEXT, PASSPHRASE).unwrap();
    let result = decrypt(&envelope, b"phase2-WRONG-passphrase");
    assert!(matches!(result, Err(CryptoError::DecryptionFailed)));
}

/// (a2) Decrypt corrupted ciphertext: flip one byte in the ciphertext body.
#[test]
fn corrupted_ciphertext_fails() {
    let mut envelope = encrypt(PLAINTEXT, PASSPHRASE).unwrap();
    let idx = 41 + 3; // inside the ciphertext region (past version+salt+nonce)
    envelope[idx] ^= 0x01;
    let result = decrypt(&envelope, PASSPHRASE);
    assert!(matches!(result, Err(CryptoError::DecryptionFailed)));
}

/// (a3) Corrupt the trailing Poly1305 tag byte.
#[test]
fn corrupted_tag_fails() {
    let mut envelope = encrypt(PLAINTEXT, PASSPHRASE).unwrap();
    let last = envelope.len() - 1;
    envelope[last] ^= 0x80;
    let result = decrypt(&envelope, PASSPHRASE);
    assert!(matches!(result, Err(CryptoError::DecryptionFailed)));
}

/// (a4) Corrupt the stored nonce: decryption must fail authentication.
#[test]
fn corrupted_nonce_fails() {
    let mut envelope = encrypt(PLAINTEXT, PASSPHRASE).unwrap();
    envelope[17] ^= 0x01; // first nonce byte (offset 1 + 16 salt)
    let result = decrypt(&envelope, PASSPHRASE);
    assert!(matches!(result, Err(CryptoError::DecryptionFailed)));
}

/// (b1) Corrupted salt: the derived key changes, decryption fails. (This is
/// also the "wrong passphrase" path seen from the envelope's side.)
#[test]
fn corrupted_salt_fails() {
    let mut envelope = encrypt(PLAINTEXT, PASSPHRASE).unwrap();
    envelope[1] ^= 0x01; // first salt byte
    let result = decrypt(&envelope, PASSPHRASE);
    assert!(matches!(result, Err(CryptoError::DecryptionFailed)));
}

/// (b2) Wrong passphrase fails to open — explicit error, no panic, no
/// partial plaintext.
#[test]
fn wrong_passphrase_fails_to_open() {
    let envelope = encrypt(PLAINTEXT, PASSPHRASE).unwrap();
    assert!(decrypt(&envelope, b"").is_err());
    assert!(decrypt(&envelope, b"phase2-correct-passphrasf").is_err());
}

/// Envelope structure rejections: truncated input and unknown version.
#[test]
fn malformed_envelopes_rejected() {
    let too_short = vec![0x01u8, 0x02, 0x03];
    assert!(matches!(
        decrypt(&too_short, PASSPHRASE),
        Err(CryptoError::InvalidEnvelope)
    ));

    let mut envelope = encrypt(PLAINTEXT, PASSPHRASE).unwrap();
    envelope[0] = 0x7f; // unknown version byte
    assert!(matches!(
        decrypt(&envelope, PASSPHRASE),
        Err(CryptoError::UnsupportedVersion)
    ));
}

/// (a5) Nonce (and salt) non-reuse: repeated encryptions of the SAME
/// plaintext under the SAME passphrase must produce distinct salts and
/// distinct nonces, hence distinct envelopes.
#[test]
fn nonce_and_salt_never_reused() {
    let mut salts = std::collections::HashSet::new();
    let mut nonces = std::collections::HashSet::new();
    let mut envelopes = std::collections::HashSet::new();
    for _ in 0..8 {
        let envelope = encrypt(PLAINTEXT, PASSPHRASE).unwrap();
        assert!(salts.insert(envelope[1..17].to_vec()), "salt reused");
        assert!(nonces.insert(envelope[17..41].to_vec()), "nonce reused");
        assert!(envelopes.insert(envelope), "identical envelope produced");
    }
}

/// Builds a two-attestation provenance ledger under a fresh keypair and
/// returns its serialized JSON plus the verifying key it is bound to.
fn build_provenance_json() -> (String, VerifyingKey) {
    let (secret, verifying_key) = generate_authorship_keypair().unwrap();
    let signing_key = SigningKey::from_bytes(&secret);
    let mut ledger = ProvenanceLedger::new(verifying_key);
    ledger
        .attest(
            "alice-author",
            "PHASE2-DOCKET",
            AttestationAction::Authorship,
            EMPTY_SHA256,
            &signing_key,
        )
        .unwrap();
    ledger
        .attest(
            "alice-author",
            "PHASE2-DOCKET",
            AttestationAction::Filing,
            EMPTY_SHA256,
            &signing_key,
        )
        .unwrap();
    assert!(ledger.verify_chain().is_ok());
    (ledger.to_json().unwrap(), verifying_key)
}

/// (c1) Ed25519: tampering with a signed attestation's content must fail
/// verification on load — `from_json` re-verifies the full chain (hashes
/// and signatures) before accepting.
#[test]
fn ed25519_tampered_attestation_fails_verification() {
    let (json, verifying_key) = build_provenance_json();
    let tampered = json.replacen("alice-author", "mallory-author", 1);
    assert_ne!(tampered, json);
    let result = ProvenanceLedger::from_json(&tampered, verifying_key);
    assert!(
        matches!(result, Err(ProvenanceError::ChainBroken(_))),
        "tampered attestation must fail chain verification"
    );
}

/// (c2) Ed25519: corrupting one hex character of a stored signature must
/// fail verification on load.
#[test]
fn ed25519_corrupted_signature_fails_verification() {
    let (json, verifying_key) = build_provenance_json();
    let marker = "\"signature\": \"";
    let start = json.find(marker).expect("signature field present") + marker.len();
    let original = json.as_bytes()[start] as char;
    let flipped = if original == 'a' { 'b' } else { 'a' };
    let mut tampered = json.clone();
    tampered.replace_range(start..start + 1, &flipped.to_string());
    let result = ProvenanceLedger::from_json(&tampered, verifying_key);
    assert!(
        result.is_err(),
        "corrupted signature must fail verification"
    );
}

/// (c3) Ed25519: a genuine ledger presented against the WRONG public key
/// must fail verification on load.
#[test]
fn ed25519_wrong_public_key_fails_verification() {
    let (json, _correct_key) = build_provenance_json();
    let (_other_secret, other_key) = generate_authorship_keypair().unwrap();
    let result = ProvenanceLedger::from_json(&json, other_key);
    assert!(
        result.is_err(),
        "verification under the wrong public key must fail"
    );
}

/// (c4) Ed25519: extending the chain with a non-bound signing key is
/// refused at attest time.
#[test]
fn ed25519_wrong_signer_cannot_extend_chain() {
    let (_secret, verifying_key) = generate_authorship_keypair().unwrap();
    let mut ledger = ProvenanceLedger::new(verifying_key);
    let (impostor_secret, _impostor_key) = generate_authorship_keypair().unwrap();
    let impostor = SigningKey::from_bytes(&impostor_secret);
    let result = ledger.attest(
        "mallory",
        "PHASE2-DOCKET",
        AttestationAction::Authorship,
        EMPTY_SHA256,
        &impostor,
    );
    assert!(matches!(result, Err(ProvenanceError::BadSignature)));
    assert!(ledger.is_empty());
}
