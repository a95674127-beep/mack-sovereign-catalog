// Cross-verification: C++ firmware signing chain -> Rust ed25519-dalek.
//
// Values below were produced by:
//   ~/workspace/sf-ites/firmware/esp32/host_test/test_sign_chain
// (C++ signing.cpp, OpenSSL Ed25519 backend on host).
//
// This test proves a signature produced by the firmware code verifies
// with the production Rust verifier (ed25519-dalek, same as ingest.rs).

#[cfg(test)]
mod cross_verify {
    use ed25519_dalek::{Signature, Verifier, VerifyingKey};
    use sha2::{Digest, Sha256};

    // Produced by C++ test_sign_chain (fixed seed, NOT a deployment key).
    const CPP_PUBKEY_HEX: &str = "e4030998cfd5ad1723c169f956aa0b9eb8619b5992bd612c2af428ebc79f8df0";
    const CPP_SIG_HEX: &str =
        "c0cfda3243b0efbbce4ed17605c2b062a0ca29977ac490fa4017196f5150b5f08f78015bfa4a9b2636bab70058591c4f0ab40c6a39e81ccfb99177d284427108";
    const CPP_JSON: &str = r#"{"schema_version":1,"device_id":"pump-01","seq":42,"timestamp_ms":1784000001234,"current_rms":7.5,"flow_rate":12.25,"temp_c":45.0,"pressure_kpa":300.0}"#;
    const CPP_DIGEST_HEX: &str = "1a42d884b5974054926155a6236ed0f2f5f22d9ca15d4cef019993ad8c98202b";

    fn hex_to_bytes(s: &str) -> Vec<u8> {
        (0..s.len())
            .step_by(2)
            .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())
            .collect()
    }

    #[test]
    fn cpp_digest_matches_rust_sha256() {
        // The digest the C++ code signed must equal SHA-256(canonical JSON)
        // as computed by the Rust side. This pins the "what is signed".
        let rust_digest = Sha256::digest(CPP_JSON.as_bytes());
        assert_eq!(
            hex::encode(rust_digest),
            CPP_DIGEST_HEX,
            "C++ digest != Rust SHA-256(canonical JSON)"
        );
    }

    #[test]
    fn cpp_signature_verifies_with_ed25519_dalek() {
        // This is the exact verification ingest.rs performs.
        let pubkey_bytes = hex_to_bytes(CPP_PUBKEY_HEX);
        let sig_bytes = hex_to_bytes(CPP_SIG_HEX);
        let digest_bytes = hex_to_bytes(CPP_DIGEST_HEX);

        let vk = VerifyingKey::from_bytes(pubkey_bytes.as_slice().try_into().unwrap())
            .expect("valid pubkey");
        let sig = Signature::from_bytes(sig_bytes.as_slice().try_into().unwrap());

        // ed25519-dalek verifies the 32 RAW digest bytes (not hex).
        vk.verify(&digest_bytes, &sig)
            .expect("C++ signature must verify with ed25519-dalek");
    }

    #[test]
    fn cpp_canonical_json_parses_as_valid_packet() {
        // The C++ canonical JSON must parse as a valid TelemetryPacket
        // (unsigned) on the Rust side.
        use ai_infinity_force_one_vault::TelemetryPacket;
        let pkt: TelemetryPacket = serde_json::from_str(CPP_JSON).expect("valid packet JSON");
        assert_eq!(pkt.device_id, "pump-01");
        assert_eq!(pkt.seq, 42);
        // Canonical bytes must be identical (idempotent serialization).
        assert_eq!(pkt.canonical_bytes(), CPP_JSON.as_bytes());
    }
}
