# External Anchoring of the Audit Ledger Head — Mechanism & Procedure

> Status: **mechanism and documentation only (prepared 2026-11-06).**
> No anchor has been created yet. Creating one requires the owner's
> Ed25519 release **private** key, which is not held on any build machine
> (custody: `attestation/SIGNING.md`). Nothing in this repository should
> be read as claiming the ledger is externally anchored until an anchor
> produced by this procedure is published and verifies.

## Why

The audit ledger is a SHA-256 hash chain: tamper-evident, not
tamper-proof. `AuditLog::verify()` detects any edit to a recorded entry,
and `AuditLog::verify_anchored(expected_head)` detects truncation — but
only against a head hash that was saved somewhere the attacker cannot
rewrite. An attacker with filesystem write access to the ledger could
rebuild a fully consistent forged chain (see `SECURITY_ARCHITECTURE.md`
§6 and `THREAT_MODEL.md` §4.1). Periodically signing the current head
hash into a place outside the machine — a git tag or release note in
this repository — closes that gap: a rebuilt chain would have to end at
the anchored head, and it cannot.

## The key

- Owner's Ed25519 release signing key. Public key:
  `attestation/allen-mack-release.pub`
- Fingerprint: `SHA256:iKgJ7s1r96fDWGlcPYObuL1cGYJNYL5e1npeF3KSZws`
- OpenSSH signature namespace: `mack-release`; signer identity in
  `attestation/allowed_signers`: `allenmack`.
- This is the same key and namespace used for the published release
  attestation in `attestation/` (`ATTESTATION.md` / `ATTESTATION.md.sig`).

## Procedure (owner, when the private key is available)

1. **Produce the head hash to anchor.** From the running system or a
   ledger export, obtain the current head hash — the hash of the newest
   entry, or the genesis hash for an empty log (`AuditLog::head_hash()`).
   Record it together with the entry count and the time:

   ```
   ledger: ai-infinity-force-one-vault
   entries: <N>
   head: <64-hex head hash>
   anchored_at: <RFC 3339 UTC time>
   ```

2. **Write the anchor statement** to a file, e.g. `anchor-YYYYMMDD.txt`,
   containing exactly those lines.

3. **Sign it** with the release key, using the same OpenSSH signing
   convention as the release attestation:

   ```
   ssh-keygen -Y sign -f <private-key-file> -n mack-release anchor-YYYYMMDD.txt
   ```

   This produces `anchor-YYYYMMDD.txt.sig`.

4. **Publish the anchor outside the machine.** Either:
   - commit `anchor-YYYYMMDD.txt` and `anchor-YYYYMMDD.txt.sig` under an
     `anchors/` directory and tag that commit
     `ledger-anchor-YYYYMMDD`, pushing both through the owner's normal
     owner-applied push path; or
   - paste the statement and the signature into a GitHub release note
     for a tag named `ledger-anchor-YYYYMMDD`.
   The anchor's value comes from being timestamped by infrastructure
   the ledger's host does not control; keep the published copy byte-for-
   byte identical to the signed file.

5. **Verify immediately after publishing** (step below) and record the
   verification output alongside the anchor.

## How a verifier checks an anchor

Given the published `anchor-YYYYMMDD.txt` and `anchor-YYYYMMDD.txt.sig`,
plus `attestation/allowed_signers` and the ledger export being audited:

```
ssh-keygen -Y verify -f attestation/allowed_signers -I allenmack \
    -n mack-release -s anchor-YYYYMMDD.txt.sig < anchor-YYYYMMDD.txt
```

Expected: `Good "mack-release" signature for allenmack ...`.

Then confirm the ledger itself ends where the anchor says it must:

- Recompute/verify the ledger chain (`AuditLog::verify()` must pass), and
- Check the head: `AuditLog::verify_anchored(<head from the anchor>)`
  must pass, and the entry count must equal the anchored `entries:` value.

If the signature verifies but the ledger's head differs from the anchor,
the ledger was truncated or rebuilt after the anchor was published —
that is exactly the forgery this mechanism exists to expose. If the
signature does not verify, the anchor itself is not the owner's.

## Cadence guidance

Anchor at every release and at any operational milestone worth being
able to prove later (before handing a ledger export to a third party,
for instance). Anchoring is cheap; an unanchored gap can never be
retroactively proven.
