# Mutation Testing — Prepared Plan (NOT RUN)

> Status: **plan only, prepared 2026-11-06. No mutation run has been
> executed and no mutation score is claimed.** `cargo-mutants` is not
> installed on the build machine, and installing it is a global tool
> install that was out of scope for the change that prepared this plan.

## Purpose

The suite's 228 passing tests show the code behaves as tested; mutation
testing checks the other direction — whether the tests would *notice*
if the code changed. `cargo-mutants` makes small deliberate changes
(mutants) to the source and re-runs the tests for each one. A mutant
that no test catches ("missed") marks behaviour the suite does not
actually guard.

## Scope: audit ledger first

Start with the tamper-evident ledger — the component whose correctness
every other claim rests on:

```
cargo mutants --file src/vault/audit.rs
```

Widen only after the ledger is clean:

```
cargo mutants --file src/vault/crypto.rs --file src/vault/keyring.rs
cargo mutants --file src/sandbox/lanes.rs
```

A whole-crate run is deliberately *not* the first step (see runtime
concerns).

## Expected runtime concerns

- `cargo-mutants` builds and tests the crate once per mutant. The full
  local suite takes ~2 minutes on this machine (7.7 GB RAM,
  `CARGO_BUILD_JOBS=2`); even a single-module mutant list can number in
  the dozens, so a scoped ledger run should be budgeted in tens of
  minutes, and a whole-crate run in hours. Run it on a machine/session
  that can be left alone, with the same environment used for CI-parity
  builds:

  ```
  export PATH="$HOME/.cargo/bin:$PATH"
  export TMPDIR=~/workspace/tmp-cargo
  export CARGO_BUILD_JOBS=2
  ```

- Run it on a clean checkout of a known commit, not on a working tree
  carrying unrelated uncommitted changes, so results attribute to the
  recorded code state.
- Expect some mutants in hash/timestamp code to be legitimately
  equivalent or timing-bound; triage each missed mutant individually
  rather than chasing a headline percentage.

## Recording results

When a run happens, record here: the exact command, the commit it ran
against, `cargo-mutants` version, total mutants / caught / missed /
timeout counts, and — for every missed mutant in the ledger — either the
test added to catch it or the reason it is equivalent. Until then, this
file is a plan, and any mutation score quoted for this project from any
other source should be treated as unverified.
