# Security Architecture — ai-infinity-force-one-vault

> Version 1.0 · September 2026 · Rust reference implementation

## 1. Executive Summary

ai-infinity-force-one-vault is a zero-trust security engine written in Rust that enforces a single, mandatory pipeline for every payload entering or leaving the vault. Each request passes through five ordered gates — sandbox containment, threat detection, zero-trust policy, Proof-of-Value (PoV) verification, and authenticated encryption — and every outcome is written to a hash-chained, tamper-evident audit ledger. No stage can be bypassed from application code; the pipeline is the only ingress.

This document is written for security reviewers, acquirers, and enterprise diligence teams. It describes the threat model, the trust boundaries, the cryptographic constructions in use, and the guarantees each stage provides, along with their known limits.

## 2. System Overview

```
                        ┌──────────────────────────────────────────┐
                        │            UnifiedPipeline               │
   request ────────────▶│  1. SandboxContainment                   │
                        │      (size/emptiness containment gate)   │
                        │  2. ThreatDetection                      │
                        │      (SHA-256 blocklist + entropy scan)  │
                        │  3. ZeroTrustPolicy                      │
                        │      (default-deny capability rules)     │
                        │  4. PoVVerification (PoV payloads only)  │
                        │      (independent re-verification)       │
                        │  5. Encryption (optional ChaCha20-Poly1305)
                        └──────────────────┬───────────────────────┘
                                           │
                                           ▼
                        ┌──────────────────────────────────────────┐
                        │  AuditLedger: SHA-256 hash chain         │
                        │  every stage outcome is appended         │
                        └──────────────────────────────────────────┘
```

Every stage returns a stage report. A request passes only if all applicable stages pass; a failure at any stage short-circuits the request and is still recorded in the audit chain, so denied attempts are as visible as successful ones.

## 3. Trust Model & Assumptions

**Trusted components:**
- The Rust runtime and its compiled dependency tree (see §8 Supply Chain).
- The local filesystem holding the audit ledger.
- The OS entropy source used for key/nonce generation.

**Untrusted by default:**
- Every payload, regardless of origin.
- Every principal, including authenticated operators.
- Every PoV claim, including claims signed by worker nodes. Claims are treated as assertions to be independently re-verified, never as facts.

**Out of scope (documented limits):**
- Physical or hypervisor-level compromise of the host.
- Denial-of-service through resource exhaustion at the network edge (rate limiting is expected to be enforced upstream).
- Side-channel attacks against the CPU (e.g., speculative execution leakage).

## 4. Threat Model

| # | Adversary capability | Control | Where enforced |
|---|----------------------|---------|----------------|
| T1 | Submit oversized or empty payloads to stress the service | Containment gate rejects size 0 and payloads over the configured byte limit | Stage 1 — SandboxContainment |
| T2 | Store known-malicious content (e.g., EICAR, blocklisted hashes) | SHA-256 hash blocklist match rejects before any storage | Stage 2 — ThreatDetection |
| T3 | Evade blocklist with novel encrypted/packed malware | Shannon entropy scan flags high-entropy blobs (> 7.2 bits/byte) | Stage 2 — ThreatDetection |
| T4 | Unauthorized principal reads or writes vault data | Default-deny capability policy; access only with an explicit grant for the exact (principal, resource, action) tuple | Stage 3 — ZeroTrustPolicy |
| T5 | Privilege escalation by an operator holding only read access | Action-level enforcement: a write through `process_payload` requires `Action::Write`; read-only grants are rejected | Stage 3 — ZeroTrustPolicy |
| T6 | Worker node forges a "verified" PoV claim to collect settlement | Independent re-verification: `hash_match` claims with identical input/output hashes are rejected regardless of the `verified` flag | Stage 4 — PoVVerification |
| T7 | Replay of a claimed-but-false PoV with mutated JSON | Strict schema parsing: malformed or missing required fields are rejected before evaluation | Stage 4 — PoVVerification |
| T8 | Ciphertext tampering (bit-flip, truncation) of stored payloads | ChaCha20-Poly1305 AEAD authentication tag; any modification fails decryption | Stage 5 — Encryption, `decrypt` |
| T9 | Offline brute-force of stolen ciphertext | Argon2id key derivation (memory-hard) from the passphrase before AEAD | Stage 5 — Encryption |
| T10 | Retroactive mutation or deletion of audit history | SHA-256 hash chain: each entry hashes sequence, timestamp, actor, action, and previous entry hash; `verify()` walks the chain | AuditLedger |
| T11 | Repudiation of a pipeline decision | Every accepted and denied request is appended to the same ledger | AuditLedger |

## 5. Stage Specifications

### 5.1 Sandbox Containment
Rejects empty payloads and payloads exceeding the configured containment limit before any downstream processing. This bounds memory consumption from a single request and provides a deterministic first-fail point.

### 5.2 Threat Detection
Two independent detectors run over the raw payload bytes:
1. **Hash blocklist** — the payload's SHA-256 is compared against `src/detection/known_bad_hashes.txt`. Matches are exact and precomputed; a large blocklist costs one hash computation plus a set lookup.
2. **Entropy scan** — Shannon entropy over the byte distribution. Dense pseudo-random content (encrypted archives, packed shellcode) scores above the 7.2 bits/byte threshold and is flagged.

Known limit: an entropy scan cannot distinguish encrypted malware from legitimately encrypted user data. Payloads entering the pipeline are plaintext by contract; ciphertext is produced only at stage 5, inside the vault.

### 5.3 Zero-Trust Policy
A capability-list policy engine with default deny. A rule binds `(Principal, Resource) → [Action]`. There is no wildcard principal, no wildcard resource, and no inheritance. `process_payload` requires `Action::Write`; any missing action produces `AccessDenied`.

### 5.4 Proof-of-Value Verification
PoV payloads are JSON documents describing a unit of work a worker node claims to have completed. The engine never trusts the `verified` boolean:
- The document must parse against the required schema (`pov_version`, `task_id`, `operator_id`, timestamps, `input_hash`, `output_hash`, `verification_method`).
- Under `hash_match`, the engine independently compares `input_hash` and `output_hash`; identical hashes mean no work occurred and the claim is rejected, even when the claim says `verified: true`.
- Unsupported verification methods are rejected rather than skipped (fail-closed).

### 5.5 Encryption
- **Cipher:** ChaCha20-Poly1305 (AEAD, RFC 8439) with a random 96-bit nonce per message.
- **Key derivation:** Argon2id (memory-hard, sidesteps GPU/ASIC speedups) over the user passphrase.
- **Integrity:** The Poly1305 tag authenticates ciphertext, associated data, and nonce; tampering of any byte fails decryption.
- **Envelopes:** the decryption path rejects short envelopes before tag verification, so truncated inputs fail fast rather than panicking.

## 6. Audit Ledger

`AuditLog` is an append-only, hash-chained sequence:
```
entry_hash[i] = SHA256( seq[i] ‖ ts[i] ‖ actor ‖ action ‖ entry_hash[i-1] )
```
`entry_hash[0]` chains to a fixed genesis hash. `verify()` recomputes every hash and checks both linkage and content; the first mismatch is returned as the breaking index. Because the hash covers the full record, edits to any historical field (actor, action, timestamp, or sequence) break the chain. The pipeline appends one entry per stage outcome, including denials, so an attacker who suppresses a denied transaction cannot do so without leaving a gap that `verify()` detects.

Known limit: the ledger is tamper-evident, not tamper-proof. An attacker with filesystem write access can truncate the entire file and rebuild a consistent chain from a forged history. Deployments that require stronger guarantees should periodically anchor the head hash to external infrastructure (e.g., a transparency log or write-once storage).

## 7. Testing & Assurance

The test suite is organized to mirror the threat model:
- `tests/pipeline_stages.rs` — one test per stage gate, including PoV spoof detection and the full happy path with round-trip decryption.
- `tests/adversarial_tests.rs` — attacker-driven cases: ciphertext bit-flipping, ciphertext truncation, audit-chain retroactive mutation, privilege escalation by a read-only operator, forged PoV claims (malformed schema and fake verification), and entropy-threshold evasion.
- Unit tests in each module cover boundary conditions (empty log, oversized payload, unsupported PoV method, wrong passphrase).

Run with:
```
cargo test
```

## 8. Supply Chain & Dependencies

Cryptographic primitives come from the RustCrypto ecosystem: `chacha20poly1305`, `argon2`, `sha2`, and `ed25519-dalek`. These are the de facto standard pure-Rust implementations, `#![no_std]` compatible, and continuously audited by the community. Dependency updates should be reviewed through `cargo audit` / `cargo deny` in CI (`.github/workflows/rust.yml`).

## 9. Deployment Notes

- Run the showcase to demonstrate every stage end to end: `cargo run --example security_showcase`.
- The YARA rule path (`src/detection/rules/eicar_test.yar`) is an optional secondary detector for deployments that can build native YARA; the pipeline does not require it.
- `frontend/ExportCenter.tsx` is the browser-side companion that verifies export archives client-side (SHA-256 via WebCrypto) before download; it is presentation-layer only and never grants trust.
