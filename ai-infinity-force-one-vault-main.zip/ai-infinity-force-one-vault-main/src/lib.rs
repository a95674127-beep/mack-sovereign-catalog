//! ai_infinity_force_one_vault — crate root.
//!
//! Wires together the MACK stack zero-trust vault engine, multi-stage
//! threat pipeline, proof-of-verification layer, tamper-evident audit ledger,
//! and military-grade offline D-DIL detection and triage suite.

pub mod api;
pub mod detection;
pub mod ingest;
pub mod pipeline;
pub mod pov;
pub mod redact;
pub mod sandbox;
pub mod telemetry;
pub mod vault;

pub use pipeline::{
    PipelineError, PipelineExecutionReport, PipelineStage, StageVerdict, UnifiedPipeline,
};
pub use vault::audit::{
    AuditEntry, AuditLog, ConcurrentLedger, SegmentVerificationReport, GENESIS_EVT_1041,
};
pub use vault::checkpoint::{CheckpointError, CheckpointRecord, CheckpointSigner};
pub use vault::crypto::{decrypt, encrypt, CryptoError};
pub use vault::persistent::{LedgerError, PersistentLedger};
pub use vault::policy::{
    AccessPolicy, Action, Decision, Effect, OperationBudget, Principal, Resource, Rule,
};
pub use vault::Vault;

pub use vault::crypto::rotate_key;
pub use vault::keyring::{KeyError, KeyRing, SecretKey};

pub use vault::provenance::{
    generate_authorship_keypair, Attestation, AttestationAction, ProvenanceError, ProvenanceLedger,
};

pub use telemetry::{
    IngestError, LedgerAnchor, PacketError, RejectionRecord, TelemetryIngestor, TelemetryPacket,
    DEFAULT_MAX_SEQ_GAP, PACKET_SCHEMA_VERSION,
};

pub use sandbox::{
    CapacityLease, ContainmentDecision, ContainmentPipeline, DdilDetonationCoordinator,
    DetonationResult, IsolationError, IsolationLevel, LaneContainmentEngine, LaneExecutionError,
    LaneId, LaneStatus, LeaseError, LeaseRequest, LeasedExecutionError, PipelineResult,
    ProcessLaneBackend, RingHealth, RingId, SandboxError, SandboxResult, SandboxRunner,
    SealedEvent, SealedEventLog, SealedLogError, SiblingOwnership, SEALED_GENESIS_HASH,
};

pub use pov::{DePinStressEngine, NodeStats, ProofOfVerification, StressTestReport};

pub use detection::{
    scan_payload, scan_result_to_stix_bundle, shannon_entropy, BlocklistVerdict, C2Detector,
    C2Indicator, ComprehensiveScanResult, DocThreatIndicator, EntropyVerdict, ExecutableIndicator,
    ExecutableInspector, HashBlocklist, MaliciousDocScanner, OfflineThreatEngine, PhishingDetector,
    PhishingIndicator, TriageAssessment, TriageOutcome, YaraError, YaraMatch, YaraScanner,
};

pub use vault::forensics::{ForensicIncidentRecord, ForensicLedger};
