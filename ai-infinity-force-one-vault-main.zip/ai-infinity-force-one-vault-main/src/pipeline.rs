//! pipeline — Unified MACK Stack Security Pipeline.
//!
//! Orchestrates the multi-stage zero-trust execution lifecycle:
//! 1. Sandbox Containment (size limits & quarantine)
//! 2. Threat Detection (Shannon entropy analysis & hash blocklist)
//! 3. Zero-Trust Access Control (RBAC/ABAC default-deny policy)
//! 4. Proof of Verification (PoV cryptographic re-derivation)
//! 5. Cryptographic Storage & Tamper-Evident Chained Audit Logging
//!
//! **Scope note (2026-10-08):** This is the showcase/demo pipeline used by
//! `main.rs` and the examples. It performs its own threat gating (hash
//! blocklist + entropy scan) before proceeding past Stage 2, but it is NOT
//! wired through `sandbox::pipeline::ContainmentPipeline`: the two are
//! separate architectures (this one is policy/PoV-centric; the containment
//! pipeline is detection→isolation-escalation-centric). Production network
//! ingress goes through `POST /api/v1/ingest/submit`, which *is* gated by
//! the `ContainmentPipeline`. Unifying the two pipelines is future work,
//! not a silent assumption — do not treat this module as covered by the
//! containment-pipeline guarantees.

use crate::detection::entropy_scan::{self, EntropyVerdict};
use crate::detection::hash_blocklist::{BlocklistVerdict, HashBlocklist};
use crate::ingest::IngestRecord;
use crate::pov::ProofOfVerification;
use crate::sandbox::isolation::{SandboxError, SandboxRunner};
use crate::vault::audit::AuditLog;
use crate::vault::crypto;
use crate::vault::policy::{
    AccessPolicy, Action, Decision, OperationBudget, Principal, Resource, Rule,
};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum PipelineStage {
    SandboxContainment,
    ThreatDetection,
    ZeroTrustPolicy,
    ProofOfVerification,
    CryptographicLedger,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct StageVerdict {
    pub stage: PipelineStage,
    pub passed: bool,
    pub details: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PipelineExecutionReport {
    pub record_id: String,
    pub passed: bool,
    pub stages: Vec<StageVerdict>,
    pub audit_chain_length: usize,
    pub audit_chain_intact: bool,
}

#[derive(Debug)]
pub enum PipelineError {
    Sandbox(SandboxError),
    ThreatDetected(String),
    AccessDenied(String),
    BudgetExhausted(String),
    PoVVerificationFailed(String),
    Crypto(crypto::CryptoError),
}

/// Unified security engine integrating all Force One Vault subsystems.
pub struct UnifiedPipeline {
    sandbox: SandboxRunner,
    blocklist: HashBlocklist,
    policy: AccessPolicy,
    audit: AuditLog,
    budget: OperationBudget,
}

impl Default for UnifiedPipeline {
    fn default() -> Self {
        Self::new()
    }
}

impl UnifiedPipeline {
    pub fn new() -> Self {
        const KNOWN_BAD_HASHES: &str = include_str!("detection/known_bad_hashes.txt");
        Self {
            sandbox: SandboxRunner::default(),
            blocklist: HashBlocklist::load_from_str(KNOWN_BAD_HASHES),
            policy: AccessPolicy::new(),
            audit: AuditLog::new(),
            budget: OperationBudget::unlimited(),
        }
    }

    pub fn with_containment_limit(max_bytes: usize) -> Self {
        const KNOWN_BAD_HASHES: &str = include_str!("detection/known_bad_hashes.txt");
        Self {
            sandbox: SandboxRunner::new(max_bytes),
            blocklist: HashBlocklist::load_from_str(KNOWN_BAD_HASHES),
            policy: AccessPolicy::new(),
            audit: AuditLog::new(),
            budget: OperationBudget::unlimited(),
        }
    }

    /// Grant authorization rule to the zero-trust policy engine.
    pub fn grant(&mut self, rule: Rule) {
        self.policy.grant(rule);
    }

    /// Sets the operation budget shared by both pipeline entry
    /// points: at most this many policy-allowed runs will be
    /// performed before the pipeline starts refusing work with
    /// [`PipelineError::BudgetExhausted`]. `None` (the default) is
    /// unlimited, preserving pre-harvest behavior. Pattern harvested
    /// from Stealth Core's gate (2026-11-10, harvest audit row 5).
    pub fn set_ops_budget(&mut self, budget: Option<usize>) {
        self.budget.set(budget);
    }

    /// Allowed pipeline runs consumed against the budget so far.
    pub fn ops_used(&self) -> usize {
        self.budget.used()
    }

    /// Allowed pipeline runs remaining; `None` when unlimited.
    pub fn ops_remaining(&self) -> Option<usize> {
        self.budget.remaining()
    }

    /// Access the audit log for inspection or verification.
    pub fn audit(&self) -> &AuditLog {
        &self.audit
    }

    /// Verify the cryptographic integrity of the audit ledger.
    pub fn verify_audit(&self) -> Result<(), usize> {
        self.audit.verify()
    }

    /// Number of chained entries in the audit ledger.
    pub fn audit_len(&self) -> usize {
        self.audit.len()
    }

    /// Ingest and process an untrusted raw payload through all security stages.
    pub fn process_payload(
        &mut self,
        principal: &Principal,
        resource: &Resource,
        lane: &str,
        raw_payload: Vec<u8>,
        encrypt_passphrase: Option<&[u8]>,
    ) -> (Result<Vec<u8>, PipelineError>, PipelineExecutionReport) {
        let record_id = format!("{}:{}", lane, raw_payload.len());
        let mut stages = Vec::new();

        // -------------------------------------------------------------
        // Stage 1: Sandbox Containment
        // -------------------------------------------------------------
        let ingest_record = IngestRecord::new(lane, raw_payload.clone());
        let sandboxed_record = match self.sandbox.execute(ingest_record) {
            Ok(rec) => {
                stages.push(StageVerdict {
                    stage: PipelineStage::SandboxContainment,
                    passed: true,
                    details: format!("Contained {} bytes within bounds", rec.payload.len()),
                });
                rec
            }
            Err(e) => {
                let err_msg = format!("Sandbox containment violation: {:?}", e);
                stages.push(StageVerdict {
                    stage: PipelineStage::SandboxContainment,
                    passed: false,
                    details: err_msg.clone(),
                });
                self.audit
                    .append(&principal.0, &format!("sandbox.reject:{}", err_msg));
                let report = PipelineExecutionReport {
                    record_id,
                    passed: false,
                    stages,
                    audit_chain_length: self.audit.len(),
                    audit_chain_intact: self.audit.verify().is_ok(),
                };
                return (Err(PipelineError::Sandbox(e)), report);
            }
        };

        // -------------------------------------------------------------
        // Stage 2: Threat Detection (Blocklist & Shannon Entropy)
        // -------------------------------------------------------------
        match self.blocklist.scan_payload(&sandboxed_record.payload) {
            BlocklistVerdict::Match(hash) => {
                let err_msg = format!("Payload matched known-bad threat hash: {}", hash);
                stages.push(StageVerdict {
                    stage: PipelineStage::ThreatDetection,
                    passed: false,
                    details: err_msg.clone(),
                });
                self.audit
                    .append(&principal.0, &format!("detection.blocked_hash:{}", hash));
                let report = PipelineExecutionReport {
                    record_id,
                    passed: false,
                    stages,
                    audit_chain_length: self.audit.len(),
                    audit_chain_intact: self.audit.verify().is_ok(),
                };
                return (Err(PipelineError::ThreatDetected(err_msg)), report);
            }
            BlocklistVerdict::Error(e) => {
                let err_msg = format!("Threat scan internal error: {}", e);
                stages.push(StageVerdict {
                    stage: PipelineStage::ThreatDetection,
                    passed: false,
                    details: err_msg.clone(),
                });
                self.audit
                    .append(&principal.0, &format!("detection.error:{}", e));
                let report = PipelineExecutionReport {
                    record_id,
                    passed: false,
                    stages,
                    audit_chain_length: self.audit.len(),
                    audit_chain_intact: self.audit.verify().is_ok(),
                };
                return (Err(PipelineError::ThreatDetected(err_msg)), report);
            }
            BlocklistVerdict::Clean => {}
        }

        if let EntropyVerdict::Suspicious(score) =
            entropy_scan::scan_payload(&sandboxed_record.payload)
        {
            let err_msg = format!(
                "Suspicious high entropy detected: {:.3} (threshold 7.2)",
                score
            );
            stages.push(StageVerdict {
                stage: PipelineStage::ThreatDetection,
                passed: false,
                details: err_msg.clone(),
            });
            self.audit.append(
                &principal.0,
                &format!("detection.blocked_entropy:{:.2}", score),
            );
            let report = PipelineExecutionReport {
                record_id,
                passed: false,
                stages,
                audit_chain_length: self.audit.len(),
                audit_chain_intact: self.audit.verify().is_ok(),
            };
            return (Err(PipelineError::ThreatDetected(err_msg)), report);
        }

        stages.push(StageVerdict {
            stage: PipelineStage::ThreatDetection,
            passed: true,
            details: "Passed blocklist scan and entropy analysis".into(),
        });

        // -------------------------------------------------------------
        // Stage 3: Zero-Trust Access Policy Enforcement
        // -------------------------------------------------------------
        // Operation budget gate (harvested 2026-11-10, audit row 5):
        // evaluated with the policy stage, before the policy decision,
        // so an exhausted budget refuses the run even for granted
        // principals — and the refusal is audited.
        if self.budget.is_exhausted() {
            let err_msg = format!(
                "Operation budget exhausted; refusing Write on '{}'",
                resource.0
            );
            stages.push(StageVerdict {
                stage: PipelineStage::ZeroTrustPolicy,
                passed: false,
                details: err_msg.clone(),
            });
            self.audit.append(
                &principal.0,
                &format!("policy.budget_exceeded:{}", resource.0),
            );
            let report = PipelineExecutionReport {
                record_id,
                passed: false,
                stages,
                audit_chain_length: self.audit.len(),
                audit_chain_intact: self.audit.verify().is_ok(),
            };
            return (Err(PipelineError::BudgetExhausted(err_msg)), report);
        }

        let decision = self.policy.evaluate(principal, resource, Action::Write);
        if decision == Decision::Deny {
            let err_msg = format!(
                "Principal '{}' unauthorized for Write on '{}'",
                principal.0, resource.0
            );
            stages.push(StageVerdict {
                stage: PipelineStage::ZeroTrustPolicy,
                passed: false,
                details: err_msg.clone(),
            });
            self.audit
                .append(&principal.0, &format!("policy.denied:{}", resource.0));
            let report = PipelineExecutionReport {
                record_id,
                passed: false,
                stages,
                audit_chain_length: self.audit.len(),
                audit_chain_intact: self.audit.verify().is_ok(),
            };
            return (Err(PipelineError::AccessDenied(err_msg)), report);
        }

        stages.push(StageVerdict {
            stage: PipelineStage::ZeroTrustPolicy,
            passed: true,
            details: format!("Access granted for '{}' on '{}'", principal.0, resource.0),
        });
        self.budget.record_allowed();

        // -------------------------------------------------------------
        // Stage 4 & 5: Cryptographic Transformation & Ledger Audit
        // -------------------------------------------------------------
        let output_data = if let Some(passphrase) = encrypt_passphrase {
            match crypto::encrypt(&sandboxed_record.payload, passphrase) {
                Ok(envelope) => {
                    self.audit.append(
                        &principal.0,
                        &format!(
                            "pipeline.store_encrypted:{}:{}b",
                            resource.0,
                            envelope.len()
                        ),
                    );
                    envelope
                }
                Err(e) => {
                    self.audit
                        .append(&principal.0, &format!("crypto.failed:{}", resource.0));
                    let report = PipelineExecutionReport {
                        record_id,
                        passed: false,
                        stages,
                        audit_chain_length: self.audit.len(),
                        audit_chain_intact: self.audit.verify().is_ok(),
                    };
                    return (Err(PipelineError::Crypto(e)), report);
                }
            }
        } else {
            self.audit.append(
                &principal.0,
                &format!(
                    "pipeline.store_raw:{}:{}b",
                    resource.0,
                    sandboxed_record.payload.len()
                ),
            );
            sandboxed_record.payload
        };

        stages.push(StageVerdict {
            stage: PipelineStage::CryptographicLedger,
            passed: true,
            details: format!(
                "Committed to tamper-evident audit ledger (depth {})",
                self.audit.len()
            ),
        });

        let report = PipelineExecutionReport {
            record_id,
            passed: true,
            stages,
            audit_chain_length: self.audit.len(),
            audit_chain_intact: self.audit.verify().is_ok(),
        };

        (Ok(output_data), report)
    }

    /// Process a decentralized Proof of Verification (PoV) submission through the pipeline.
    pub fn process_pov(
        &mut self,
        principal: &Principal,
        resource: &Resource,
        lane: &str,
        raw_json: &str,
    ) -> (Result<bool, PipelineError>, PipelineExecutionReport) {
        let payload_bytes = raw_json.as_bytes().to_vec();
        let record_id = format!("pov:{}", lane);
        let mut stages = Vec::new();

        // Stage 1: Sandbox
        let ingest_record = IngestRecord::new(lane, payload_bytes.clone());
        if let Err(e) = self.sandbox.execute(ingest_record) {
            stages.push(StageVerdict {
                stage: PipelineStage::SandboxContainment,
                passed: false,
                details: format!("PoV JSON rejected by containment: {:?}", e),
            });
            self.audit.append(&principal.0, "pov.sandbox_reject");
            let report = PipelineExecutionReport {
                record_id,
                passed: false,
                stages,
                audit_chain_length: self.audit.len(),
                audit_chain_intact: self.audit.verify().is_ok(),
            };
            return (Err(PipelineError::Sandbox(e)), report);
        }
        stages.push(StageVerdict {
            stage: PipelineStage::SandboxContainment,
            passed: true,
            details: "PoV JSON containment validated".into(),
        });

        // Stage 2: Policy — with the operation budget gate
        // (harvested 2026-11-10, audit row 5) checked first.
        if self.budget.is_exhausted() {
            let err_msg = format!(
                "Operation budget exhausted; refusing PoV submission on '{}'",
                resource.0
            );
            stages.push(StageVerdict {
                stage: PipelineStage::ZeroTrustPolicy,
                passed: false,
                details: err_msg.clone(),
            });
            self.audit.append(&principal.0, "pov.budget_exceeded");
            let report = PipelineExecutionReport {
                record_id,
                passed: false,
                stages,
                audit_chain_length: self.audit.len(),
                audit_chain_intact: self.audit.verify().is_ok(),
            };
            return (Err(PipelineError::BudgetExhausted(err_msg)), report);
        }

        let decision = self.policy.evaluate(principal, resource, Action::Write);
        if decision == Decision::Deny {
            let err_msg = format!(
                "Principal '{}' denied write on PoV resource '{}'",
                principal.0, resource.0
            );
            stages.push(StageVerdict {
                stage: PipelineStage::ZeroTrustPolicy,
                passed: false,
                details: err_msg.clone(),
            });
            self.audit.append(&principal.0, "pov.policy_denied");
            let report = PipelineExecutionReport {
                record_id,
                passed: false,
                stages,
                audit_chain_length: self.audit.len(),
                audit_chain_intact: self.audit.verify().is_ok(),
            };
            return (Err(PipelineError::AccessDenied(err_msg)), report);
        }
        stages.push(StageVerdict {
            stage: PipelineStage::ZeroTrustPolicy,
            passed: true,
            details: "PoV submission authorized by policy".into(),
        });
        self.budget.record_allowed();

        // Stage 3: Deserialize & PoV Independent Verification
        let pov: ProofOfVerification = match serde_json::from_str(raw_json) {
            Ok(p) => p,
            Err(e) => {
                let err_msg = format!("PoV JSON parsing failure: {}", e);
                stages.push(StageVerdict {
                    stage: PipelineStage::ProofOfVerification,
                    passed: false,
                    details: err_msg.clone(),
                });
                self.audit
                    .append(&principal.0, &format!("pov.parse_error:{}", e));
                let report = PipelineExecutionReport {
                    record_id,
                    passed: false,
                    stages,
                    audit_chain_length: self.audit.len(),
                    audit_chain_intact: self.audit.verify().is_ok(),
                };
                return (Err(PipelineError::PoVVerificationFailed(err_msg)), report);
            }
        };

        let verified = pov.independently_verify();
        let mut logged_pov = pov.clone();
        logged_pov.verified = verified;

        stages.push(StageVerdict {
            stage: PipelineStage::ProofOfVerification,
            passed: verified,
            details: if verified {
                format!(
                    "PoV task '{}' independently verified (hash match)",
                    pov.task_id
                )
            } else {
                format!(
                    "PoV task '{}' verification failed (spoofed or mismatched proof)",
                    pov.task_id
                )
            },
        });

        // Stage 4: Chained Audit
        self.audit.append(&principal.0, &logged_pov.to_log_entry());
        stages.push(StageVerdict {
            stage: PipelineStage::CryptographicLedger,
            passed: true,
            details: format!(
                "PoV outcome logged to tamper-evident ledger (depth {})",
                self.audit.len()
            ),
        });

        let report = PipelineExecutionReport {
            record_id,
            passed: verified,
            stages,
            audit_chain_length: self.audit.len(),
            audit_chain_intact: self.audit.verify().is_ok(),
        };

        (Ok(verified), report)
    }
}
