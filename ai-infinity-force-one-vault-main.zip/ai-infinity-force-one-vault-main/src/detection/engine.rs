//! Offline Unified Threat Detection Engine for Military / D-DIL Operations.
//!
//! Synthesizes hash blocklists, Shannon entropy analysis, malicious document hooks,
//! phishing lures, C2 beaconing signatures, and binary/shellcode inspection into a
//! deterministic 3-outcome fail-closed verdict (Clean / Quarantine / Sealed).

use super::c2_callbacks::{C2Detector, C2Indicator};
use super::entropy_scan::{scan_payload, EntropyVerdict};
use super::hash_blocklist::{BlocklistVerdict, HashBlocklist};
use super::malicious_doc::{DocThreatIndicator, MaliciousDocScanner};
use super::pe_shellcode::{ExecutableIndicator, ExecutableInspector};
use super::phishing::{PhishingDetector, PhishingIndicator};
use super::triage::{TriageAssessment, TriageOutcome};
use super::yara::{YaraError, YaraMatch, YaraScanner};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ComprehensiveScanResult {
    pub payload_size: usize,
    pub entropy: f64,
    pub triage: TriageAssessment,
    pub blocklist_match: Option<String>,
    pub doc_indicators: Vec<DocThreatIndicator>,
    pub phishing_indicators: Vec<PhishingIndicator>,
    pub c2_indicators: Vec<C2Indicator>,
    pub executable_indicators: Vec<ExecutableIndicator>,
    pub yara_matches: Vec<YaraMatch>,
}

pub struct OfflineThreatEngine {
    blocklist: HashBlocklist,
    entropy_threshold: f64,
    yara: Option<YaraScanner>,
}

impl Default for OfflineThreatEngine {
    fn default() -> Self {
        const DEFAULT_BLOCKLIST: &str = include_str!("known_bad_hashes.txt");
        Self {
            blocklist: HashBlocklist::load_from_str(DEFAULT_BLOCKLIST),
            entropy_threshold: 7.2,
            // The bundled ruleset is tested to compile (see yara::tests);
            // a failure here is a programming error, surfaced loudly.
            yara: Some(YaraScanner::with_default_rules().expect("bundled YARA rules must compile")),
        }
    }
}

impl OfflineThreatEngine {
    pub fn new(blocklist: HashBlocklist, entropy_threshold: f64) -> Self {
        Self {
            blocklist,
            entropy_threshold,
            yara: Some(YaraScanner::with_default_rules().expect("bundled YARA rules must compile")),
        }
    }

    /// Replaces the YARA ruleset with custom source. Fails loudly on bad
    /// rules instead of silently scanning with nothing.
    pub fn with_yara_rules(mut self, source: &str) -> Result<Self, YaraError> {
        self.yara = Some(YaraScanner::compile(source)?);
        Ok(self)
    }

    /// Disables YARA matching entirely. The engine still runs every other
    /// heuristic; `yara_matches` will always be empty.
    pub fn without_yara(mut self) -> Self {
        self.yara = None;
        self
    }

    /// Evaluates a raw payload completely offline and returns a fail-closed triage assessment.
    pub fn scan_payload(&self, data: &[u8]) -> ComprehensiveScanResult {
        let payload_size = data.len();
        if payload_size == 0 {
            return ComprehensiveScanResult {
                payload_size: 0,
                entropy: 0.0,
                triage: TriageAssessment::fail_closed(
                    "Empty payload rejected under fail-closed policy",
                ),
                blocklist_match: None,
                doc_indicators: Vec::new(),
                phishing_indicators: Vec::new(),
                c2_indicators: Vec::new(),
                executable_indicators: Vec::new(),
                yara_matches: Vec::new(),
            };
        }

        let mut reasons = Vec::new();
        let mut total_score: u32 = 0;

        // 1. Hash blocklist match
        let blocklist_match = match self.blocklist.scan_payload(data) {
            BlocklistVerdict::Match(hash) => {
                reasons.push(format!("Known malicious hash match: {}", hash));
                total_score += 100;
                Some(hash)
            }
            _ => None,
        };

        // 2. Shannon entropy analysis
        let entropy_verdict = scan_payload(data);
        let entropy = match entropy_verdict {
            EntropyVerdict::Suspicious(score) => {
                reasons.push(format!(
                    "Elevated Shannon entropy: {:.2} (threshold: {:.2})",
                    score, self.entropy_threshold
                ));
                total_score += 35;
                score
            }
            EntropyVerdict::Normal(score) => score,
        };

        // 3. Malicious document inspection
        let doc_indicators = MaliciousDocScanner::scan(data);
        for ind in &doc_indicators {
            reasons.push(format!(
                "{}: {} ({})",
                ind.category, ind.pattern, ind.description
            ));
            total_score += ind.severity;
        }

        // 4. Phishing detection
        let text_sample = String::from_utf8_lossy(data);
        let phishing_indicators = PhishingDetector::scan(&text_sample);
        for ind in &phishing_indicators {
            reasons.push(format!(
                "Phishing indicator: {} - {}",
                ind.pattern_type, ind.description
            ));
            total_score += ind.severity;
        }

        // 5. C2 callbacks & reverse shell signatures
        let c2_indicators = C2Detector::scan(data);
        for ind in &c2_indicators {
            reasons.push(format!("C2 artifact detected: {}", ind.description));
            total_score += ind.severity;
        }

        // 6. Executable and shellcode inspection
        let executable_indicators = ExecutableInspector::inspect(data);
        for ind in &executable_indicators {
            reasons.push(format!(
                "Binary pattern: {} - {}",
                ind.classification, ind.description
            ));
            total_score += ind.severity;
        }

        // 7. YARA rule matching (pure-Rust yara-x; no libyara needed).
        // Fail-closed: a scan error means we cannot trust a "clean" result,
        // so the payload is treated as suspicious. The error is recorded
        // and contributes to the threat score.
        let yara_matches: Vec<YaraMatch> = match &self.yara {
            Some(scanner) => match scanner.scan(data) {
                Ok(m) => m,
                Err(e) => {
                    reasons.push(format!("YARA scan error (fail-closed): {e}"));
                    total_score += 60; // force Sealed outcome
                    Vec::new()
                }
            },
            None => Vec::new(),
        };
        for m in &yara_matches {
            reasons.push(format!(
                "YARA rule '{}' matched: {} (score {})",
                m.rule, m.description, m.score
            ));
            total_score += m.score;
        }

        // Clamp threat score to 100
        let threat_score = total_score.min(100);

        // Fail-closed 3-outcome classification:
        // Clean: score == 0 and no indicators
        // Quarantine: 1 <= score < 60
        // Sealed: score >= 60, or any C2 indicator, or blocklist match,
        //         or any high-confidence YARA match (score >= 60)
        let high_confidence_yara = yara_matches.iter().any(|m| m.score >= 60);
        let outcome = if blocklist_match.is_some()
            || !c2_indicators.is_empty()
            || high_confidence_yara
            || threat_score >= 60
        {
            TriageOutcome::Sealed
        } else if threat_score > 0 {
            TriageOutcome::Quarantine
        } else {
            TriageOutcome::Clean
        };

        let requires_jag_s2_escalation = outcome == TriageOutcome::Sealed;
        let quarantine_lane_recommended = match outcome {
            TriageOutcome::Clean => None,
            TriageOutcome::Quarantine => Some("MACK-06".to_string()), // Default comms triage lane
            TriageOutcome::Sealed => Some("MACK-12".to_string()),     // Failsafe sealed lane
        };

        ComprehensiveScanResult {
            payload_size,
            entropy,
            triage: TriageAssessment {
                outcome,
                threat_score,
                reasons,
                quarantine_lane_recommended,
                requires_jag_s2_escalation,
            },
            blocklist_match,
            doc_indicators,
            phishing_indicators,
            c2_indicators,
            executable_indicators,
            yara_matches,
        }
    }
}
