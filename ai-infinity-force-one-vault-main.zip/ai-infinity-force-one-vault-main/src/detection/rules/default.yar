/*
 * default.yar — STARTER YARA ruleset for ai-infinity-force-one-vault.
 *
 * These are a handful of well-understood heuristic rules, not a maintained
 * threat-intelligence feed. They will produce false positives on legitimate
 * admin tooling (Sysinternals, installers, scripts). For production use,
 * replace or extend this file with a curated ruleset and treat every match
 * as a triage signal, never as a conviction.
 *
 * Rule metadata contract used by detection::yara:
 *   description = human-readable summary (string)
 *   score       = 0..100 contribution to the threat score (integer)
 */

rule pe_with_powershell_download
{
    meta:
        description = "PE binary containing PowerShell download/execution keywords"
        score = 55
    strings:
        $mz = "MZ"
        $ps1 = "powershell" nocase
        $dl1 = "DownloadString" nocase
        $dl2 = "Invoke-Expression" nocase
        $dl3 = "IEX(" nocase
    condition:
        $mz at 0 and $ps1 and 1 of ($dl*)
}

rule possible_process_injection
{
    meta:
        description = "Binary referencing process-injection APIs"
        score = 60
    strings:
        $mz = "MZ"
        $api1 = "CreateRemoteThread" nocase
        $api2 = "VirtualAllocEx" nocase
        $api3 = "WriteProcessMemory" nocase
        $api4 = "NtMapViewOfSection" nocase
    condition:
        $mz at 0 and 2 of ($api*)
}

rule credential_access_keywords
{
    meta:
        description = "Payload containing credential-dumping tool keywords"
        score = 50
    strings:
        $k1 = "sekurlsa" nocase
        $k2 = "mimikatz" nocase
        $k3 = "lsass" nocase
        $k4 = "procdump" nocase
        $k5 = "ntds.dit" nocase
    condition:
        2 of ($k*)
}

rule suspicious_script_obfuscation
{
    meta:
        description = "Script using base64 decoding plus dynamic invocation"
        score = 45
    strings:
        $b64_1 = "FromBase64String" nocase
        $b64_2 = "base64 -d" nocase
        $b64_3 = "certutil -decode" nocase
        $inv_1 = "Invoke-Expression" nocase
        $inv_2 = "eval(" nocase
        $inv_3 = "Execute(" nocase
    condition:
        1 of ($b64*) and 1 of ($inv*)
}
