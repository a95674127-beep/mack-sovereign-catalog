use sha2::{Digest, Sha256};
use std::collections::HashSet;
use std::fs;

pub enum BlocklistVerdict {
    Match(String),
    Clean,
    Error(String),
}

pub struct HashBlocklist {
    known_bad: HashSet<String>,
}

impl HashBlocklist {
    pub fn load(path: &str) -> std::io::Result<Self> {
        let content = fs::read_to_string(path)?;
        Ok(Self::load_from_str(&content))
    }

    pub fn load_from_str(content: &str) -> Self {
        let known_bad = content
            .lines()
            .map(|l| l.trim().to_lowercase())
            .filter(|l| !l.is_empty() && !l.starts_with('#'))
            .collect();
        Self { known_bad }
    }

    pub fn scan_payload(&self, data: &[u8]) -> BlocklistVerdict {
        let mut hasher = Sha256::new();
        hasher.update(data);
        let hash = hex::encode(hasher.finalize());

        if self.known_bad.contains(&hash) {
            BlocklistVerdict::Match(hash)
        } else {
            BlocklistVerdict::Clean
        }
    }

    pub fn scan_payload_checked(&self, data: &[u8]) -> BlocklistVerdict {
        if data.is_empty() {
            return BlocklistVerdict::Error("empty payload".to_string());
        }
        self.scan_payload(data)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detects_known_hash() {
        let mut set = HashSet::new();
        let mut hasher = Sha256::new();
        hasher.update(b"malicious payload");
        let hash = hex::encode(hasher.finalize());
        set.insert(hash.clone());

        let bl = HashBlocklist { known_bad: set };
        match bl.scan_payload(b"malicious payload") {
            BlocklistVerdict::Match(h) => assert_eq!(h, hash),
            _ => panic!("expected match"),
        }
    }

    #[test]
    fn clean_payload_is_not_matched() {
        let bl = HashBlocklist::load_from_str("deadbeef\n# comment\n\ncafebabe\n");
        match bl.scan_payload(b"totally harmless data") {
            BlocklistVerdict::Clean => {}
            _ => panic!("expected clean"),
        }
    }

    #[test]
    fn load_from_str_detects_match() {
        let mut hasher = Sha256::new();
        hasher.update(b"evil bytes");
        let hash = hex::encode(hasher.finalize());

        let content = format!("# list of bad hashes\n{}\n\ncafebabe\n", hash);
        let bl = HashBlocklist::load_from_str(&content);

        match bl.scan_payload(b"evil bytes") {
            BlocklistVerdict::Match(h) => assert_eq!(h, hash),
            _ => panic!("expected match"),
        }
    }

    #[test]
    fn load_from_str_skips_comments_and_blank_lines() {
        let bl = HashBlocklist::load_from_str("\n# comment line\n\n   \nabc123\n");
        assert_eq!(bl.known_bad.len(), 1);
        assert!(bl.known_bad.contains("abc123"));
    }

    #[test]
    fn empty_payload_returns_error() {
        let bl = HashBlocklist::load_from_str("");
        match bl.scan_payload_checked(b"") {
            BlocklistVerdict::Error(_) => {}
            _ => panic!("expected error"),
        }
    }
}
