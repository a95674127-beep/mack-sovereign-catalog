//! Mack Stack 3-Outcome Fail-Closed Triage Engine.
//!
//! Provides deterministic, fail-closed classification for tactical endpoints (TOC, Patriot/THAAD
//! maintenance laptops, and C2 nodes) operating in D-DIL environments without cloud exfiltration.

use serde::{Deserialize, Serialize};

/// Canonical 3-Outcome Fail-Closed Verdict.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TriageOutcome {
    /// Zero threat indicators detected; payload verified benign and cleared for host access.
    Clean,
    /// Suspicious behavioral anomalies, elevated entropy, or non-critical risk patterns detected;
    /// payload is restricted to isolated sandbox containment with exponential backoff.
    Quarantine,
    /// Critical threat, weaponized exploit, C2 beaconing signature, or blocklist match;
    /// payload is immediately zero-knowledge encrypted, cryptographic chain-of-custody recorded,
    /// host execution locked out, and routed to sealed vault storage pending S2/JAG forensics.
    Sealed,
}

impl TriageOutcome {
    pub fn as_str(&self) -> &'static str {
        match self {
            TriageOutcome::Clean => "CLEAN",
            TriageOutcome::Quarantine => "QUARANTINE",
            TriageOutcome::Sealed => "SEALED",
        }
    }

    /// Evaluates if the outcome allows execution or requires containment.
    pub fn is_executable_on_host(&self) -> bool {
        matches!(self, TriageOutcome::Clean)
    }

    /// Evaluates if the outcome requires immediate cryptographic sealing.
    pub fn is_sealed(&self) -> bool {
        matches!(self, TriageOutcome::Sealed)
    }
}

/// Comprehensive triage assessment containing detailed risk telemetry.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TriageAssessment {
    pub outcome: TriageOutcome,
    pub threat_score: u32, // 0 - 100
    pub reasons: Vec<String>,
    pub quarantine_lane_recommended: Option<String>,
    pub requires_jag_s2_escalation: bool,
}

impl TriageAssessment {
    pub fn fail_closed(reason: impl Into<String>) -> Self {
        Self {
            outcome: TriageOutcome::Sealed,
            threat_score: 100,
            reasons: vec![reason.into()],
            quarantine_lane_recommended: Some("MACK-12".to_string()),
            requires_jag_s2_escalation: true,
        }
    }
}
