//! Detection module for threat detection, payload inspection, and tactical triage.
//!
//! # Defense & D-DIL Capabilities
//! - **Native Offline Inspection**: Pure Rust SHA-256 blocklists, Shannon entropy,
//!   weaponized document patterns (macros/VBA/PDF/RTF), phishing lures, C2 beaconing signatures,
//!   and binary header/shellcode inspection.
//! - **Mack Stack 3-Outcome Triage**: Clean, Quarantine, and Sealed fail-closed classification.

pub mod c2_callbacks;
pub mod engine;
pub mod entropy_scan;
pub mod hash_blocklist;
pub mod malicious_doc;
pub mod pe_shellcode;
pub mod phishing;
pub mod stix;
pub mod triage;
pub mod yara;

pub use c2_callbacks::{C2Detector, C2Indicator};
pub use engine::{ComprehensiveScanResult, OfflineThreatEngine};
pub use entropy_scan::{scan_payload, shannon_entropy, EntropyVerdict};
pub use hash_blocklist::{BlocklistVerdict, HashBlocklist};
pub use malicious_doc::{DocThreatIndicator, MaliciousDocScanner};
pub use pe_shellcode::{ExecutableIndicator, ExecutableInspector};
pub use phishing::{PhishingDetector, PhishingIndicator};
pub use stix::scan_result_to_stix_bundle;
pub use triage::{TriageAssessment, TriageOutcome};
pub use yara::{YaraError, YaraMatch, YaraScanner, DEFAULT_RULES};
