// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! detection::stix — Export threat-engine findings as STIX 2.1 bundles.
//!
//! STIX (Structured Threat Information eXpression) is the lingua franca for
//! sharing threat intelligence. [`scan_result_to_stix_bundle`] converts a
//! [`ComprehensiveScanResult`](crate::detection::ComprehensiveScanResult)
//! into a STIX 2.1 `bundle` containing:
//!
//! - an `identity` for this engine,
//! - a top-level `file` SCO for the scanned payload (SHA-256, size) with a
//!   deterministic ID derived from the payload hash, referenced by an
//!   `observed-data` object via `object_refs` (the STIX 2.1 model; the
//!   embedded `objects` dictionary was STIX 2.0),
//! - one `indicator` per strong finding (blocklist hit, YARA match, C2
//!   artifact), each with a STIX pattern over the payload hash,
//! - a `report` tying the objects together with the triage verdict.
//!
//! Every SDO carries `created_by_ref` pointing at the engine identity, and
//! indicators use the STIX 2.1 `indicator_types` property (2.0's `labels`
//! does not exist on 2.1 indicators).
//!
//! Weaker heuristic findings (document/phishing/executable patterns) are
//! summarized in the report description rather than minted as indicators:
//! they are triage signals, and STIX indicators should stay high-signal.
//! A clean scan still produces identity + observed-data + report, so the
//! "we looked and found nothing" fact is itself shareable.

use chrono::Utc;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};

use crate::detection::{ComprehensiveScanResult, TriageOutcome};

fn new_id(prefix: &str) -> String {
    format!("{prefix}--{}", uuid::Uuid::new_v4())
}

fn now_stix() -> String {
    Utc::now().format("%Y-%m-%dT%H:%M:%S%.3fZ").to_string()
}

fn sha256_hex(data: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data);
    hex::encode(hasher.finalize())
}

/// Deterministic STIX ID for the payload's `file` SCO.
///
/// STIX 2.1 (section 2.9) prefers deterministic IDs for SCOs, generated
/// from the object's contributing properties — for a `file`, its hashes.
/// The first 128 bits of the payload's SHA-256 are formatted as a UUID
/// with the version-5 nibble and RFC 4122 variant bits set, so the same
/// payload yields the same `file` ID in every bundle, with no new
/// dependencies and no randomness.
fn file_id_for_digest(digest_hex: &str) -> String {
    let raw = hex::decode(digest_hex).expect("digest is sha256 hex");
    let mut b: [u8; 16] = raw[..16].try_into().expect("sha256 is 32 bytes");
    b[6] = (b[6] & 0x0f) | 0x50; // version 5
    b[8] = (b[8] & 0x3f) | 0x80; // RFC 4122 variant
    format!("file--{}", uuid::Uuid::from_bytes(b))
}

/// Converts a threat-engine scan result into a STIX 2.1 bundle.
///
/// `payload` is the exact bytes that were scanned; its SHA-256 anchors the
/// `observed-data` object and every indicator pattern.
pub fn scan_result_to_stix_bundle(result: &ComprehensiveScanResult, payload: &[u8]) -> Value {
    let ts = now_stix();
    let digest = sha256_hex(payload);

    let identity_id = new_id("identity");
    let observed_id = new_id("observed-data");
    let report_id = new_id("report");
    let file_id = file_id_for_digest(&digest);

    let identity = json!({
        "type": "identity",
        "spec_version": "2.1",
        "id": identity_id.clone(),
        "created": ts,
        "modified": ts,
        "name": "ai-infinity-force-one-vault OfflineThreatEngine",
        "identity_class": "system",
        "description": "Offline zero-trust threat detection engine: hash blocklist, entropy, YARA, document/phishing/C2/binary heuristics with fail-closed triage.",
    });

    // STIX 2.1: SCOs are top-level bundle objects; observed-data links to
    // them with object_refs (the embedded "objects" dict was STIX 2.0).
    let file_sco = json!({
        "type": "file",
        "spec_version": "2.1",
        "id": file_id.clone(),
        "hashes": { "SHA-256": digest },
        "size": payload.len(),
    });

    let observed = json!({
        "type": "observed-data",
        "spec_version": "2.1",
        "id": observed_id.clone(),
        "created_by_ref": identity_id.clone(),
        "created": ts,
        "modified": ts,
        "first_observed": ts,
        "last_observed": ts,
        "number_observed": 1,
        "object_refs": [file_id.clone()],
    });

    let mut objects = vec![identity, file_sco, observed];
    let mut indicator_ids: Vec<String> = Vec::new();

    // Strong findings become indicators with STIX patterns over the hash.
    let add_indicator = |name: &str,
                         description: &str,
                         objects: &mut Vec<Value>,
                         indicator_ids: &mut Vec<String>| {
        let id = new_id("indicator");
        indicator_ids.push(id.clone());
        objects.push(json!({
            "type": "indicator",
            "spec_version": "2.1",
            "id": id,
            "created_by_ref": identity_id.clone(),
            "created": ts,
            "modified": ts,
            "name": name,
            "description": description,
            "pattern": format!("[file:hashes.'SHA-256' = '{digest}']"),
            "pattern_type": "stix",
            "valid_from": ts,
            "indicator_types": ["malicious-activity"],
        }));
    };

    if let Some(hash) = &result.blocklist_match {
        add_indicator(
            "Known malicious hash",
            &format!("Payload SHA-256 matches threat-intel blocklist entry {hash}"),
            &mut objects,
            &mut indicator_ids,
        );
    }
    for m in &result.yara_matches {
        add_indicator(
            &format!("YARA match: {}", m.rule),
            &format!(
                "YARA rule '{}' matched ({}). Score contribution: {}.",
                m.rule, m.description, m.score
            ),
            &mut objects,
            &mut indicator_ids,
        );
    }
    for c2 in &result.c2_indicators {
        add_indicator(
            "C2 artifact",
            &format!("C2 callback artifact: {}", c2.description),
            &mut objects,
            &mut indicator_ids,
        );
    }

    let verdict = match result.triage.outcome {
        TriageOutcome::Clean => "CLEAN",
        TriageOutcome::Quarantine => "QUARANTINE",
        TriageOutcome::Sealed => "SEALED",
    };
    let mut report_desc = format!(
        "Fail-closed triage verdict: {verdict} (threat score {}/100). ",
        result.triage.threat_score
    );
    if result.triage.reasons.is_empty() {
        report_desc.push_str("No indicators found.");
    } else {
        report_desc.push_str("Top reasons: ");
        let top: Vec<&str> = result
            .triage
            .reasons
            .iter()
            .take(5)
            .map(|s| s.as_str())
            .collect();
        report_desc.push_str(&top.join("; "));
    }

    let mut object_refs: Vec<String> = vec![observed_id.clone(), file_id];
    object_refs.extend(indicator_ids);

    objects.push(json!({
        "type": "report",
        "spec_version": "2.1",
        "id": report_id,
        "created_by_ref": identity_id,
        "created": ts,
        "modified": ts,
        "name": format!("ai-infinity-force-one-vault triage: {verdict}"),
        "description": report_desc,
        "published": ts,
        "object_refs": object_refs,
    }));

    json!({
        "type": "bundle",
        "id": new_id("bundle"),
        "objects": objects,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::detection::OfflineThreatEngine;

    fn object_types(bundle: &Value) -> Vec<String> {
        bundle["objects"]
            .as_array()
            .unwrap()
            .iter()
            .map(|o| o["type"].as_str().unwrap().to_string())
            .collect()
    }

    #[test]
    fn malicious_scan_produces_full_bundle() {
        let engine = OfflineThreatEngine::default();
        // Known-bad hash from the bundled blocklist (used by existing tests).
        let payload = b"malicious_test_payload";
        let result = engine.scan_payload(payload);
        assert!(result.blocklist_match.is_some());

        let bundle = scan_result_to_stix_bundle(&result, payload);
        assert_eq!(bundle["type"], "bundle");
        assert!(bundle["id"].as_str().unwrap().starts_with("bundle--"));

        let types = object_types(&bundle);
        assert!(types.contains(&"identity".to_string()));
        assert!(types.contains(&"observed-data".to_string()));
        assert!(types.contains(&"indicator".to_string()));
        assert!(types.contains(&"report".to_string()));

        // Every object carries the STIX 2.1 required fields. (SCOs such as
        // `file` have spec_version and id but no created/modified in 2.1.)
        for obj in bundle["objects"].as_array().unwrap() {
            assert_eq!(obj["spec_version"], "2.1", "missing spec_version on {obj}");
            assert!(
                obj["id"].as_str().unwrap().contains("--"),
                "bad id on {obj}"
            );
            if obj["type"] != "file" {
                assert!(
                    obj["created"].as_str().is_some(),
                    "missing created on {obj}"
                );
            }
        }

        // The indicator pattern is anchored on the payload hash.
        let expected = sha256_hex(payload);
        let indicator = bundle["objects"]
            .as_array()
            .unwrap()
            .iter()
            .find(|o| o["type"] == "indicator")
            .unwrap();
        assert!(
            indicator["pattern"].as_str().unwrap().contains(&expected),
            "pattern not anchored on payload hash"
        );

        // STIX 2.1: observed-data references the top-level file SCO via
        // object_refs; the file carries the same hash and size.
        let observed = bundle["objects"]
            .as_array()
            .unwrap()
            .iter()
            .find(|o| o["type"] == "observed-data")
            .unwrap();
        assert!(
            observed.get("objects").is_none(),
            "observed-data still uses the STIX 2.0 embedded objects dict"
        );
        let file_ref = observed["object_refs"][0].as_str().unwrap();
        let file = bundle["objects"]
            .as_array()
            .unwrap()
            .iter()
            .find(|o| o["type"] == "file")
            .unwrap();
        assert_eq!(file["id"].as_str().unwrap(), file_ref);
        assert_eq!(file["hashes"]["SHA-256"].as_str().unwrap(), expected);
        assert_eq!(file["size"].as_u64().unwrap(), payload.len() as u64);
    }

    #[test]
    fn file_sco_id_is_deterministic_across_bundles() {
        let engine = OfflineThreatEngine::default();
        let payload = b"quarterly earnings report, nothing suspicious whatsoever";
        let result = engine.scan_payload(payload);

        let file_id_of = |bundle: &Value| {
            bundle["objects"]
                .as_array()
                .unwrap()
                .iter()
                .find(|o| o["type"] == "file")
                .unwrap()["id"]
                .as_str()
                .unwrap()
                .to_string()
        };

        let first = file_id_of(&scan_result_to_stix_bundle(&result, payload));
        let second = file_id_of(&scan_result_to_stix_bundle(&result, payload));
        assert!(first.starts_with("file--"));
        assert_eq!(first, second, "same payload must yield the same file id");

        let other_payload = b"a completely different payload";
        let other_result = engine.scan_payload(other_payload);
        let other = file_id_of(&scan_result_to_stix_bundle(&other_result, other_payload));
        assert_ne!(
            first, other,
            "different payload must yield a different file id"
        );
    }

    #[test]
    fn stix21_property_names_and_created_by_refs() {
        let engine = OfflineThreatEngine::default();
        let payload = b"malicious_test_payload";
        let result = engine.scan_payload(payload);
        let bundle = scan_result_to_stix_bundle(&result, payload);
        let objects = bundle["objects"].as_array().unwrap();

        let identity_id = objects.iter().find(|o| o["type"] == "identity").unwrap()["id"]
            .as_str()
            .unwrap();

        // Every SDO except the identity itself names its creator.
        for obj in objects {
            if obj["type"] == "identity" || obj["type"] == "file" {
                continue;
            }
            assert_eq!(
                obj["created_by_ref"].as_str().unwrap(),
                identity_id,
                "missing or wrong created_by_ref on {obj}"
            );
        }

        // Indicators use the 2.1 property name; 2.0's `labels` must be gone.
        for ind in objects.iter().filter(|o| o["type"] == "indicator") {
            assert_eq!(ind["indicator_types"][0], "malicious-activity");
            assert!(
                ind.get("labels").is_none(),
                "indicator still carries STIX 2.0 `labels`"
            );
        }

        // The report references the observed-data, the file, and indicators.
        let report = objects.iter().find(|o| o["type"] == "report").unwrap();
        let refs: Vec<&str> = report["object_refs"]
            .as_array()
            .unwrap()
            .iter()
            .map(|r| r.as_str().unwrap())
            .collect();
        assert!(refs.iter().any(|r| r.starts_with("observed-data--")));
        assert!(refs.iter().any(|r| r.starts_with("file--")));
        assert!(refs.iter().any(|r| r.starts_with("indicator--")));
    }

    #[test]
    fn yara_match_becomes_indicator() {
        let engine = OfflineThreatEngine::default();
        let mut payload = b"MZ".to_vec();
        payload.extend_from_slice(
            b"\x00CreateRemoteThread\x00VirtualAllocEx\x00WriteProcessMemory\x00",
        );
        let result = engine.scan_payload(&payload);
        assert!(
            result
                .yara_matches
                .iter()
                .any(|m| m.rule == "possible_process_injection"),
            "yara did not fire: {result:?}"
        );

        let bundle = scan_result_to_stix_bundle(&result, &payload);
        let indicators: Vec<&Value> = bundle["objects"]
            .as_array()
            .unwrap()
            .iter()
            .filter(|o| o["type"] == "indicator")
            .collect();
        assert!(
            indicators.iter().any(|i| i["name"]
                .as_str()
                .unwrap()
                .contains("possible_process_injection")),
            "no indicator for the yara match"
        );
    }

    #[test]
    fn clean_scan_has_no_indicators_but_still_reports() {
        let engine = OfflineThreatEngine::default();
        let payload = b"quarterly earnings report, nothing suspicious whatsoever";
        let result = engine.scan_payload(payload);
        assert_eq!(result.triage.outcome, TriageOutcome::Clean);

        let bundle = scan_result_to_stix_bundle(&result, payload);
        let types = object_types(&bundle);
        assert!(!types.contains(&"indicator".to_string()));
        assert!(types.contains(&"report".to_string()));
        let report = bundle["objects"]
            .as_array()
            .unwrap()
            .iter()
            .find(|o| o["type"] == "report")
            .unwrap();
        assert!(report["name"].as_str().unwrap().contains("CLEAN"));
    }
}
