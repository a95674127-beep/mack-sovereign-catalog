use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExecutableIndicator {
    pub classification: String,
    pub description: String,
    pub severity: u32,
}

pub struct ExecutableInspector;

impl ExecutableInspector {
    pub fn inspect(data: &[u8]) -> Vec<ExecutableIndicator> {
        let mut findings = Vec::new();

        if data.len() < 4 {
            return findings;
        }

        if data.len() >= 2 && data[0] == b'M' && data[1] == b'Z' {
            findings.push(ExecutableIndicator {
                classification: "Windows PE".to_string(),
                description: "Windows Portable Executable (MZ DOS/PE header detected)".to_string(),
                severity: 40,
            });
        }

        if data.len() >= 4 && &data[0..4] == b"\x7fELF" {
            findings.push(ExecutableIndicator {
                classification: "Linux ELF".to_string(),
                description: "Linux Executable & Linkable Format (ELF binary detected)".to_string(),
                severity: 40,
            });
        }

        if data.len() >= 4
            && (&data[0..4] == b"\xfe\xed\xfa\xce"
                || &data[0..4] == b"\xfe\xed\xfa\xcf"
                || &data[0..4] == b"\xcf\xfa\xed\xfe")
        {
            findings.push(ExecutableIndicator {
                classification: "macOS Mach-O".to_string(),
                description: "Mach-O executable binary format detected".to_string(),
                severity: 40,
            });
        }

        let mut consecutive_nops = 0;
        for &byte in data {
            if byte == 0x90 {
                consecutive_nops += 1;
                if consecutive_nops >= 16 {
                    findings.push(ExecutableIndicator {
                        classification: "Shellcode NOP Sled".to_string(),
                        description:
                            "Consecutive 0x90 NOP sled indicating potential exploit padding"
                                .to_string(),
                        severity: 55,
                    });
                    break;
                }
            } else {
                consecutive_nops = 0;
            }
        }

        findings
    }
}
