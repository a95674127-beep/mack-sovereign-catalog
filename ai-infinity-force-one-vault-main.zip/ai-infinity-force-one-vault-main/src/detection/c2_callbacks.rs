use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct C2Indicator {
    pub indicator_type: String,
    pub description: String,
    pub severity: u32,
}

pub struct C2Detector;

impl C2Detector {
    const C2_SIGNATURES: &'static [(&'static str, &'static str, u32)] = &[
        (
            "/meterpreter",
            "Metasploit Meterpreter reverse stage URI pattern",
            60,
        ),
        (
            "/beacon",
            "Cobalt Strike malleable C2 default beacon endpoint",
            60,
        ),
        (
            "/submit.php?id=",
            "Cobalt Strike data exfiltration URI pattern",
            50,
        ),
        ("nc -e /bin/sh", "Netcat reverse shell spawn command", 65),
        (
            "nc -e /bin/bash",
            "Netcat interactive reverse shell execution",
            65,
        ),
        (
            "/dev/tcp/",
            "Bash direct pseudo-device socket network redirection",
            60,
        ),
        (
            "Invoke-Expression",
            "PowerShell IEX dynamic string execution",
            45,
        ),
        (
            "IEX(New-Object Net.WebClient)",
            "Classic PowerShell cradle download & execute",
            60,
        ),
        (
            "DownloadString('http",
            "Remote script stager pull over HTTP",
            50,
        ),
        ("whoami & ipconfig", "Reconnaissance execution sequence", 30),
        ("systeminfo", "Host enumeration telemetry command", 20),
        (
            "socks5://",
            "SOCKS5 proxy tunnel definition for egress routing",
            35,
        ),
    ];

    pub fn scan(data: &[u8]) -> Vec<C2Indicator> {
        let mut matches = Vec::new();
        let payload_str = String::from_utf8_lossy(data);
        let payload_lower = payload_str.to_lowercase();

        for &(pattern, desc, sev) in Self::C2_SIGNATURES {
            if payload_lower.contains(&pattern.to_lowercase()) {
                matches.push(C2Indicator {
                    indicator_type: "C2 Artifact".to_string(),
                    description: desc.to_string(),
                    severity: sev,
                });
            }
        }

        matches
    }
}
