use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PhishingIndicator {
    pub pattern_type: String,
    pub description: String,
    pub severity: u32,
}

pub struct PhishingDetector;

impl PhishingDetector {
    const KEYWORDS: &'static [(&'static str, &'static str, u32)] = &[
        (
            "password reset",
            "Credential harvesting lure: password reset",
            25,
        ),
        (
            "verify your account",
            "Urgent verification credential lure",
            25,
        ),
        (
            "cac pin",
            "DoD Common Access Card (CAC) PIN harvesting attempt",
            50,
        ),
        (
            "sipr credentials",
            "SIPRNet credential harvesting attempt",
            60,
        ),
        ("nipr credentials", "NIPRNet credential lure", 40),
        (
            "update your security token",
            "Authentication token theft lure",
            30,
        ),
        (
            "classified orders",
            "Phishing lure impersonating military personnel orders",
            35,
        ),
        (
            "immediate action required",
            "Urgency pressure trigger common in BEC / phishing",
            15,
        ),
    ];

    const SUSPICIOUS_SCHEMES_OR_HOSTS: &'static [(&'static str, &'static str, u32)] = &[
        (
            "http://",
            "Unencrypted plaintext HTTP link in tactical message",
            15,
        ),
        (
            "xn--",
            "Internationalized / Punycode domain spoofing attempt",
            35,
        ),
        (
            ".xyz",
            "High-abuse TLD often used in disposable phishing sites",
            20,
        ),
        (".top", "High-abuse TLD", 20),
        (".ru", "Non-allied country code top-level domain", 25),
        ("bit.ly/", "URL shortener masking destination endpoint", 20),
        (
            "tinyurl.com/",
            "URL shortener masking destination endpoint",
            20,
        ),
    ];

    pub fn scan(text: &str) -> Vec<PhishingIndicator> {
        let mut findings = Vec::new();
        let text_lower = text.to_lowercase();

        for &(kw, desc, sev) in Self::KEYWORDS {
            if text_lower.contains(kw) {
                findings.push(PhishingIndicator {
                    pattern_type: "Keyword Lure".to_string(),
                    description: desc.to_string(),
                    severity: sev,
                });
            }
        }

        for &(scheme, desc, sev) in Self::SUSPICIOUS_SCHEMES_OR_HOSTS {
            if text_lower.contains(scheme) {
                findings.push(PhishingIndicator {
                    pattern_type: "Suspicious Host/URI".to_string(),
                    description: desc.to_string(),
                    severity: sev,
                });
            }
        }

        if let Some(pos) = text_lower.find("://") {
            let after = &text_lower[pos + 3..];
            if after
                .chars()
                .take(4)
                .all(|c| c.is_ascii_digit() || c == '.')
            {
                findings.push(PhishingIndicator {
                    pattern_type: "Direct IP Link".to_string(),
                    description: "Direct numerical IP address in URL rather than domain"
                        .to_string(),
                    severity: 30,
                });
            }
        }

        findings
    }
}
