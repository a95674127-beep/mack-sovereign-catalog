use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DocThreatIndicator {
    pub category: String,
    pub pattern: String,
    pub severity: u32,
    pub description: String,
}

pub struct MaliciousDocScanner;

impl MaliciousDocScanner {
    const SUSPICIOUS_PATTERNS: &'static [(&'static str, &'static str, u32, &'static str)] = &[
        (
            "VBA Macro",
            "AutoOpen",
            25,
            "Auto-executing macro routine in document open",
        ),
        (
            "VBA Macro",
            "Document_Open",
            25,
            "VBA Document_Open event trigger",
        ),
        (
            "VBA Macro",
            "Workbook_Open",
            25,
            "Excel Workbook_Open execution trigger",
        ),
        (
            "VBA Macro",
            "vbaProject.bin",
            30,
            "Embedded binary VBA macro project",
        ),
        (
            "VBA Shell",
            "WScript.Shell",
            40,
            "Host script shell invocation object",
        ),
        (
            "VBA Shell",
            "ShellExecute",
            40,
            "Direct system execution call",
        ),
        (
            "VBA Shell",
            "powershell",
            40,
            "PowerShell spawn within document stream",
        ),
        (
            "VBA Shell",
            "cmd.exe",
            35,
            "Windows command prompt process spawn",
        ),
        (
            "PDF Vector",
            "/JavaScript",
            35,
            "Embedded JavaScript execution block in PDF",
        ),
        ("PDF Vector", "/JS", 30, "Abbreviated PDF JavaScript action"),
        (
            "PDF Vector",
            "/Launch",
            50,
            "PDF launch action targeting external binary",
        ),
        (
            "PDF Vector",
            "/EmbeddedFiles",
            25,
            "Embedded secondary payload within PDF",
        ),
        (
            "PDF Vector",
            "/OpenAction",
            25,
            "Automated trigger executed on document load",
        ),
        (
            "RTF Exploit",
            "\\objdata",
            30,
            "Embedded OLE data block in RTF document",
        ),
        (
            "RTF Exploit",
            "\\objupdate",
            35,
            "Automatic OLE object update exploit (CVE-2017-0199 vector)",
        ),
    ];

    pub fn scan(data: &[u8]) -> Vec<DocThreatIndicator> {
        let mut matches = Vec::new();
        let payload_str = String::from_utf8_lossy(data);
        let payload_lower = payload_str.to_lowercase();

        for &(cat, pat, sev, desc) in Self::SUSPICIOUS_PATTERNS {
            if payload_lower.contains(&pat.to_lowercase()) {
                matches.push(DocThreatIndicator {
                    category: cat.to_string(),
                    pattern: pat.to_string(),
                    severity: sev,
                    description: desc.to_string(),
                });
            }
        }
        matches
    }
}
