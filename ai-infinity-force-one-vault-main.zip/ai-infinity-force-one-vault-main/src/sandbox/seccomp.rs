// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! sandbox::seccomp — seccomp-bpf syscall profile for the lane worker
//! (Elevation A3, 2026-11-10).
//!
//! Defense in depth beside Landlock: Landlock strips the worker's
//! filesystem access; this profile strips its *syscall* surface. The
//! worker's whole job is: read framed requests from inherited stdin,
//! run in-memory containment checks, write framed responses to
//! inherited stdout. It never needs to open a socket, spawn a process,
//! load a module, or touch the clock — so those syscalls are denied.
//!
//! Mechanism: a classic-BPF allowlist installed with
//! `prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER)` after
//! `PR_SET_NO_NEW_PRIVS`. Anything not on the list gets
//! `SECCOMP_RET_ERRNO(EPERM)` — a clean, survivable denial the caller
//! can observe, rather than a kill the host would have to infer.
//! A wrong-architecture invocation is killed outright
//! (`SECCOMP_RET_KILL_PROCESS`): the allowlist is written against the
//! x86-64 syscall table, and running it under any other numbering
//! would deny/allow the wrong calls.
//!
//! Fail-closed contract: [`apply_lane_seccomp_profile`] returns `Err`
//! if any step fails, and the worker refuses to start in that case —
//! it never runs unfiltered. The filter is installed by the worker
//! itself, after Landlock, before the handshake is sent.
//!
//! The dependency is a single direct `libc` edge (Linux-only), used
//! for the raw `prctl`/`sock_filter` ABI; no seccomp helper crate.

/// Why installing the profile failed. The worker treats every variant
/// as fatal (fail-closed).
#[derive(Debug)]
pub enum SeccompError {
    /// `PR_SET_NO_NEW_PRIVS` failed.
    NoNewPrivs(i32),
    /// `PR_SET_SECCOMP` failed.
    InstallFailed(i32),
    /// The BPF program could not be built (internal inconsistency).
    ProgramBuild(String),
}

impl std::fmt::Display for SeccompError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SeccompError::NoNewPrivs(e) => {
                write!(f, "prctl(PR_SET_NO_NEW_PRIVS) failed: errno {e}")
            }
            SeccompError::InstallFailed(e) => {
                write!(f, "prctl(PR_SET_SECCOMP, FILTER) failed: errno {e}")
            }
            SeccompError::ProgramBuild(d) => write!(f, "seccomp program build failed: {d}"),
        }
    }
}

impl std::error::Error for SeccompError {}

/// x86-64 syscall numbers the lane worker is allowed to make.
///
/// Shaped to what the worker actually does after startup: frame I/O on
/// inherited pipes (`read`/`write`/`close`), allocator behavior
/// (`brk`/`mmap`/`munmap`/`mprotect`/`madvise`), the Rust runtime's
/// per-thread bookkeeping (`futex`, `rseq`, TLS via `arch_prctl` /
/// `set_tid_address` / `set_robust_list`), bounded sleeps for the
/// test delay hook (`nanosleep`/`clock_nanosleep`), scheduling yields,
/// identity queries used by std (`getpid`/`gettid`/`getuid`…), signal
/// plumbing, and clean exit (`exit`/`exit_group`). Everything else —
/// sockets, exec, file opening beyond the inherited descriptors,
/// module loading, ptrace, mount, time setting — is denied with EPERM.
#[cfg(target_arch = "x86_64")]
const ALLOWED_SYSCALLS: &[i64] = &[
    libc::SYS_read,
    libc::SYS_write,
    libc::SYS_close,
    libc::SYS_fstat,
    libc::SYS_lseek,
    libc::SYS_mmap,
    libc::SYS_mprotect,
    libc::SYS_munmap,
    libc::SYS_brk,
    libc::SYS_madvise,
    libc::SYS_futex,
    libc::SYS_rseq,
    libc::SYS_arch_prctl,
    libc::SYS_set_tid_address,
    libc::SYS_set_robust_list,
    libc::SYS_prlimit64,
    libc::SYS_readv,
    libc::SYS_writev,
    libc::SYS_pread64,
    libc::SYS_pwrite64,
    libc::SYS_poll,
    libc::SYS_ppoll,
    libc::SYS_select,
    libc::SYS_pselect6,
    libc::SYS_epoll_wait,
    libc::SYS_epoll_pwait,
    libc::SYS_sched_yield,
    libc::SYS_nanosleep,
    libc::SYS_clock_nanosleep,
    libc::SYS_clock_gettime,
    libc::SYS_gettimeofday,
    libc::SYS_times,
    libc::SYS_getpid,
    libc::SYS_gettid,
    libc::SYS_getuid,
    libc::SYS_geteuid,
    libc::SYS_getgid,
    libc::SYS_getegid,
    libc::SYS_getrandom,
    libc::SYS_sigaltstack,
    libc::SYS_rt_sigaction,
    libc::SYS_rt_sigprocmask,
    libc::SYS_rt_sigreturn,
    libc::SYS_tgkill,
    libc::SYS_clone,
    libc::SYS_clone3,
    libc::SYS_exit,
    libc::SYS_exit_group,
    libc::SYS_restart_syscall,
];

#[cfg(not(target_arch = "x86_64"))]
const ALLOWED_SYSCALLS: &[i64] = &[];

// Classic-BPF instruction encodings (linux/bpf_common.h, linux/seccomp.h).
const BPF_LD_W_ABS: u16 = 0x20; // BPF_LD | BPF_W | BPF_ABS
const BPF_JMP_JEQ_K: u16 = 0x15; // BPF_JMP | BPF_JEQ | BPF_K
const BPF_RET_K: u16 = 0x06; // BPF_RET | BPF_K
const SECCOMP_RET_ALLOW: u32 = 0x7fff_0000;
const SECCOMP_RET_ERRNO_EPERM: u32 = 0x0005_0000 | 1; // SECCOMP_RET_ERRNO | EPERM
const SECCOMP_RET_KILL_PROCESS: u32 = 0x8000_0000;
const AUDIT_ARCH_X86_64: u32 = 0xC000_003E;
// struct seccomp_data offsets: nr at 0, arch at 4.
const DATA_NR_OFFSET: u32 = 0;
const DATA_ARCH_OFFSET: u32 = 4;

fn stmt(code: u16, k: u32) -> libc::sock_filter {
    libc::sock_filter {
        code,
        jt: 0,
        jf: 0,
        k,
    }
}

fn jump_if_eq(code: u16, k: u32, jt: u8, jf: u8) -> libc::sock_filter {
    libc::sock_filter { code, jt, jf, k }
}

/// Builds the BPF program: arch check (kill on mismatch), then a JEQ
/// chain over the allowlist, then default-deny EPERM.
///
/// Layout: [arch load, arch JEQ -> +1 | KILL], [nr load],
/// one JEQ per allowed syscall (jt -> ALLOW, jf -> next),
/// [ERRNO], [ALLOW]. The ALLOW block sits last so every allow jump
/// lands within the u8 jump range (the chain is short).
fn build_program() -> Result<Vec<libc::sock_filter>, SeccompError> {
    if ALLOWED_SYSCALLS.is_empty() {
        return Err(SeccompError::ProgramBuild(
            "empty allowlist (unsupported architecture)".to_string(),
        ));
    }
    let mut prog = Vec::with_capacity(ALLOWED_SYSCALLS.len() + 5);
    // if (arch != AUDIT_ARCH_X86_64) KILL_PROCESS;
    prog.push(stmt(BPF_LD_W_ABS, DATA_ARCH_OFFSET));
    prog.push(jump_if_eq(BPF_JMP_JEQ_K, AUDIT_ARCH_X86_64, 1, 0));
    prog.push(stmt(BPF_RET_K, SECCOMP_RET_KILL_PROCESS));
    // switch (nr) { case ALLOWED: ALLOW; } default: ERRNO(EPERM)
    prog.push(stmt(BPF_LD_W_ABS, DATA_NR_OFFSET));
    let allow_index = prog.len() + ALLOWED_SYSCALLS.len() + 1; // index of the ALLOW stmt
    for &nr in ALLOWED_SYSCALLS {
        let jt = u8::try_from(allow_index - (prog.len() + 1)).map_err(|_| {
            SeccompError::ProgramBuild("allow jump exceeds classic-BPF range".to_string())
        })?;
        prog.push(jump_if_eq(
            BPF_JMP_JEQ_K,
            u32::try_from(nr).unwrap_or(u32::MAX),
            jt,
            0,
        ));
    }
    prog.push(stmt(BPF_RET_K, SECCOMP_RET_ERRNO_EPERM));
    prog.push(stmt(BPF_RET_K, SECCOMP_RET_ALLOW));
    Ok(prog)
}

/// Installs the lane worker seccomp-bpf profile on the current
/// process. Irreversible by design. Fail-closed: any error means the
/// caller must not run unfiltered.
pub fn apply_lane_seccomp_profile() -> Result<(), SeccompError> {
    let mut program = build_program()?;
    let prog = libc::sock_fprog {
        len: u16::try_from(program.len())
            .map_err(|_| SeccompError::ProgramBuild("program too long".to_string()))?,
        filter: program.as_mut_ptr(),
    };
    // SAFETY: prctl with a live, correctly-built sock_fprog; the
    // filter buffer outlives the call. NO_NEW_PRIVS first is required
    // for an unprivileged filter install.
    unsafe {
        if libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0 {
            return Err(SeccompError::NoNewPrivs(*libc::__errno_location()));
        }
        if libc::prctl(
            libc::PR_SET_SECCOMP,
            libc::SECCOMP_MODE_FILTER,
            &prog as *const libc::sock_fprog,
            0,
            0,
        ) != 0
        {
            return Err(SeccompError::InstallFailed(*libc::__errno_location()));
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn program_is_well_formed() {
        let prog = build_program().expect("program builds on x86_64 linux");
        // header(3) + nr load(1) + chain + deny + allow
        assert_eq!(prog.len(), ALLOWED_SYSCALLS.len() + 6);
        let last = prog.last().expect("non-empty");
        assert_eq!(last.k, SECCOMP_RET_ALLOW);
        // Every allow jump lands exactly on the ALLOW statement.
        let allow_index = prog.len() - 1;
        for (i, insn) in prog.iter().enumerate().skip(4) {
            if insn.code == BPF_JMP_JEQ_K {
                assert_eq!(i + 1 + insn.jt as usize, allow_index, "jump at {i}");
            }
        }
    }

    /// The behavioral deny proof (install profile -> socket attempt is
    /// refused, normal I/O still works) lives in the worker binary's
    /// `--self-test-seccomp` mode, exercised by the `sandbox::process`
    /// tests, because installing a filter is irreversible per-process.
    /// This test pins the allowlist's shape.
    #[test]
    fn allowlist_excludes_dangerous_syscalls() {
        for banned in [
            libc::SYS_socket,
            libc::SYS_connect,
            libc::SYS_execve,
            libc::SYS_ptrace,
            libc::SYS_mount,
            libc::SYS_init_module,
            libc::SYS_open,
            libc::SYS_openat,
            libc::SYS_creat,
        ] {
            assert!(
                !ALLOWED_SYSCALLS.contains(&banned),
                "syscall {banned} must not be allowlisted"
            );
        }
        for needed in [libc::SYS_read, libc::SYS_write, libc::SYS_exit_group] {
            assert!(ALLOWED_SYSCALLS.contains(&needed));
        }
    }
}
