// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! sandbox::process — Process-isolated lane execution with Linux Landlock confinement.
//!
//! [`ProcessLaneBackend`] runs containment checks in a separate OS process
//! ([`lane_worker`](crate::bin_docs)), so a hostile payload never shares
//! memory with the host. On Linux the worker additionally confines itself
//! with Landlock: no filesystem access at all.
//!
//! Honest limits:
//! - This is OS-process isolation, not a microVM or hardware enclave. It
//!   stops memory-sharing attacks and (on Linux) filesystem access, but a
//!   kernel-level exploit is still out of scope.
//! - Each backend holds one worker process for its lifetime; a dead worker
//!   is respawned transparently on the next request and the restart is
//!   counted via [`ProcessLaneBackend::restarts`].
//! - Requests are serialized per backend (one in-flight request). Lane
//!   parallelism comes from having one backend per lane.

use std::io::{BufRead, BufReader, Read, Write};
use std::path::PathBuf;
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::mpsc;
use std::sync::Mutex;
use std::time::Duration;

use serde::{Deserialize, Serialize};

use crate::ingest::IngestRecord;
use crate::sandbox::isolation::SandboxError;
use crate::sandbox::limits::LaneLimits;

/// How strongly a lane backend is isolated.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IsolationLevel {
    /// Same-process checks only. Fast, but shares memory with the host.
    InProcess,
    /// Separate OS process. Memory is isolated; the filesystem is not
    /// restricted (non-Linux, or Landlock unavailable).
    Process,
    /// Separate OS process plus Linux Landlock confinement: the worker
    /// cannot open, read, or write any file.
    ProcessWithLandlock,
}

/// Failures that happen before a containment verdict exists. These are
/// infrastructure errors, not payload verdicts, and are always fail-closed:
/// the payload is never accepted on these paths.
#[derive(Debug)]
pub enum IsolationError {
    WorkerNotFound(String),
    SpawnFailed(String),
    HandshakeFailed(String),
}

impl std::fmt::Display for IsolationError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            IsolationError::WorkerNotFound(d) => write!(f, "lane worker binary not found: {d}"),
            IsolationError::SpawnFailed(d) => write!(f, "lane worker failed to spawn: {d}"),
            IsolationError::HandshakeFailed(d) => write!(f, "lane worker handshake failed: {d}"),
        }
    }
}

impl std::error::Error for IsolationError {}

#[derive(Debug, Serialize)]
struct WorkerRequest {
    id: u64,
    lane: String,
    payload_hex: String,
    max_bytes: usize,
    #[serde(default)]
    delay_ms: u64,
}

#[derive(Debug, Deserialize)]
struct WorkerResponse {
    id: u64,
    accepted: bool,
    error: Option<String>,
}

#[derive(Debug, Deserialize)]
struct Handshake {
    ready: bool,
    landlock: bool,
    /// Whether the worker installed its seccomp-bpf profile
    /// (Elevation A3). Defaults to false for older workers.
    #[serde(default)]
    seccomp: bool,
    #[allow(dead_code)]
    pid: u32,
}

fn worker_binary_name() -> String {
    if cfg!(windows) {
        "lane_worker.exe".to_string()
    } else {
        "lane_worker".to_string()
    }
}

/// Locates the `lane_worker` binary. Search order:
/// 1. `LANE_WORKER_PATH` environment override (deployments, installers).
/// 2. Next to the current executable.
/// 3. Next to the current executable's parent (covers `target/debug/deps/`
///    when running under `cargo test`).
fn find_worker_binary() -> Result<PathBuf, IsolationError> {
    if let Ok(p) = std::env::var("LANE_WORKER_PATH") {
        let path = PathBuf::from(&p);
        if path.is_file() {
            return Ok(path);
        }
        return Err(IsolationError::WorkerNotFound(format!(
            "LANE_WORKER_PATH={p} is not a file"
        )));
    }

    let name = worker_binary_name();
    let current =
        std::env::current_exe().map_err(|e| IsolationError::WorkerNotFound(e.to_string()))?;
    let mut candidates = Vec::new();
    if let Some(dir) = current.parent() {
        candidates.push(dir.join(&name));
        if let Some(parent) = dir.parent() {
            candidates.push(parent.join(&name));
        }
    }
    for c in candidates {
        if c.is_file() {
            return Ok(c);
        }
    }
    Err(IsolationError::WorkerNotFound(format!(
        "looked next to {} for {name}",
        current.display()
    )))
}

/// Live worker process plus its response pump.
struct WorkerProc {
    child: Child,
    stdin: ChildStdin,
    /// Receives framed responses from the pump thread; `Err` means the
    /// worker died or the protocol broke.
    responses: mpsc::Receiver<Result<WorkerResponse, String>>,
    next_id: u64,
    landlock: bool,
    seccomp: bool,
}

/// Mutable backend state behind the lock.
struct BackendInner {
    proc_: Option<WorkerProc>,
    /// How many times the worker has been (re)spawned after the first.
    restarts: u64,
}

fn read_frame<R: Read>(input: &mut R) -> Result<Vec<u8>, String> {
    let mut len_buf = [0u8; 4];
    input
        .read_exact(&mut len_buf)
        .map_err(|e| format!("response frame length read failed: {e}"))?;
    let len = u32::from_be_bytes(len_buf) as usize;
    if len > 64 * 1024 * 1024 {
        return Err(format!("response frame too large: {len} bytes"));
    }
    let mut buf = vec![0u8; len];
    input
        .read_exact(&mut buf)
        .map_err(|e| format!("response frame body read failed: {e}"))?;
    Ok(buf)
}

fn spawn_worker_at(
    path: &std::path::Path,
    limits: &LaneLimits,
) -> Result<WorkerProc, IsolationError> {
    let mut cmd = Command::new(path);
    cmd.stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .env_remove("LANE_WORKER_ALLOW_DELAY");
    // Elevation A4: per-lane rlimits, applied in the child between
    // fork and exec so they are in force before any worker code runs.
    // A failing setrlimit fails the spawn itself (fail-closed): no
    // unlimited worker ever runs.
    #[cfg(target_os = "linux")]
    {
        use std::os::unix::process::CommandExt;
        let limits = *limits;
        // SAFETY: the closure only calls async-signal-safe setrlimit
        // wrappers on a copied value — the documented pre_exec pattern.
        unsafe {
            cmd.pre_exec(move || limits.enforce());
        }
    }
    #[cfg(not(target_os = "linux"))]
    let _ = limits;
    // Test hook: the worker honors `delay_ms` only with this env var, which
    // is set here solely under `cfg(test)`. Production workers ignore it.
    #[cfg(test)]
    cmd.env("LANE_WORKER_ALLOW_DELAY", "1");
    let mut child = cmd
        .spawn()
        .map_err(|e| IsolationError::SpawnFailed(format!("{}: {e}", path.display())))?;

    let stdin = child
        .stdin
        .take()
        .ok_or_else(|| IsolationError::SpawnFailed("worker stdin was not piped".to_string()))?;
    let stdout = child
        .stdout
        .take()
        .ok_or_else(|| IsolationError::SpawnFailed("worker stdout was not piped".to_string()))?;
    let mut stderr = child.stderr.take();

    // Handshake: one JSON line, or EOF if the worker died (e.g. Landlock
    // unavailable -> fail-closed exit). Read with a timeout so a hung
    // worker cannot wedge backend construction forever.
    let (hs_tx, hs_rx) = mpsc::channel();
    std::thread::spawn(move || {
        let mut reader = BufReader::new(stdout);
        let mut line = String::new();
        let result = reader
            .read_line(&mut line)
            .map_err(|e| format!("handshake read failed: {e}"))
            .and_then(|n| {
                if n == 0 {
                    Err("worker exited before handshake (see stderr)".to_string())
                } else {
                    Ok(line)
                }
            });
        let _ = hs_tx.send((result, reader));
    });

    let (handshake_line, reader) = match hs_rx.recv_timeout(Duration::from_secs(10)) {
        Ok((Ok(line), reader)) => (line, reader),
        Ok((Err(e), _)) => {
            let _ = child.kill();
            let _ = child.wait();
            let mut err_detail = String::new();
            if let Some(ref mut err) = stderr {
                let mut buf = String::new();
                let _ = err.read_to_string(&mut buf);
                err_detail = buf;
            }
            return Err(IsolationError::HandshakeFailed(format!(
                "{e}. stderr: {err_detail}"
            )));
        }
        Err(_) => {
            let _ = child.kill();
            let _ = child.wait();
            return Err(IsolationError::HandshakeFailed(
                "worker did not send handshake within 10s".to_string(),
            ));
        }
    };

    let handshake: Handshake = serde_json::from_str(handshake_line.trim()).map_err(|e| {
        let _ = child.kill();
        IsolationError::HandshakeFailed(format!("bad handshake JSON: {e}"))
    })?;
    if !handshake.ready {
        let _ = child.kill();
        return Err(IsolationError::HandshakeFailed(
            "worker reported ready=false".to_string(),
        ));
    }

    // Response pump: owns the worker's stdout, forwards framed responses.
    // Exits on EOF or protocol error; the backend treats a dead pump as a
    // dead worker. The channel is bounded at 1 (Elevation A4
    // backpressure audit): requests are serialized per backend, so one
    // response slot is all a well-behaved worker can ever fill — and a
    // flooding worker now back-pressures its own pump thread and stdout
    // pipe instead of growing host memory without limit.
    let (resp_tx, resp_rx) = mpsc::sync_channel(1);
    std::thread::spawn(move || {
        let mut reader = reader;
        loop {
            let frame = read_frame(&mut reader);
            let msg = match frame {
                Ok(bytes) => match serde_json::from_slice::<WorkerResponse>(&bytes) {
                    Ok(resp) => Ok(resp),
                    Err(e) => Err(format!("bad response JSON: {e}")),
                },
                Err(e) => Err(e),
            };
            let dead = msg.is_err();
            if resp_tx.send(msg).is_err() {
                break;
            }
            if dead {
                break;
            }
        }
    });

    Ok(WorkerProc {
        child,
        stdin,
        responses: resp_rx,
        next_id: 1,
        landlock: handshake.landlock,
        seccomp: handshake.seccomp,
    })
}

/// Executes containment checks in a sandboxed worker process.
pub struct ProcessLaneBackend {
    inner: Mutex<BackendInner>,
    worker_path: PathBuf,
    max_payload_bytes: usize,
    timeout: Duration,
    /// Per-lane rlimits applied to every (re)spawn of the worker
    /// (Elevation A4).
    limits: LaneLimits,
}

impl std::fmt::Debug for ProcessLaneBackend {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let (worker_alive, restarts) = self
            .inner
            .lock()
            .map(|g| (g.proc_.is_some(), g.restarts))
            .unwrap_or((false, 0));
        f.debug_struct("ProcessLaneBackend")
            .field("max_payload_bytes", &self.max_payload_bytes)
            .field("timeout", &self.timeout)
            .field("worker_alive", &worker_alive)
            .field("restarts", &restarts)
            .finish()
    }
}

impl ProcessLaneBackend {
    /// Spawns the worker process. Fails if the worker binary cannot be
    /// found, started, or handshaked — never silently degraded.
    pub fn spawn(max_payload_bytes: usize, timeout: Duration) -> Result<Self, IsolationError> {
        let path = find_worker_binary()?;
        Self::spawn_with_path(path, max_payload_bytes, timeout)
    }

    /// Spawns the worker at an explicit path (installers, custom layouts).
    /// Same fail-closed guarantees as [`ProcessLaneBackend::spawn`].
    pub fn spawn_with_path(
        worker_path: PathBuf,
        max_payload_bytes: usize,
        timeout: Duration,
    ) -> Result<Self, IsolationError> {
        if !worker_path.is_file() {
            return Err(IsolationError::WorkerNotFound(format!(
                "{} is not a file",
                worker_path.display()
            )));
        }
        let limits = LaneLimits::resolved();
        let proc = spawn_worker_at(&worker_path, &limits)?;
        Ok(Self {
            inner: Mutex::new(BackendInner {
                proc_: Some(proc),
                restarts: 0,
            }),
            worker_path,
            max_payload_bytes,
            timeout,
            limits,
        })
    }

    fn lock(&self) -> std::sync::MutexGuard<'_, BackendInner> {
        self.inner
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    /// How strongly this backend is isolated (from the worker handshake).
    pub fn isolation_level(&self) -> IsolationLevel {
        match self.lock().proc_.as_ref() {
            Some(p) if p.landlock => IsolationLevel::ProcessWithLandlock,
            Some(_) => IsolationLevel::Process,
            None => IsolationLevel::Process,
        }
    }

    /// Number of times the worker has been respawned after dying.
    pub fn restarts(&self) -> u64 {
        self.lock().restarts
    }

    /// Whether the current worker installed its seccomp-bpf syscall
    /// profile (from the handshake; Elevation A3). On Linux a worker
    /// that cannot install the profile refuses to start, so a live
    /// backend always reports true there.
    pub fn seccomp_active(&self) -> bool {
        self.lock()
            .proc_
            .as_ref()
            .map(|p| p.seccomp)
            .unwrap_or(false)
    }

    /// The per-lane rlimits every worker (re)spawn runs under
    /// (Elevation A4).
    pub fn limits(&self) -> LaneLimits {
        self.limits
    }

    /// PID of the current worker, if alive. Test/observability hook.
    pub fn worker_pid(&self) -> Option<u32> {
        self.lock().proc_.as_ref().map(|p| p.child.id())
    }

    /// Kill the current worker without respawning. Test hook to prove a
    /// worker crash is surfaced honestly instead of hanging or being
    /// silently absorbed.
    #[cfg(test)]
    pub fn kill_worker(&self) {
        let mut guard = self.lock();
        if let Some(mut proc) = guard.proc_.take() {
            let _ = proc.child.kill();
            let _ = proc.child.wait();
        }
    }

    fn ensure_worker(
        &self,
        guard: &mut std::sync::MutexGuard<'_, BackendInner>,
    ) -> Result<(), SandboxError> {
        let needs_respawn = match guard.proc_.as_mut() {
            Some(proc) => matches!(proc.child.try_wait(), Ok(Some(_)) | Err(_)),
            None => true,
        };
        if needs_respawn {
            match spawn_worker_at(&self.worker_path, &self.limits) {
                Ok(proc) => {
                    guard.proc_ = Some(proc);
                    guard.restarts += 1;
                    Ok(())
                }
                Err(e) => Err(SandboxError::WorkerSpawnFailed(e.to_string())),
            }
        } else {
            Ok(())
        }
    }

    fn execute_inner(
        &self,
        record: IngestRecord,
        delay_ms: u64,
    ) -> Result<IngestRecord, SandboxError> {
        let mut guard = self.lock();
        self.ensure_worker(&mut guard)?;
        let proc = guard.proc_.as_mut().expect("worker ensured");

        let id = proc.next_id;
        proc.next_id += 1;
        let req = WorkerRequest {
            id,
            lane: record.lane.clone(),
            payload_hex: hex::encode(&record.payload),
            max_bytes: self.max_payload_bytes,
            delay_ms,
        };
        let mut frame =
            serde_json::to_vec(&req).map_err(|e| SandboxError::WorkerProtocol(e.to_string()))?;
        let mut prefixed = (frame.len() as u32).to_be_bytes().to_vec();
        prefixed.append(&mut frame);

        if proc.stdin.write_all(&prefixed).is_err() || proc.stdin.flush().is_err() {
            // Worker died mid-write: reap it so the next call respawns.
            let mut dead = guard.proc_.take().expect("worker ensured");
            let _ = dead.child.kill();
            let _ = dead.child.wait();
            return Err(SandboxError::WorkerCrashed {
                detail: "worker died while receiving request".to_string(),
            });
        }

        match proc.responses.recv_timeout(self.timeout) {
            Ok(Ok(resp)) => {
                if resp.id != id {
                    return Err(SandboxError::WorkerProtocol(format!(
                        "response id mismatch: expected {id}, got {}",
                        resp.id
                    )));
                }
                if resp.accepted {
                    let mut accepted = record;
                    accepted.status = crate::ingest::IngestStatus::Accepted;
                    Ok(accepted)
                } else {
                    Err(match resp.error.as_deref() {
                        Some("EmptyPayload") => SandboxError::EmptyPayload,
                        Some("PayloadTooLarge") => SandboxError::PayloadTooLarge {
                            max: self.max_payload_bytes,
                            actual: record.payload.len(),
                        },
                        Some(other) => SandboxError::WorkerProtocol(other.to_string()),
                        None => SandboxError::WorkerProtocol(
                            "worker rejected payload without a reason".to_string(),
                        ),
                    })
                }
            }
            Ok(Err(detail)) => {
                // Pump reported death/protocol break: reap so next call respawns.
                let mut dead = guard.proc_.take().expect("worker ensured");
                let _ = dead.child.kill();
                let _ = dead.child.wait();
                Err(SandboxError::WorkerCrashed { detail })
            }
            Err(_) => {
                // Timed out: the worker may be hung or exploited into a loop.
                // Kill it; the next call respawns a fresh one.
                let mut dead = guard.proc_.take().expect("worker ensured");
                let _ = dead.child.kill();
                let _ = dead.child.wait();
                Err(SandboxError::WorkerTimedOut {
                    after: self.timeout,
                })
            }
        }
    }

    /// Runs one containment check in the worker process.
    pub fn execute(&self, record: IngestRecord) -> Result<IngestRecord, SandboxError> {
        self.execute_inner(record, 0)
    }

    /// Test hook: asks the worker to sleep `delay_ms` before answering.
    /// Honored only when the worker runs with `LANE_WORKER_ALLOW_DELAY=1`
    /// (set by the backend solely under `cfg(test)`).
    #[cfg(test)]
    pub fn execute_with_delay(
        &self,
        record: IngestRecord,
        delay_ms: u64,
    ) -> Result<IngestRecord, SandboxError> {
        self.execute_inner(record, delay_ms)
    }
}

impl Drop for ProcessLaneBackend {
    fn drop(&mut self) {
        if let Ok(mut guard) = self.inner.lock() {
            if let Some(mut proc) = guard.proc_.take() {
                let _ = proc.child.kill();
                let _ = proc.child.wait();
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ingest::IngestStatus;

    fn test_backend() -> ProcessLaneBackend {
        ProcessLaneBackend::spawn(1_048_576, Duration::from_secs(10))
            .expect("worker should spawn in tests")
    }

    #[test]
    fn worker_reports_real_isolation_level() {
        let backend = test_backend();
        // This test runs on Linux in CI/dev; the level must be honest
        // about what the handshake reported, not assumed.
        let level = backend.isolation_level();
        if cfg!(target_os = "linux") {
            assert_eq!(level, IsolationLevel::ProcessWithLandlock);
        } else {
            assert_eq!(level, IsolationLevel::Process);
        }
    }

    #[test]
    fn isolated_verdicts_match_inprocess_verdicts() {
        use crate::sandbox::isolation::SandboxRunner;
        // Same size limit on both sides: the verdicts must agree exactly.
        let backend = ProcessLaneBackend::spawn(16, Duration::from_secs(10))
            .expect("worker should spawn in tests");
        let runner = SandboxRunner::new(16);

        let cases: Vec<Vec<u8>> = vec![
            vec![1, 2, 3],           // valid
            vec![],                  // empty -> reject
            vec![0u8; 17],           // oversized -> reject
            vec![0u8; 16],           // exactly at limit -> accept
            b"hello world".to_vec(), // valid
        ];
        for payload in cases {
            let expected = runner.execute(IngestRecord::new("MACK-01", payload.clone()));
            let actual = backend.execute(IngestRecord::new("MACK-01", payload));
            match (expected, actual) {
                (Ok(_), Ok(r)) => assert_eq!(r.status, IngestStatus::Accepted),
                (Err(e1), Err(e2)) => assert_eq!(
                    std::mem::discriminant(&e1),
                    std::mem::discriminant(&e2),
                    "verdict mismatch"
                ),
                (a, b) => panic!("verdict mismatch: {a:?} vs {b:?}"),
            }
        }
    }

    #[test]
    fn worker_death_between_requests_heals_transparently() {
        let backend = test_backend();
        let pid = backend.worker_pid().expect("worker pid");
        assert!(pid > 0);

        // Kill the worker between requests: the next execute must respawn
        // a fresh worker and succeed, with the restart counted for
        // observability — never hang, never silently skip the check.
        backend.kill_worker();

        let recovered = backend
            .execute(IngestRecord::new("MACK-01", vec![1, 2, 3]))
            .expect("respawned worker should accept");
        assert_eq!(recovered.status, IngestStatus::Accepted);
        assert!(backend.restarts() >= 1);
    }

    /// A worker that dies *during* a request must surface WorkerCrashed
    /// (fail-closed), not a hang and not a false accept.
    #[cfg(target_os = "linux")]
    #[test]
    fn worker_death_during_request_is_fail_closed() {
        let backend = ProcessLaneBackend::spawn(1_048_576, Duration::from_secs(30)).expect("spawn");
        let pid = backend.worker_pid().expect("worker pid");

        // SIGKILL the worker 200ms into a 3s delayed request, from outside
        // the backend (no mutex involved, so it lands mid-request).
        std::thread::spawn(move || {
            std::thread::sleep(Duration::from_millis(200));
            let _ = Command::new("kill").arg("-9").arg(pid.to_string()).output();
        });

        match backend.execute_with_delay(IngestRecord::new("MACK-01", vec![1, 2, 3]), 3000) {
            Err(SandboxError::WorkerCrashed { .. }) => {}
            other => panic!("expected WorkerCrashed, got {other:?}"),
        }

        // And the backend is usable again afterwards.
        let ok = backend
            .execute(IngestRecord::new("MACK-01", vec![1, 2, 3]))
            .expect("should recover after crash");
        assert_eq!(ok.status, IngestStatus::Accepted);
    }

    #[test]
    fn worker_timeout_kills_hung_worker() {
        let backend =
            ProcessLaneBackend::spawn(1_048_576, Duration::from_millis(300)).expect("spawn");
        match backend.execute_with_delay(IngestRecord::new("MACK-01", vec![1]), 10_000) {
            Err(SandboxError::WorkerTimedOut { .. }) => {}
            other => panic!("expected WorkerTimedOut, got {other:?}"),
        }
        // And the backend recovers on the next call.
        let ok = backend
            .execute(IngestRecord::new("MACK-01", vec![1]))
            .expect("should recover after timeout");
        assert_eq!(ok.status, IngestStatus::Accepted);
    }

    /// Elevation A3: the worker's seccomp profile must actually deny a
    /// forbidden syscall (socket creation) while the worker still
    /// operates — proven via the worker's own `--self-test-seccomp`
    /// mode — and every normally-spawned worker must report the
    /// profile active in its handshake (which also proves the normal
    /// request path works under the filter, via the other tests in
    /// this module that execute real payloads through it).
    #[test]
    fn seccomp_self_test_blocks_socket_and_worker_reports_profile() {
        let path = find_worker_binary().expect("worker binary");
        let out = Command::new(&path)
            .arg("--self-test-seccomp")
            .output()
            .expect("seccomp self-test run");
        let stdout = String::from_utf8_lossy(&out.stdout);
        if cfg!(target_os = "linux") {
            assert!(out.status.success(), "seccomp self-test failed: {stdout}");
            assert!(
                stdout.contains(r#""socket_blocked":true"#),
                "filtered worker could still create sockets: {stdout}"
            );
            let backend = test_backend();
            assert!(
                backend.seccomp_active(),
                "spawned worker did not report an active seccomp profile"
            );
        }
    }

    /// Elevation A4: the spawned worker must actually run under the
    /// backend's rlimits — read the kernel's own report for the live
    /// worker PID (`/proc/<pid>/limits`) and compare all three values.
    #[cfg(target_os = "linux")]
    #[test]
    fn worker_runs_under_lane_rlimits() {
        let backend = test_backend();
        let pid = backend.worker_pid().expect("worker pid");
        let limits = backend.limits();
        let report = std::fs::read_to_string(format!("/proc/{pid}/limits"))
            .expect("kernel limits report for the live worker");
        let line_value = |name: &str| -> u64 {
            report
                .lines()
                .find(|l| l.starts_with(name))
                .unwrap_or_else(|| panic!("{name} missing from /proc limits:\n{report}"))
                .split_whitespace()
                .nth(3)
                .and_then(|v| v.parse::<u64>().ok())
                .unwrap_or_else(|| panic!("{name} value not numeric in /proc limits"))
        };
        assert_eq!(line_value("Max cpu time"), limits.cpu_seconds);
        assert_eq!(line_value("Max address space"), limits.address_space_bytes);
        assert_eq!(line_value("Max open files"), limits.open_files);
        // And the limited worker still does its job.
        let ok = backend
            .execute(IngestRecord::new("MACK-01", vec![1, 2, 3]))
            .expect("limited worker should accept");
        assert_eq!(ok.status, IngestStatus::Accepted);
    }

    #[test]
    fn landlock_self_test_blocks_filesystem() {
        let path = find_worker_binary().expect("worker binary");
        let out = Command::new(&path)
            .arg("--self-test")
            .output()
            .expect("self-test run");
        let stdout = String::from_utf8_lossy(&out.stdout);
        if cfg!(target_os = "linux") {
            assert!(out.status.success(), "self-test failed: {stdout}");
            assert!(
                stdout.contains(r#""fs_blocked":true"#),
                "worker could still read the filesystem: {stdout}"
            );
        }
    }

    #[test]
    fn missing_worker_binary_is_an_honest_error() {
        let bogus = PathBuf::from("/nonexistent/lane_worker_xyz");
        match ProcessLaneBackend::spawn_with_path(bogus, 1024, Duration::from_secs(5)) {
            Err(IsolationError::WorkerNotFound(_)) => {}
            other => panic!("expected WorkerNotFound, got {other:?}"),
        }
    }
}
