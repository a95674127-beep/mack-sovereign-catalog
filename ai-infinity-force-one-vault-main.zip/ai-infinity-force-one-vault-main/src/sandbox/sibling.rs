//! Dependency-free sibling-ring ownership model.
//!
//! This module is a deterministic in-process model, not a distributed lock
//! service. In production, fencing tokens must also be enforced by the system
//! that commits side effects, and ownership state must be coordinated durably.

use std::collections::BTreeMap;

pub const DEFAULT_LANE_CAPACITY: u8 = 12;
pub const MAX_LEASE_TTL_MS: u64 = 30_000;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum RingId {
    Alpha,
    Beta,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RingHealth {
    Healthy,
    Suspect,
    Partitioned,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CapacityLease {
    pub task_id: String,
    pub owner: RingId,
    pub lanes: u8,
    pub fencing_token: u64,
    pub expires_at_ms: u64,
    pub idempotency_key: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LeaseError {
    EmptyTaskId,
    EmptyIdempotencyKey,
    InvalidLaneCount,
    InvalidTtl,
    ClockOverflow,
    OwnershipConflict {
        current_owner: RingId,
        expires_at_ms: u64,
    },
    UnhealthyRequester,
    StaleFencingToken {
        current: u64,
        supplied: u64,
    },
    UnknownTask,
}

#[derive(Debug, Clone)]
pub struct SiblingOwnership {
    health: BTreeMap<RingId, RingHealth>,
    leases: BTreeMap<String, CapacityLease>,
    next_fencing_token: u64,
    lane_capacity: u8,
}

impl Default for SiblingOwnership {
    fn default() -> Self {
        Self::new(DEFAULT_LANE_CAPACITY)
    }
}

impl SiblingOwnership {
    pub fn new(lane_capacity: u8) -> Self {
        let mut health = BTreeMap::new();
        health.insert(RingId::Alpha, RingHealth::Healthy);
        health.insert(RingId::Beta, RingHealth::Healthy);
        Self {
            health,
            leases: BTreeMap::new(),
            next_fencing_token: 1,
            lane_capacity: lane_capacity.min(DEFAULT_LANE_CAPACITY),
        }
    }

    pub fn set_health(&mut self, ring: RingId, health: RingHealth) {
        self.health.insert(ring, health);
    }

    pub fn health(&self, ring: RingId) -> RingHealth {
        self.health
            .get(&ring)
            .copied()
            .unwrap_or(RingHealth::Partitioned)
    }

    /// Request or idempotently repeat a lease. A live lease held by another
    /// ring is never silently stolen, even when that ring is marked suspect.
    pub fn request_lease(
        &mut self,
        requester: RingId,
        task_id: &str,
        idempotency_key: &str,
        lanes: u8,
        now_ms: u64,
        ttl_ms: u64,
    ) -> Result<CapacityLease, LeaseError> {
        if task_id.trim().is_empty() {
            return Err(LeaseError::EmptyTaskId);
        }
        if idempotency_key.trim().is_empty() {
            return Err(LeaseError::EmptyIdempotencyKey);
        }
        if lanes == 0 || lanes > self.lane_capacity {
            return Err(LeaseError::InvalidLaneCount);
        }
        if ttl_ms == 0 || ttl_ms > MAX_LEASE_TTL_MS {
            return Err(LeaseError::InvalidTtl);
        }
        let expires_at_ms = now_ms
            .checked_add(ttl_ms)
            .ok_or(LeaseError::ClockOverflow)?;
        if self.health(requester) != RingHealth::Healthy {
            return Err(LeaseError::UnhealthyRequester);
        }

        if let Some(existing) = self.leases.get(task_id) {
            if existing.expires_at_ms > now_ms {
                if existing.owner == requester
                    && existing.idempotency_key == idempotency_key
                    && existing.lanes == lanes
                {
                    return Ok(existing.clone());
                }
                return Err(LeaseError::OwnershipConflict {
                    current_owner: existing.owner,
                    expires_at_ms: existing.expires_at_ms,
                });
            }
        }

        let token = self.next_fencing_token;
        self.next_fencing_token = self
            .next_fencing_token
            .checked_add(1)
            .ok_or(LeaseError::ClockOverflow)?;
        let lease = CapacityLease {
            task_id: task_id.to_owned(),
            owner: requester,
            lanes,
            fencing_token: token,
            expires_at_ms,
            idempotency_key: idempotency_key.to_owned(),
        };
        self.leases.insert(task_id.to_owned(), lease.clone());
        Ok(lease)
    }

    /// Validate a write at the resource boundary. Expired or stale tokens fail closed.
    pub fn authorize_commit(
        &self,
        task_id: &str,
        owner: RingId,
        fencing_token: u64,
        now_ms: u64,
    ) -> Result<(), LeaseError> {
        let lease = self.leases.get(task_id).ok_or(LeaseError::UnknownTask)?;
        if lease.expires_at_ms <= now_ms {
            return Err(LeaseError::OwnershipConflict {
                current_owner: lease.owner,
                expires_at_ms: lease.expires_at_ms,
            });
        }
        if lease.fencing_token != fencing_token || lease.owner != owner {
            return Err(LeaseError::StaleFencingToken {
                current: lease.fencing_token,
                supplied: fencing_token,
            });
        }
        if self.health(owner) != RingHealth::Healthy {
            return Err(LeaseError::UnhealthyRequester);
        }
        Ok(())
    }

    pub fn lease(&self, task_id: &str) -> Option<&CapacityLease> {
        self.leases.get(task_id)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn grants_bounded_lease_and_authorizes_current_owner() {
        let mut mesh = SiblingOwnership::default();
        let lease = mesh
            .request_lease(RingId::Alpha, "task-1", "idem-1", 4, 100, 500)
            .expect("valid lease");
        assert_eq!(lease.lanes, 4);
        assert_eq!(
            mesh.authorize_commit("task-1", RingId::Alpha, lease.fencing_token, 200),
            Ok(())
        );
    }

    #[test]
    fn live_lease_cannot_be_stolen_by_sibling() {
        let mut mesh = SiblingOwnership::default();
        mesh.request_lease(RingId::Alpha, "task-1", "idem-1", 2, 100, 500)
            .unwrap();
        assert!(matches!(
            mesh.request_lease(RingId::Beta, "task-1", "idem-2", 2, 200, 500),
            Err(LeaseError::OwnershipConflict {
                current_owner: RingId::Alpha,
                ..
            })
        ));
    }

    #[test]
    fn identical_request_is_idempotent() {
        let mut mesh = SiblingOwnership::default();
        let first = mesh
            .request_lease(RingId::Alpha, "task-1", "idem-1", 2, 100, 500)
            .unwrap();
        let repeated = mesh
            .request_lease(RingId::Alpha, "task-1", "idem-1", 2, 200, 500)
            .unwrap();
        assert_eq!(first, repeated);
    }

    #[test]
    fn expired_lease_reassignment_increments_fencing_token() {
        let mut mesh = SiblingOwnership::default();
        let first = mesh
            .request_lease(RingId::Alpha, "task-1", "idem-1", 2, 100, 100)
            .unwrap();
        let second = mesh
            .request_lease(RingId::Beta, "task-1", "idem-2", 2, 200, 100)
            .unwrap();
        assert!(second.fencing_token > first.fencing_token);
        assert!(matches!(
            mesh.authorize_commit("task-1", RingId::Alpha, first.fencing_token, 201),
            Err(LeaseError::StaleFencingToken { .. })
        ));
    }

    #[test]
    fn unhealthy_ring_cannot_request_or_commit() {
        let mut mesh = SiblingOwnership::default();
        mesh.set_health(RingId::Beta, RingHealth::Suspect);
        assert_eq!(
            mesh.request_lease(RingId::Beta, "task-1", "idem-1", 1, 0, 10),
            Err(LeaseError::UnhealthyRequester)
        );
    }

    #[test]
    fn rejects_unbounded_requests() {
        let mut mesh = SiblingOwnership::default();
        assert_eq!(
            mesh.request_lease(RingId::Alpha, "task-1", "idem-1", 13, 0, 10),
            Err(LeaseError::InvalidLaneCount)
        );
        assert_eq!(
            mesh.request_lease(
                RingId::Alpha,
                "task-1",
                "idem-1",
                1,
                0,
                MAX_LEASE_TTL_MS + 1
            ),
            Err(LeaseError::InvalidTtl)
        );
    }
}
