//! sandbox::lanes — 12-Lane Containment Engine with Automated Quarantine Backoff (Milestone 1).
//!
//! Patent Claim #1 / MACK-STACK-01:
//! 12-lane containment sandbox with per-process/thread isolation, zero cross-contamination
//! (MACK-01 through MACK-12), and automated quarantine exponential backoff (1s, 2s, 4s).

use crate::ingest::IngestRecord;
use crate::sandbox::isolation::{SandboxError, SandboxRunner};
use crate::sandbox::process::{IsolationError, IsolationLevel, ProcessLaneBackend};
use crate::sandbox::sibling::{CapacityLease, LeaseError, RingHealth, RingId, SiblingOwnership};
use std::collections::HashMap;
use std::sync::{Mutex, MutexGuard};
use std::time::{Duration, Instant};

/// Locks a mutex, recovering the guard when a previous holder panicked
/// while holding it. Same policy as the audit ledger's
/// `ConcurrentLedger` (src/vault/audit.rs): one panicked task must not
/// wedge every other caller behind a poisoned lock.
fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
    mutex
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

/// Canonical MACK Stack Lane Identifier.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum LaneId {
    Mack01Propulsion,
    Mack02NavLidar,
    Mack03FlightController,
    Mack04AiCore,
    Mack05PowerMgmt,
    Mack06Comms,
    Mack07SensorFusion,
    Mack08Thermal,
    Mack09Structural,
    Mack10Payload,
    Mack11Telemetry,
    Mack12Failsafe,
}

impl LaneId {
    pub const ALL_LANES: [LaneId; 12] = [
        LaneId::Mack01Propulsion,
        LaneId::Mack02NavLidar,
        LaneId::Mack03FlightController,
        LaneId::Mack04AiCore,
        LaneId::Mack05PowerMgmt,
        LaneId::Mack06Comms,
        LaneId::Mack07SensorFusion,
        LaneId::Mack08Thermal,
        LaneId::Mack09Structural,
        LaneId::Mack10Payload,
        LaneId::Mack11Telemetry,
        LaneId::Mack12Failsafe,
    ];

    pub fn code(&self) -> &'static str {
        match self {
            LaneId::Mack01Propulsion => "MACK-01",
            LaneId::Mack02NavLidar => "MACK-02",
            LaneId::Mack03FlightController => "MACK-03",
            LaneId::Mack04AiCore => "MACK-04",
            LaneId::Mack05PowerMgmt => "MACK-05",
            LaneId::Mack06Comms => "MACK-06",
            LaneId::Mack07SensorFusion => "MACK-07",
            LaneId::Mack08Thermal => "MACK-08",
            LaneId::Mack09Structural => "MACK-09",
            LaneId::Mack10Payload => "MACK-10",
            LaneId::Mack11Telemetry => "MACK-11",
            LaneId::Mack12Failsafe => "MACK-12",
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            LaneId::Mack01Propulsion => "propulsion",
            LaneId::Mack02NavLidar => "nav_lidar",
            LaneId::Mack03FlightController => "flight_controller",
            LaneId::Mack04AiCore => "ai_core",
            LaneId::Mack05PowerMgmt => "power_mgmt",
            LaneId::Mack06Comms => "comms",
            LaneId::Mack07SensorFusion => "sensor_fusion",
            LaneId::Mack08Thermal => "thermal",
            LaneId::Mack09Structural => "structural",
            LaneId::Mack10Payload => "payload",
            LaneId::Mack11Telemetry => "telemetry",
            LaneId::Mack12Failsafe => "failsafe",
        }
    }

    pub fn from_index(index: usize) -> Option<Self> {
        Self::ALL_LANES.get(index).copied()
    }

    pub fn from_str_lenient(s: &str) -> Option<Self> {
        for lane in Self::ALL_LANES.iter() {
            if s.eq_ignore_ascii_case(lane.code()) || s.eq_ignore_ascii_case(lane.label()) {
                return Some(*lane);
            }
        }
        None
    }
}

/// Status of an individual execution lane.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LaneStatus {
    Green,
    Quarantined {
        backoff_level: u8,
        remaining: Duration,
    },
    TerminalLockout,
}

/// How a lane executes its containment check.
#[derive(Debug)]
enum LaneRunner {
    /// Same-process checks (original behavior; fastest).
    InProcess(SandboxRunner),
    /// Separate OS worker process, Landlock-confined on Linux.
    Isolated(ProcessLaneBackend),
}

impl LaneRunner {
    fn execute(&self, record: IngestRecord) -> Result<IngestRecord, SandboxError> {
        match self {
            LaneRunner::InProcess(r) => r.execute(record),
            LaneRunner::Isolated(b) => b.execute(record),
        }
    }

    fn isolation_level(&self) -> IsolationLevel {
        match self {
            LaneRunner::InProcess(_) => IsolationLevel::InProcess,
            LaneRunner::Isolated(b) => b.isolation_level(),
        }
    }
}

/// Per-lane isolation runtime state.
#[derive(Debug)]
struct LaneState {
    runner: LaneRunner,
    consecutive_failures: u32,
    quarantine_until: Option<Instant>,
    total_processed: u64,
    total_rejected: u64,
}

impl LaneState {
    fn new(max_payload_bytes: usize) -> Self {
        Self {
            runner: LaneRunner::InProcess(SandboxRunner::new(max_payload_bytes)),
            consecutive_failures: 0,
            quarantine_until: None,
            total_processed: 0,
            total_rejected: 0,
        }
    }

    fn new_isolated(backend: ProcessLaneBackend) -> Self {
        Self {
            runner: LaneRunner::Isolated(backend),
            consecutive_failures: 0,
            quarantine_until: None,
            total_processed: 0,
            total_rejected: 0,
        }
    }

    /// Check if lane is currently quarantined.
    fn check_quarantine(&mut self, now: Instant) -> Option<Duration> {
        if let Some(until) = self.quarantine_until {
            if now < until {
                Some(until.duration_since(now))
            } else {
                self.quarantine_until = None;
                None
            }
        } else {
            None
        }
    }

    /// Calculate backoff duration: 1s -> 2s -> 4s (or cap at 8s/terminal).
    fn backoff_duration(level: u32) -> Duration {
        match level {
            1 => Duration::from_secs(1),
            2 => Duration::from_secs(2),
            3 => Duration::from_secs(4),
            _ => Duration::from_secs(8),
        }
    }

    fn record_failure(&mut self, now: Instant) -> Duration {
        self.consecutive_failures += 1;
        self.total_rejected += 1;
        let dur = Self::backoff_duration(self.consecutive_failures);
        self.quarantine_until = Some(now + dur);
        dur
    }

    fn record_success(&mut self) {
        self.consecutive_failures = 0;
        self.quarantine_until = None;
        self.total_processed += 1;
    }
}

/// The 12-Lane Containment Engine managing isolated sandboxes.
pub struct LaneContainmentEngine {
    lanes: Mutex<HashMap<LaneId, LaneState>>,
    _max_payload_bytes: usize,
    /// Optional sibling-ring ownership gate (see `crate::sandbox::sibling`).
    /// `None` unless built with `new_with_ownership`; existing constructors
    /// leave it disabled and behavior is unchanged.
    ownership: Option<Mutex<SiblingOwnership>>,
}

impl LaneContainmentEngine {
    pub fn new(max_payload_bytes: usize) -> Self {
        let mut map = HashMap::new();
        for &lane in &LaneId::ALL_LANES {
            map.insert(lane, LaneState::new(max_payload_bytes));
        }
        Self {
            lanes: Mutex::new(map),
            _max_payload_bytes: max_payload_bytes,
            ownership: None,
        }
    }

    /// Builds an engine with the sibling-ring ownership model enabled.
    ///
    /// Ownership is opt-in: engines built with `new` / `new_isolated`
    /// behave exactly as before. With ownership enabled, the leased
    /// execution path (`execute_lane_leased`) refuses to run a task
    /// unless the requesting ring holds a live capacity lease for it,
    /// and re-validates the lease's fencing token before the result is
    /// released — the in-process analogue of enforcing fencing at the
    /// resource that commits side effects. The model is in-memory only;
    /// see `crate::sandbox::sibling` for its stated limits.
    pub fn new_with_ownership(max_payload_bytes: usize) -> Self {
        let mut engine = Self::new(max_payload_bytes);
        engine.ownership = Some(Mutex::new(SiblingOwnership::default()));
        engine
    }

    /// Whether the sibling ownership gate is enabled on this engine.
    pub fn ownership_enabled(&self) -> bool {
        self.ownership.is_some()
    }

    /// Executes an ingest payload within a specific isolated lane.
    /// Returns Ok(IngestRecord) if execution passes containment,
    /// or Err(SandboxError) if rejected / quarantined.
    pub fn execute_lane(
        &self,
        lane_id: LaneId,
        record: IngestRecord,
    ) -> Result<IngestRecord, LaneExecutionError> {
        let now = Instant::now();
        let mut map = lock(&self.lanes);
        let state = map
            .get_mut(&lane_id)
            .expect("Lane must exist in 12-lane engine");

        // 1. Check if lane is in active quarantine backoff
        if let Some(remaining) = state.check_quarantine(now) {
            return Err(LaneExecutionError::LaneQuarantined {
                lane: lane_id,
                consecutive_failures: state.consecutive_failures,
                remaining,
            });
        }

        // 2. Execute within the lane's isolated sandbox runner
        match state.runner.execute(record) {
            Ok(passed_record) => {
                state.record_success();
                Ok(passed_record)
            }
            Err(err) => {
                let backoff = state.record_failure(now);
                Err(LaneExecutionError::SandboxViolation {
                    lane: lane_id,
                    error: err,
                    backoff_applied: backoff,
                })
            }
        }
    }

    /// Executes a record in a lane under a sibling-ring capacity lease.
    ///
    /// The requesting ring must first obtain a one-lane lease for the
    /// task from the ownership model; a live lease held by the sibling
    /// ring, an unhealthy requester, or an out-of-bounds request is
    /// denied before any lane runs. After execution, the lease's fencing
    /// token is re-validated (`authorize_commit`) at the same logical
    /// instant (`request.now_ms`), and the passed record is released
    /// only if the caller still owns the task. Callers supply `now_ms`
    /// so lease timing stays deterministic and testable; it must be the
    /// caller's current wall-clock time in milliseconds.
    ///
    /// Requires an engine built with `new_with_ownership`.
    pub fn execute_lane_leased(
        &self,
        request: LeaseRequest<'_>,
        lane_id: LaneId,
        record: IngestRecord,
    ) -> Result<IngestRecord, LeasedExecutionError> {
        let ownership = self
            .ownership
            .as_ref()
            .ok_or(LeasedExecutionError::OwnershipNotEnabled)?;
        let lease = {
            let mut guard = lock(ownership);
            guard.request_lease(
                request.ring,
                request.task_id,
                request.idempotency_key,
                1,
                request.now_ms,
                request.ttl_ms,
            )?
        };
        let passed = self.execute_lane(lane_id, record)?;
        let guard = lock(ownership);
        guard.authorize_commit(
            request.task_id,
            request.ring,
            lease.fencing_token,
            request.now_ms,
        )?;
        Ok(passed)
    }

    /// Re-validate a lease at a commit boundary without executing a lane.
    /// Fails closed on expired leases, stale fencing tokens, wrong owner,
    /// or an unhealthy ring. Requires ownership to be enabled.
    pub fn validate_commit(
        &self,
        task_id: &str,
        ring: RingId,
        fencing_token: u64,
        now_ms: u64,
    ) -> Result<(), LeasedExecutionError> {
        let ownership = self
            .ownership
            .as_ref()
            .ok_or(LeasedExecutionError::OwnershipNotEnabled)?;
        let guard = lock(ownership);
        guard.authorize_commit(task_id, ring, fencing_token, now_ms)?;
        Ok(())
    }

    /// Set a ring's health in the ownership model (no-op when the
    /// ownership gate is not enabled on this engine).
    pub fn set_ring_health(&self, ring: RingId, health: RingHealth) {
        if let Some(ownership) = &self.ownership {
            lock(ownership).set_health(ring, health);
        }
    }

    /// A ring's current health, or `None` when ownership is not enabled.
    pub fn ring_health(&self, ring: RingId) -> Option<RingHealth> {
        self.ownership
            .as_ref()
            .map(|ownership| lock(ownership).health(ring))
    }

    /// The current lease recorded for a task, if any.
    pub fn lease_for(&self, task_id: &str) -> Option<CapacityLease> {
        self.ownership
            .as_ref()
            .and_then(|ownership| lock(ownership).lease(task_id).cloned())
    }

    /// Inspect the status of a specific lane.
    pub fn lane_status(&self, lane_id: LaneId) -> LaneStatus {
        let now = Instant::now();
        let mut map = lock(&self.lanes);
        let state = map.get_mut(&lane_id).expect("Lane must exist");

        if let Some(remaining) = state.check_quarantine(now) {
            LaneStatus::Quarantined {
                backoff_level: state.consecutive_failures as u8,
                remaining,
            }
        } else {
            LaneStatus::Green
        }
    }

    /// Reset quarantine for a specific lane (e.g. administrative re-clear).
    pub fn clear_lane_quarantine(&self, lane_id: LaneId) {
        let mut map = lock(&self.lanes);
        if let Some(state) = map.get_mut(&lane_id) {
            state.consecutive_failures = 0;
            state.quarantine_until = None;
        }
    }

    /// Total count of lanes configured (guaranteed 12).
    pub fn lane_count(&self) -> usize {
        12
    }

    /// Builds an engine whose lanes execute containment checks in separate
    /// OS worker processes (Landlock-confined on Linux) instead of
    /// in-process. Spawning can fail (missing worker binary, sandbox
    /// unavailable); that failure is returned, never silently downgraded
    /// to in-process execution.
    pub fn new_isolated(
        max_payload_bytes: usize,
        worker_timeout: Duration,
    ) -> Result<Self, IsolationError> {
        let mut map = HashMap::new();
        for &lane in &LaneId::ALL_LANES {
            let backend = ProcessLaneBackend::spawn(max_payload_bytes, worker_timeout)?;
            map.insert(lane, LaneState::new_isolated(backend));
        }
        Ok(Self {
            lanes: Mutex::new(map),
            _max_payload_bytes: max_payload_bytes,
            ownership: None,
        })
    }

    /// The isolation level actually in effect for a lane, as reported by
    /// the worker handshake — not assumed.
    pub fn lane_isolation_level(&self, lane_id: LaneId) -> IsolationLevel {
        let map = lock(&self.lanes);
        let state = map.get(&lane_id).expect("Lane must exist");
        state.runner.isolation_level()
    }
}

impl Default for LaneContainmentEngine {
    fn default() -> Self {
        Self::new(1_048_576) // 1 MB default
    }
}

#[derive(Debug)]
pub enum LaneExecutionError {
    LaneQuarantined {
        lane: LaneId,
        consecutive_failures: u32,
        remaining: Duration,
    },
    SandboxViolation {
        lane: LaneId,
        error: SandboxError,
        backoff_applied: Duration,
    },
}

impl std::fmt::Display for LaneExecutionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            LaneExecutionError::LaneQuarantined {
                lane,
                consecutive_failures,
                remaining,
            } => {
                write!(
                    f,
                    "Lane {} quarantined (level {}) - remaining {:?}",
                    lane.code(),
                    consecutive_failures,
                    remaining
                )
            }
            LaneExecutionError::SandboxViolation {
                lane,
                error,
                backoff_applied,
            } => {
                write!(
                    f,
                    "Lane {} sandbox violation: {:?} (backoff: {:?})",
                    lane.code(),
                    error,
                    backoff_applied
                )
            }
        }
    }
}

impl std::error::Error for LaneExecutionError {}

/// Parameters for a leased lane execution (`execute_lane_leased`).
#[derive(Debug, Clone, Copy)]
pub struct LeaseRequest<'a> {
    /// The ring requesting ownership of the task.
    pub ring: RingId,
    /// Task identifier the lease is taken on.
    pub task_id: &'a str,
    /// Idempotency key: repeating a request with the same key, lane
    /// count, and owner returns the existing lease instead of failing.
    pub idempotency_key: &'a str,
    /// The caller's current wall-clock time in milliseconds.
    pub now_ms: u64,
    /// Lease time-to-live in milliseconds (bounded by the model).
    pub ttl_ms: u64,
}

/// Error returned by the leased execution path (`execute_lane_leased`
/// and `validate_commit` on `LaneContainmentEngine`).
#[derive(Debug)]
pub enum LeasedExecutionError {
    /// The engine was built without the ownership gate enabled.
    OwnershipNotEnabled,
    /// The lane execution itself failed (quarantine or sandbox violation).
    Lane(LaneExecutionError),
    /// The sibling ownership model denied the lease or the commit.
    Lease(LeaseError),
}

impl std::fmt::Display for LeasedExecutionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            LeasedExecutionError::OwnershipNotEnabled => {
                write!(f, "sibling ownership gate is not enabled on this engine")
            }
            LeasedExecutionError::Lane(err) => write!(f, "lane execution failed: {}", err),
            LeasedExecutionError::Lease(err) => write!(f, "ownership denied: {:?}", err),
        }
    }
}

impl std::error::Error for LeasedExecutionError {}

impl From<LaneExecutionError> for LeasedExecutionError {
    fn from(err: LaneExecutionError) -> Self {
        LeasedExecutionError::Lane(err)
    }
}

impl From<LeaseError> for LeasedExecutionError {
    fn from(err: LeaseError) -> Self {
        LeasedExecutionError::Lease(err)
    }
}

#[cfg(test)]
mod leased_execution_tests {
    use super::*;

    fn record(lane: LaneId) -> IngestRecord {
        IngestRecord::new(lane.code(), b"valid payload".to_vec())
    }

    fn req(
        ring: RingId,
        task_id: &'static str,
        key: &'static str,
        now_ms: u64,
        ttl_ms: u64,
    ) -> LeaseRequest<'static> {
        LeaseRequest {
            ring,
            task_id,
            idempotency_key: key,
            now_ms,
            ttl_ms,
        }
    }

    #[test]
    fn leased_execution_succeeds_for_lease_holder() {
        let engine = LaneContainmentEngine::new_with_ownership(1_048_576);
        let lane = LaneId::Mack04AiCore;
        let passed = engine
            .execute_lane_leased(
                req(RingId::Alpha, "task-1", "idem-1", 1_000, 500),
                lane,
                record(lane),
            )
            .expect("lease holder executes");
        assert_eq!(passed.payload, b"valid payload".to_vec());
        let lease = engine.lease_for("task-1").expect("lease recorded");
        assert_eq!(lease.owner, RingId::Alpha);
    }

    #[test]
    fn leased_execution_denied_while_sibling_holds_live_lease() {
        let engine = LaneContainmentEngine::new_with_ownership(1_048_576);
        let lane = LaneId::Mack04AiCore;
        engine
            .execute_lane_leased(
                req(RingId::Alpha, "task-1", "idem-1", 1_000, 500),
                lane,
                record(lane),
            )
            .unwrap();
        let denied = engine.execute_lane_leased(
            req(RingId::Beta, "task-1", "idem-2", 1_100, 500),
            lane,
            record(lane),
        );
        assert!(matches!(
            denied,
            Err(LeasedExecutionError::Lease(LeaseError::OwnershipConflict {
                current_owner: RingId::Alpha,
                ..
            }))
        ));
    }

    #[test]
    fn sibling_takes_over_after_expiry_and_stale_commit_fails() {
        let engine = LaneContainmentEngine::new_with_ownership(1_048_576);
        let lane = LaneId::Mack07SensorFusion;
        engine
            .execute_lane_leased(
                req(RingId::Alpha, "task-9", "idem-1", 100, 100),
                lane,
                record(lane),
            )
            .unwrap();
        let stale_token = engine.lease_for("task-9").unwrap().fencing_token;

        // Lease expired at t=200; the sibling takes over at t=250.
        engine
            .execute_lane_leased(
                req(RingId::Beta, "task-9", "idem-2", 250, 100),
                lane,
                record(lane),
            )
            .expect("sibling takes over after expiry");
        let current_token = engine.lease_for("task-9").unwrap().fencing_token;
        assert!(current_token > stale_token);

        // The previous owner's token no longer authorizes a commit.
        assert!(matches!(
            engine.validate_commit("task-9", RingId::Alpha, stale_token, 260),
            Err(LeasedExecutionError::Lease(
                LeaseError::StaleFencingToken { .. }
            ))
        ));
        // The current owner's token does.
        assert!(engine
            .validate_commit("task-9", RingId::Beta, current_token, 260)
            .is_ok());
    }

    #[test]
    fn unhealthy_ring_cannot_execute_leased() {
        let engine = LaneContainmentEngine::new_with_ownership(1_048_576);
        let lane = LaneId::Mack11Telemetry;
        engine.set_ring_health(RingId::Beta, RingHealth::Suspect);
        let denied = engine.execute_lane_leased(
            req(RingId::Beta, "task-1", "idem-1", 0, 100),
            lane,
            record(lane),
        );
        assert!(matches!(
            denied,
            Err(LeasedExecutionError::Lease(LeaseError::UnhealthyRequester))
        ));
    }

    #[test]
    fn leased_execution_requires_ownership_enabled() {
        let engine = LaneContainmentEngine::new(1_048_576);
        let lane = LaneId::Mack01Propulsion;
        let denied = engine.execute_lane_leased(
            req(RingId::Alpha, "task-1", "idem-1", 0, 100),
            lane,
            record(lane),
        );
        assert!(matches!(
            denied,
            Err(LeasedExecutionError::OwnershipNotEnabled)
        ));
    }
}
