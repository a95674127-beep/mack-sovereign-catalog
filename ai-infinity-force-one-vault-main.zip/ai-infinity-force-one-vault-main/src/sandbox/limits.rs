// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! sandbox::limits — per-lane resource limits (rlimits) for worker
//! processes (Elevation A4, 2026-11-10).
//!
//! Every lane worker is spawned with three rlimits applied in the
//! child between fork and exec (`Command::pre_exec`), so the limits
//! are in force before a single byte of worker code runs:
//!
//! - `RLIMIT_CPU` — wall of CPU seconds; a worker that burns past it
//!   is killed by the kernel instead of spinning forever.
//! - `RLIMIT_AS` — address-space ceiling; a worker whose memory blows
//!   up fails its allocations instead of taking the host down with it.
//! - `RLIMIT_NOFILE` — descriptor ceiling; the worker needs only its
//!   three inherited stdio descriptors, so a small cap suffices.
//!
//! Fail-closed contract: if any `setrlimit` call fails, `enforce`
//! returns the error, `pre_exec` fails, and the spawn itself fails —
//! the backend surfaces `IsolationError::SpawnFailed` and no
//! unlimited worker ever runs.
//!
//! Values are configurable through [`LaneLimits::resolved`], which
//! reads `MACK_LANE_CPU_SECONDS`, `MACK_LANE_ADDRESS_SPACE_BYTES`, and
//! `MACK_LANE_OPEN_FILES` (invalid or missing values fall back to the
//! defaults below).

use std::io;

/// Resource ceilings for one lane worker process.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct LaneLimits {
    /// `RLIMIT_CPU`: maximum CPU seconds before the kernel kills the
    /// worker (SIGXCPU, then SIGKILL at the hard limit — both are set
    /// to the same value).
    pub cpu_seconds: u64,
    /// `RLIMIT_AS`: maximum virtual address space, in bytes.
    pub address_space_bytes: u64,
    /// `RLIMIT_NOFILE`: maximum number of open file descriptors.
    pub open_files: u64,
}

impl Default for LaneLimits {
    fn default() -> Self {
        Self {
            cpu_seconds: 300,
            address_space_bytes: 1 << 30, // 1 GiB
            open_files: 256,
        }
    }
}

impl LaneLimits {
    /// The limits to spawn with: defaults overridden by the
    /// `MACK_LANE_*` environment variables when they parse as `u64`.
    pub fn resolved() -> Self {
        Self::from_env(|k| std::env::var(k).ok())
    }

    /// Testable core of [`LaneLimits::resolved`]: `get` supplies
    /// variable values by name.
    pub fn from_env(get: impl Fn(&str) -> Option<String>) -> Self {
        let mut limits = Self::default();
        if let Some(v) = get("MACK_LANE_CPU_SECONDS")
            .and_then(|s| s.parse::<u64>().ok())
            .filter(|&v| v > 0)
        {
            limits.cpu_seconds = v;
        }
        if let Some(v) = get("MACK_LANE_ADDRESS_SPACE_BYTES")
            .and_then(|s| s.parse::<u64>().ok())
            .filter(|&v| v > 0)
        {
            limits.address_space_bytes = v;
        }
        if let Some(v) = get("MACK_LANE_OPEN_FILES")
            .and_then(|s| s.parse::<u64>().ok())
            .filter(|&v| v > 0)
        {
            limits.open_files = v;
        }
        limits
    }

    /// Applies all three limits to the *current* process. Called from
    /// the child's `pre_exec` hook, i.e. after fork and before exec,
    /// so in practice it only ever runs inside a freshly-spawned
    /// worker. Fail-closed: the first failing `setrlimit` aborts.
    #[cfg(target_os = "linux")]
    pub fn enforce(&self) -> io::Result<()> {
        set_one(libc::RLIMIT_CPU, self.cpu_seconds)?;
        set_one(libc::RLIMIT_AS, self.address_space_bytes)?;
        set_one(libc::RLIMIT_NOFILE, self.open_files)?;
        Ok(())
    }

    /// Non-Linux: no rlimit mechanism is wired up; spawning behaves
    /// as before (Landlock and seccomp are likewise Linux-only).
    #[cfg(not(target_os = "linux"))]
    pub fn enforce(&self) -> io::Result<()> {
        Ok(())
    }
}

#[cfg(target_os = "linux")]
fn set_one(resource: libc::__rlimit_resource_t, value: u64) -> io::Result<()> {
    let lim = libc::rlimit {
        rlim_cur: value,
        rlim_max: value,
    };
    // SAFETY: setrlimit with a valid resource constant and a pointer
    // to a live rlimit struct; the struct outlives the call.
    let rc = unsafe { libc::setrlimit(resource, &lim) };
    if rc != 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults_are_the_documented_values() {
        let d = LaneLimits::default();
        assert_eq!(d.cpu_seconds, 300);
        assert_eq!(d.address_space_bytes, 1 << 30);
        assert_eq!(d.open_files, 256);
    }

    #[test]
    fn env_overrides_parse_and_invalid_values_fall_back() {
        let limits = LaneLimits::from_env(|k| match k {
            "MACK_LANE_CPU_SECONDS" => Some("17".to_string()),
            "MACK_LANE_ADDRESS_SPACE_BYTES" => Some("not-a-number".to_string()),
            "MACK_LANE_OPEN_FILES" => Some("64".to_string()),
            _ => None,
        });
        assert_eq!(limits.cpu_seconds, 17);
        assert_eq!(
            limits.address_space_bytes,
            LaneLimits::default().address_space_bytes
        );
        assert_eq!(limits.open_files, 64);
    }

    #[test]
    fn zero_is_rejected_as_an_override() {
        let limits = LaneLimits::from_env(|k| match k {
            "MACK_LANE_CPU_SECONDS" => Some("0".to_string()),
            _ => None,
        });
        assert_eq!(limits.cpu_seconds, LaneLimits::default().cpu_seconds);
    }
}
