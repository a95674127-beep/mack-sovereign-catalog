// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! sandbox::sealed_log — Persistent forensic records for `Sealed` outcomes.
//!
//! When the [`ContainmentPipeline`](super::pipeline::ContainmentPipeline)
//! refuses to execute a payload (`SealedHold`), the decision alone is not
//! enough: institutional-grade forensics requires a durable,
//! tamper-evident record of *what* was sealed and *why*.
//!
//! [`SealedEventLog`] appends one hash-chained record per sealed payload to
//! an embedded [`redb`] database. By default only the payload's SHA-256,
//! reason code, lane, timestamp, threat score, and indicators are stored —
//! **never the raw payload bytes**. Raw-payload retention is available only
//! through an explicit opt-in that encrypts the bytes with
//! [`vault::crypto::encrypt`](crate::vault::crypto::encrypt) before storage.
//!
//! Honest limits:
//! - Single-node durability (same as [`PersistentLedger`](crate::vault::persistent::PersistentLedger)).
//!   Protects against crashes, not against an attacker who can rewrite the
//!   database file. Pair with external anchoring for stronger guarantees.
//! - Each record's `record_hash` is the ledger anchor ID: it can be copied
//!   into the main audit ledger to cross-reference the sealed event.

use redb::{Database, ReadableTable, ReadableTableMetadata, TableDefinition};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::path::{Path, PathBuf};
use std::sync::Mutex;

use zeroize::Zeroizing;

use crate::vault::crypto;

const EVENTS_TABLE: TableDefinition<u64, String> = TableDefinition::new("sealed_events");
const PAYLOADS_TABLE: TableDefinition<u64, Vec<u8>> =
    TableDefinition::new("sealed_payloads_encrypted");
const META_TABLE: TableDefinition<&str, String> = TableDefinition::new("sealed_meta");
const META_NEXT_SEQ: &str = "next_seq";
const META_HEAD_HASH: &str = "head_hash";

/// Genesis hash for the first sealed-event record.
pub const SEALED_GENESIS_HASH: &str =
    "0000000000000000000000000000000000000000000000000000000000000000";

/// A single persistent forensic record for a sealed payload.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SealedEvent {
    /// Monotonic sequence number within this log.
    pub seq: u64,
    /// Unique event identifier (UUID v4).
    pub event_id: String,
    /// RFC 3339 UTC timestamp of the seal decision.
    pub timestamp_rfc3339: String,
    /// Lane code the payload was submitted to (e.g. "MACK-06").
    pub lane_code: String,
    /// Hex SHA-256 of the sealed payload. The payload itself is NOT stored
    /// unless encrypted retention was explicitly enabled.
    pub payload_sha256: String,
    /// Machine-readable reason code, e.g. "blocklist_match", "c2_signature",
    /// "fail_closed_empty", "high_entropy".
    pub reason_code: String,
    /// Threat score 0–100 from the triage assessment.
    pub threat_score: u32,
    /// Human-readable detection indicators from the scan.
    pub indicators: Vec<String>,
    /// Whether encrypted raw-payload bytes exist in the payload table.
    pub payload_retained: bool,
    /// Hash of the previous record (genesis for seq 0).
    pub prev_hash: String,
    /// This record's hash — the ledger anchor ID for cross-referencing.
    pub record_hash: String,
}

impl SealedEvent {
    /// Computes the tamper-evident record hash over all fields except
    /// `record_hash` itself.
    pub fn compute_hash(&self) -> String {
        let mut hasher = Sha256::new();
        hasher.update(self.seq.to_le_bytes());
        hasher.update(self.event_id.as_bytes());
        hasher.update(self.timestamp_rfc3339.as_bytes());
        hasher.update(self.lane_code.as_bytes());
        hasher.update(self.payload_sha256.as_bytes());
        hasher.update(self.reason_code.as_bytes());
        hasher.update(self.threat_score.to_le_bytes());
        for ind in &self.indicators {
            hasher.update(ind.as_bytes());
            hasher.update(b"\x00");
        }
        hasher.update([u8::from(self.payload_retained)]);
        hasher.update(self.prev_hash.as_bytes());
        hex::encode(hasher.finalize())
    }
}

/// Errors from the sealed-event log.
#[derive(Debug)]
pub enum SealedLogError {
    Io(std::io::Error),
    Db(Box<redb::Error>),
    /// Stored records failed chain verification on open.
    Corrupt {
        broken_seq: u64,
    },
    Decode(serde_json::Error),
    Crypto(crypto::CryptoError),
}

impl std::fmt::Display for SealedLogError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SealedLogError::Io(e) => write!(f, "sealed log I/O error: {e}"),
            SealedLogError::Db(e) => write!(f, "sealed log database error: {e}"),
            SealedLogError::Corrupt { broken_seq } => {
                write!(f, "sealed log corrupt: chain broken at seq {broken_seq}")
            }
            SealedLogError::Decode(e) => write!(f, "sealed log decode error: {e}"),
            SealedLogError::Crypto(e) => write!(f, "sealed log crypto error: {e}"),
        }
    }
}

impl std::error::Error for SealedLogError {}

impl From<redb::Error> for SealedLogError {
    fn from(e: redb::Error) -> Self {
        SealedLogError::Db(Box::new(e))
    }
}
impl From<redb::CommitError> for SealedLogError {
    fn from(e: redb::CommitError) -> Self {
        SealedLogError::Db(Box::new(e.into()))
    }
}
impl From<redb::DatabaseError> for SealedLogError {
    fn from(e: redb::DatabaseError) -> Self {
        SealedLogError::Db(Box::new(e.into()))
    }
}
impl From<redb::TransactionError> for SealedLogError {
    fn from(e: redb::TransactionError) -> Self {
        SealedLogError::Db(Box::new(e.into()))
    }
}
impl From<redb::TableError> for SealedLogError {
    fn from(e: redb::TableError) -> Self {
        SealedLogError::Db(Box::new(e.into()))
    }
}
impl From<redb::StorageError> for SealedLogError {
    fn from(e: redb::StorageError) -> Self {
        SealedLogError::Db(Box::new(e.into()))
    }
}
impl From<std::io::Error> for SealedLogError {
    fn from(e: std::io::Error) -> Self {
        SealedLogError::Io(e)
    }
}
impl From<serde_json::Error> for SealedLogError {
    fn from(e: serde_json::Error) -> Self {
        SealedLogError::Decode(e)
    }
}
impl From<crypto::CryptoError> for SealedLogError {
    fn from(e: crypto::CryptoError) -> Self {
        SealedLogError::Crypto(e)
    }
}

/// Restricts the database file at `path` to owner-only access (0600),
/// and its parent directory to 0700 when this open created it.
///
/// Mode discipline harvested from VaultLane's store (pattern authored
/// by Allen Mack in VaultLane `src/store.rs`; folded into the vault
/// 2026-11-10, harvest audit row 7). The redb file holds the sealed
/// forensic event chain; without this it inherits the process umask
/// (typically 0644 — readable by every local user). Applied on every
/// open, so a file created loose is tightened when next opened.
/// No-op on non-Unix platforms.
#[cfg(unix)]
fn restrict_db_file_permissions(
    path: &Path,
    parent: Option<&Path>,
    created_parent: bool,
) -> std::io::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600))?;
    if created_parent {
        if let Some(parent) = parent {
            if !parent.as_os_str().is_empty() {
                std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700))?;
            }
        }
    }
    Ok(())
}

#[cfg(not(unix))]
fn restrict_db_file_permissions(
    _path: &Path,
    _parent: Option<&Path>,
    _created_parent: bool,
) -> std::io::Result<()> {
    Ok(())
}

/// Persistent, hash-chained forensic log for sealed payloads.
///
/// Backed by a [`redb`] database file. Re-verifies the full chain on open;
/// a corrupt database refuses to open rather than serving bad data.
pub struct SealedEventLog {
    db: Database,
    path: PathBuf,
    /// Serializes writers so seq allocation and head-hash update are atomic.
    write_lock: Mutex<()>,
}

impl SealedEventLog {
    /// Opens (or creates) the sealed-event log at `path`, re-verifying the
    /// hash chain. Fails closed on corruption.
    pub fn open(path: impl AsRef<Path>) -> Result<Self, SealedLogError> {
        let path = path.as_ref().to_path_buf();
        let mut created_parent = false;
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() {
                created_parent = !parent.exists();
                std::fs::create_dir_all(parent)?;
            }
        }
        let db = Database::create(&path)?;
        restrict_db_file_permissions(&path, path.parent(), created_parent)?;
        {
            let write_txn = db.begin_write()?;
            {
                let mut events = write_txn.open_table(EVENTS_TABLE)?;
                let mut payloads = write_txn.open_table(PAYLOADS_TABLE)?;
                let mut meta = write_txn.open_table(META_TABLE)?;
                // Touch tables so they exist even when empty.
                let _ = (&mut events, &mut payloads, &mut meta);
                if meta.get(META_NEXT_SEQ)?.is_none() {
                    meta.insert(META_NEXT_SEQ, "0".to_string())?;
                }
                if meta.get(META_HEAD_HASH)?.is_none() {
                    meta.insert(META_HEAD_HASH, SEALED_GENESIS_HASH.to_string())?;
                }
            }
            write_txn.commit()?;
        }
        let log = Self {
            db,
            path,
            write_lock: Mutex::new(()),
        };
        log.verify_chain()?;
        Ok(log)
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    /// Number of sealed-event records.
    pub fn len(&self) -> Result<u64, SealedLogError> {
        let read_txn = self.db.begin_read()?;
        let events = read_txn.open_table(EVENTS_TABLE)?;
        Ok(events.len()?)
    }

    pub fn is_empty(&self) -> Result<bool, SealedLogError> {
        Ok(self.len()? == 0)
    }

    /// Records a sealed payload. Stores hash + metadata only; the raw
    /// payload bytes are never persisted by this method.
    pub fn record(
        &self,
        lane_code: &str,
        payload_sha256: &str,
        reason_code: &str,
        threat_score: u32,
        indicators: Vec<String>,
    ) -> Result<SealedEvent, SealedLogError> {
        self.record_inner(
            lane_code,
            payload_sha256,
            reason_code,
            threat_score,
            indicators,
            None,
        )
    }

    /// Records a sealed payload **with encrypted raw-payload retention**.
    ///
    /// This is the explicit opt-in path: `payload` is encrypted with
    /// [`crypto::encrypt`] under `passphrase` before storage. Callers must
    /// have obtained the passphrase through an approved channel; it is not
    /// stored anywhere in this log.
    pub fn record_with_retained_payload(
        &self,
        lane_code: &str,
        payload: &[u8],
        reason_code: &str,
        threat_score: u32,
        indicators: Vec<String>,
        passphrase: &[u8],
    ) -> Result<SealedEvent, SealedLogError> {
        let mut hasher = Sha256::new();
        hasher.update(payload);
        let payload_sha256 = hex::encode(hasher.finalize());
        let encrypted = crypto::encrypt(payload, passphrase)?;
        self.record_inner(
            lane_code,
            &payload_sha256,
            reason_code,
            threat_score,
            indicators,
            Some(encrypted),
        )
    }

    fn record_inner(
        &self,
        lane_code: &str,
        payload_sha256: &str,
        reason_code: &str,
        threat_score: u32,
        indicators: Vec<String>,
        encrypted_payload: Option<Vec<u8>>,
    ) -> Result<SealedEvent, SealedLogError> {
        // Poison-recovering lock, same policy as the audit ledger's
        // ConcurrentLedger: a panicked writer must not wedge the log.
        let _guard = self
            .write_lock
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let write_txn = self.db.begin_write()?;
        let event = {
            let mut meta = write_txn.open_table(META_TABLE)?;
            let mut events = write_txn.open_table(EVENTS_TABLE)?;
            let mut payloads = write_txn.open_table(PAYLOADS_TABLE)?;

            let seq: u64 = meta
                .get(META_NEXT_SEQ)?
                .map(|v| v.value().parse().unwrap_or(0))
                .unwrap_or(0);
            let prev_hash = meta
                .get(META_HEAD_HASH)?
                .map(|v| v.value())
                .unwrap_or_else(|| SEALED_GENESIS_HASH.to_string());

            let timestamp_rfc3339 = chrono::Utc::now().to_rfc3339();
            let event_id = uuid::Uuid::new_v4().to_string();
            let payload_retained = encrypted_payload.is_some();
            let mut event = SealedEvent {
                seq,
                event_id,
                timestamp_rfc3339,
                lane_code: lane_code.to_string(),
                payload_sha256: payload_sha256.to_string(),
                reason_code: reason_code.to_string(),
                threat_score,
                indicators,
                payload_retained,
                prev_hash,
                record_hash: String::new(),
            };
            event.record_hash = event.compute_hash();
            let record_hash = event.record_hash.clone();

            events.insert(seq, serde_json::to_string(&event)?)?;
            if let Some(enc) = encrypted_payload {
                payloads.insert(seq, enc)?;
            }
            meta.insert(META_NEXT_SEQ, (seq + 1).to_string())?;
            meta.insert(META_HEAD_HASH, record_hash)?;
            event
        };
        write_txn.commit()?;
        Ok(event)
    }

    /// Fetches a sealed-event record by sequence number.
    pub fn get(&self, seq: u64) -> Result<Option<SealedEvent>, SealedLogError> {
        let read_txn = self.db.begin_read()?;
        let events = read_txn.open_table(EVENTS_TABLE)?;
        match events.get(seq)? {
            Some(v) => Ok(Some(serde_json::from_str(v.value().as_str())?)),
            None => Ok(None),
        }
    }

    /// Returns all sealed-event records in sequence order.
    pub fn all(&self) -> Result<Vec<SealedEvent>, SealedLogError> {
        let read_txn = self.db.begin_read()?;
        let events = read_txn.open_table(EVENTS_TABLE)?;
        let mut out = Vec::new();
        for entry in events.iter()? {
            let (_k, v) = entry?;
            out.push(serde_json::from_str(v.value().as_str())?);
        }
        Ok(out)
    }

    /// Retrieves and decrypts a retained payload. Returns `Ok(None)` when
    /// no retained payload exists for `seq` (the default). The plaintext
    /// is returned inside [`Zeroizing`] (harvested 2026-11-10, audit
    /// row 4) so it is wiped when the caller drops it.
    pub fn retained_payload(
        &self,
        seq: u64,
        passphrase: &[u8],
    ) -> Result<Option<Zeroizing<Vec<u8>>>, SealedLogError> {
        let read_txn = self.db.begin_read()?;
        let payloads = read_txn.open_table(PAYLOADS_TABLE)?;
        match payloads.get(seq)? {
            Some(v) => Ok(Some(crypto::decrypt(&v.value(), passphrase)?)),
            None => Ok(None),
        }
    }

    /// Re-verifies the full hash chain. Returns `Ok(())` when intact.
    pub fn verify_chain(&self) -> Result<(), SealedLogError> {
        let events = self.all()?;
        let mut expected_prev = SEALED_GENESIS_HASH.to_string();
        for (expected_seq, event) in events.iter().enumerate() {
            if event.seq != expected_seq as u64 {
                return Err(SealedLogError::Corrupt {
                    broken_seq: event.seq,
                });
            }
            if event.prev_hash != expected_prev {
                return Err(SealedLogError::Corrupt {
                    broken_seq: event.seq,
                });
            }
            if event.compute_hash() != event.record_hash {
                return Err(SealedLogError::Corrupt {
                    broken_seq: event.seq,
                });
            }
            expected_prev = event.record_hash.clone();
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_path(name: &str) -> PathBuf {
        let mut p = std::env::temp_dir();
        p.push(format!(
            "sealed_log_test_{}_{}.redb",
            name,
            std::process::id()
        ));
        // Clean any stale file from a previous failed run.
        let _ = std::fs::remove_file(&p);
        p
    }

    /// Harvest (2026-11-10, audit row 7): the redb file must be created
    /// owner-only (0600), not umask-default, and a file loosened
    /// externally is tightened again on the next open.
    #[cfg(unix)]
    #[test]
    fn database_file_is_owner_only() {
        use std::os::unix::fs::PermissionsExt;
        let path = temp_path("perms");
        {
            let _log = SealedEventLog::open(&path).unwrap();
        }
        let mode = std::fs::metadata(&path)
            .expect("metadata")
            .permissions()
            .mode();
        assert_eq!(mode & 0o777, 0o600, "sealed log file must be 0600");
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).expect("loosen");
        {
            let _log = SealedEventLog::open(&path).unwrap();
        }
        let mode = std::fs::metadata(&path)
            .expect("metadata")
            .permissions()
            .mode();
        assert_eq!(mode & 0o777, 0o600, "reopen must tighten to 0600");
        let _ = std::fs::remove_file(&path);
    }

    fn sha256_hex(data: &[u8]) -> String {
        let mut h = Sha256::new();
        h.update(data);
        hex::encode(h.finalize())
    }

    #[test]
    fn record_stores_hash_not_raw_payload() {
        let path = temp_path("no_raw");
        let log = SealedEventLog::open(&path).unwrap();
        let payload = b"malicious payload bytes";
        let event = log
            .record(
                "MACK-06",
                &sha256_hex(payload),
                "c2_signature",
                95,
                vec!["c2 beacon pattern".to_string()],
            )
            .unwrap();

        assert_eq!(event.seq, 0);
        assert_eq!(event.payload_sha256, sha256_hex(payload));
        assert!(!event.payload_retained);
        // No raw bytes anywhere: the retained-payload lookup must be empty.
        assert!(log
            .retained_payload(0, b"any-passphrase")
            .unwrap()
            .is_none());
        // And the JSON in the DB must not contain the raw payload.
        let stored = log.get(0).unwrap().unwrap();
        let json = serde_json::to_string(&stored).unwrap();
        assert!(!json.contains("malicious payload bytes"));
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn chain_verifies_across_reopen() {
        let path = temp_path("reopen");
        let first_hash: String;
        {
            let log = SealedEventLog::open(&path).unwrap();
            let e1 = log
                .record("MACK-06", &sha256_hex(b"one"), "r1", 80, vec![])
                .unwrap();
            let e2 = log
                .record("MACK-10", &sha256_hex(b"two"), "r2", 90, vec![])
                .unwrap();
            assert_eq!(e2.prev_hash, e1.record_hash);
            first_hash = e2.record_hash.clone();
            assert!(log.verify_chain().is_ok());
        }
        // Reopen from disk: chain must still verify, head must match.
        let log2 = SealedEventLog::open(&path).unwrap();
        assert!(log2.verify_chain().is_ok());
        assert_eq!(log2.len().unwrap(), 2);
        assert_eq!(log2.get(1).unwrap().unwrap().record_hash, first_hash);
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn retained_payload_round_trips_encrypted() {
        let path = temp_path("retained");
        let log = SealedEventLog::open(&path).unwrap();
        let payload = b"super secret malicious bytes";
        let passphrase = b"correct horse battery staple";
        let event = log
            .record_with_retained_payload(
                "MACK-12",
                payload,
                "blocklist_match",
                100,
                vec!["known-bad hash".to_string()],
                passphrase,
            )
            .unwrap();
        assert!(event.payload_retained);

        // Correct passphrase decrypts.
        let recovered = log
            .retained_payload(event.seq, passphrase)
            .unwrap()
            .expect("retained payload must exist");
        assert_eq!(recovered.as_slice(), &payload[..]);

        // Wrong passphrase fails (authenticated encryption rejects it).
        assert!(log
            .retained_payload(event.seq, b"wrong-passphrase")
            .is_err());

        // Raw payload is not in the event JSON.
        let json = serde_json::to_string(&log.get(event.seq).unwrap().unwrap()).unwrap();
        assert!(!json.contains("super secret malicious"));
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn corrupt_chain_refuses_to_open() {
        let path = temp_path("corrupt");
        {
            let log = SealedEventLog::open(&path).unwrap();
            log.record("MACK-06", &sha256_hex(b"x"), "r", 50, vec![])
                .unwrap();
            log.record("MACK-06", &sha256_hex(b"y"), "r", 50, vec![])
                .unwrap();
        }
        // Tamper: rewrite seq-1's JSON with a forged record_hash.
        {
            let db = Database::create(&path).unwrap();
            let w = db.begin_write().unwrap();
            {
                let mut events = w.open_table(EVENTS_TABLE).unwrap();
                let raw = events.get(1u64).unwrap().unwrap().value();
                let mut ev: SealedEvent = serde_json::from_str(&raw).unwrap();
                ev.record_hash = "ff".repeat(32);
                events
                    .insert(1u64, serde_json::to_string(&ev).unwrap())
                    .unwrap();
            }
            w.commit().unwrap();
        }
        let reopened = SealedEventLog::open(&path);
        assert!(
            matches!(reopened, Err(SealedLogError::Corrupt { .. })),
            "tampered chain must refuse to open"
        );
        let _ = std::fs::remove_file(&path);
    }
}
