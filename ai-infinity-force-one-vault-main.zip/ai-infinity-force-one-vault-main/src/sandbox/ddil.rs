//! D-DIL Detonation Coordinator.
//!
//! Routes payloads through the [`ContainmentPipeline`] (detect → decide →
//! contain) so that every execution is gated by a threat assessment.
//!
//! **Security note (2026-10-08):** This coordinator previously scanned with
//! `OfflineThreatEngine` but then executed `Quarantine`-verdict payloads in
//! the *standard* (in-process) lane engine — a containment bypass. It now
//! delegates to `ContainmentPipeline`, which escalates `Quarantine` to
//! process-isolated execution (fail-closed if isolation is unavailable) and
//! never executes `Sealed` payloads. The public API is unchanged.

use super::lanes::LaneId;
use super::pipeline::{ContainmentDecision, ContainmentPipeline};
use crate::detection::engine::ComprehensiveScanResult;
use crate::detection::triage::TriageOutcome;
use crate::ingest::IngestRecord;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DetonationResult {
    pub lane_id: String,
    pub record_id: String,
    pub triage: TriageOutcome,
    pub threat_score: u32,
    pub execution_passed: bool,
    pub error_message: Option<String>,
}

pub struct DdilDetonationCoordinator {
    pipeline: ContainmentPipeline,
}

impl Default for DdilDetonationCoordinator {
    fn default() -> Self {
        Self::new(1_048_576)
    }
}

impl DdilDetonationCoordinator {
    pub fn new(max_payload_bytes: usize) -> Self {
        Self {
            pipeline: ContainmentPipeline::new(max_payload_bytes),
        }
    }

    /// Whether process-isolated containment is available for escalated
    /// (`Quarantine`) payloads.
    pub fn has_isolated_containment(&self) -> bool {
        self.pipeline.has_isolated_containment()
    }

    pub fn detonate_lane(
        &self,
        lane: LaneId,
        record: IngestRecord,
    ) -> (DetonationResult, ComprehensiveScanResult) {
        let lane_code = lane.code().to_string();
        let record_id = format!("{}-{}", record.lane, record.received_at);

        // All detection → containment decisions are made by the pipeline.
        // There is no path from here to ungated execution.
        let result = self.pipeline.process(lane, record.payload);
        let triage = result.scan.triage.outcome;
        let threat_score = result.scan.triage.threat_score;
        let scan = result.scan;

        let (execution_passed, error_message) = match &result.decision {
            ContainmentDecision::ExecuteStandard { .. }
            | ContainmentDecision::ExecuteIsolated { .. } => match result.execution {
                Some(Ok(_)) => (true, None),
                Some(Err(e)) => (false, Some(e.to_string())),
                None => (
                    false,
                    Some(
                        "Pipeline returned no execution result for an executable verdict"
                            .to_string(),
                    ),
                ),
            },
            ContainmentDecision::SealedHold { .. } => (
                false,
                Some("Payload sealed fail-closed due to critical threat verdict".to_string()),
            ),
        };

        (
            DetonationResult {
                lane_id: lane_code,
                record_id,
                triage,
                threat_score,
                execution_passed,
                error_message,
            },
            scan,
        )
    }

    pub fn detonate_batch_12_lanes(&self, records: Vec<IngestRecord>) -> Vec<DetonationResult> {
        let mut results = Vec::new();
        for (idx, record) in records.into_iter().enumerate() {
            let lane = LaneId::from_index(idx % 12).unwrap_or(LaneId::Mack12Failsafe);
            let (det_res, _) = self.detonate_lane(lane, record);
            results.push(det_res);
        }
        results
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sealed_payload_is_not_executed_via_coordinator() {
        let coordinator = DdilDetonationCoordinator::new(1_048_576);
        // Empty payload → fail-closed → Sealed.
        let record = IngestRecord::new("mack06", vec![]);
        let (result, _scan) = coordinator.detonate_lane(LaneId::Mack06Comms, record);
        assert_eq!(result.triage, TriageOutcome::Sealed);
        assert!(!result.execution_passed);
        assert!(result.error_message.unwrap().contains("sealed"));
    }

    #[test]
    fn quarantine_does_not_bypass_to_standard_engine() {
        // The coordinator must route Quarantine through the pipeline's
        // isolated path (or reject fail-closed), never silently execute
        // in the standard engine as the pre-2026-10-08 code did.
        let coordinator = DdilDetonationCoordinator::new(1_048_576);
        let mut payload = vec![0u8; 512];
        for (i, b) in payload.iter_mut().enumerate() {
            *b = ((i * 2654435761) % 256) as u8;
        }
        let record = IngestRecord::new("mack10", payload);
        let (result, _scan) = coordinator.detonate_lane(LaneId::Mack10Payload, record);
        // Either Quarantine (isolated or fail-closed reject) or Sealed.
        assert_ne!(result.triage, TriageOutcome::Clean);
    }

    #[test]
    fn clean_payload_still_executes() {
        let coordinator = DdilDetonationCoordinator::new(1_048_576);
        let record = IngestRecord::new("mack04", b"hello, this is a benign test payload".to_vec());
        let (result, _scan) = coordinator.detonate_lane(LaneId::Mack04AiCore, record);
        assert_eq!(result.triage, TriageOutcome::Clean);
        assert!(result.execution_passed);
    }
}
