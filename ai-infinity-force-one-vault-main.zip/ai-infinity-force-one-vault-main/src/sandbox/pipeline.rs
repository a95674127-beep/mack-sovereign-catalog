//! sandbox::pipeline — Detection-Containment Pipeline.
//!
//! Wires the [`OfflineThreatEngine`] (detection) to the [`LaneContainmentEngine`]
//! (containment) so that no payload executes without a threat assessment, and
//! containment escalates with the assessed threat level.
//!
//! Pipeline:
//! 1. **Detect**: Every payload is scanned by `OfflineThreatEngine`.
//! 2. **Decide**: The triage verdict determines containment:
//!    - `Clean` → execute in the target lane (standard containment).
//!    - `Quarantine` → execute in a process-isolated lane (escalated containment).
//!    - `Sealed` → DO NOT EXECUTE. Route to MACK-12 (failsafe) for forensic holding.
//! 3. **Contain**: Execution happens at the decided isolation level.
//!
//! Fail-closed: if the isolated backend cannot be spawned, `Quarantine` and
//! `Sealed` payloads are rejected — never silently downgraded to in-process.

use std::sync::Arc;
use std::time::Duration;

use sha2::{Digest, Sha256};

use crate::detection::engine::{ComprehensiveScanResult, OfflineThreatEngine};
use crate::detection::triage::TriageOutcome;
use crate::ingest::{IngestRecord, IngestStatus};
use crate::sandbox::lanes::{LaneContainmentEngine, LaneExecutionError, LaneId};

use super::sealed_log::{SealedEvent, SealedEventLog};

/// What the pipeline decided for a payload.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ContainmentDecision {
    /// Payload is clean; execute normally in the target lane.
    ExecuteStandard { lane: LaneId },
    /// Payload is suspicious; execute in process-isolated containment.
    ExecuteIsolated { lane: LaneId },
    /// Payload is malicious; do not execute. Held for forensics.
    SealedHold { lane: LaneId },
}

/// The outcome of running a payload through the pipeline.
#[derive(Debug)]
pub struct PipelineResult {
    /// The detection scan that drove the decision.
    pub scan: ComprehensiveScanResult,
    /// The containment decision made from the triage verdict.
    pub decision: ContainmentDecision,
    /// The execution outcome, if the payload was executed.
    /// `None` when the payload was sealed without execution.
    pub execution: Option<Result<IngestRecord, LaneExecutionError>>,
    /// The persistent forensic record, when a `Sealed` payload was recorded
    /// to an attached [`SealedEventLog`]. The `record_hash` is the ledger
    /// anchor ID for cross-referencing.
    pub sealed_event: Option<SealedEvent>,
    /// Set when sealed-event recording was attempted but failed. The payload
    /// remains sealed (never executed) even when recording fails; the error
    /// is surfaced here so operators can remediate the forensic gap.
    pub sealed_record_error: Option<String>,
}

/// Derives a machine-readable reason code from the scan's triage reasons.
/// Falls back to `"sealed"` when the scan produced no reasons.
fn reason_code_from_scan(scan: &ComprehensiveScanResult) -> String {
    scan.triage
        .reasons
        .first()
        .map(|r| {
            let slug: String = r
                .to_lowercase()
                .chars()
                .map(|c| if c.is_ascii_alphanumeric() { c } else { '_' })
                .collect();
            let trimmed = slug.trim_matches('_');
            if trimmed.is_empty() {
                "sealed".to_string()
            } else {
                trimmed.chars().take(64).collect()
            }
        })
        .unwrap_or_else(|| "sealed".to_string())
}

fn sha256_hex(data: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data);
    hex::encode(hasher.finalize())
}

/// Detection-Containment Pipeline: mandatory threat scan before any execution,
/// with containment that escalates with the assessed threat.
pub struct ContainmentPipeline {
    detector: OfflineThreatEngine,
    standard: LaneContainmentEngine,
    isolated: Option<LaneContainmentEngine>,
    sealed_log: Option<Arc<SealedEventLog>>,
}

impl ContainmentPipeline {
    /// Builds the pipeline. Attempts to spawn a process-isolated engine for
    /// escalated containment; if that fails, the isolated engine is `None`
    /// and suspicious payloads will be rejected (fail-closed).
    pub fn new(max_payload_bytes: usize) -> Self {
        let isolated =
            LaneContainmentEngine::new_isolated(max_payload_bytes, Duration::from_secs(30)).ok();
        Self {
            detector: OfflineThreatEngine::default(),
            standard: LaneContainmentEngine::new(max_payload_bytes),
            isolated,
            sealed_log: None,
        }
    }

    /// Builds the pipeline with a custom threat engine (e.g. custom YARA rules).
    pub fn with_detector(detector: OfflineThreatEngine, max_payload_bytes: usize) -> Self {
        let isolated =
            LaneContainmentEngine::new_isolated(max_payload_bytes, Duration::from_secs(30)).ok();
        Self {
            detector,
            standard: LaneContainmentEngine::new(max_payload_bytes),
            isolated,
            sealed_log: None,
        }
    }

    /// Attaches a persistent forensic log. Every `Sealed` outcome is then
    /// automatically recorded (payload SHA-256 + metadata; no raw bytes).
    pub fn with_sealed_log(mut self, log: Arc<SealedEventLog>) -> Self {
        self.sealed_log = Some(log);
        self
    }

    /// Whether a forensic log is attached for sealed outcomes.
    pub fn has_sealed_log(&self) -> bool {
        self.sealed_log.is_some()
    }

    /// Whether process-isolated containment is available for escalation.
    pub fn has_isolated_containment(&self) -> bool {
        self.isolated.is_some()
    }

    /// Runs a payload through detect → decide → contain.
    ///
    /// The `target_lane` is the caller's intended lane. The pipeline may
    /// override the execution lane based on the triage verdict:
    /// - `Quarantine` executes in the isolated engine (same lane ID).
    /// - `Sealed` does not execute; the record is marked for forensic hold
    ///   on MACK-12.
    ///
    /// When a [`SealedEventLog`] is attached via [`with_sealed_log`](Self::with_sealed_log),
    /// every `Sealed` outcome is automatically recorded (payload SHA-256 +
    /// metadata; no raw bytes). See [`process_with_retention`](Self::process_with_retention)
    /// for the explicit encrypted-retention variant.
    pub fn process(&self, target_lane: LaneId, payload: Vec<u8>) -> PipelineResult {
        self.process_inner(target_lane, payload, None)
    }

    /// Like [`process`](Self::process), but when the payload is sealed and a
    /// [`SealedEventLog`] is attached, the raw payload bytes are additionally
    /// retained **encrypted** under `retention_passphrase`.
    ///
    /// This is the explicit opt-in for raw-payload forensics. The passphrase
    /// is used transiently for this call only and is never stored.
    pub fn process_with_retention(
        &self,
        target_lane: LaneId,
        payload: Vec<u8>,
        retention_passphrase: &[u8],
    ) -> PipelineResult {
        self.process_inner(target_lane, payload, Some(retention_passphrase))
    }

    fn process_inner(
        &self,
        target_lane: LaneId,
        payload: Vec<u8>,
        retention_passphrase: Option<&[u8]>,
    ) -> PipelineResult {
        // Step 1: Detect. Every payload is scanned; no exceptions.
        let scan = self.detector.scan_payload(&payload);

        // Step 2: Decide containment from the triage verdict.
        let decision = match scan.triage.outcome {
            TriageOutcome::Clean => ContainmentDecision::ExecuteStandard { lane: target_lane },
            TriageOutcome::Quarantine => ContainmentDecision::ExecuteIsolated { lane: target_lane },
            TriageOutcome::Sealed => ContainmentDecision::SealedHold {
                lane: LaneId::Mack12Failsafe,
            },
        };

        // Forensic bookkeeping for sealed payloads (computed before the
        // payload is moved into an execution branch).
        let mut sealed_event: Option<SealedEvent> = None;
        let mut sealed_record_error: Option<String> = None;
        if let ContainmentDecision::SealedHold { lane } = &decision {
            if let Some(log) = &self.sealed_log {
                let reason = reason_code_from_scan(&scan);
                let indicators = scan.triage.reasons.clone();
                let record_result = match retention_passphrase {
                    Some(passphrase) => log.record_with_retained_payload(
                        lane.code(),
                        &payload,
                        &reason,
                        scan.triage.threat_score,
                        indicators,
                        passphrase,
                    ),
                    None => log.record(
                        lane.code(),
                        &sha256_hex(&payload),
                        &reason,
                        scan.triage.threat_score,
                        indicators,
                    ),
                };
                match record_result {
                    Ok(event) => sealed_event = Some(event),
                    // The payload stays sealed regardless; the failure is
                    // surfaced so the forensic gap can be remediated.
                    Err(e) => {
                        sealed_record_error = Some(format!("sealed-event record failed: {e}"))
                    }
                }
            }
        }

        // Step 3: Contain — execute at the decided level.
        let execution = match &decision {
            ContainmentDecision::ExecuteStandard { lane } => {
                let record = IngestRecord::new(lane.label(), payload);
                Some(self.standard.execute_lane(*lane, record))
            }
            ContainmentDecision::ExecuteIsolated { lane } => {
                match &self.isolated {
                    Some(engine) => {
                        let record = IngestRecord::new(lane.label(), payload);
                        Some(engine.execute_lane(*lane, record))
                    }
                    None => {
                        // Fail-closed: no isolated backend means we cannot
                        // safely contain a suspicious payload. Reject it.
                        let mut record = IngestRecord::new(lane.label(), payload);
                        record.status = IngestStatus::Rejected;
                        Some(Err(LaneExecutionError::SandboxViolation {
                            lane: *lane,
                            error: crate::sandbox::isolation::SandboxError::WorkerSpawnFailed(
                                "Process-isolated containment unavailable; \
                                 quarantined payload rejected (fail-closed)"
                                    .to_string(),
                            ),
                            backoff_applied: Duration::from_secs(0),
                        }))
                    }
                }
            }
            ContainmentDecision::SealedHold { lane } => {
                // Never execute. Mark the record as held for forensics.
                let _ = lane; // MACK-12 is the forensic holding lane.
                None
            }
        };

        PipelineResult {
            scan,
            decision,
            execution,
            sealed_event,
            sealed_record_error,
        }
    }

    /// Direct access to the underlying detector for standalone scans.
    pub fn detector(&self) -> &OfflineThreatEngine {
        &self.detector
    }

    /// Direct access to the standard lane engine.
    pub fn standard_engine(&self) -> &LaneContainmentEngine {
        &self.standard
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn clean_payload_executes_in_standard_lane() {
        let pipeline = ContainmentPipeline::new(1_048_576);
        let result = pipeline.process(
            LaneId::Mack04AiCore,
            b"hello, this is a benign test payload".to_vec(),
        );
        assert_eq!(
            result.decision,
            ContainmentDecision::ExecuteStandard {
                lane: LaneId::Mack04AiCore
            }
        );
        assert_eq!(result.scan.triage.outcome, TriageOutcome::Clean);
        let execution = result.execution.expect("clean payload must execute");
        assert!(execution.is_ok());
    }

    #[test]
    fn empty_payload_is_sealed_not_executed() {
        let pipeline = ContainmentPipeline::new(1_048_576);
        let result = pipeline.process(LaneId::Mack04AiCore, vec![]);
        // Empty payload is fail-closed → Sealed → no execution.
        assert_eq!(result.scan.triage.outcome, TriageOutcome::Sealed);
        assert!(matches!(
            result.decision,
            ContainmentDecision::SealedHold { .. }
        ));
        assert!(result.execution.is_none());
    }

    #[test]
    fn high_entropy_payload_escalates_containment() {
        let pipeline = ContainmentPipeline::new(1_048_576);
        // High-entropy blob: likely packed/encrypted → Quarantine or Sealed.
        let mut payload = vec![0u8; 512];
        // Fill with pseudo-random bytes for high entropy.
        for (i, b) in payload.iter_mut().enumerate() {
            *b = ((i * 2654435761) % 256) as u8;
        }
        let result = pipeline.process(LaneId::Mack10Payload, payload);
        // Must NOT be Clean; must escalate.
        assert_ne!(result.scan.triage.outcome, TriageOutcome::Clean);
        match result.decision {
            ContainmentDecision::ExecuteStandard { .. } => {
                panic!("suspicious payload must not use standard containment")
            }
            ContainmentDecision::ExecuteIsolated { lane } => {
                assert_eq!(lane, LaneId::Mack10Payload);
            }
            ContainmentDecision::SealedHold { lane } => {
                assert_eq!(lane, LaneId::Mack12Failsafe);
                assert!(result.execution.is_none());
            }
        }
    }

    #[test]
    fn sealed_payload_never_executes() {
        let pipeline = ContainmentPipeline::new(1_048_576);
        // Known-bad pattern: C2 callback signature should trigger Sealed.
        let payload = b"POST /c2/beacon HTTP/1.1\r\nHost: evil.example.com\r\n".to_vec();
        let result = pipeline.process(LaneId::Mack06Comms, payload);
        if result.scan.triage.outcome == TriageOutcome::Sealed {
            assert!(matches!(
                result.decision,
                ContainmentDecision::SealedHold {
                    lane: LaneId::Mack12Failsafe
                }
            ));
            assert!(
                result.execution.is_none(),
                "sealed payload must never execute"
            );
        }
    }

    #[test]
    fn quarantine_without_isolated_backend_is_rejected() {
        // Build a pipeline with no isolated engine by using a zero timeout
        // that forces spawn failure... instead, test the fail-closed path
        // directly: construct with detector only and no isolated engine.
        let detector = OfflineThreatEngine::default();
        let pipeline = ContainmentPipeline {
            detector,
            standard: LaneContainmentEngine::new(1_048_576),
            isolated: None, // Simulate unavailable isolated backend.
            sealed_log: None,
        };
        assert!(!pipeline.has_isolated_containment());

        // Suspicious payload with no isolated backend → rejected, not downgraded.
        let mut payload = vec![0u8; 512];
        for (i, b) in payload.iter_mut().enumerate() {
            *b = ((i * 2654435761) % 256) as u8;
        }
        let result = pipeline.process(LaneId::Mack10Payload, payload);
        match result.decision {
            ContainmentDecision::ExecuteIsolated { .. } => {
                let execution = result.execution.expect("must have execution result");
                assert!(
                    execution.is_err(),
                    "quarantined payload with no isolated backend must be rejected"
                );
            }
            ContainmentDecision::SealedHold { .. } => {
                assert!(result.execution.is_none());
            }
            ContainmentDecision::ExecuteStandard { .. } => {
                panic!("suspicious payload must not use standard containment");
            }
        }
    }

    fn sealed_test_log(name: &str) -> (Arc<SealedEventLog>, std::path::PathBuf) {
        let mut p = std::env::temp_dir();
        p.push(format!(
            "pipeline_sealed_{}_{}.redb",
            name,
            std::process::id()
        ));
        let _ = std::fs::remove_file(&p);
        let log = Arc::new(SealedEventLog::open(&p).expect("open sealed log"));
        (log, p)
    }

    #[test]
    fn sealed_payload_is_recorded_to_forensic_log() {
        let (log, path) = sealed_test_log("recorded");
        let pipeline = ContainmentPipeline::new(1_048_576).with_sealed_log(Arc::clone(&log));
        assert!(pipeline.has_sealed_log());

        // Empty payload → fail-closed → Sealed.
        let result = pipeline.process(LaneId::Mack04AiCore, vec![]);
        assert!(matches!(
            result.decision,
            ContainmentDecision::SealedHold { .. }
        ));
        assert!(result.execution.is_none());
        assert!(result.sealed_record_error.is_none());

        // A forensic record must exist.
        let event = result.sealed_event.expect("sealed event must be recorded");
        assert_eq!(event.seq, 0);
        // Empty payload SHA-256 is the well-known constant.
        assert_eq!(
            event.payload_sha256,
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
        assert!(
            !event.payload_retained,
            "raw bytes must not be retained by default"
        );
        assert!(!event.record_hash.is_empty());

        // The record survives a reopen and the chain verifies.
        drop(pipeline);
        drop(log);
        let log2 = SealedEventLog::open(&path).unwrap();
        assert!(log2.verify_chain().is_ok());
        let stored = log2.get(0).unwrap().unwrap();
        assert_eq!(stored.record_hash, event.record_hash);
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn clean_payload_does_not_touch_forensic_log() {
        let (log, path) = sealed_test_log("clean");
        let pipeline = ContainmentPipeline::new(1_048_576).with_sealed_log(Arc::clone(&log));
        let result = pipeline.process(
            LaneId::Mack04AiCore,
            b"hello, this is a benign test payload".to_vec(),
        );
        assert!(matches!(
            result.decision,
            ContainmentDecision::ExecuteStandard { .. }
        ));
        assert!(result.sealed_event.is_none());
        assert!(log.is_empty().unwrap());
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn retention_variant_encrypts_raw_payload() {
        let (log, path) = sealed_test_log("retention");
        let pipeline = ContainmentPipeline::new(1_048_576).with_sealed_log(Arc::clone(&log));
        let payload = vec![]; // empty → Sealed
        let passphrase = b"forensic-passphrase-2026";
        let result =
            pipeline.process_with_retention(LaneId::Mack06Comms, payload.clone(), passphrase);
        assert!(matches!(
            result.decision,
            ContainmentDecision::SealedHold { .. }
        ));
        let event = result.sealed_event.expect("sealed event must be recorded");
        assert!(event.payload_retained);
        let recovered = log
            .retained_payload(event.seq, passphrase)
            .unwrap()
            .expect("retained payload must decrypt");
        assert_eq!(recovered.as_slice(), payload.as_slice());
        let _ = std::fs::remove_file(&path);
    }
}
