//! pov::stress — Decentralized Network Stress-Test Runner (Milestone 3).
//!
//! Simulates multi-operator, multi-node concurrent submissions across a
//! decentralized network (DePIN), executing independent verification on all
//! submitted Proof of Verification records, scoring operators, and measuring
//! throughput, latency, and spoof detection.

use crate::pov::ProofOfVerification;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

#[derive(Debug, Clone)]
pub struct NodeStats {
    pub operator_id: String,
    pub total_submitted: u64,
    pub verified_valid: u64,
    pub rejected: u64,
}

#[derive(Debug, Clone)]
pub struct StressTestReport {
    pub total_tasks: usize,
    pub passed_tasks: usize,
    pub rejected_tasks: usize,
    pub duration: Duration,
    pub tasks_per_second: f64,
    pub operator_stats: HashMap<String, NodeStats>,
}

pub struct DePinStressEngine {
    concurrency_limit: usize,
}

impl Default for DePinStressEngine {
    fn default() -> Self {
        Self {
            concurrency_limit: 8,
        }
    }
}

impl DePinStressEngine {
    pub fn new(concurrency_limit: usize) -> Self {
        Self { concurrency_limit }
    }

    /// Simulates running a batch of PoV records through decentralized verification.
    pub fn run_stress_test(&self, tasks: Vec<ProofOfVerification>) -> StressTestReport {
        let start = Instant::now();
        let total_tasks = tasks.len();
        let stats_map: Arc<Mutex<HashMap<String, NodeStats>>> =
            Arc::new(Mutex::new(HashMap::new()));
        let passed_counter = Arc::new(Mutex::new(0usize));
        let rejected_counter = Arc::new(Mutex::new(0usize));

        let chunks = tasks.chunks((tasks.len() / self.concurrency_limit).max(1));
        let mut handles = Vec::new();

        for chunk in chunks {
            let chunk_vec = chunk.to_vec();
            let s_map = Arc::clone(&stats_map);
            let p_cnt = Arc::clone(&passed_counter);
            let r_cnt = Arc::clone(&rejected_counter);

            handles.push(std::thread::spawn(move || {
                for task in chunk_vec {
                    let is_valid = task.independently_verify();
                    let op_id = task.operator_id.clone();

                    if is_valid {
                        *p_cnt.lock().unwrap() += 1;
                    } else {
                        *r_cnt.lock().unwrap() += 1;
                    }

                    let mut map = s_map.lock().unwrap();
                    let entry = map.entry(op_id.clone()).or_insert(NodeStats {
                        operator_id: op_id,
                        total_submitted: 0,
                        verified_valid: 0,
                        rejected: 0,
                    });
                    entry.total_submitted += 1;
                    if is_valid {
                        entry.verified_valid += 1;
                    } else {
                        entry.rejected += 1;
                    }
                }
            }));
        }

        for h in handles {
            h.join().unwrap();
        }

        let duration = start.elapsed();
        let passed_tasks = *passed_counter.lock().unwrap();
        let rejected_tasks = *rejected_counter.lock().unwrap();
        let tasks_per_second = if duration.as_secs_f64() > 0.0 {
            total_tasks as f64 / duration.as_secs_f64()
        } else {
            total_tasks as f64 * 1000.0
        };

        let operator_stats = Arc::try_unwrap(stats_map).unwrap().into_inner().unwrap();

        StressTestReport {
            total_tasks,
            passed_tasks,
            rejected_tasks,
            duration,
            tasks_per_second,
            operator_stats,
        }
    }
}
