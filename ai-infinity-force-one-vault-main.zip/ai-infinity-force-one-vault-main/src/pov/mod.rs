pub mod stress;

use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProofOfVerification {
    pub pov_version: String,
    pub task_id: String,
    pub operator_id: String,
    #[serde(alias = "timestamp_submitted", default)]
    pub timestamp_start: String,
    #[serde(alias = "timestamp_completed", default)]
    pub timestamp_end: String,
    pub task_type: String,
    pub input_hash: String,
    pub output_hash: String,
    pub verification_method: String,
    #[serde(default)]
    pub verified: bool,
    #[serde(default)]
    pub signature: String,
}

impl ProofOfVerification {
    pub fn from_json(json: &str) -> Result<Self, serde_json::Error> {
        serde_json::from_str(json)
    }

    pub fn batch_from_json(json: &str) -> Result<Vec<Self>, serde_json::Error> {
        serde_json::from_str(json)
    }

    pub fn to_log_entry(&self) -> String {
        format!(
            "PoV task={} operator={} type={} method={} verified={} input_hash={} output_hash={}",
            self.task_id,
            self.operator_id,
            self.task_type,
            self.verification_method,
            self.verified,
            self.input_hash,
            self.output_hash,
        )
    }

    pub fn signing_message(&self) -> Vec<u8> {
        format!(
            "{}:{}:{}:{}:{}:{}:{}",
            self.task_id,
            self.operator_id,
            self.timestamp_start,
            self.timestamp_end,
            self.task_type,
            self.input_hash,
            self.output_hash,
        )
        .into_bytes()
    }

    pub fn sign(&mut self, signing_key: &SigningKey) -> String {
        let message = self.signing_message();
        let sig = signing_key.sign(&message);
        let hex_sig = hex::encode(sig.to_bytes());
        self.signature = hex_sig.clone();
        hex_sig
    }

    pub fn verify_operator_signature(&self, verifying_key: &VerifyingKey) -> bool {
        if self.signature.is_empty() {
            return false;
        }
        let sig_bytes = match hex::decode(&self.signature) {
            Ok(b) => b,
            Err(_) => return false,
        };
        let signature = match Signature::from_slice(&sig_bytes) {
            Ok(s) => s,
            Err(_) => return false,
        };
        verifying_key
            .verify(&self.signing_message(), &signature)
            .is_ok()
    }

    pub fn independently_verify(&self) -> bool {
        match self.verification_method.as_str() {
            "hash_match" => self.input_hash != self.output_hash,
            "merkle_proof" => !self.input_hash.is_empty() && self.input_hash != self.output_hash,
            _ => false,
        }
    }
}

pub use stress::{DePinStressEngine, NodeStats, StressTestReport};

#[cfg(test)]
mod tests {
    use super::*;
    use rand::rngs::OsRng;

    fn sample_pov(input_hash: &str, output_hash: &str, verified: bool) -> ProofOfVerification {
        ProofOfVerification {
            pov_version: "1.0".to_string(),
            task_id: "task_0001".to_string(),
            operator_id: "operator_0001".to_string(),
            timestamp_start: "2026-08-28T00:00:00Z".to_string(),
            timestamp_end: "2026-08-28T00:00:01Z".to_string(),
            task_type: "example_task".to_string(),
            input_hash: input_hash.to_string(),
            output_hash: output_hash.to_string(),
            verification_method: "hash_match".to_string(),
            verified,
            signature: "signature".to_string(),
        }
    }

    #[test]
    fn independently_verifies_when_hashes_differ() {
        let pov = sample_pov("abc123", "def456", true);
        assert!(pov.independently_verify());
    }

    #[test]
    fn fails_verification_when_hashes_match() {
        let pov = sample_pov("abc123", "abc123", true);
        assert!(!pov.independently_verify());
    }

    #[test]
    fn fails_verification_with_unsupported_method() {
        let mut pov = sample_pov("abc123", "def456", true);
        pov.verification_method = "unsupported_method".to_string();
        assert!(!pov.independently_verify());
    }

    #[test]
    fn parses_valid_pov_json() {
        let json = r#"{
            "pov_version": "1.0",
            "task_id": "task_0001",
            "operator_id": "operator_0001",
            "timestamp_start": "2026-08-28T00:00:00Z",
            "timestamp_end": "2026-08-28T00:00:01Z",
            "task_type": "example_task",
            "input_hash": "abc123",
            "output_hash": "def456",
            "verification_method": "hash_match",
            "verified": true,
            "signature": "sig"
        }"#;

        let pov = ProofOfVerification::from_json(json).unwrap();
        assert_eq!(pov.task_id, "task_0001");
        assert_eq!(pov.operator_id, "operator_0001");
    }

    #[test]
    fn rejects_malformed_json() {
        let bad_json = "{ not valid json";
        let result = ProofOfVerification::from_json(bad_json);
        assert!(result.is_err());
    }

    #[test]
    fn ed25519_operator_signing_and_verification() {
        let mut csprng = OsRng;
        let signing_key = SigningKey::generate(&mut csprng);
        let verifying_key = signing_key.verifying_key();

        let mut pov = sample_pov("input_hash_xyz", "output_hash_abc", true);
        let sig = pov.sign(&signing_key);
        assert!(!sig.is_empty());
        assert!(pov.verify_operator_signature(&verifying_key));

        // Wrong verifying key fails
        let other_key = SigningKey::generate(&mut csprng).verifying_key();
        assert!(!pov.verify_operator_signature(&other_key));

        // Tampered payload fails
        pov.output_hash = "tampered_output".to_string();
        assert!(!pov.verify_operator_signature(&verifying_key));
    }
}
