// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! telemetry::packet — Telemetry packet schema for SF-ITES pump monitoring.
//!
//! A [`TelemetryPacket`] is the unit of ingestion: one sensor snapshot from
//! one edge device. The schema is deliberately JSON (human-readable,
//! debuggable in the field) with a SHA-256 [`TelemetryPacket::packet_hash`]
//! computed over a canonical field ordering.
//!
//! Honest limits:
//! - The canonical JSON form is defined by THIS implementation (serde field
//!   declaration order). When ESP32 edge signing is implemented, the
//!   firmware MUST reproduce this exact byte layout before signing, or
//!   signatures will not verify. The canonical form is versioned via
//!   [`PACKET_SCHEMA_VERSION`] so a future change is detectable.
//! - `signature` is currently `None` in practice: edge-device Ed25519
//!   signing does not exist yet. The verification path in `ingest.rs` is
//!   implemented and tested, but nothing in the field produces signatures.

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

/// Schema version for the canonical packet form. Bump when the canonical
/// JSON layout changes; verifiers must reject unknown versions.
pub const PACKET_SCHEMA_VERSION: u32 = 1;

/// Plausible sensor ranges. Anything outside is a failed sensor, not data.
/// Mirrors the ranges in `~/workspace/sf-ites/sim/layer1_safety_sim.py`.
pub const CURRENT_RANGE_A: (f32, f32) = (0.0, 50.0);
pub const FLOW_RANGE_LPM: (f32, f32) = (0.0, 100.0);
pub const TEMP_RANGE_C: (f32, f32) = (-20.0, 150.0);
pub const PRESSURE_RANGE_KPA: (f32, f32) = (0.0, 2000.0);

/// Maximum acceptable clock skew: packets timestamped more than this far in
/// the future are rejected (likely a misconfigured or spoofed clock).
pub const MAX_FUTURE_SKEW_MS: i64 = 5 * 60 * 1000;

/// One sensor snapshot from one edge device.
///
/// `signature`, when present, must be a 64-byte Ed25519 signature over the
/// 32 raw bytes of [`TelemetryPacket::packet_hash`], made with the device's
/// registered verifying key. See `ingest.rs` for the verification path.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct TelemetryPacket {
    /// Stable device identifier, e.g. `"pump-01"`.
    pub device_id: String,
    /// Monotonic per-device sequence number. Replays and gaps are rejected
    /// by the ingestor.
    pub seq: u64,
    /// Unix timestamp in milliseconds.
    pub timestamp_ms: i64,
    /// RMS current draw in amps.
    pub current_rms: f32,
    /// Flow rate in litres per minute.
    pub flow_rate: f32,
    /// Winding/casing temperature in degrees Celsius.
    pub temp_c: f32,
    /// Head pressure in kilopascals.
    pub pressure_kpa: f32,
    /// Optional Ed25519 signature (64 bytes). `None` until edge signing exists.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub signature: Option<Vec<u8>>,
}

/// The canonical, signable projection of a packet: every field except
/// `signature`, in a fixed order. serde serializes struct fields in
/// declaration order, which IS the canonicalization — do not reorder these
/// fields without bumping [`PACKET_SCHEMA_VERSION`].
#[derive(Serialize)]
struct CanonicalPacket<'a> {
    schema_version: u32,
    device_id: &'a str,
    seq: u64,
    timestamp_ms: i64,
    current_rms: f32,
    flow_rate: f32,
    temp_c: f32,
    pressure_kpa: f32,
}

impl TelemetryPacket {
    /// Canonical JSON bytes (signature excluded). This exact byte string is
    /// what gets hashed and, eventually, signed by edge devices.
    pub fn canonical_bytes(&self) -> Vec<u8> {
        let canonical = CanonicalPacket {
            schema_version: PACKET_SCHEMA_VERSION,
            device_id: &self.device_id,
            seq: self.seq,
            timestamp_ms: self.timestamp_ms,
            current_rms: self.current_rms,
            flow_rate: self.flow_rate,
            temp_c: self.temp_c,
            pressure_kpa: self.pressure_kpa,
        };
        // Serialization of this fixed struct cannot fail.
        serde_json::to_vec(&canonical).expect("canonical packet serialization")
    }

    /// SHA-256 over [`TelemetryPacket::canonical_bytes`], hex-encoded.
    /// This is the tamper-evidence anchor stored in the ledger.
    pub fn packet_hash(&self) -> String {
        let mut hasher = Sha256::new();
        hasher.update(self.canonical_bytes());
        hex_encode(&hasher.finalize())
    }

    /// Raw 32-byte digest, for signature verification (signatures cover raw
    /// bytes, not the hex string).
    pub fn packet_digest(&self) -> [u8; 32] {
        let mut hasher = Sha256::new();
        hasher.update(self.canonical_bytes());
        hasher.finalize().into()
    }

    /// Schema-level validation: ranges and timestamp skew. Sequence/replay
    /// checks live in the ingestor, which tracks per-device state.
    pub fn validate(&self, now_ms: i64) -> Result<(), PacketError> {
        if self.device_id.is_empty() {
            return Err(PacketError::EmptyDeviceId);
        }
        check_range("current_rms", self.current_rms, CURRENT_RANGE_A)?;
        check_range("flow_rate", self.flow_rate, FLOW_RANGE_LPM)?;
        check_range("temp_c", self.temp_c, TEMP_RANGE_C)?;
        check_range("pressure_kpa", self.pressure_kpa, PRESSURE_RANGE_KPA)?;
        // NaN passes all comparisons, so check it explicitly.
        for (name, v) in [
            ("current_rms", self.current_rms),
            ("flow_rate", self.flow_rate),
            ("temp_c", self.temp_c),
            ("pressure_kpa", self.pressure_kpa),
        ] {
            if !v.is_finite() {
                return Err(PacketError::NonFinite {
                    field: name,
                    value: v,
                });
            }
        }
        let skew = self.timestamp_ms - now_ms;
        if skew > MAX_FUTURE_SKEW_MS {
            return Err(PacketError::FutureTimestamp { skew_ms: skew });
        }
        if let Some(sig) = &self.signature {
            if sig.len() != 64 {
                return Err(PacketError::BadSignatureLength { len: sig.len() });
            }
        }
        Ok(())
    }
}

fn check_range(field: &'static str, value: f32, (lo, hi): (f32, f32)) -> Result<(), PacketError> {
    // Note: NaN comparisons are all false, so NaN falls through to the
    // explicit non-finite check in validate(). This branch only fires for
    // real out-of-range numbers.
    if value.is_nan() || value < lo || value > hi {
        // Re-check NaN so the error variant is accurate.
        if value.is_nan() {
            return Err(PacketError::NonFinite { field, value });
        }
        return Err(PacketError::OutOfRange {
            field,
            value,
            lo,
            hi,
        });
    }
    Ok(())
}

fn hex_encode(bytes: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push(HEX[(b >> 4) as usize] as char);
        s.push(HEX[(b & 0xf) as usize] as char);
    }
    s
}

/// Schema-level packet problems. Ingestor-level problems (replay, gaps,
/// signature verification) are [`super::ingest::IngestError`].
#[derive(Debug, Clone, PartialEq)]
pub enum PacketError {
    EmptyDeviceId,
    OutOfRange {
        field: &'static str,
        value: f32,
        lo: f32,
        hi: f32,
    },
    NonFinite {
        field: &'static str,
        value: f32,
    },
    FutureTimestamp {
        skew_ms: i64,
    },
    BadSignatureLength {
        len: usize,
    },
}

impl std::fmt::Display for PacketError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PacketError::EmptyDeviceId => write!(f, "device_id is empty"),
            PacketError::OutOfRange {
                field,
                value,
                lo,
                hi,
            } => {
                write!(f, "{field}={value} out of range [{lo}, {hi}]")
            }
            PacketError::NonFinite { field, value } => {
                write!(f, "{field}={value} is not finite")
            }
            PacketError::FutureTimestamp { skew_ms } => {
                write!(
                    f,
                    "timestamp is {skew_ms}ms in the future (skew limit exceeded)"
                )
            }
            PacketError::BadSignatureLength { len } => {
                write!(f, "signature length {len} != 64 bytes")
            }
        }
    }
}

impl std::error::Error for PacketError {}

#[cfg(test)]
pub(crate) mod tests {
    use super::*;

    pub(crate) fn sample_packet() -> TelemetryPacket {
        TelemetryPacket {
            device_id: "pump-01".to_string(),
            seq: 1,
            timestamp_ms: 1_784_000_000_000,
            current_rms: 5.0,
            flow_rate: 2.5,
            temp_c: 42.0,
            pressure_kpa: 310.0,
            signature: None,
        }
    }

    #[test]
    fn hash_is_stable_and_excludes_signature() {
        let mut p = sample_packet();
        let h1 = p.packet_hash();
        // Mutating a covered field changes the hash...
        p.flow_rate = 0.0;
        let h2 = p.packet_hash();
        assert_ne!(h1, h2);
        // ...but adding a signature does not (signature covers the hash,
        // not the other way around).
        p.flow_rate = 2.5;
        p.signature = Some(vec![0u8; 64]);
        assert_eq!(p.packet_hash(), h1);
    }

    #[test]
    fn hash_is_64_hex_chars() {
        let h = sample_packet().packet_hash();
        assert_eq!(h.len(), 64);
        assert!(h.chars().all(|c| c.is_ascii_hexdigit()));
    }

    #[test]
    fn digest_matches_hash_bytes() {
        let p = sample_packet();
        let digest = p.packet_digest();
        assert_eq!(hex_encode(&digest), p.packet_hash());
    }

    #[test]
    fn valid_packet_passes() {
        let now = 1_784_000_000_000;
        assert!(sample_packet().validate(now).is_ok());
    }

    #[test]
    fn out_of_range_rejected_per_field() {
        let now = 1_784_000_000_000;
        let mut p = sample_packet();
        p.current_rms = 51.0;
        assert!(matches!(
            p.validate(now),
            Err(PacketError::OutOfRange {
                field: "current_rms",
                ..
            })
        ));
        p.current_rms = 5.0;
        p.flow_rate = 101.0;
        assert!(matches!(
            p.validate(now),
            Err(PacketError::OutOfRange {
                field: "flow_rate",
                ..
            })
        ));
        p.flow_rate = 2.5;
        p.temp_c = 200.0;
        assert!(matches!(
            p.validate(now),
            Err(PacketError::OutOfRange {
                field: "temp_c",
                ..
            })
        ));
        p.temp_c = 42.0;
        p.pressure_kpa = 2001.0;
        assert!(matches!(
            p.validate(now),
            Err(PacketError::OutOfRange {
                field: "pressure_kpa",
                ..
            })
        ));
    }

    #[test]
    fn nan_rejected() {
        let now = 1_784_000_000_000;
        let mut p = sample_packet();
        p.flow_rate = f32::NAN;
        assert!(matches!(
            p.validate(now),
            Err(PacketError::NonFinite {
                field: "flow_rate",
                ..
            })
        ));
    }

    #[test]
    fn future_timestamp_rejected() {
        let now = 1_784_000_000_000;
        let mut p = sample_packet();
        p.timestamp_ms = now + MAX_FUTURE_SKEW_MS + 1;
        assert!(matches!(
            p.validate(now),
            Err(PacketError::FutureTimestamp { .. })
        ));
        // Exactly at the boundary is fine.
        p.timestamp_ms = now + MAX_FUTURE_SKEW_MS;
        assert!(p.validate(now).is_ok());
    }

    #[test]
    fn bad_signature_length_rejected() {
        let now = 1_784_000_000_000;
        let mut p = sample_packet();
        p.signature = Some(vec![0u8; 32]);
        assert!(matches!(
            p.validate(now),
            Err(PacketError::BadSignatureLength { len: 32 })
        ));
    }

    #[test]
    fn empty_device_id_rejected() {
        let now = 1_784_000_000_000;
        let mut p = sample_packet();
        p.device_id.clear();
        assert!(matches!(p.validate(now), Err(PacketError::EmptyDeviceId)));
    }
}
