// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! telemetry::ingest — Audit-chained telemetry ingestion for SF-ITES.
//!
//! [`TelemetryIngestor`] is the trust boundary between untrusted edge
//! devices and the tamper-evident ledger. Every packet is validated,
//! de-duplicated, and (when signed) signature-checked BEFORE it reaches
//! [`PersistentLedger`]. Rejections are explicit errors, never silent drops,
//! and every rejection is counted and logged for observability.
//!
//! Honest limits:
//! - Unsigned packets (`signature: None`) are currently ACCEPTED. Edge
//!   signing does not exist yet, so requiring signatures would brick the
//!   pipeline. The verification path is implemented and tested; flip
//!   `require_signatures` when firmware signing ships.
//! - The sequence-gap threshold is a heuristic, not a proof of anything.
//!   A gap usually means lost packets (UDP, reboot); a huge gap can also
//!   mean a compromised device skipping ahead. The threshold is
//!   configurable via [`TelemetryIngestor::set_max_seq_gap`].
//! - Replay rejection means a device that retransmits after ITS OWN crash
//!   will have those retransmits rejected. The ledger is append-only; there
//!   is no safe way to merge duplicates without breaking the audit trail.
//!   Device firmware must persist its sequence counter across reboots.

use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

use ed25519_dalek::{Signature, Verifier, VerifyingKey};
use serde::{Deserialize, Serialize};

use super::packet::{PacketError, TelemetryPacket, PACKET_SCHEMA_VERSION};
use crate::vault::persistent::{LedgerError, PersistentLedger};

/// Default maximum tolerated sequence gap before a packet is treated as
/// suspicious. Heuristic — see module docs.
pub const DEFAULT_MAX_SEQ_GAP: u64 = 1000;

/// Cap on retained rejection records (observability ring buffer).
const MAX_REJECTIONS_KEPT: usize = 64;

/// Where a successfully ingested packet landed in the ledger.
#[derive(Debug, Clone)]
pub struct LedgerAnchor {
    /// Ledger entry sequence number.
    pub entry_sequence: usize,
    /// Ledger entry hash (chain link).
    pub entry_hash: String,
    /// The packet's own content hash (tamper-evidence anchor).
    pub packet_hash: String,
}

/// One rejected packet, for observability. Rejections are never silent.
#[derive(Debug, Clone)]
pub struct RejectionRecord {
    pub timestamp_ms: i64,
    pub device_id: String,
    pub reason: String,
}

/// The shape stored in the ledger's action field for each ingested packet.
#[derive(Debug, Serialize, Deserialize)]
struct LedgerPayload {
    #[serde(rename = "type")]
    kind: String,
    schema_version: u32,
    packet_hash: String,
    packet: TelemetryPacket,
}

/// All the ways ingestion can refuse a packet.
#[derive(Debug)]
pub enum IngestError {
    /// Schema-level problem (ranges, timestamp, malformed signature).
    Packet(PacketError),
    /// `seq` already seen for this device. Not a duplicate ingest — rejected.
    Replay {
        device_id: String,
        seq: u64,
        last_seq: u64,
    },
    /// `seq` jumped further than the configured gap threshold.
    SequenceGap {
        device_id: String,
        seq: u64,
        last_seq: u64,
        gap: u64,
    },
    /// Packet carries a signature but no verifying key is registered for
    /// this device. Cannot verify → cannot trust → rejected.
    UnknownDeviceKey { device_id: String },
    /// Signature present, key known, verification failed.
    BadSignature { device_id: String },
    /// The ledger itself refused the write.
    Ledger(LedgerError),
}

impl std::fmt::Display for IngestError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            IngestError::Packet(e) => write!(f, "invalid packet: {e}"),
            IngestError::Replay { device_id, seq, last_seq } => write!(
                f,
                "replay rejected: device {device_id} seq {seq} <= last seen {last_seq}"
            ),
            IngestError::SequenceGap { device_id, seq, last_seq, gap } => write!(
                f,
                "sequence gap rejected: device {device_id} jumped from {last_seq} to {seq} (gap {gap})"
            ),
            IngestError::UnknownDeviceKey { device_id } => write!(
                f,
                "signed packet from {device_id} but no verifying key registered"
            ),
            IngestError::BadSignature { device_id } => {
                write!(f, "signature verification failed for device {device_id}")
            }
            IngestError::Ledger(e) => write!(f, "ledger error: {e}"),
        }
    }
}

impl std::error::Error for IngestError {}

impl From<PacketError> for IngestError {
    fn from(e: PacketError) -> Self {
        IngestError::Packet(e)
    }
}

impl From<LedgerError> for IngestError {
    fn from(e: LedgerError) -> Self {
        IngestError::Ledger(e)
    }
}

fn now_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

/// The ingestion trust boundary. Owns a [`PersistentLedger`]; validates,
/// deduplicates, and optionally signature-verifies every packet before it
/// is appended.
pub struct TelemetryIngestor {
    ledger: PersistentLedger,
    /// device_id -> highest seq successfully ingested.
    last_seq: Mutex<HashMap<String, u64>>,
    /// device_id -> Ed25519 verifying key (32 bytes).
    device_keys: Mutex<HashMap<String, [u8; 32]>>,
    max_seq_gap: AtomicU64,
    require_signatures: std::sync::atomic::AtomicBool,
    rejection_count: AtomicU64,
    rejections: Mutex<Vec<RejectionRecord>>,
}

impl TelemetryIngestor {
    /// Creates an ingestor around an already-opened ledger.
    pub fn new(ledger: PersistentLedger) -> Self {
        Self {
            ledger,
            last_seq: Mutex::new(HashMap::new()),
            device_keys: Mutex::new(HashMap::new()),
            max_seq_gap: AtomicU64::new(DEFAULT_MAX_SEQ_GAP),
            require_signatures: std::sync::atomic::AtomicBool::new(false),
            rejection_count: AtomicU64::new(0),
            rejections: Mutex::new(Vec::new()),
        }
    }

    /// Opens a ledger at `path` and wraps it. Convenience for tests and
    /// single-process deployments.
    ///
    /// Rebuilds per-device sequence state from existing ledger entries, so
    /// replay protection survives restarts: a device retransmitting an old
    /// `seq` after OUR restart is still rejected.
    pub fn open(path: impl AsRef<std::path::Path>) -> Result<Self, LedgerError> {
        let ingestor = Self::new(PersistentLedger::open(path)?);
        ingestor.rebuild_seq_state();
        Ok(ingestor)
    }

    /// Scans committed telemetry entries and restores the highest seen
    /// `seq` per device. Called by [`TelemetryIngestor::open`].
    fn rebuild_seq_state(&self) {
        let mut seqs = self.last_seq.lock().unwrap_or_else(|p| p.into_inner());
        for entry in self.ledger.entries() {
            if let Ok(payload) = serde_json::from_str::<LedgerPayload>(&entry.action) {
                if payload.kind == "telemetry_ingest" {
                    let device = payload.packet.device_id.clone();
                    let seq = payload.packet.seq;
                    seqs.entry(device)
                        .and_modify(|last| *last = (*last).max(seq))
                        .or_insert(seq);
                }
            }
        }
    }

    /// Direct access to the underlying ledger (reads, verification).
    pub fn ledger(&self) -> &PersistentLedger {
        &self.ledger
    }

    /// Registers (or replaces) the Ed25519 verifying key for a device.
    /// The key bytes are parsed immediately so a bad key fails here, not
    /// at ingest time.
    pub fn register_device(
        &self,
        device_id: &str,
        verifying_key_bytes: &[u8; 32],
    ) -> Result<(), IngestError> {
        VerifyingKey::from_bytes(verifying_key_bytes).map_err(|_| IngestError::BadSignature {
            device_id: device_id.to_string(),
        })?;
        self.device_keys
            .lock()
            .unwrap_or_else(|p| p.into_inner())
            .insert(device_id.to_string(), *verifying_key_bytes);
        Ok(())
    }

    /// Removes a device's key (decommissioned / compromised device).
    /// Packets with signatures from this device will then be rejected as
    /// [`IngestError::UnknownDeviceKey`].
    pub fn deregister_device(&self, device_id: &str) {
        self.device_keys
            .lock()
            .unwrap_or_else(|p| p.into_inner())
            .remove(device_id);
    }

    /// Sets the sequence-gap suspicion threshold. See module docs: heuristic.
    pub fn set_max_seq_gap(&self, gap: u64) {
        self.max_seq_gap.store(gap, Ordering::SeqCst);
    }

    /// When true, unsigned packets are rejected. Default false until edge
    /// firmware signing ships — see module docs.
    pub fn set_require_signatures(&self, require: bool) {
        self.require_signatures.store(require, Ordering::SeqCst);
    }

    /// Total packets rejected since creation (all reasons).
    pub fn rejection_count(&self) -> u64 {
        self.rejection_count.load(Ordering::SeqCst)
    }

    /// Recent rejection records, newest last. Bounded at [`MAX_REJECTIONS_KEPT`].
    pub fn recent_rejections(&self) -> Vec<RejectionRecord> {
        self.rejections
            .lock()
            .unwrap_or_else(|p| p.into_inner())
            .clone()
    }

    fn record_rejection(&self, device_id: &str, reason: String) {
        self.rejection_count.fetch_add(1, Ordering::SeqCst);
        let mut guard = self.rejections.lock().unwrap_or_else(|p| p.into_inner());
        guard.push(RejectionRecord {
            timestamp_ms: now_ms(),
            device_id: device_id.to_string(),
            reason,
        });
        if guard.len() > MAX_REJECTIONS_KEPT {
            let excess = guard.len() - MAX_REJECTIONS_KEPT;
            guard.drain(..excess);
        }
    }

    /// Validates, deduplicates, optionally signature-verifies, and appends
    /// a packet to the tamper-evident ledger. Returns where it landed.
    ///
    /// Every rejection path records the rejection and returns a specific
    /// [`IngestError`] — nothing is silently dropped.
    pub fn ingest(&self, packet: &TelemetryPacket) -> Result<LedgerAnchor, IngestError> {
        let now = now_ms();

        // 1. Schema validation: ranges, timestamp skew, signature length.
        if let Err(e) = packet.validate(now) {
            let err = IngestError::Packet(e);
            self.record_rejection(&packet.device_id, err.to_string());
            return Err(err);
        }

        // 2. Replay and gap checks against per-device sequence state.
        {
            let mut seqs = self.last_seq.lock().unwrap_or_else(|p| p.into_inner());
            if let Some(&last) = seqs.get(&packet.device_id) {
                if packet.seq <= last {
                    let err = IngestError::Replay {
                        device_id: packet.device_id.clone(),
                        seq: packet.seq,
                        last_seq: last,
                    };
                    self.record_rejection(&packet.device_id, err.to_string());
                    return Err(err);
                }
                let gap = packet.seq - last - 1;
                let max_gap = self.max_seq_gap.load(Ordering::SeqCst);
                if gap > max_gap {
                    let err = IngestError::SequenceGap {
                        device_id: packet.device_id.clone(),
                        seq: packet.seq,
                        last_seq: last,
                        gap,
                    };
                    self.record_rejection(&packet.device_id, err.to_string());
                    return Err(err);
                }
            }
            // Tentatively record; rolled back below if the ledger write fails.
            seqs.insert(packet.device_id.clone(), packet.seq);
        }

        // 3. Signature verification (when present, or when required).
        if let Err(e) = self.verify_signature(packet) {
            // Roll back the sequence reservation: the packet was NOT ingested.
            let mut seqs = self.last_seq.lock().unwrap_or_else(|p| p.into_inner());
            // Only roll back if our insert is still the current value (no
            // concurrent ingest raced ahead — single-threaded in practice,
            // but be correct anyway).
            if seqs.get(&packet.device_id) == Some(&packet.seq) {
                // Restore previous value: we don't know it here, so remove
                // the key and let the next packet re-baseline. Documented
                // tradeoff: a rejected packet after a gap erases the baseline
                // rather than risking a phantom seq. The next valid packet
                // re-establishes it.
                seqs.remove(&packet.device_id);
            }
            self.record_rejection(&packet.device_id, e.to_string());
            return Err(e);
        }

        // 4. Append to the tamper-evident ledger.
        let packet_hash = packet.packet_hash();
        let payload = LedgerPayload {
            kind: "telemetry_ingest".to_string(),
            schema_version: PACKET_SCHEMA_VERSION,
            packet_hash: packet_hash.clone(),
            packet: packet.clone(),
        };
        let action = serde_json::to_string(&payload).expect("ledger payload serialization");
        let actor = format!("telemetry:{}", packet.device_id);
        match self.ledger.append(&actor, &action) {
            Ok(entry) => Ok(LedgerAnchor {
                entry_sequence: entry.sequence,
                entry_hash: entry.hash,
                packet_hash,
            }),
            Err(e) => {
                // Ledger write failed: roll back the sequence reservation so
                // a retry isn't falsely flagged as a replay.
                let mut seqs = self.last_seq.lock().unwrap_or_else(|p| p.into_inner());
                if seqs.get(&packet.device_id) == Some(&packet.seq) {
                    seqs.remove(&packet.device_id);
                }
                let err = IngestError::Ledger(e);
                self.record_rejection(&packet.device_id, err.to_string());
                Err(err)
            }
        }
    }

    fn verify_signature(&self, packet: &TelemetryPacket) -> Result<(), IngestError> {
        let require = self.require_signatures.load(Ordering::SeqCst);
        let Some(sig_bytes) = &packet.signature else {
            if require {
                let err = IngestError::BadSignature {
                    device_id: packet.device_id.clone(),
                };
                return Err(err);
            }
            // Unsigned packets accepted while edge signing doesn't exist.
            // Documented in module docs — this is the honest interim state.
            return Ok(());
        };

        let keys = self.device_keys.lock().unwrap_or_else(|p| p.into_inner());
        let key_bytes =
            keys.get(&packet.device_id)
                .ok_or_else(|| IngestError::UnknownDeviceKey {
                    device_id: packet.device_id.clone(),
                })?;
        let vk = VerifyingKey::from_bytes(key_bytes).map_err(|_| IngestError::BadSignature {
            device_id: packet.device_id.clone(),
        })?;
        let sig = Signature::from_slice(sig_bytes).map_err(|_| IngestError::BadSignature {
            device_id: packet.device_id.clone(),
        })?;
        // Signatures cover the 32 raw digest bytes, not the hex string.
        vk.verify(&packet.packet_digest(), &sig)
            .map_err(|_| IngestError::BadSignature {
                device_id: packet.device_id.clone(),
            })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::telemetry::packet::tests::sample_packet;
    use ed25519_dalek::{Signer, SigningKey};
    use std::sync::atomic::{AtomicU64, Ordering};

    static TEST_COUNTER: AtomicU64 = AtomicU64::new(0);

    fn temp_ledger_path(test_name: &str) -> std::path::PathBuf {
        let id = TEST_COUNTER.fetch_add(1, Ordering::SeqCst);
        let mut p = std::env::temp_dir();
        p.push(format!(
            "telemetry_test_{}_{}_{}",
            test_name,
            std::process::id(),
            id
        ));
        p.push("ledger.redb");
        p
    }

    fn cleanup(path: &std::path::Path) {
        if let Some(parent) = path.parent() {
            let _ = std::fs::remove_dir_all(parent);
        }
    }

    fn open_ingestor(test_name: &str) -> (TelemetryIngestor, std::path::PathBuf) {
        let path = temp_ledger_path(test_name);
        let ingestor = TelemetryIngestor::open(&path).expect("open ingestor");
        (ingestor, path)
    }

    /// Deterministic test keypair — no RNG needed.
    fn test_signing_key() -> SigningKey {
        SigningKey::from_bytes(&[0x42u8; 32])
    }

    fn sign_packet(packet: &TelemetryPacket, key: &SigningKey) -> TelemetryPacket {
        let mut signed = packet.clone();
        let sig = key.sign(&packet.packet_digest());
        signed.signature = Some(sig.to_bytes().to_vec());
        signed
    }

    /// Extracts telemetry payloads from ledger entries, in order.
    fn telemetry_entries(ingestor: &TelemetryIngestor) -> Vec<LedgerPayload> {
        ingestor
            .ledger()
            .entries()
            .iter()
            .filter_map(|e| serde_json::from_str::<LedgerPayload>(&e.action).ok())
            .collect()
    }

    #[test]
    fn valid_packet_ingests_and_verifies() {
        let (ingestor, path) = open_ingestor("valid");
        // Use a current timestamp so skew checks pass with real clock.
        let mut p = sample_packet();
        p.timestamp_ms = now_ms();

        let anchor = ingestor.ingest(&p).expect("ingest");
        assert_eq!(anchor.packet_hash, p.packet_hash());

        // Retrievable from the ledger with matching hash.
        let stored = telemetry_entries(&ingestor);
        assert_eq!(stored.len(), 1);
        assert_eq!(stored[0].packet_hash, p.packet_hash());
        assert_eq!(stored[0].packet, p);

        // Ledger chain still verifies after ingestion.
        assert!(ingestor.ledger().verify().is_ok());
        // Anchor points at the real entry.
        let entries = ingestor.ledger().entries();
        assert_eq!(entries[anchor.entry_sequence].hash, anchor.entry_hash);
        cleanup(&path);
    }

    #[test]
    fn tampered_packet_field_is_rejected() {
        let (ingestor, path) = open_ingestor("tamper");
        // Sign a packet, then modify a covered field AFTER signing.
        let key = test_signing_key();
        ingestor
            .register_device("pump-01", &key.verifying_key().to_bytes())
            .expect("register");
        let mut p = sample_packet();
        p.timestamp_ms = now_ms();
        let signed = sign_packet(&p, &key);

        // Tamper: change flow_rate after the signature was made.
        let mut tampered = signed.clone();
        tampered.flow_rate = 99.9;
        let err = ingestor.ingest(&tampered).expect_err("tampered must fail");
        assert!(
            matches!(err, IngestError::BadSignature { .. }),
            "expected BadSignature, got: {err}"
        );
        assert_eq!(ingestor.rejection_count(), 1);
        // Nothing reached the ledger.
        assert!(ingestor.ledger().is_empty());
        cleanup(&path);
    }

    #[test]
    fn valid_signature_accepted() {
        let (ingestor, path) = open_ingestor("sig_ok");
        let key = test_signing_key();
        ingestor
            .register_device("pump-01", &key.verifying_key().to_bytes())
            .expect("register");
        let mut p = sample_packet();
        p.timestamp_ms = now_ms();
        let signed = sign_packet(&p, &key);
        let anchor = ingestor.ingest(&signed).expect("signed ingest");
        assert_eq!(anchor.packet_hash, signed.packet_hash());
        assert_eq!(ingestor.rejection_count(), 0);
        cleanup(&path);
    }

    #[test]
    fn signed_by_wrong_key_rejected() {
        let (ingestor, path) = open_ingestor("sig_wrong");
        let key = test_signing_key();
        let other = SigningKey::from_bytes(&[0x99u8; 32]);
        ingestor
            .register_device("pump-01", &key.verifying_key().to_bytes())
            .expect("register");
        let mut p = sample_packet();
        p.timestamp_ms = now_ms();
        // Signed with a DIFFERENT key than registered.
        let bad = sign_packet(&p, &other);
        let err = ingestor.ingest(&bad).expect_err("wrong key must fail");
        assert!(matches!(err, IngestError::BadSignature { .. }));
        cleanup(&path);
    }

    #[test]
    fn signed_packet_unknown_device_rejected() {
        let (ingestor, path) = open_ingestor("sig_unknown");
        let key = test_signing_key();
        // No register_device call.
        let mut p = sample_packet();
        p.timestamp_ms = now_ms();
        let signed = sign_packet(&p, &key);
        let err = ingestor
            .ingest(&signed)
            .expect_err("unknown device must fail");
        assert!(matches!(err, IngestError::UnknownDeviceKey { .. }));
        cleanup(&path);
    }

    #[test]
    fn replay_rejected() {
        let (ingestor, path) = open_ingestor("replay");
        let mut p = sample_packet();
        p.timestamp_ms = now_ms();
        ingestor.ingest(&p).expect("first ingest");
        // Same seq again → replay.
        let err = ingestor.ingest(&p).expect_err("replay must fail");
        assert!(
            matches!(
                err,
                IngestError::Replay {
                    seq: 1,
                    last_seq: 1,
                    ..
                }
            ),
            "got: {err}"
        );
        // Only one entry in the ledger.
        assert_eq!(ingestor.ledger().len(), 1);
        assert_eq!(ingestor.rejection_count(), 1);
        cleanup(&path);
    }

    #[test]
    fn out_of_range_rejected_and_logged() {
        let (ingestor, path) = open_ingestor("range");
        let mut p = sample_packet();
        p.timestamp_ms = now_ms();
        p.current_rms = 75.0; // > 50A max
        let err = ingestor.ingest(&p).expect_err("out of range must fail");
        assert!(matches!(
            err,
            IngestError::Packet(PacketError::OutOfRange { .. })
        ));
        assert!(ingestor.ledger().is_empty());
        // Rejection is observable, not silent.
        assert_eq!(ingestor.rejection_count(), 1);
        let recent = ingestor.recent_rejections();
        assert_eq!(recent.len(), 1);
        assert_eq!(recent[0].device_id, "pump-01");
        assert!(recent[0].reason.contains("out of range"));
        cleanup(&path);
    }

    #[test]
    fn sequence_gap_rejected() {
        let (ingestor, path) = open_ingestor("gap");
        let mut p = sample_packet();
        p.timestamp_ms = now_ms();
        p.seq = 10;
        ingestor.ingest(&p).expect("baseline ingest");
        // Jump of 2000 > default max gap of 1000.
        p.seq = 2011;
        let err = ingestor.ingest(&p).expect_err("gap must fail");
        assert!(
            matches!(err, IngestError::SequenceGap { gap: 2000, .. }),
            "got: {err}"
        );
        // Small gaps are fine.
        p.seq = 11;
        ingestor.ingest(&p).expect("small gap ok");
        assert_eq!(ingestor.ledger().len(), 2);
        cleanup(&path);
    }

    #[test]
    fn gap_threshold_configurable() {
        let (ingestor, path) = open_ingestor("gap_cfg");
        ingestor.set_max_seq_gap(5000);
        let mut p = sample_packet();
        p.timestamp_ms = now_ms();
        p.seq = 10;
        ingestor.ingest(&p).expect("baseline");
        p.seq = 2011; // gap 2000 < 5000 now
        ingestor.ingest(&p).expect("within raised threshold");
        cleanup(&path);
    }

    #[test]
    fn ledger_chain_survives_ingestion_and_reopen() {
        let (ingestor, path) = open_ingestor("reopen");
        for seq in 1..=5u64 {
            let mut p = sample_packet();
            p.timestamp_ms = now_ms();
            p.seq = seq;
            ingestor.ingest(&p).expect("ingest");
        }
        let head_before = ingestor.ledger().head_hash();
        assert!(ingestor.ledger().verify().is_ok());
        drop(ingestor);

        // Reopen: chain re-verifies, anchored head matches.
        let ingestor2 = TelemetryIngestor::open(&path).expect("reopen");
        assert!(ingestor2.ledger().verify().is_ok());
        assert!(ingestor2.ledger().verify_anchored(&head_before).is_ok());
        assert_eq!(telemetry_entries(&ingestor2).len(), 5);
        // Per-device seq state IS rebuilt from the ledger on open, so a
        // retransmit after OUR restart is still rejected as a replay.
        let mut replay = sample_packet();
        replay.timestamp_ms = now_ms();
        replay.seq = 5;
        let err = ingestor2.ingest(&replay).expect_err("replay after reopen");
        assert!(matches!(err, IngestError::Replay { .. }), "got: {err}");
        cleanup(&path);
    }

    #[test]
    fn require_signatures_rejects_unsigned() {
        let (ingestor, path) = open_ingestor("req_sig");
        ingestor.set_require_signatures(true);
        let mut p = sample_packet();
        p.timestamp_ms = now_ms();
        let err = ingestor
            .ingest(&p)
            .expect_err("unsigned must fail when required");
        assert!(matches!(err, IngestError::BadSignature { .. }));
        cleanup(&path);
    }
}
