// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! telemetry — Audit-chained telemetry ingestion for SF-ITES pump monitoring.
//!
//! Trust boundary between untrusted edge devices and the tamper-evident
//! ledger: [`packet::TelemetryPacket`] defines the schema,
//! [`ingest::TelemetryIngestor`] validates, deduplicates, optionally
//! signature-verifies, and appends every packet to
//! [`crate::vault::persistent::PersistentLedger`].

pub mod ingest;
pub mod packet;

pub use ingest::{
    IngestError, LedgerAnchor, RejectionRecord, TelemetryIngestor, DEFAULT_MAX_SEQ_GAP,
};
pub use packet::{
    PacketError, TelemetryPacket, CURRENT_RANGE_A, FLOW_RANGE_LPM, MAX_FUTURE_SKEW_MS,
    PACKET_SCHEMA_VERSION, PRESSURE_RANGE_KPA, TEMP_RANGE_C,
};
