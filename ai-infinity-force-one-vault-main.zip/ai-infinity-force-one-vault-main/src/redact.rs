// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! Streaming output redaction: text leaving the vault passes through a
//! [`Redactor`] that replaces every occurrence of a known secret value
//! with `[REDACTED]` before the bytes reach a response, a log, or an
//! export.
//!
//! Provenance: component authored by Allen Mack in VaultLane
//! (`src/redact.rs`); ported into the vault 2026-11-10 (harvest audit
//! row 3) with its test suite. Wired at the API boundary in
//! `src/api/mod.rs`.
//!
//! Scope, honestly: this stops *accidental* leakage of known vault
//! values into output and logs. It does not stop a malicious caller
//! from exfiltrating a secret it legitimately holds (e.g. over the
//! network). Matching covers each value in its exact form AND its
//! common full-value encodings — base64 (padded and unpadded) and hex
//! (lower and upper case) — because programs love logging keys in
//! exactly those forms. What still defeats it: partial encodings (only
//! part of the value encoded), other transforms (reversal,
//! compression, URL encoding with escapes), and byte-splitting a value
//! across separate writes with unrelated output interleaved.
//!
//! Streaming correctness: a secret may straddle two read chunks, and
//! a secret may even overlap itself (e.g. "topsecret" starts and ends
//! with 't'). The redactor therefore emits only a prefix of the buffer
//! that is provably safe: no complete occurrence of any secret crosses
//! the emit boundary, the emitted part does not end with a proper
//! prefix of any secret, and the last `max_secret_len - 1` bytes are
//! always held for the next chunk. [`Redactor::finish`] flushes (and
//! scrubs) the remainder at end-of-stream.

/// The replacement marker written in place of a secret value.
pub const MARKER: &[u8] = b"[REDACTED]";

/// Secrets shorter than this are not redacted (too many false hits).
pub const MIN_SECRET_LEN: usize = 4;

pub struct Redactor {
    secrets: Vec<Vec<u8>>,
    max_len: usize,
    buf: Vec<u8>,
}

/// Standard-alphabet base64 (RFC 4648), optionally with padding.
fn base64_encode(data: &[u8], padded: bool) -> Vec<u8> {
    const ALPHABET: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = Vec::with_capacity(data.len().div_ceil(3) * 4);
    for chunk in data.chunks(3) {
        let b0 = chunk[0] as u32;
        let b1 = *chunk.get(1).unwrap_or(&0) as u32;
        let b2 = *chunk.get(2).unwrap_or(&0) as u32;
        let n = (b0 << 16) | (b1 << 8) | b2;
        out.push(ALPHABET[(n >> 18) as usize & 63]);
        out.push(ALPHABET[(n >> 12) as usize & 63]);
        if chunk.len() > 1 {
            out.push(ALPHABET[(n >> 6) as usize & 63]);
        } else if padded {
            out.push(b'=');
        }
        if chunk.len() > 2 {
            out.push(ALPHABET[n as usize & 63]);
        } else if padded {
            out.push(b'=');
        }
    }
    out
}

fn hex_encode(data: &[u8], upper: bool) -> Vec<u8> {
    let digits: &[u8; 16] = if upper {
        b"0123456789ABCDEF"
    } else {
        b"0123456789abcdef"
    };
    let mut out = Vec::with_capacity(data.len() * 2);
    for b in data {
        out.push(digits[(b >> 4) as usize]);
        out.push(digits[(b & 0xF) as usize]);
    }
    out
}

/// Every byte-pattern that represents `value` in output: the raw
/// bytes plus the common full-value encodings.
fn patterns_for(value: &str) -> Vec<Vec<u8>> {
    let raw = value.as_bytes();
    vec![
        raw.to_vec(),
        base64_encode(raw, true),
        base64_encode(raw, false),
        hex_encode(raw, false),
        hex_encode(raw, true),
    ]
}

impl Redactor {
    pub fn new(values: &[&str]) -> Self {
        let mut secrets: Vec<Vec<u8>> = Vec::new();
        for v in values.iter().filter(|v| v.len() >= MIN_SECRET_LEN) {
            secrets.extend(patterns_for(v));
        }
        secrets.sort();
        secrets.dedup();
        // Longest first so a longer pattern wins over a substring of it.
        secrets.sort_by_key(|s| std::cmp::Reverse(s.len()));
        let max_len = secrets.iter().map(|s| s.len()).max().unwrap_or(0);
        Redactor {
            secrets,
            max_len,
            buf: Vec::new(),
        }
    }

    /// Whether any redaction is active (at least one usable secret).
    pub fn active(&self) -> bool {
        !self.secrets.is_empty()
    }

    /// All start positions of full occurrences of any secret in `buf`.
    fn occurrences(&self, buf: &[u8]) -> Vec<(usize, usize)> {
        let mut found = Vec::new();
        for secret in &self.secrets {
            if secret.len() > buf.len() {
                continue;
            }
            let mut i = 0;
            while i + secret.len() <= buf.len() {
                if &buf[i..i + secret.len()] == secret.as_slice() {
                    found.push((i, i + secret.len()));
                }
                i += 1;
            }
        }
        found
    }

    /// Length of the longest suffix of `head` that is a proper prefix
    /// of any secret (0 when there is none).
    fn proper_prefix_suffix(&self, head: &[u8]) -> usize {
        if self.max_len <= 1 {
            return 0;
        }
        let limit = (self.max_len - 1).min(head.len());
        for k in (1..=limit).rev() {
            let suffix = &head[head.len() - k..];
            if self
                .secrets
                .iter()
                .any(|s| s.len() > k && &s[..k] == suffix)
            {
                return k;
            }
        }
        0
    }

    /// The largest prefix length of `buf` that is safe to scrub+emit.
    /// The boundary is pulled back until all of these hold:
    /// - no complete occurrence of a secret ends exactly at the buffer
    ///   tail in a way that a longer secret could extend it (tail
    ///   occurrences are held whole for the next chunk / `finish`),
    /// - no complete occurrence straddles the boundary,
    /// - the emitted head does not end with raw bytes forming a proper
    ///   prefix of a secret whose completion could arrive later.
    ///
    /// v0.4.1 (audit finding vaultlane/redact/self-overlap-holdback-dos):
    /// only occurrences ending in the final `max_len - 1` bytes may
    /// pull the boundary back — they are the only ones a longer secret
    /// could still extend. An occurrence ending earlier is final: any
    /// longer secret extending it would already be fully present in
    /// the buffer and found as its own occurrence, and `scrub` picks
    /// the longest match. The candidates are evaluated on the final
    /// `2 * max_len - 1` bytes (every occurrence passing the end
    /// filter starts inside that window), so the scan cost per chunk
    /// is bounded by the longest secret, not by the buffer. Before
    /// this, occurrences across the whole buffer participated, and
    /// for a self-overlapping secret printed repeatedly, the boundary
    /// cascaded to 0 on every chunk: nothing was ever emitted and the
    /// buffer grew without bound. The prefix rule is what keeps a
    /// non-candidate occurrence from straddling the final boundary
    /// with its bytes emitted raw: the head would end with that
    /// occurrence's proper prefix, and rule (b) cuts exactly that.
    fn safe_emit_len(&self, buf: &[u8]) -> usize {
        if self.max_len == 0 || buf.is_empty() {
            return 0;
        }
        let n = buf.len();
        // Occurrences ending after this point may still be extended.
        // (Saturating: a buffer shorter than the holdback makes every
        // occurrence a candidate.)
        let extendable_after = n.saturating_sub(self.max_len - 1);
        let window = (2 * self.max_len - 1).min(n);
        let wstart = n - window;
        let active: Vec<(usize, usize)> = self
            .occurrences(&buf[wstart..])
            .into_iter()
            .map(|(start, end)| (start + wstart, end + wstart))
            .filter(|&(_, end)| end > extendable_after)
            .collect();
        let mut s = n;
        // Tail occurrences are held whole: a longer secret may extend
        // them, and `finish` will scrub them if the stream ends here.
        for &(start, end) in &active {
            if end == n {
                s = s.min(start);
            }
        }
        loop {
            let mut next = s;
            // (a) A still-extendable occurrence must not straddle the
            // boundary.
            for &(start, end) in &active {
                if start < next && end > next {
                    next = start;
                }
            }
            // (b) The emitted head must not end with raw bytes forming
            // a proper prefix of a secret.
            let cut = self.raw_tail_prefix_len(&buf[..next]);
            next -= cut;
            if next == s {
                return s;
            }
            s = next;
        }
    }

    /// The length of the longest suffix of `head`'s raw tail that is a
    /// proper prefix of any secret. The raw tail is what `scrub` emits
    /// verbatim: the bytes after the last complete occurrence. Bytes
    /// consumed by a complete occurrence become the marker, so they
    /// cannot pair with later output to spell out a secret — only the
    /// raw tail can.
    fn raw_tail_prefix_len(&self, head: &[u8]) -> usize {
        // Replay scrub's greedy scan to find where the last complete
        // occurrence ends.
        let mut i = 0;
        let mut last_match_end = 0;
        'scan: while i < head.len() {
            for secret in &self.secrets {
                if head.len() - i >= secret.len() && &head[i..i + secret.len()] == secret {
                    i += secret.len();
                    last_match_end = i;
                    continue 'scan;
                }
            }
            i += 1;
        }
        self.proper_prefix_suffix(&head[last_match_end..])
    }

    /// Replace every full occurrence of every secret in `data`.
    fn scrub(&self, data: &[u8]) -> Vec<u8> {
        if self.secrets.is_empty() || data.is_empty() {
            return data.to_vec();
        }
        let mut out = Vec::with_capacity(data.len());
        let mut i = 0;
        'scan: while i < data.len() {
            for secret in &self.secrets {
                if data.len() - i >= secret.len() && &data[i..i + secret.len()] == secret {
                    out.extend_from_slice(MARKER);
                    i += secret.len();
                    continue 'scan;
                }
            }
            out.push(data[i]);
            i += 1;
        }
        out
    }

    /// Feed a chunk; returns the bytes safe to emit now.
    pub fn push(&mut self, chunk: &[u8]) -> Vec<u8> {
        if !self.active() {
            return chunk.to_vec();
        }
        self.buf.extend_from_slice(chunk);
        let emit_len = self.safe_emit_len(&self.buf);
        if emit_len == 0 {
            return Vec::new();
        }
        let head: Vec<u8> = self.buf.drain(..emit_len).collect();
        self.scrub(&head)
    }

    /// End of stream: scrub and emit everything still held.
    pub fn finish(&mut self) -> Vec<u8> {
        let rest = std::mem::take(&mut self.buf);
        self.scrub(&rest)
    }
}

/// One-shot convenience (vault-side addition, not part of the
/// VaultLane original): scrub a complete buffer in a single call.
/// Equivalent to `push` + `finish` on a fresh [`Redactor`].
pub fn scrub_once(values: &[&str], data: &[u8]) -> Vec<u8> {
    let mut redactor = Redactor::new(values);
    let mut out = redactor.push(data);
    out.extend(redactor.finish());
    out
}

/// Secret-lifetime policy (v0.4): the pattern table IS secret material
/// (raw values plus their encodings), and the holdback buffer can
/// contain secret fragments. Both are zeroed when the redactor drops.
impl Drop for Redactor {
    fn drop(&mut self) {
        use zeroize::Zeroize;
        for p in &mut self.secrets {
            p.zeroize();
        }
        self.buf.zeroize();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn run_split(secret: &str, stream: &[u8], split: usize) -> Vec<u8> {
        let mut r = Redactor::new(&[secret]);
        let mut out = r.push(&stream[..split]);
        out.extend(r.push(&stream[split..]));
        out.extend(r.finish());
        out
    }

    fn run_drip(secret: &str, stream: &[u8]) -> Vec<u8> {
        let mut r = Redactor::new(&[secret]);
        let mut out = Vec::new();
        for b in stream {
            out.extend(r.push(&[*b]));
        }
        out.extend(r.finish());
        out
    }

    #[test]
    fn redacts_whole_secret() {
        let mut r = Redactor::new(&["hunter2"]);
        let mut all = r.push(b"login ok with hunter2 done");
        all.extend(r.finish());
        assert_eq!(all, b"login ok with [REDACTED] done");
    }

    #[test]
    fn redacts_at_every_split_point() {
        let secret = "s3cr3t-value";
        let stream = format!("prefix {secret} suffix").into_bytes();
        for split in 0..=stream.len() {
            let out = run_split(secret, &stream, split);
            let text = String::from_utf8_lossy(&out).to_string();
            assert!(
                !text.contains(secret),
                "secret leaked at split {split}: {text}"
            );
            assert!(text.contains("[REDACTED]"), "no marker at split {split}");
            assert!(text.starts_with("prefix "), "prefix mangled at {split}");
            assert!(text.ends_with(" suffix"), "suffix mangled at {split}");
        }
    }

    #[test]
    fn self_overlapping_secret_never_leaks() {
        // "topsecret" ends with its own first byte: a naive holdback
        // emits "topsecre" and then "t" on the next chunk. Every split
        // point and a byte-at-a-time drip must both stay clean.
        let secret = "topsecret";
        let stream = format!("say {secret} now").into_bytes();
        for split in 0..=stream.len() {
            let out = run_split(secret, &stream, split);
            let text = String::from_utf8_lossy(&out).to_string();
            assert!(!text.contains(secret), "leak at split {split}: {text}");
            assert!(!text.contains("topsecre"), "partial leak at {split}");
            assert!(text.contains("[REDACTED]"), "no marker at {split}");
        }
        let out = run_drip(secret, &stream);
        let text = String::from_utf8_lossy(&out).to_string();
        assert!(!text.contains(secret), "drip leak: {text}");
        assert!(text.contains("[REDACTED]"));
        assert!(text.starts_with("say ") && text.ends_with(" now"));
    }

    #[test]
    fn repeated_char_secret_never_leaks() {
        let secret = "aaaaaa";
        let stream = b"xx aaaaaa yy".to_vec();
        for split in 0..=stream.len() {
            let out = run_split(secret, &stream, split);
            let text = String::from_utf8_lossy(&out).to_string();
            assert!(!text.contains(secret), "leak at split {split}: {text}");
        }
        let out = run_drip(secret, &stream);
        assert!(!String::from_utf8_lossy(&out).contains(secret));
    }

    #[test]
    fn secret_at_stream_end_is_flushed_by_finish() {
        let mut r = Redactor::new(&["abcdef"]);
        let mut out = r.push(b"value: abcdef");
        out.extend(r.finish());
        assert_eq!(out, b"value: [REDACTED]");
    }

    #[test]
    fn self_overlapping_secret_streams_with_progress() {
        // Regression test for the v0.4.1 fix (audit finding
        // vaultlane/redact/self-overlap-holdback-dos): before it,
        // safe_emit_len let occurrences across the whole buffer pull
        // the emit boundary back, and for a self-overlapping secret
        // ("abcabc" has period 3 < length 6) printed in a tiled
        // stream the boundary cascaded to 0 on every chunk — push
        // emitted NOTHING and the buffer grew without bound. The fix
        // must restore streaming progress while never leaking.
        let secret = "abcabc";
        let mut stream = Vec::new();
        while stream.len() < 12 * 1024 {
            stream.extend_from_slice(b"abc");
        }
        let mut r = Redactor::new(&[secret]);
        let mut emitted_before_finish = 0usize;
        let mut out = Vec::new();
        for chunk in stream.chunks(1024) {
            let emit = r.push(chunk);
            emitted_before_finish += emit.len();
            out.extend(emit);
        }
        assert!(
            emitted_before_finish > 0,
            "no emission progress on a tiled self-overlapping stream"
        );
        out.extend(r.finish());
        let text = String::from_utf8_lossy(&out).to_string();
        assert!(!text.contains(secret), "secret leaked: {text}");
        assert!(text.contains("[REDACTED]"), "no marker in output");
    }

    #[test]
    fn short_values_are_not_redacted() {
        let mut r = Redactor::new(&["abc"]);
        assert!(!r.active());
        let out = r.push(b"abc abc");
        assert_eq!(out, b"abc abc");
    }

    #[test]
    fn longer_secret_wins_over_substring() {
        let mut r = Redactor::new(&["abcd", "abcdefgh"]);
        let mut out = r.push(b"xabcdefghy");
        out.extend(r.finish());
        assert_eq!(out, b"x[REDACTED]y");
    }

    #[test]
    fn partial_prefix_is_not_emitted_early() {
        let mut r = Redactor::new(&["topsecretvalue"]);
        let out = r.push(b"the topse");
        // "topse" is a proper prefix of the secret: only "the " may emit.
        assert_eq!(out, b"the ");
        let mut rest = r.push(b"cretvalue is out");
        rest.extend(r.finish());
        assert_eq!(rest, b"[REDACTED] is out");
    }

    #[test]
    fn secret_extended_by_next_chunk_uses_longer_match() {
        // "abcd" sits at the first chunk's tail; the next chunk extends
        // it into the longer secret "abcdef". Nothing may leak and the
        // longer value is the one that gets masked.
        let mut r = Redactor::new(&["abcd", "abcdef"]);
        let mut out = r.push(b"key is abcd");
        out.extend(r.push(b"ef!"));
        out.extend(r.finish());
        let text = String::from_utf8_lossy(&out).to_string();
        assert!(!text.contains("abcd"), "leaked: {text}");
        assert_eq!(text, "key is [REDACTED]!");
    }

    #[test]
    fn plain_output_passes_through() {
        let mut r = Redactor::new(&["zzz-not-present"]);
        let mut out = r.push(b"hello world, nothing to hide here");
        out.extend(r.finish());
        assert_eq!(out, b"hello world, nothing to hide here");
    }

    #[test]
    fn base64_encoding_is_redacted() {
        // base64("hunter2-secret") = "aHVudGVyMi1zZWNyZXQ="
        let secret = "hunter2-secret";
        let encoded = "aHVudGVyMi1zZWNyZXQ=";
        let mut r = Redactor::new(&[secret]);
        let mut out = r.push(format!("key b64: {encoded} end").as_bytes());
        out.extend(r.finish());
        let text = String::from_utf8_lossy(&out).to_string();
        assert!(!text.contains(encoded), "base64 leaked: {text}");
        assert!(text.contains("[REDACTED]"));
        assert!(text.starts_with("key b64: ") && text.ends_with(" end"));
    }

    #[test]
    fn base64_unpadded_is_redacted() {
        let secret = "hunter2-secret";
        let encoded = "aHVudGVyMi1zZWNyZXQ"; // no trailing '='
        let mut r = Redactor::new(&[secret]);
        let mut out = r.push(format!("k={encoded}!").as_bytes());
        out.extend(r.finish());
        let text = String::from_utf8_lossy(&out).to_string();
        assert!(!text.contains(encoded), "unpadded base64 leaked: {text}");
        assert!(text.contains("[REDACTED]"));
    }

    #[test]
    fn base64_split_at_every_point_is_redacted() {
        let secret = "s3cr3t-value";
        let encoded = base64_encode(secret.as_bytes(), true);
        let mut stream = b"pre ".to_vec();
        stream.extend_from_slice(&encoded);
        stream.extend_from_slice(b" post");
        for split in 0..=stream.len() {
            let mut r = Redactor::new(&[secret]);
            let mut out = r.push(&stream[..split]);
            out.extend(r.push(&stream[split..]));
            out.extend(r.finish());
            let text = String::from_utf8_lossy(&out).to_string();
            assert!(
                !text.contains(&String::from_utf8_lossy(&encoded).to_string()),
                "encoded form leaked at split {split}: {text}"
            );
            assert!(text.contains("[REDACTED]"), "no marker at {split}");
        }
    }

    #[test]
    fn hex_encodings_are_redacted() {
        // hex("hunter2") = "68756e74657232"
        let secret = "hunter2";
        for encoded in ["68756e74657232", "68756E74657232"] {
            let mut r = Redactor::new(&[secret]);
            let mut out = r.push(format!("hex: {encoded}.").as_bytes());
            out.extend(r.finish());
            let text = String::from_utf8_lossy(&out).to_string();
            assert!(!text.contains(encoded), "hex leaked ({encoded}): {text}");
            assert!(text.contains("[REDACTED]"));
        }
    }

    #[test]
    fn encoders_match_known_vectors() {
        assert_eq!(
            base64_encode(b"hunter2-secret", true),
            b"aHVudGVyMi1zZWNyZXQ="
        );
        assert_eq!(
            base64_encode(b"hunter2-secret", false),
            b"aHVudGVyMi1zZWNyZXQ"
        );
        assert_eq!(base64_encode(b"f", true), b"Zg==");
        assert_eq!(base64_encode(b"fo", true), b"Zm8=");
        assert_eq!(base64_encode(b"foo", true), b"Zm9v");
        assert_eq!(hex_encode(b"hunter2", false), b"68756e74657232");
        assert_eq!(hex_encode(b"hunter2", true), b"68756E74657232");
    }
}
