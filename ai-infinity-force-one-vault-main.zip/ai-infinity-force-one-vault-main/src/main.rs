//! main.rs — AI Infinity Force One Security Showcase Runner.

use ai_infinity_force_one_vault::pipeline::UnifiedPipeline;
use ai_infinity_force_one_vault::vault::policy::{Action, Effect, Principal, Resource, Rule};
use std::fs;

fn main() {
    println!("Running AI Infinity Force One Security Showcase...\n");
    println!("For full multi-scenario interactive showcase, run: cargo run --example security_showcase\n");

    let mut pipeline = UnifiedPipeline::new();
    let operator = Principal("operator_0001".to_string());
    let pov_resource = Resource("pov_ledger".to_string());

    pipeline.grant(Rule {
        effect: Effect::Allow,
        principal: operator.clone(),
        resource: pov_resource.clone(),
        actions: vec![Action::Write],
    });

    let pov_dir = "pov";
    if let Ok(entries) = fs::read_dir(pov_dir) {
        let mut files: Vec<_> = entries
            .filter_map(|entry| entry.ok())
            .map(|entry| entry.path())
            .filter(|path| path.extension().map(|ext| ext == "json").unwrap_or(false))
            .collect();
        files.sort();

        println!(
            "Ingesting {} PoV task file(s) through Unified Security Pipeline:",
            files.len()
        );
        for path in &files {
            let filename = path.file_name().unwrap().to_string_lossy();
            if let Ok(json) = fs::read_to_string(path) {
                let (res, _rep) =
                    pipeline.process_pov(&operator, &pov_resource, "main_lane", &json);
                match res {
                    Ok(true) => println!("  - [VERIFIED] {}", filename),
                    Ok(false) => {
                        println!("  - [FAILED/SPOOFED] {} (logged to audit ledger)", filename)
                    }
                    Err(e) => println!("  - [REJECTED] {}: {:?}", filename, e),
                }
            }
        }
    }

    println!("\nTotal audit ledger entries: {}", pipeline.audit_len());
    match pipeline.verify_audit() {
        Ok(()) => println!("Audit ledger verified: Hash chain 100% intact.\n"),
        Err(idx) => println!("Audit ledger broken at index: {}\n", idx),
    }
}
