// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! vault::checkpoint — Ed25519-signed chain-tip checkpoints for the audit ledger.
//!
//! The hash chain in [`super::audit`] proves a ledger is internally
//! consistent, but on its own it cannot see its own tail being cut:
//! a truncated or rolled-back chain still verifies. [`super::audit::
//! AuditLog::verify_anchored`] closes that gap only when a caller
//! supplies a head hash saved earlier, somewhere else.
//!
//! Checkpoints make the anchor self-contained. At an explicit
//! checkpoint, the ledger's current state — the number of entries
//! (`seq`) and the head hash — is signed with an Ed25519 key and the
//! signed record is stored in a dedicated table in the same database.
//! Verification then re-checks the chain *and* every checkpoint:
//! each signature must verify against its recorded `(seq, head_hash)`,
//! the chain state at that `seq` must match what was signed, and the
//! chain must still reach the latest checkpoint. A ledger truncated
//! or rolled back past its latest checkpoint fails verification.
//!
//! Honest limits, same family as the rest of the ledger:
//! - Checkpoints bind the chain tip at checkpoint time. Entries
//!   appended after the latest checkpoint are covered by the hash
//!   chain only, until the next checkpoint.
//! - An attacker who can rewrite the database *and delete the
//!   checkpoint records themselves* removes the anchor along with the
//!   entries. Checkpoints raise the bar; they do not make the ledger
//!   immutable, and they are not a substitute for an external witness.
//! - Only chain tips are signed, never individual entries: signing
//!   every append would cost orders of magnitude of append throughput
//!   to protect a property the hash chain already provides.
//!
//! Checkpointing is opt-in and off by default. The signing key is
//! loaded only from a key file named by the [`CHECKPOINT_KEY_FILE_ENV`]
//! environment variable; with no key configured, no checkpoint records
//! are written and ledger behavior is unchanged.

use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use redb::{Database, ReadableTable, TableDefinition};
use serde::{Deserialize, Serialize};
use std::fmt::Write as _;
use std::path::Path;
use zeroize::{Zeroize, Zeroizing};

use super::audit::AuditLog;

/// Environment variable naming the checkpoint signing key file
/// (a raw 32-byte Ed25519 seed). Unset = checkpointing disabled.
pub const CHECKPOINT_KEY_FILE_ENV: &str = "MACK_CHECKPOINT_KEY_FILE";

/// Domain separator prefixed to every checkpoint message, so a
/// checkpoint signature can never be replayed as a signature over any
/// other payload shape.
pub const CHECKPOINT_DOMAIN: &[u8] = b"mack-checkpoint-v1";

/// Dedicated table for checkpoint records, keyed by checkpoint `seq`.
/// Separate from the entries/meta tables; their formats are untouched.
pub const CHECKPOINTS_TABLE: TableDefinition<u64, String> =
    TableDefinition::new("audit_checkpoints");

fn to_hex(bytes: &[u8]) -> String {
    let mut out = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        let _ = write!(out, "{:02x}", b);
    }
    out
}

/// A signed statement of the ledger's state at one moment: the chain
/// had `seq` entries and its head hash was `head_hash`, attested by
/// the Ed25519 key whose public half is `pubkey`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CheckpointRecord {
    /// Number of ledger entries covered by this checkpoint. The
    /// checkpoint binds the entry with sequence `seq - 1` (or the
    /// genesis hash when `seq` is 0).
    pub seq: u64,
    /// Hex head hash of the ledger at `seq`.
    pub head_hash: String,
    /// Hex Ed25519 signature over [`checkpoint_message`].
    pub signature: String,
    /// Hex Ed25519 public key that produced `signature`.
    pub pubkey: String,
}

/// The exact byte string a checkpoint signs:
/// `"mack-checkpoint-v1" || seq (8 bytes, big-endian) || head_hash`.
pub fn checkpoint_message(seq: u64, head_hash: &str) -> Vec<u8> {
    let mut msg = Vec::with_capacity(CHECKPOINT_DOMAIN.len() + 8 + head_hash.len());
    msg.extend_from_slice(CHECKPOINT_DOMAIN);
    msg.extend_from_slice(&seq.to_be_bytes());
    msg.extend_from_slice(head_hash.as_bytes());
    msg
}

/// Errors from checkpoint signing, storage, and verification.
#[derive(Debug)]
pub enum CheckpointError {
    /// Filesystem / OS error (e.g. reading the key file).
    Io(std::io::Error),
    /// Embedded database error.
    Db(Box<redb::Error>),
    /// A stored checkpoint record could not be deserialized.
    Decode(serde_json::Error),
    /// The key file exists but is not a raw 32-byte Ed25519 seed.
    InvalidKeyFile(String),
    /// The hash chain itself is broken; value is the first bad index.
    ChainBroken {
        /// Index of the first entry that fails chain verification.
        broken_index: usize,
    },
    /// A checkpoint's signature does not verify against its recorded
    /// public key and `(seq, head_hash)`.
    BadSignature {
        /// Sequence of the checkpoint whose signature failed.
        seq: u64,
    },
    /// The chain's state at a checkpoint's `seq` differs from the
    /// signed head hash (entries were rewritten under the checkpoint).
    StateMismatch {
        /// Sequence of the checkpoint whose state no longer matches.
        seq: u64,
    },
    /// The chain no longer reaches the latest checkpoint: entries
    /// were truncated or rolled back past it.
    Truncated {
        /// Sequence bound by the checkpoint.
        checkpoint_seq: u64,
        /// Entries actually present in the ledger.
        ledger_entries: u64,
    },
    /// A checkpoint was produced by a different key than the caller
    /// requires (see `expected_pubkey` in [`verify_checkpoints`]).
    WrongKey {
        /// Sequence of the checkpoint signed by the unexpected key.
        seq: u64,
    },
}

impl std::fmt::Display for CheckpointError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CheckpointError::Io(e) => write!(f, "checkpoint I/O error: {e}"),
            CheckpointError::Db(e) => write!(f, "checkpoint database error: {e}"),
            CheckpointError::Decode(e) => write!(f, "checkpoint decode error: {e}"),
            CheckpointError::InvalidKeyFile(msg) => {
                write!(f, "invalid checkpoint key file: {msg}")
            }
            CheckpointError::ChainBroken { broken_index } => {
                write!(f, "audit chain broken at entry {broken_index}")
            }
            CheckpointError::BadSignature { seq } => {
                write!(f, "checkpoint at seq {seq} has an invalid signature")
            }
            CheckpointError::StateMismatch { seq } => {
                write!(
                    f,
                    "ledger state at checkpoint seq {seq} does not match the signed head hash"
                )
            }
            CheckpointError::Truncated {
                checkpoint_seq,
                ledger_entries,
            } => write!(
                f,
                "ledger has {ledger_entries} entries but a checkpoint binds seq {checkpoint_seq}: truncated or rolled back"
            ),
            CheckpointError::WrongKey { seq } => {
                write!(f, "checkpoint at seq {seq} was signed by an unexpected key")
            }
        }
    }
}

impl std::error::Error for CheckpointError {}

impl From<redb::Error> for CheckpointError {
    fn from(e: redb::Error) -> Self {
        CheckpointError::Db(Box::new(e))
    }
}

impl From<redb::TransactionError> for CheckpointError {
    fn from(e: redb::TransactionError) -> Self {
        CheckpointError::Db(Box::new(e.into()))
    }
}

impl From<redb::TableError> for CheckpointError {
    fn from(e: redb::TableError) -> Self {
        CheckpointError::Db(Box::new(e.into()))
    }
}

impl From<redb::StorageError> for CheckpointError {
    fn from(e: redb::StorageError) -> Self {
        CheckpointError::Db(Box::new(e.into()))
    }
}

impl From<redb::CommitError> for CheckpointError {
    fn from(e: redb::CommitError) -> Self {
        CheckpointError::Db(Box::new(e.into()))
    }
}

impl From<redb::DatabaseError> for CheckpointError {
    fn from(e: redb::DatabaseError) -> Self {
        CheckpointError::Db(Box::new(e.into()))
    }
}

impl From<std::io::Error> for CheckpointError {
    fn from(e: std::io::Error) -> Self {
        CheckpointError::Io(e)
    }
}

impl From<serde_json::Error> for CheckpointError {
    fn from(e: serde_json::Error) -> Self {
        CheckpointError::Decode(e)
    }
}

/// Holds the Ed25519 seed used to sign checkpoints. The seed lives
/// only in a key file on disk and in scrubbed memory here; it is
/// never logged or exported.
pub struct CheckpointSigner {
    seed: Zeroizing<[u8; 32]>,
}

impl CheckpointSigner {
    /// Builds a signer from a raw 32-byte Ed25519 seed.
    pub fn from_seed(seed: [u8; 32]) -> Self {
        Self {
            seed: Zeroizing::new(seed),
        }
    }

    /// Loads a signer from a key file containing exactly one raw
    /// 32-byte Ed25519 seed.
    pub fn from_key_file(path: impl AsRef<Path>) -> Result<Self, CheckpointError> {
        let path = path.as_ref();
        let mut bytes = std::fs::read(path)?;
        if bytes.len() != 32 {
            let found = bytes.len();
            bytes.zeroize();
            return Err(CheckpointError::InvalidKeyFile(format!(
                "{}: expected a 32-byte Ed25519 seed, found {found} bytes",
                path.display()
            )));
        }
        let mut seed = [0u8; 32];
        seed.copy_from_slice(&bytes);
        bytes.zeroize();
        Ok(Self::from_seed(seed))
    }

    /// Loads a signer from the key file named by
    /// [`CHECKPOINT_KEY_FILE_ENV`]. Returns `Ok(None)` — checkpointing
    /// disabled — when the variable is unset. This is the only way
    /// production code obtains a signer: no env var, no checkpoints.
    pub fn from_env() -> Result<Option<Self>, CheckpointError> {
        match std::env::var_os(CHECKPOINT_KEY_FILE_ENV) {
            None => Ok(None),
            Some(path) => Ok(Some(Self::from_key_file(std::path::PathBuf::from(path))?)),
        }
    }

    fn signing_key(&self) -> SigningKey {
        SigningKey::from_bytes(&self.seed)
    }

    /// Hex public key this signer attests under.
    pub fn public_key_hex(&self) -> String {
        to_hex(&self.signing_key().verifying_key().to_bytes())
    }

    /// Signs the ledger state `(seq, head_hash)` and returns the
    /// record to store.
    pub fn sign_checkpoint(&self, seq: u64, head_hash: &str) -> CheckpointRecord {
        let signing_key = self.signing_key();
        let signature = signing_key.sign(&checkpoint_message(seq, head_hash));
        CheckpointRecord {
            seq,
            head_hash: head_hash.to_string(),
            signature: to_hex(&signature.to_bytes()),
            pubkey: to_hex(&signing_key.verifying_key().to_bytes()),
        }
    }
}

/// Verifies one record's signature against its own recorded public
/// key and `(seq, head_hash)`.
fn verify_record_signature(record: &CheckpointRecord) -> Result<(), CheckpointError> {
    let bad = || CheckpointError::BadSignature { seq: record.seq };
    let pub_bytes = hex::decode(record.pubkey.trim()).map_err(|_| bad())?;
    let pub_array: [u8; 32] = pub_bytes.try_into().map_err(|_| bad())?;
    let verifying_key = VerifyingKey::from_bytes(&pub_array).map_err(|_| bad())?;
    let sig_bytes = hex::decode(record.signature.trim()).map_err(|_| bad())?;
    let sig_array: [u8; 64] = sig_bytes.try_into().map_err(|_| bad())?;
    let signature = Signature::from_bytes(&sig_array);
    verifying_key
        .verify(
            &checkpoint_message(record.seq, &record.head_hash),
            &signature,
        )
        .map_err(|_| bad())
}

/// Verifies a ledger against its checkpoint records:
///
/// 1. The hash chain must verify exactly as
///    [`AuditLog::verify`](super::audit::AuditLog::verify) does.
/// 2. Every checkpoint's signature must verify against its recorded
///    `(seq, head_hash)` and public key; when `expected_pubkey` is
///    given, every checkpoint must carry that key — a checkpoint
///    signed by any other key is rejected.
/// 3. The chain must reach every checkpoint (no truncation or
///    rollback past it) and its state at that `seq` must equal the
///    signed head hash.
///
/// An empty `checkpoints` set verifies exactly like the plain chain.
pub fn verify_checkpoints(
    log: &AuditLog,
    checkpoints: &[CheckpointRecord],
    expected_pubkey: Option<&str>,
) -> Result<(), CheckpointError> {
    log.verify()
        .map_err(|broken_index| CheckpointError::ChainBroken { broken_index })?;

    let entries = log.entries();
    for record in checkpoints {
        if let Some(expected) = expected_pubkey {
            if record.pubkey != expected {
                return Err(CheckpointError::WrongKey { seq: record.seq });
            }
        }
        verify_record_signature(record)?;
        if record.seq > entries.len() as u64 {
            return Err(CheckpointError::Truncated {
                checkpoint_seq: record.seq,
                ledger_entries: entries.len() as u64,
            });
        }
        let actual_head = if record.seq == 0 {
            log.genesis_hash().to_string()
        } else {
            entries[(record.seq - 1) as usize].hash.clone()
        };
        if actual_head != record.head_hash {
            return Err(CheckpointError::StateMismatch { seq: record.seq });
        }
    }
    Ok(())
}

/// Persists a checkpoint record in the checkpoints table of `db`.
/// The table is created on first use; no other table is touched.
pub fn store_checkpoint(db: &Database, record: &CheckpointRecord) -> Result<(), CheckpointError> {
    let json = serde_json::to_string(record)?;
    let write_txn = db.begin_write()?;
    {
        let mut table = write_txn.open_table(CHECKPOINTS_TABLE)?;
        table.insert(record.seq, json)?;
    }
    write_txn.commit()?;
    Ok(())
}

/// Loads every stored checkpoint record, in sequence order. A
/// database that has never been checkpointed yields an empty list.
pub fn load_checkpoints(db: &Database) -> Result<Vec<CheckpointRecord>, CheckpointError> {
    let read_txn = db.begin_read()?;
    let table = match read_txn.open_table(CHECKPOINTS_TABLE) {
        Ok(table) => table,
        Err(redb::TableError::TableDoesNotExist(_)) => return Ok(Vec::new()),
        Err(e) => return Err(e.into()),
    };
    let mut records = Vec::new();
    for item in table.iter()? {
        let (_seq, json) = item?;
        records.push(serde_json::from_str(&json.value())?);
    }
    Ok(records)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::vault::persistent::PersistentLedger;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicU64, Ordering};

    static TEST_COUNTER: AtomicU64 = AtomicU64::new(5000);

    const TEST_ENTRIES_TABLE: TableDefinition<u64, String> = TableDefinition::new("audit_entries");

    fn temp_ledger_path(test_name: &str) -> PathBuf {
        let id = TEST_COUNTER.fetch_add(1, Ordering::SeqCst);
        let mut p = std::env::temp_dir();
        p.push(format!(
            "vault_checkpoint_test_{}_{}_{}",
            test_name,
            std::process::id(),
            id
        ));
        p.push("ledger.redb");
        p
    }

    fn cleanup(path: &Path) {
        if let Some(parent) = path.parent() {
            let _ = std::fs::remove_dir_all(parent);
        }
    }

    fn test_signer() -> CheckpointSigner {
        CheckpointSigner::from_seed([7u8; 32])
    }

    fn delete_entry(db: &Database, seq: u64) {
        let txn = db.begin_write().expect("write txn");
        {
            let mut table = txn.open_table(TEST_ENTRIES_TABLE).expect("entries table");
            table.remove(seq).expect("remove entry");
        }
        txn.commit().expect("commit");
    }

    fn rewrite_checkpoint(db: &Database, record: &CheckpointRecord) {
        let txn = db.begin_write().expect("write txn");
        {
            let mut table = txn
                .open_table(CHECKPOINTS_TABLE)
                .expect("checkpoints table");
            let json = serde_json::to_string(record).expect("encode");
            table.insert(record.seq, json).expect("insert");
        }
        txn.commit().expect("commit");
    }

    #[test]
    fn checkpoint_round_trip_verifies() {
        let path = temp_ledger_path("round_trip");
        let signer = test_signer();
        let ledger = PersistentLedger::open(&path).expect("open");

        // Checkpoint of the empty ledger binds the genesis hash at seq 0.
        let genesis_record = ledger.checkpoint(&signer).expect("checkpoint empty");
        assert_eq!(genesis_record.seq, 0);
        assert_eq!(genesis_record.head_hash, ledger.genesis_hash());
        assert_eq!(genesis_record.pubkey, signer.public_key_hex());

        for i in 0..5 {
            ledger
                .append("alice", &format!("action_{i}"))
                .expect("append");
        }
        let record = ledger.checkpoint(&signer).expect("checkpoint");
        assert_eq!(record.seq, 5);
        assert_eq!(record.head_hash, ledger.head_hash());
        assert_eq!(record.pubkey, signer.public_key_hex());

        let stored = ledger.checkpoints().expect("load checkpoints");
        assert_eq!(stored.len(), 2);
        assert_eq!(stored[1], record);

        // Verifies with no key requirement, and with the signer's key pinned.
        ledger.verify_checkpoints(None).expect("verify checkpoints");
        ledger
            .verify_checkpoints(Some(&signer.public_key_hex()))
            .expect("verify checkpoints with pinned key");
        drop(ledger);

        // Checkpoints survive reopen and still verify.
        let ledger = PersistentLedger::open(&path).expect("reopen");
        assert_eq!(ledger.checkpoints().expect("load").len(), 2);
        ledger
            .verify_checkpoints(None)
            .expect("verify after reopen");
        cleanup(&path);
    }

    #[test]
    fn truncation_past_checkpoint_detected() {
        let path = temp_ledger_path("truncate");
        let signer = test_signer();
        {
            let ledger = PersistentLedger::open(&path).expect("open");
            for i in 0..5 {
                ledger
                    .append("alice", &format!("action_{i}"))
                    .expect("append");
            }
            ledger.checkpoint(&signer).expect("checkpoint");
        }
        // Attacker cuts the tail: the remaining 3 entries still form a
        // valid hash chain, but they no longer reach the checkpoint.
        {
            let db = Database::create(&path).expect("raw open");
            delete_entry(&db, 4);
            delete_entry(&db, 3);
        }
        let ledger = PersistentLedger::open(&path).expect("reopen");
        assert_eq!(ledger.len(), 3);
        assert!(
            ledger.verify().is_ok(),
            "truncated chain is internally valid"
        );
        match ledger.verify_checkpoints(None) {
            Err(CheckpointError::Truncated {
                checkpoint_seq,
                ledger_entries,
            }) => {
                assert_eq!(checkpoint_seq, 5);
                assert_eq!(ledger_entries, 3);
            }
            other => panic!("expected Truncated error, got: {other:?}"),
        }
        cleanup(&path);
    }

    #[test]
    fn rollback_past_latest_checkpoint_detected() {
        let path = temp_ledger_path("rollback");
        let signer = test_signer();
        {
            let ledger = PersistentLedger::open(&path).expect("open");
            for i in 0..3 {
                ledger
                    .append("alice", &format!("action_{i}"))
                    .expect("append");
            }
            ledger.checkpoint(&signer).expect("checkpoint at 3");
            for i in 3..5 {
                ledger
                    .append("alice", &format!("action_{i}"))
                    .expect("append");
            }
            ledger.checkpoint(&signer).expect("checkpoint at 5");
        }
        // Attacker rolls the ledger back to the seq-3 state, hoping the
        // older checkpoint covers it. The latest checkpoint binds seq 5,
        // so the rolled-back state must fail.
        {
            let db = Database::create(&path).expect("raw open");
            delete_entry(&db, 4);
            delete_entry(&db, 3);
        }
        let ledger = PersistentLedger::open(&path).expect("reopen");
        assert_eq!(ledger.len(), 3);
        assert!(ledger.verify().is_ok());
        match ledger.verify_checkpoints(None) {
            Err(CheckpointError::Truncated {
                checkpoint_seq: 5,
                ledger_entries: 3,
            }) => {}
            other => panic!("expected Truncated(5, 3), got: {other:?}"),
        }
        cleanup(&path);
    }

    #[test]
    fn forged_signature_rejected() {
        let path = temp_ledger_path("forged");
        let signer = test_signer();
        {
            let ledger = PersistentLedger::open(&path).expect("open");
            for i in 0..3 {
                ledger
                    .append("alice", &format!("action_{i}"))
                    .expect("append");
            }
            ledger.checkpoint(&signer).expect("checkpoint");
        }
        // Attacker flips one character of the stored signature.
        {
            let db = Database::create(&path).expect("raw open");
            let mut records = load_checkpoints(&db).expect("load");
            let record = records.first_mut().expect("one record");
            let mut sig = record.signature.clone().into_bytes();
            sig[0] = if sig[0] == b'0' { b'1' } else { b'0' };
            record.signature = String::from_utf8(sig).expect("utf8");
            rewrite_checkpoint(&db, record);
        }
        let ledger = PersistentLedger::open(&path).expect("reopen");
        match ledger.verify_checkpoints(None) {
            Err(CheckpointError::BadSignature { seq: 3 }) => {}
            other => panic!("expected BadSignature at seq 3, got: {other:?}"),
        }
        cleanup(&path);
    }

    #[test]
    fn wrong_key_rejected() {
        let path = temp_ledger_path("wrong_key");
        let signer = test_signer();
        let other = CheckpointSigner::from_seed([9u8; 32]);
        let ledger = PersistentLedger::open(&path).expect("open");
        for i in 0..3 {
            ledger
                .append("alice", &format!("action_{i}"))
                .expect("append");
        }
        ledger.checkpoint(&signer).expect("checkpoint");

        // The checkpoint is genuine, but the caller requires a
        // different notary key: rejected.
        match ledger.verify_checkpoints(Some(&other.public_key_hex())) {
            Err(CheckpointError::WrongKey { seq: 3 }) => {}
            other_result => panic!("expected WrongKey at seq 3, got: {other_result:?}"),
        }
        // And the genuine key is accepted.
        ledger
            .verify_checkpoints(Some(&signer.public_key_hex()))
            .expect("genuine key verifies");
        cleanup(&path);
    }

    #[test]
    fn checkpointing_disabled_without_env() {
        // No key file configured: the signer loader reports "disabled".
        std::env::remove_var(CHECKPOINT_KEY_FILE_ENV);
        let unloaded = CheckpointSigner::from_env().expect("from_env without var");
        assert!(unloaded.is_none(), "no env var means checkpointing is off");

        // A ledger that is never checkpointed carries no records and
        // verifies exactly as the plain chain does.
        let path = temp_ledger_path("disabled");
        let ledger = PersistentLedger::open(&path).expect("open");
        for i in 0..3 {
            ledger
                .append("alice", &format!("action_{i}"))
                .expect("append");
        }
        assert!(ledger.checkpoints().expect("load").is_empty());
        ledger.verify_checkpoints(None).expect("verify unchanged");
        assert!(ledger.verify().is_ok());
        drop(ledger);

        // The checkpoints table was never created in the database.
        {
            let db = Database::create(&path).expect("raw open");
            let read_txn = db.begin_read().expect("read txn");
            assert!(
                matches!(
                    read_txn.open_table(CHECKPOINTS_TABLE),
                    Err(redb::TableError::TableDoesNotExist(_))
                ),
                "disabled checkpointing must not create the table"
            );
        }

        // With the env var set, the signer loads from that key file.
        let key_path = temp_ledger_path("env_key");
        if let Some(dir) = key_path.parent() {
            std::fs::create_dir_all(dir).expect("create key dir");
        }
        let key_file = key_path.with_file_name("checkpoint-key.bin");
        std::fs::write(&key_file, [7u8; 32]).expect("write key file");
        std::env::set_var(CHECKPOINT_KEY_FILE_ENV, &key_file);
        let loaded = CheckpointSigner::from_env().expect("from_env with var");
        std::env::remove_var(CHECKPOINT_KEY_FILE_ENV);
        match loaded {
            Some(signer) => assert_eq!(signer.public_key_hex(), test_signer().public_key_hex()),
            None => panic!("env-configured signer must load"),
        }

        // A key file that is not a 32-byte seed is refused.
        let bad_file = key_path.with_file_name("bad-key.bin");
        std::fs::write(&bad_file, b"short").expect("write bad key file");
        assert!(matches!(
            CheckpointSigner::from_key_file(&bad_file),
            Err(CheckpointError::InvalidKeyFile(_))
        ));
        cleanup(&path);
        cleanup(&key_path);
    }
}
