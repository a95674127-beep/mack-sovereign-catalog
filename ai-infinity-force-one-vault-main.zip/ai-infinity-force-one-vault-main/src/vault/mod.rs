//! vault — Force One Vault module root.
//!
//! Ties together the vault's subsystems: crypto (encryption),
//! policy (access control), and audit (tamper-evident logging).
pub mod keyring;
pub mod provenance;

pub mod audit;
pub mod checkpoint;
pub mod crypto;
pub mod persistent;
pub mod policy;
use crate::detection::entropy_scan::{self, EntropyVerdict};
use crate::detection::hash_blocklist::{BlocklistVerdict, HashBlocklist};
use crate::pov::ProofOfVerification;
use audit::AuditLog;
use policy::{AccessPolicy, Action, Decision, OperationBudget, Principal, Resource};
use zeroize::Zeroizing;

/// The Force One Vault: combines encrypted storage, access policy
/// enforcement, and a tamper-evident audit trail into one interface.
pub struct Vault {
    policy: AccessPolicy,
    audit: AuditLog,
    blocklist: HashBlocklist,
    budget: OperationBudget,
}

#[derive(Debug)]
pub enum VaultError {
    AccessDenied,
    BudgetExhausted,
    Crypto(crypto::CryptoError),
    DetectionBlocked(String),
    InvalidPov(String),
}

impl Vault {
    /// Ingest a batch of PoV JSON records and verify them independently.
    pub fn ingest_pov_batch_json(
        &mut self,
        principal: &Principal,
        json_str: &str,
    ) -> Result<Vec<(String, bool)>, serde_json::Error> {
        let batch = ProofOfVerification::batch_from_json(json_str)?;
        let mut results = Vec::new();
        for pov in batch {
            let is_valid = pov.independently_verify();
            self.log_pov(principal, &pov);
            results.push((pov.task_id.clone(), is_valid));
        }
        Ok(results)
    }
    pub fn new() -> Self {
        const KNOWN_BAD_HASHES: &str = include_str!("../detection/known_bad_hashes.txt");
        let blocklist = HashBlocklist::load_from_str(KNOWN_BAD_HASHES);

        Self {
            policy: AccessPolicy::new(),
            audit: AuditLog::new(),
            blocklist,
            budget: OperationBudget::unlimited(),
        }
    }

    pub fn grant(&mut self, rule: policy::Rule) {
        self.policy.grant(rule);
    }

    /// Sets the operation budget: at most this many further
    /// policy-allowed store/retrieve operations will be performed
    /// before the vault starts refusing work with
    /// [`VaultError::BudgetExhausted`]. `None` (the default) is
    /// unlimited, preserving pre-harvest behavior. Pattern harvested
    /// from Stealth Core's gate (2026-11-10, harvest audit row 5).
    pub fn set_ops_budget(&mut self, budget: Option<usize>) {
        self.budget.set(budget);
    }

    /// Allowed operations consumed against the budget so far.
    pub fn ops_used(&self) -> usize {
        self.budget.used()
    }

    /// Allowed operations remaining; `None` when unlimited.
    pub fn ops_remaining(&self) -> Option<usize> {
        self.budget.remaining()
    }

    pub fn store(
        &mut self,
        principal: &Principal,
        resource: &Resource,
        plaintext: &[u8],
        passphrase: &[u8],
    ) -> Result<Vec<u8>, VaultError> {
        // Operation budget gate (harvested 2026-11-10, audit row 5):
        // checked BEFORE policy, so an exhausted vault refuses work
        // even for granted principals — and the refusal is audited,
        // mirroring Stealth Core's gate.
        if self.budget.is_exhausted() {
            self.audit.append(
                &principal.0,
                &format!("store.budget_exceeded:{}", resource.0),
            );
            return Err(VaultError::BudgetExhausted);
        }

        let decision = self.policy.evaluate(principal, resource, Action::Write);

        if decision == Decision::Deny {
            self.audit
                .append(&principal.0, &format!("store.denied:{}", resource.0));
            return Err(VaultError::AccessDenied);
        }

        match self.blocklist.scan_payload(plaintext) {
            BlocklistVerdict::Match(hash) => {
                self.audit
                    .append(&principal.0, &format!("store.blocked_hash:{}", hash));
                return Err(VaultError::DetectionBlocked(format!(
                    "known-bad hash: {}",
                    hash
                )));
            }
            BlocklistVerdict::Error(e) => {
                self.audit
                    .append(&principal.0, &format!("store.scan_error:{}", e));
                return Err(VaultError::DetectionBlocked(format!("scan error: {}", e)));
            }
            BlocklistVerdict::Clean => {}
        }

        if let EntropyVerdict::Suspicious(score) = entropy_scan::scan_payload(plaintext) {
            self.audit
                .append(&principal.0, &format!("store.blocked_entropy:{:.2}", score));
            return Err(VaultError::DetectionBlocked(format!(
                "suspicious entropy: {:.2}",
                score
            )));
        }

        match crypto::encrypt(plaintext, passphrase) {
            Ok(envelope) => {
                self.audit
                    .append(&principal.0, &format!("store.success:{}", resource.0));
                self.budget.record_allowed();
                Ok(envelope)
            }
            Err(e) => {
                self.audit
                    .append(&principal.0, &format!("store.crypto_failed:{}", resource.0));
                Err(VaultError::Crypto(e))
            }
        }
    }

    pub fn retrieve(
        &mut self,
        principal: &Principal,
        resource: &Resource,
        envelope: &[u8],
        passphrase: &[u8],
    ) -> Result<Zeroizing<Vec<u8>>, VaultError> {
        // Operation budget gate (harvested 2026-11-10, audit row 5):
        // checked BEFORE policy; the refusal is audited.
        if self.budget.is_exhausted() {
            self.audit.append(
                &principal.0,
                &format!("retrieve.budget_exceeded:{}", resource.0),
            );
            return Err(VaultError::BudgetExhausted);
        }

        let decision = self.policy.evaluate(principal, resource, Action::Read);

        if decision == Decision::Deny {
            self.audit
                .append(&principal.0, &format!("retrieve.denied:{}", resource.0));
            return Err(VaultError::AccessDenied);
        }

        match crypto::decrypt(envelope, passphrase) {
            Ok(plaintext) => {
                self.audit
                    .append(&principal.0, &format!("retrieve.success:{}", resource.0));
                self.budget.record_allowed();
                Ok(plaintext)
            }
            Err(e) => {
                self.audit.append(
                    &principal.0,
                    &format!("retrieve.crypto_failed:{}", resource.0),
                );
                Err(VaultError::Crypto(e))
            }
        }
    }

    pub fn verify_audit(&self) -> Result<(), usize> {
        self.audit.verify()
    }

    pub fn audit_len(&self) -> usize {
        self.audit.len()
    }

    pub fn log_pov(&mut self, principal: &Principal, pov: &ProofOfVerification) -> bool {
        let actually_verified = pov.independently_verify();

        let mut checked_pov = pov.clone();
        checked_pov.verified = actually_verified;

        self.audit.append(&principal.0, &checked_pov.to_log_entry());
        actually_verified
    }

    pub fn ingest_pov_json(
        &mut self,
        principal: &Principal,
        json: &str,
    ) -> Result<bool, VaultError> {
        match serde_json::from_str::<ProofOfVerification>(json) {
            Ok(pov) => Ok(self.log_pov(principal, &pov)),
            Err(e) => Err(VaultError::InvalidPov(e.to_string())),
        }
    }
}

impl Default for Vault {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Harvest (2026-11-10, audit row 5), mirroring Stealth Core's
    /// budget test shape: a budget of 2 allows exactly two gated
    /// operations; the third is refused with BudgetExhausted, and
    /// the refusal is written to the audit chain.
    #[test]
    fn operation_budget_refuses_after_limit() {
        let mut vault = Vault::new();
        vault.set_ops_budget(Some(2));
        let alice = Principal("alice".into());
        let secret = Resource("budget_secret".into());
        vault.grant(policy::Rule {
            effect: policy::Effect::Allow,
            principal: alice.clone(),
            resource: secret.clone(),
            actions: vec![Action::Write, Action::Read],
        });

        let envelope = vault
            .store(&alice, &secret, b"low entropy budget data", b"passphrase")
            .expect("first op within budget");
        assert_eq!(vault.ops_used(), 1);
        vault
            .retrieve(&alice, &secret, &envelope, b"passphrase")
            .expect("second op within budget");
        assert_eq!(vault.ops_used(), 2);
        assert_eq!(vault.ops_remaining(), Some(0));

        let result = vault.store(&alice, &secret, b"low entropy budget data", b"passphrase");
        assert!(
            matches!(result, Err(VaultError::BudgetExhausted)),
            "third op must be refused: {result:?}"
        );
        assert_eq!(vault.ops_used(), 2, "refused ops do not consume budget");
        assert!(
            vault
                .audit
                .entries()
                .iter()
                .any(|e| e.action == "store.budget_exceeded:budget_secret"),
            "the refusal must be audited"
        );
        vault.verify_audit().expect("audit chain intact");
    }

    /// A policy denial must not consume budget (Stealth semantics:
    /// only allowed operations count).
    #[test]
    fn operation_budget_ignores_denied_ops() {
        let mut vault = Vault::new();
        vault.set_ops_budget(Some(1));
        let alice = Principal("alice".into());
        let secret = Resource("budget_secret".into());

        // No grant yet: denied, and the budget is untouched.
        let denied = vault.store(&alice, &secret, b"low entropy budget data", b"passphrase");
        assert!(matches!(denied, Err(VaultError::AccessDenied)));
        assert_eq!(vault.ops_used(), 0);

        vault.grant(policy::Rule {
            effect: policy::Effect::Allow,
            principal: alice.clone(),
            resource: secret.clone(),
            actions: vec![Action::Write],
        });
        vault
            .store(&alice, &secret, b"low entropy budget data", b"passphrase")
            .expect("the single budgeted op");
        assert_eq!(vault.ops_used(), 1);
    }

    /// The default (no budget set) is unlimited — pre-harvest
    /// behavior is unchanged.
    #[test]
    fn operation_budget_default_unlimited() {
        let mut vault = Vault::new();
        assert_eq!(vault.ops_remaining(), None);
        let alice = Principal("alice".into());
        let secret = Resource("budget_secret".into());
        vault.grant(policy::Rule {
            effect: policy::Effect::Allow,
            principal: alice.clone(),
            resource: secret.clone(),
            actions: vec![Action::Write],
        });
        for _ in 0..5 {
            vault
                .store(&alice, &secret, b"low entropy budget data", b"passphrase")
                .expect("unlimited by default");
        }
        assert_eq!(vault.ops_used(), 5);
        assert_eq!(vault.ops_remaining(), None);
    }

    #[test]
    fn denies_store_without_grant() {
        let mut vault = Vault::new();
        let alice = Principal("alice".into());
        let secret = Resource("secret1".into());

        let result = vault.store(&alice, &secret, b"top secret", b"pw");
        assert!(matches!(result, Err(VaultError::AccessDenied)));
        assert_eq!(vault.audit_len(), 1);
    }

    #[test]
    fn allows_store_and_retrieve_with_grant() {
        let mut vault = Vault::new();
        let alice = Principal("alice".into());
        let secret = Resource("secret1".into());

        vault.grant(policy::Rule {
            effect: policy::Effect::Allow,
            principal: alice.clone(),
            resource: secret.clone(),
            actions: vec![Action::Write, Action::Read],
        });

        let ciphertext = vault
            .store(&alice, &secret, b"hello vault", b"passphrase")
            .unwrap();
        let plaintext = vault
            .retrieve(&alice, &secret, &ciphertext, b"passphrase")
            .unwrap();

        assert_eq!(plaintext.as_slice(), &b"hello vault"[..]);
    }

    #[test]
    fn rejects_store_with_blocklisted_payload() {
        let mut vault = Vault::new();
        let alice = Principal("alice".into());
        let secret = Resource("secret1".into());

        vault.grant(policy::Rule {
            effect: policy::Effect::Allow,
            principal: alice.clone(),
            resource: secret.clone(),
            actions: vec![Action::Write, Action::Read],
        });

        let result = vault.store(&alice, &secret, b"malicious_test_payload", b"pass");
        assert!(matches!(result, Err(VaultError::DetectionBlocked(_))));
        assert_eq!(vault.audit_len(), 1);
    }

    #[test]
    fn logs_pov_to_audit() {
        let mut vault = Vault::new();
        let alice = Principal("alice".into());
        let pov = ProofOfVerification {
            pov_version: "0.1".into(),
            task_id: "task_0001".into(),
            operator_id: "operator_0001".into(),
            timestamp_start: "2026-08-28T20:00:00Z".into(),
            timestamp_end: "2026-08-28T20:00:07Z".into(),
            task_type: "example_task".into(),
            input_hash: "sha256:input_placeholder".into(),
            output_hash: "sha256:output_placeholder".into(),
            verification_method: "hash_match".into(),
            verified: true,
            signature: "placeholder_signature".into(),
        };

        let result = vault.log_pov(&alice, &pov);
        assert!(result);
        assert_eq!(vault.audit_len(), 1);
    }

    #[test]
    fn logs_failed_pov_to_audit() {
        let mut vault = Vault::new();
        let alice = Principal("alice".into());
        let pov = ProofOfVerification {
            pov_version: "0.1".into(),
            task_id: "task_0002".into(),
            operator_id: "operator_0002".into(),
            timestamp_start: "2026-08-28T21:00:00Z".into(),
            timestamp_end: "2026-08-28T21:00:09Z".into(),
            task_type: "example_task".into(),
            input_hash: "sha256:same_hash".into(),
            output_hash: "sha256:same_hash".into(),
            verification_method: "hash_match".into(),
            verified: true,
            signature: "placeholder_signature".into(),
        };

        let result = vault.log_pov(&alice, &pov);
        assert!(!result);
        assert_eq!(vault.audit_len(), 1);
    }

    #[test]
    fn overrides_false_claim_when_hashes_actually_differ() {
        let mut vault = Vault::new();
        let alice = Principal("alice".into());
        let pov = ProofOfVerification {
            pov_version: "0.1".into(),
            task_id: "task_0003".into(),
            operator_id: "operator_0003".into(),
            timestamp_start: "2026-08-28T22:00:00Z".into(),
            timestamp_end: "2026-08-28T22:00:05Z".into(),
            task_type: "example_task".into(),
            input_hash: "sha256:real_input".into(),
            output_hash: "sha256:real_output".into(),
            verification_method: "hash_match".into(),
            verified: false,
            signature: "placeholder_signature".into(),
        };

        let result = vault.log_pov(&alice, &pov);
        assert!(result);
    }

    #[test]
    fn ingests_valid_pov_json() {
        let mut vault = Vault::new();
        let alice = Principal("alice".into());
        let json = r#"{
            "pov_version": "1.0",
            "task_id": "task_0001",
            "operator_id": "operator_0001",
            "timestamp_start": "2026-08-28T00:00:00Z",
            "timestamp_end": "2026-08-28T00:00:01Z",
            "task_type": "example_task",
            "input_hash": "abc123",
            "output_hash": "def456",
            "verification_method": "hash_match",
            "verified": true,
            "signature": "sig"
        }"#;

        let result = vault.ingest_pov_json(&alice, json);
        assert!(result.is_ok());
        assert!(result.unwrap());
        assert_eq!(vault.audit_len(), 1);
    }

    #[test]
    fn rejects_malformed_pov_json() {
        let mut vault = Vault::new();
        let alice = Principal("alice".into());
        let bad_json = "{ not valid json";

        let result = vault.ingest_pov_json(&alice, bad_json);
        assert!(matches!(result, Err(VaultError::InvalidPov(_))));
        assert_eq!(vault.audit_len(), 0);
    }
}

pub mod forensics;
pub use forensics::{ForensicIncidentRecord, ForensicLedger};
