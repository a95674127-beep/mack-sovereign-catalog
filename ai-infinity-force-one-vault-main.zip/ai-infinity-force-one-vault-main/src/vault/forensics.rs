//! Military & JAG/S2 Forensic Incident Chain of Custody.
//!
//! Produces tamper-evident, hash-chained after-action reports (AAR)
//! for cyber incident response, Air Defense Artillery C2 integrity, and JAG legal review.

use crate::detection::triage::TriageOutcome;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::sync::{Mutex, MutexGuard};

/// Locks a mutex, recovering the guard when a previous holder panicked
/// while holding it — the same policy as the audit ledger's
/// `ConcurrentLedger` (src/vault/audit.rs).
fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
    mutex
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ForensicIncidentRecord {
    pub incident_id: String,
    pub timestamp_utc: DateTime<Utc>,
    pub lane_code: String,
    pub payload_sha256: String,
    pub triage_outcome: TriageOutcome,
    pub threat_score: u32,
    pub detected_indicators: Vec<String>,
    pub operator_id: String,
    pub prev_record_hash: String,
    pub record_hash: String,
}

impl ForensicIncidentRecord {
    /// Computes the tamper-evident record hash over all fields except
    /// `record_hash` itself.
    pub fn compute_hash(&self) -> String {
        let mut hasher = Sha256::new();
        hasher.update(self.incident_id.as_bytes());
        hasher.update(self.timestamp_utc.to_rfc3339().as_bytes());
        hasher.update(self.lane_code.as_bytes());
        hasher.update(self.payload_sha256.as_bytes());
        hasher.update(self.triage_outcome.as_str().as_bytes());
        hasher.update(self.threat_score.to_le_bytes());
        hasher.update(self.operator_id.as_bytes());
        hasher.update(self.prev_record_hash.as_bytes());
        hex::encode(hasher.finalize())
    }
}

/// Inputs for [`ForensicLedger::record_incident`], grouped so the call
/// stays readable as the incident schema grows.
pub struct IncidentReport<'a> {
    pub incident_id: &'a str,
    pub lane_code: &'a str,
    pub payload_bytes: &'a [u8],
    pub triage_outcome: TriageOutcome,
    pub threat_score: u32,
    pub detected_indicators: Vec<String>,
    pub operator_id: &'a str,
}

pub struct ForensicLedger {
    records: Mutex<Vec<ForensicIncidentRecord>>,
}

impl Default for ForensicLedger {
    fn default() -> Self {
        Self::new()
    }
}

impl ForensicLedger {
    pub const GENESIS_HASH: &'static str =
        "0000000000000000000000000000000000000000000000000000000000000000";

    pub fn new() -> Self {
        Self {
            records: Mutex::new(Vec::new()),
        }
    }

    /// Appends a new forensic incident record to the tamper-evident chain.
    pub fn record_incident(&self, report: IncidentReport<'_>) -> ForensicIncidentRecord {
        let timestamp_utc = Utc::now();

        let mut payload_hasher = Sha256::new();
        payload_hasher.update(report.payload_bytes);
        let payload_sha256 = hex::encode(payload_hasher.finalize());

        let mut lock = lock(&self.records);
        let prev_record_hash = lock
            .last()
            .map(|r| r.record_hash.clone())
            .unwrap_or_else(|| Self::GENESIS_HASH.to_string());

        let mut record = ForensicIncidentRecord {
            incident_id: report.incident_id.to_string(),
            timestamp_utc,
            lane_code: report.lane_code.to_string(),
            payload_sha256,
            triage_outcome: report.triage_outcome,
            threat_score: report.threat_score,
            detected_indicators: report.detected_indicators,
            operator_id: report.operator_id.to_string(),
            prev_record_hash,
            record_hash: String::new(),
        };
        record.record_hash = record.compute_hash();

        lock.push(record.clone());
        record
    }

    /// Verifies the complete cryptographic chain of custody.
    pub fn verify_chain(&self) -> bool {
        let lock = lock(&self.records);
        let mut expected_prev = Self::GENESIS_HASH.to_string();

        for record in lock.iter() {
            if record.prev_record_hash != expected_prev {
                return false;
            }

            let computed = record.compute_hash();

            if computed != record.record_hash {
                return false;
            }

            expected_prev = record.record_hash.clone();
        }

        true
    }

    pub fn incident_count(&self) -> usize {
        lock(&self.records).len()
    }
}
