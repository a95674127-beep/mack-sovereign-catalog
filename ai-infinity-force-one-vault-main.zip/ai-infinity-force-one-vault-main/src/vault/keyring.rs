//! vault::keyring — secure key lifecycle: zeroized secret keys and rotation.
//!
//! SecretKey wraps a 32-byte symmetric key in `Zeroizing` so the key material
//! is overwritten with zeros the moment it goes out of scope, including on
//! panic-driven unwinding. KeyRing manages a set of SecretKeys with a single
//! active key for encryption and any number of retained keys for decryption,
//! enabling rotation without downtime and without re-encrypting history.

use chacha20poly1305::{
    aead::{Aead, KeyInit},
    XChaCha20Poly1305, XNonce,
};
use rand::RngCore;
use std::collections::HashMap;
use thiserror::Error;
use zeroize::{Zeroize, Zeroizing};

const ENVELOPE_VERSION: u8 = 0x02; // keyring envelope: [ver][key_id][nonce][ct]
const KEY_LEN: usize = 32;
const NONCE_LEN: usize = 24;

#[derive(Debug, Error)]
pub enum KeyError {
    #[error("encryption failed")]
    EncryptionFailed,
    #[error("decryption failed (wrong key or corrupted data)")]
    DecryptionFailed,
    #[error("envelope is too short to be valid")]
    InvalidEnvelope,
    #[error("unsupported envelope version: {0}")]
    UnsupportedVersion(u8),
    #[error("no key exists for key_id {0}")]
    UnknownKeyId(u32),
    #[error("cannot revoke the only active key; rotate first")]
    CannotRevokeActiveKey,
    #[error("random generation failed")]
    RandomGenerationFailed,
}

/// A 32-byte symmetric key held in zeroizing memory.
///
/// Backed by `Zeroizing<[u8; KEY_LEN]>` which wipes memory with zeros on drop.
///
/// Deliberately NOT `Clone`: secret key material must never be silently
/// duplicable. A second owner is created only explicitly, via
/// [`SecretKey::from_bytes`] on bytes obtained through
/// [`SecretKey::expose_zeroized`].
pub struct SecretKey {
    key: Zeroizing<[u8; KEY_LEN]>,
}

impl SecretKey {
    /// Generates a new random key from the OS entropy source.
    pub fn random() -> Result<Self, KeyError> {
        let mut bytes = Zeroizing::new([0u8; KEY_LEN]);
        rand::thread_rng().fill_bytes(&mut *bytes);
        Ok(Self { key: bytes })
    }

    /// Creates a SecretKey from raw bytes, taking ownership into zeroizing memory.
    pub fn from_bytes(raw: [u8; KEY_LEN]) -> Self {
        Self {
            key: Zeroizing::new(raw),
        }
    }

    /// Runs `f` with the raw key bytes, keeping the buffer protected.
    pub fn expose_zeroized<T>(&self, f: impl FnOnce(&[u8; KEY_LEN]) -> T) -> T {
        f(&self.key)
    }

    /// Immediately overwrites the key material with zeros. The key is
    /// unusable afterwards; subsequent operations fail.
    pub fn zeroize_now(&mut self) {
        self.key.zeroize();
    }

    pub fn is_zeroed(&self) -> bool {
        self.key.iter().all(|b| *b == 0)
    }

    /// Encrypts plaintext, returning an envelope of
    /// `[version (1)] [key_id (4, big-endian)] [nonce (24)] [ciphertext+tag]`.
    pub fn encrypt(&self, key_id: u32, plaintext: &[u8]) -> Result<Vec<u8>, KeyError> {
        if self.is_zeroed() {
            return Err(KeyError::EncryptionFailed);
        }
        let cipher = self.cipher();
        let mut nonce_bytes = [0u8; NONCE_LEN];
        rand::thread_rng()
            .try_fill_bytes(&mut nonce_bytes)
            .map_err(|_| KeyError::RandomGenerationFailed)?;
        let nonce = XNonce::from(nonce_bytes);

        let ciphertext = cipher
            .encrypt(&nonce, plaintext)
            .map_err(|_| KeyError::EncryptionFailed)?;

        let mut envelope = Vec::with_capacity(1 + 4 + NONCE_LEN + ciphertext.len());
        envelope.push(ENVELOPE_VERSION);
        envelope.extend_from_slice(&key_id.to_be_bytes());
        envelope.extend_from_slice(&nonce_bytes);
        envelope.extend_from_slice(&ciphertext);
        Ok(envelope)
    }

    /// Decrypts an envelope produced by [`SecretKey::encrypt`].
    ///
    /// The plaintext is returned inside [`Zeroizing`] so it is wiped
    /// when the caller drops it (Elevation A2 zeroize coverage audit,
    /// 2026-11-10 — this path previously returned a plain `Vec<u8>`).
    pub fn decrypt(&self, envelope: &[u8]) -> Result<Zeroizing<Vec<u8>>, KeyError> {
        if self.is_zeroed() {
            return Err(KeyError::DecryptionFailed);
        }
        if envelope.len() < 1 + 4 + NONCE_LEN + 16 {
            return Err(KeyError::InvalidEnvelope);
        }
        if envelope[0] != ENVELOPE_VERSION {
            return Err(KeyError::UnsupportedVersion(envelope[0]));
        }
        let nonce =
            XNonce::try_from(&envelope[5..5 + NONCE_LEN]).map_err(|_| KeyError::InvalidEnvelope)?;
        let ciphertext = &envelope[5 + NONCE_LEN..];

        self.cipher()
            .decrypt(&nonce, ciphertext)
            .map(Zeroizing::new)
            .map_err(|_| KeyError::DecryptionFailed)
    }

    /// Builds the cipher directly from the zeroizing key buffer
    /// (`new_from_slice`), so no intermediate owned key copy is made —
    /// the temporary `Key` the old code constructed was never wiped.
    /// Construction can only fail on a wrong key length, which the
    /// fixed `[u8; KEY_LEN]` buffer makes impossible; the cipher's own
    /// internal key state lives only inside the returned cipher object
    /// for the duration of the operation.
    fn cipher(&self) -> XChaCha20Poly1305 {
        XChaCha20Poly1305::new_from_slice(&*self.key)
            .expect("KEY_LEN-byte key is always a valid XChaCha20-Poly1305 key")
    }
}

/// A rotation-aware set of zeroized keys: one active key for encryption,
/// retained predecessor keys for decryption of existing envelopes.
pub struct KeyRing {
    keys: HashMap<u32, SecretKey>,
    active_key_id: u32,
    next_key_id: u32,
}

impl KeyRing {
    pub fn new() -> Result<Self, KeyError> {
        let mut ring = Self {
            keys: HashMap::new(),
            active_key_id: 0,
            next_key_id: 1,
        };
        ring.rotate()?;
        Ok(ring)
    }

    /// Generates a fresh random key and makes it the active encryption key.
    /// The previous active key is retained for decryption (zero downtime).
    /// Returns the new active key id.
    pub fn rotate(&mut self) -> Result<u32, KeyError> {
        let key = SecretKey::random()?;
        let id = self.next_key_id;
        self.next_key_id += 1;
        self.keys.insert(id, key);
        self.active_key_id = id;
        Ok(id)
    }

    pub fn active_key_id(&self) -> u32 {
        self.active_key_id
    }

    pub fn contains_key(&self, key_id: u32) -> bool {
        self.keys.contains_key(&key_id)
    }

    /// Encrypts with the currently active key.
    pub fn encrypt(&self, plaintext: &[u8]) -> Result<Vec<u8>, KeyError> {
        let key = self
            .keys
            .get(&self.active_key_id)
            .ok_or(KeyError::UnknownKeyId(self.active_key_id))?;
        key.encrypt(self.active_key_id, plaintext)
    }

    /// Decrypts with whichever retained key the envelope's key id selects.
    /// The plaintext is returned inside [`Zeroizing`] (see
    /// [`SecretKey::decrypt`]).
    pub fn decrypt(&self, envelope: &[u8]) -> Result<Zeroizing<Vec<u8>>, KeyError> {
        if envelope.len() < 5 {
            return Err(KeyError::InvalidEnvelope);
        }
        if envelope[0] != ENVELOPE_VERSION {
            return Err(KeyError::UnsupportedVersion(envelope[0]));
        }
        let key_id = u32::from_be_bytes([envelope[1], envelope[2], envelope[3], envelope[4]]);
        let key = self
            .keys
            .get(&key_id)
            .ok_or(KeyError::UnknownKeyId(key_id))?;
        key.decrypt(envelope)
    }

    /// Decrypts an envelope and re-encrypts it under the active key.
    /// Returns the new envelope; the caller is responsible for atomically
    /// replacing the stored one.
    pub fn re_encrypt(&self, envelope: &[u8]) -> Result<Vec<u8>, KeyError> {
        let plaintext = self.decrypt(envelope)?;
        self.encrypt(&plaintext)
    }

    /// Removes a retired key permanently. Envelopes encrypted under it
    /// become undecryptable. The active key cannot be revoked directly;
    /// rotate first, then revoke the old id.
    pub fn revoke_key(&mut self, key_id: u32) -> Result<(), KeyError> {
        if key_id == self.active_key_id {
            return Err(KeyError::CannotRevokeActiveKey);
        }
        match self.keys.remove(&key_id) {
            Some(mut key) => {
                key.zeroize_now();
                Ok(())
            }
            None => Err(KeyError::UnknownKeyId(key_id)),
        }
    }

    /// Number of retained keys (active + retired).
    pub fn len(&self) -> usize {
        self.keys.len()
    }

    pub fn is_empty(&self) -> bool {
        self.keys.is_empty()
    }
}

impl Default for KeyRing {
    fn default() -> Self {
        Self::new().expect("OS entropy source must be available")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Elevation A2: `SecretKey::decrypt` returns the plaintext inside
    /// `Zeroizing`, so dropping the return value wipes it (the wipe
    /// itself is the `zeroize` crate's guarantee; this test pins the
    /// wrapped round-trip so the signature cannot silently regress to
    /// a plain `Vec<u8>`).
    #[test]
    fn secret_key_decrypt_returns_zeroizing_plaintext() {
        let key = SecretKey::random().unwrap();
        let envelope = key.encrypt(7, b"sealed secret").unwrap();
        let plaintext: Zeroizing<Vec<u8>> = key.decrypt(&envelope).unwrap();
        assert_eq!(plaintext.as_slice(), b"sealed secret");
        drop(plaintext);
    }

    /// Elevation A2: same guarantee at the `KeyRing` facade.
    #[test]
    fn keyring_decrypt_returns_zeroizing_plaintext() {
        let keyring = KeyRing::new().unwrap();
        let envelope = keyring.encrypt(b"ring secret").unwrap();
        let plaintext: Zeroizing<Vec<u8>> = keyring.decrypt(&envelope).unwrap();
        assert_eq!(plaintext.as_slice(), b"ring secret");
        drop(plaintext);
    }
}
