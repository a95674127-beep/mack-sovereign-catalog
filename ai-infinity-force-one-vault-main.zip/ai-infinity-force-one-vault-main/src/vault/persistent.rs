// Copyright (c) 2026 Allen Mack. All Rights Reserved.
// Proprietary software - see NOTICE at the repository root.
//! vault::persistent — Crash-surviving audit ledger backed by an embedded database.
//!
//! The in-memory [`AuditLog`] loses everything on restart, which is fatal for a
//! system whose job is proving what happened. [`PersistentLedger`] keeps the
//! exact same hash-chained semantics but durably persists every entry to a
//! pure-Rust embedded database ([`redb`], no C toolchain required), so the
//! chain survives crashes and restarts and is re-verified on every open.
//!
//! Honest limits:
//! - This is single-node durability, not distributed consensus. It protects
//!   against crashes, not against an attacker who can rewrite the database
//!   file itself. Pair it with external anchoring (e.g. publishing head
//!   hashes elsewhere) for tamper-evidence against privileged attackers.
//! - Concurrent writers are serialized through one mutex; throughput is
//!   bounded by disk fsync latency, not memory speed.

use redb::{Database, ReadableTable, ReadableTableMetadata, TableDefinition};
use std::path::{Path, PathBuf};
use std::sync::Mutex;

use super::audit::{AuditEntry, AuditLog, SegmentVerificationReport};
use super::checkpoint::{self, CheckpointError, CheckpointRecord, CheckpointSigner};

const ENTRIES_TABLE: TableDefinition<u64, String> = TableDefinition::new("audit_entries");
const META_TABLE: TableDefinition<&str, String> = TableDefinition::new("audit_meta");
const META_GENESIS_KEY: &str = "genesis";

/// Errors from opening, writing, or verifying the persistent ledger.
#[derive(Debug)]
pub enum LedgerError {
    /// Filesystem / OS error opening the database file.
    Io(std::io::Error),
    /// Embedded database error.
    Db(Box<redb::Error>),
    /// Stored entries failed chain verification on open. The value is the
    /// index of the first broken entry.
    Corrupt { broken_index: usize },
    /// A stored entry could not be deserialized.
    Decode(serde_json::Error),
}

impl std::fmt::Display for LedgerError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            LedgerError::Io(e) => write!(f, "ledger I/O error: {e}"),
            LedgerError::Db(e) => write!(f, "ledger database error: {e}"),
            LedgerError::Corrupt { broken_index } => {
                write!(f, "ledger corrupt: chain broken at entry {broken_index}")
            }
            LedgerError::Decode(e) => write!(f, "ledger decode error: {e}"),
        }
    }
}

impl std::error::Error for LedgerError {}

impl From<redb::Error> for LedgerError {
    fn from(e: redb::Error) -> Self {
        LedgerError::Db(Box::new(e))
    }
}

impl From<redb::TransactionError> for LedgerError {
    fn from(e: redb::TransactionError) -> Self {
        LedgerError::Db(Box::new(e.into()))
    }
}

impl From<redb::TableError> for LedgerError {
    fn from(e: redb::TableError) -> Self {
        LedgerError::Db(Box::new(e.into()))
    }
}

impl From<redb::StorageError> for LedgerError {
    fn from(e: redb::StorageError) -> Self {
        LedgerError::Db(Box::new(e.into()))
    }
}

impl From<redb::CommitError> for LedgerError {
    fn from(e: redb::CommitError) -> Self {
        LedgerError::Db(Box::new(e.into()))
    }
}

impl From<redb::DatabaseError> for LedgerError {
    fn from(e: redb::DatabaseError) -> Self {
        LedgerError::Db(Box::new(e.into()))
    }
}

impl From<std::io::Error> for LedgerError {
    fn from(e: std::io::Error) -> Self {
        LedgerError::Io(e)
    }
}

/// Restricts the database file at `path` to owner-only access (0600),
/// and its parent directory to 0700 when this open created it.
///
/// Mode discipline harvested from VaultLane's store (pattern authored
/// by Allen Mack in VaultLane `src/store.rs`; folded into the vault
/// 2026-11-10, harvest audit row 7). The redb file holds the encrypted
/// vault's audit chain; without this it inherits the process umask
/// (typically 0644 — readable by every local user). Applied on every
/// open, so a file created loose is tightened when next opened.
/// No-op on non-Unix platforms.
#[cfg(unix)]
fn restrict_db_file_permissions(
    path: &Path,
    parent: Option<&Path>,
    created_parent: bool,
) -> std::io::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600))?;
    if created_parent {
        if let Some(parent) = parent {
            if !parent.as_os_str().is_empty() {
                std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700))?;
            }
        }
    }
    Ok(())
}

#[cfg(not(unix))]
fn restrict_db_file_permissions(
    _path: &Path,
    _parent: Option<&Path>,
    _created_parent: bool,
) -> std::io::Result<()> {
    Ok(())
}

/// A hash-chained audit ledger that survives restarts.
///
/// Every `append` is written to disk before it is reported as committed. On
/// `open`, the full chain is loaded and re-verified; a corrupt database
/// refuses to open rather than silently serving bad data.
pub struct PersistentLedger {
    db: Database,
    inner: Mutex<AuditLog>,
    path: PathBuf,
}

impl PersistentLedger {
    /// Opens (or creates) the ledger at `path`, using the default genesis
    /// hash for new databases.
    pub fn open(path: impl AsRef<Path>) -> Result<Self, LedgerError> {
        Self::open_with_genesis(path, None)
    }

    /// Opens (or creates) the ledger at `path`. For a new database,
    /// `genesis` overrides the default genesis hash; for an existing
    /// database the stored genesis is used and `genesis` is ignored.
    pub fn open_with_genesis(
        path: impl AsRef<Path>,
        genesis: Option<&str>,
    ) -> Result<Self, LedgerError> {
        let path = path.as_ref().to_path_buf();
        let mut created_parent = false;
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() {
                created_parent = !parent.exists();
                std::fs::create_dir_all(parent)?;
            }
        }
        let db = Database::create(&path)?;
        restrict_db_file_permissions(&path, path.parent(), created_parent)?;

        // Ensure tables exist and load (or initialize) the genesis hash.
        let stored_genesis = {
            let write_txn = db.begin_write()?;
            let genesis_value = {
                // Read first, then drop the table handle before any insert,
                // so the immutable read borrow never overlaps a mutable one.
                let existing: Option<String> = {
                    let meta = write_txn.open_table(META_TABLE)?;
                    // Bind before the block ends so the `?` temporary drops
                    // before `meta` does.
                    let opt = meta.get(META_GENESIS_KEY)?.map(|g| g.value());
                    opt
                };
                match existing {
                    Some(g) => g,
                    None => {
                        let g = genesis
                            .unwrap_or(super::audit::GENESIS_EVT_1041)
                            .to_string();
                        let mut meta = write_txn.open_table(META_TABLE)?;
                        meta.insert(META_GENESIS_KEY, g.clone())?;
                        g
                    }
                }
            };
            // Make sure the entries table exists even when empty.
            let _ = write_txn.open_table(ENTRIES_TABLE)?;
            write_txn.commit()?;
            genesis_value
        };

        // Load every entry in sequence order and rebuild the chain.
        let entries: Vec<AuditEntry> = {
            let read_txn = db.begin_read()?;
            let table = read_txn.open_table(ENTRIES_TABLE)?;
            let mut loaded = Vec::with_capacity(table.len()? as usize);
            for item in table.iter()? {
                let (_seq, json) = item?;
                let entry: AuditEntry =
                    serde_json::from_str(&json.value()).map_err(LedgerError::Decode)?;
                loaded.push(entry);
            }
            loaded
        };

        let log = AuditLog::from_entries(stored_genesis, entries)
            .map_err(|broken_index| LedgerError::Corrupt { broken_index })?;

        Ok(Self {
            db,
            inner: Mutex::new(log),
            path,
        })
    }

    /// Path of the underlying database file.
    pub fn path(&self) -> &Path {
        &self.path
    }

    fn lock(&self) -> std::sync::MutexGuard<'_, AuditLog> {
        self.inner
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    /// Appends an entry and durably persists it before returning.
    ///
    /// The in-memory lock is held across the database write so concurrent
    /// writers stay serialized; if the database write fails, the in-memory
    /// append is rolled back so the two can never disagree about what was
    /// committed.
    pub fn append(&self, actor: &str, action: &str) -> Result<AuditEntry, LedgerError> {
        let mut guard = self.lock();
        let entry = guard.append(actor, action).clone();
        let json = serde_json::to_string(&entry).map_err(LedgerError::Decode)?;

        let persisted = (|| -> Result<(), LedgerError> {
            let write_txn = self.db.begin_write()?;
            {
                let mut table = write_txn.open_table(ENTRIES_TABLE)?;
                table.insert(entry.sequence as u64, json)?;
            }
            write_txn.commit()?;
            Ok(())
        })();

        if let Err(e) = persisted {
            // Roll back: the entry was never durably stored.
            guard.pop_last();
            return Err(e);
        }

        Ok(entry)
    }

    /// Number of committed entries.
    pub fn len(&self) -> usize {
        self.lock().len()
    }

    /// True when no entries have been committed yet.
    pub fn is_empty(&self) -> bool {
        self.lock().is_empty()
    }

    /// Hash of the newest entry, or the genesis hash when empty.
    pub fn head_hash(&self) -> String {
        self.lock().head_hash()
    }

    /// Genesis hash this ledger is bound to.
    pub fn genesis_hash(&self) -> String {
        self.lock().genesis_hash().to_string()
    }

    /// A snapshot copy of all committed entries, in sequence order.
    pub fn entries(&self) -> Vec<AuditEntry> {
        self.lock().entries().to_vec()
    }

    /// Re-verifies the full in-memory chain.
    pub fn verify(&self) -> Result<(), usize> {
        self.lock().verify()
    }

    /// Verifies the chain and checks it still ends at a previously saved head
    /// hash. Catches trailing-entry deletion, which plain `verify()` cannot see.
    pub fn verify_anchored(&self, expected_head: &str) -> Result<(), usize> {
        self.lock().verify_anchored(expected_head)
    }

    /// Signs the current chain tip with `signer` and stores the
    /// checkpoint record in the ledger database (see
    /// [`super::checkpoint`]). Checkpointing is explicit and opt-in:
    /// nothing calls this unless a caller loaded a
    /// [`CheckpointSigner`] (from the `MACK_CHECKPOINT_KEY_FILE`
    /// environment variable) and asked for a checkpoint.
    pub fn checkpoint(
        &self,
        signer: &CheckpointSigner,
    ) -> Result<CheckpointRecord, CheckpointError> {
        let (seq, head_hash) = {
            let guard = self.lock();
            (guard.len() as u64, guard.head_hash())
        };
        let record = signer.sign_checkpoint(seq, &head_hash);
        checkpoint::store_checkpoint(&self.db, &record)?;
        Ok(record)
    }

    /// Every checkpoint record stored in this ledger's database, in
    /// sequence order. Empty when the ledger was never checkpointed.
    pub fn checkpoints(&self) -> Result<Vec<CheckpointRecord>, CheckpointError> {
        checkpoint::load_checkpoints(&self.db)
    }

    /// Verifies the hash chain *and* every stored checkpoint (see
    /// [`checkpoint::verify_checkpoints`]). Catches truncation and
    /// rollback past the latest checkpoint, which plain
    /// [`PersistentLedger::verify`] cannot see. When `expected_pubkey`
    /// is given, every checkpoint must carry that key.
    pub fn verify_checkpoints(&self, expected_pubkey: Option<&str>) -> Result<(), CheckpointError> {
        let records = self.checkpoints()?;
        let guard = self.lock();
        checkpoint::verify_checkpoints(&guard, &records, expected_pubkey)
    }

    /// Segment verification report over the full chain.
    pub fn verify_segments(&self) -> SegmentVerificationReport {
        let guard = self.lock();
        let total = guard.len();
        guard.verify_segment(0, total)
    }

    /// Forces any buffered database state to disk.
    pub fn flush(&self) -> Result<(), LedgerError> {
        // redb commits are durable on commit; this is a no-op hook kept for
        // API symmetry with writers that buffer. Documented as such so callers
        // don't assume extra durability semantics.
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering};

    static TEST_COUNTER: AtomicU64 = AtomicU64::new(0);

    fn temp_ledger_path(test_name: &str) -> PathBuf {
        let id = TEST_COUNTER.fetch_add(1, Ordering::SeqCst);
        let mut p = std::env::temp_dir();
        p.push(format!(
            "vault_ledger_test_{}_{}_{}",
            test_name,
            std::process::id(),
            id
        ));
        // Use a fresh file per test; redb creates it on open.
        p.push("ledger.redb");
        p
    }

    fn cleanup(path: &Path) {
        if let Some(parent) = path.parent() {
            let _ = std::fs::remove_dir_all(parent);
        }
    }

    /// Harvest (2026-11-10, audit row 7): the redb file must be created
    /// owner-only (0600), not umask-default, and a file loosened
    /// externally is tightened again on the next open.
    #[cfg(unix)]
    #[test]
    fn database_file_is_owner_only() {
        use std::os::unix::fs::PermissionsExt;
        let path = temp_ledger_path("perms");
        {
            let _ledger = PersistentLedger::open(&path).expect("open");
        }
        let mode = std::fs::metadata(&path)
            .expect("metadata")
            .permissions()
            .mode();
        assert_eq!(mode & 0o777, 0o600, "ledger file must be 0600");
        // Loosen it by hand; reopening must tighten it back to 0600.
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).expect("loosen");
        {
            let _ledger = PersistentLedger::open(&path).expect("reopen");
        }
        let mode = std::fs::metadata(&path)
            .expect("metadata")
            .permissions()
            .mode();
        assert_eq!(mode & 0o777, 0o600, "reopen must tighten to 0600");
        cleanup(&path);
    }

    #[test]
    fn round_trip_persists_and_reverifies() {
        let path = temp_ledger_path("round_trip");
        let heads: Vec<String>;
        {
            let ledger = PersistentLedger::open(&path).expect("open");
            assert!(ledger.is_empty());
            for i in 0..5 {
                let e = ledger
                    .append("alice", &format!("action_{i}"))
                    .expect("append");
                assert_eq!(e.sequence, i);
            }
            assert_eq!(ledger.len(), 5);
            assert!(ledger.verify().is_ok());
            heads = ledger.entries().iter().map(|e| e.hash.clone()).collect();
            ledger.flush().expect("flush");
        }
        // Reopen in a new instance: the chain must survive and re-verify.
        {
            let ledger = PersistentLedger::open(&path).expect("reopen");
            assert_eq!(ledger.len(), 5);
            assert!(ledger.verify().is_ok());
            let reopened: Vec<String> = ledger.entries().iter().map(|e| e.hash.clone()).collect();
            assert_eq!(heads, reopened);
            // Anchoring still works across restarts.
            let head = ledger.head_hash();
            assert!(ledger.verify_anchored(&head).is_ok());
        }
        cleanup(&path);
    }

    #[test]
    fn appends_continue_sequence_across_restart() {
        let path = temp_ledger_path("sequence");
        {
            let ledger = PersistentLedger::open(&path).expect("open");
            ledger.append("alice", "first").expect("append");
        }
        {
            let ledger = PersistentLedger::open(&path).expect("reopen");
            let e = ledger.append("bob", "second").expect("append");
            assert_eq!(e.sequence, 1);
            assert_eq!(ledger.len(), 2);
            assert!(ledger.verify().is_ok());
        }
        cleanup(&path);
    }

    #[test]
    fn tampered_database_refuses_to_open() {
        let path = temp_ledger_path("tamper");
        {
            let ledger = PersistentLedger::open(&path).expect("open");
            for i in 0..3 {
                ledger
                    .append("alice", &format!("action_{i}"))
                    .expect("append");
            }
        }
        // Tamper directly with the stored entry, bypassing the ledger API.
        {
            let db = Database::create(&path).expect("raw open");
            let write_txn = db.begin_write().expect("txn");
            {
                let mut table = write_txn.open_table(ENTRIES_TABLE).expect("table");
                let mut entry: AuditEntry = {
                    let read_txn = db.begin_read().expect("read");
                    let t = read_txn.open_table(ENTRIES_TABLE).expect("t");
                    let json = t.get(1u64).expect("get").expect("present").value();
                    serde_json::from_str(&json).expect("decode")
                };
                entry.action = "forged_action".to_string();
                let json = serde_json::to_string(&entry).expect("encode");
                table.insert(1u64, json).expect("insert");
            }
            write_txn.commit().expect("commit");
        }
        // Reopening must refuse: the chain no longer verifies.
        match PersistentLedger::open(&path) {
            Err(LedgerError::Corrupt { broken_index }) => {
                assert_eq!(broken_index, 1);
            }
            Err(e) => panic!("expected Corrupt error, got: {e}"),
            Ok(_) => panic!("expected Corrupt error, but the tampered database opened clean"),
        }
        cleanup(&path);
    }

    #[test]
    fn custom_genesis_is_stored_and_reused() {
        let path = temp_ledger_path("genesis");
        {
            let ledger =
                PersistentLedger::open_with_genesis(&path, Some("CUSTOM_GENESIS")).expect("open");
            assert_eq!(ledger.genesis_hash(), "CUSTOM_GENESIS");
            ledger.append("alice", "login").expect("append");
            assert_eq!(ledger.entries()[0].prev_hash, "CUSTOM_GENESIS");
        }
        {
            // Reopen without specifying genesis: the stored one must win.
            let ledger = PersistentLedger::open(&path).expect("reopen");
            assert_eq!(ledger.genesis_hash(), "CUSTOM_GENESIS");
            assert!(ledger.verify().is_ok());
        }
        cleanup(&path);
    }

    #[test]
    fn concurrent_appends_all_persist() {
        let path = temp_ledger_path("concurrent");
        let ledger = std::sync::Arc::new(PersistentLedger::open(&path).expect("open"));
        let mut handles = Vec::new();
        for lane in 0..8 {
            let l = ledger.clone();
            handles.push(std::thread::spawn(move || {
                for i in 0..25 {
                    l.append(&format!("MACK-{:02}", lane + 1), &format!("event_{i}"))
                        .expect("append");
                }
            }));
        }
        for h in handles {
            h.join().expect("thread");
        }
        assert_eq!(ledger.len(), 200);
        assert!(ledger.verify().is_ok());
        drop(ledger);
        // Everything must still be there after reopen.
        let ledger = PersistentLedger::open(&path).expect("reopen");
        assert_eq!(ledger.len(), 200);
        assert!(ledger.verify().is_ok());
        cleanup(&path);
    }
}

#[cfg(test)]
mod tamper_tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering};

    static TAMPER_COUNTER: AtomicU64 = AtomicU64::new(1000);

    fn tamper_path(name: &str) -> PathBuf {
        let id = TAMPER_COUNTER.fetch_add(1, Ordering::SeqCst);
        let mut dir = std::env::temp_dir();
        dir.push(format!(
            "vault_tamper_{}_{}_{}",
            name,
            std::process::id(),
            id
        ));
        std::fs::create_dir_all(&dir).expect("create test dir");
        dir.push("ledger.redb");
        dir
    }

    fn cleanup(path: &Path) {
        // Remove only this test's own subdirectory, never a shared parent.
        if let Some(parent) = path.parent() {
            let _ = std::fs::remove_dir_all(parent);
        }
    }

    fn make_ledger(path: &Path, n: usize) -> String {
        let ledger = PersistentLedger::open(path).expect("open");
        for i in 0..n {
            ledger
                .append("alice", &format!("action_{i}"))
                .expect("append");
        }
        let head = ledger.head_hash();
        ledger.flush().expect("flush");
        head
    }

    fn read_entry(db: &Database, seq: u64) -> AuditEntry {
        let txn = db.begin_read().expect("read txn");
        let table = txn.open_table(ENTRIES_TABLE).expect("table");
        let json = table.get(seq).expect("get").expect("present").value();
        serde_json::from_str(&json).expect("decode")
    }

    fn write_entry(db: &Database, seq: u64, entry: &AuditEntry) {
        let txn = db.begin_write().expect("write txn");
        {
            let mut table = txn.open_table(ENTRIES_TABLE).expect("table");
            let json = serde_json::to_string(entry).expect("encode");
            table.insert(seq, json).expect("insert");
        }
        txn.commit().expect("commit");
    }

    fn delete_entry(db: &Database, seq: u64) {
        let txn = db.begin_write().expect("write txn");
        {
            let mut table = txn.open_table(ENTRIES_TABLE).expect("table");
            table.remove(seq).expect("remove");
        }
        txn.commit().expect("commit");
    }

    #[test]
    fn tamper_flip_byte_in_payload_rejected() {
        let path = tamper_path("flip");
        make_ledger(&path, 5);
        {
            let db = Database::create(&path).expect("raw open");
            let mut entry = read_entry(&db, 2);
            // Flip one byte in the action payload.
            let mut bytes = entry.action.into_bytes();
            bytes[0] ^= 0x01;
            entry.action = String::from_utf8(bytes).expect("utf8");
            write_entry(&db, 2, &entry);
        }
        match PersistentLedger::open(&path) {
            Err(LedgerError::Corrupt { broken_index }) => assert_eq!(broken_index, 2),
            Err(e) => panic!("expected Corrupt, got: {e}"),
            Ok(_) => panic!("tampered ledger opened clean"),
        }
        cleanup(&path);
    }

    #[test]
    fn tamper_delete_middle_entry_rejected() {
        let path = tamper_path("delete_mid");
        make_ledger(&path, 5);
        {
            let db = Database::create(&path).expect("raw open");
            delete_entry(&db, 2);
        }
        // Entry 3's prev_hash no longer links to anything; the chain breaks.
        match PersistentLedger::open(&path) {
            Err(LedgerError::Corrupt { .. }) => {}
            Err(e) => panic!("expected Corrupt, got: {e}"),
            Ok(_) => panic!("ledger with deleted middle entry opened clean"),
        }
        cleanup(&path);
    }

    #[test]
    fn tamper_swap_two_entries_rejected() {
        let path = tamper_path("swap");
        make_ledger(&path, 5);
        {
            let db = Database::create(&path).expect("raw open");
            let e1 = read_entry(&db, 1);
            let e2 = read_entry(&db, 2);
            // Swap the entry bodies but keep the sequence keys.
            let mut e1_swapped = e1;
            let mut e2_swapped = e2;
            std::mem::swap(&mut e1_swapped.action, &mut e2_swapped.action);
            std::mem::swap(&mut e1_swapped.hash, &mut e2_swapped.hash);
            std::mem::swap(&mut e1_swapped.prev_hash, &mut e2_swapped.prev_hash);
            // Fix sequence fields to match keys (attacker tries to be clever).
            e1_swapped.sequence = 1;
            e2_swapped.sequence = 2;
            write_entry(&db, 1, &e1_swapped);
            write_entry(&db, 2, &e2_swapped);
        }
        match PersistentLedger::open(&path) {
            Err(LedgerError::Corrupt { .. }) => {}
            Err(e) => panic!("expected Corrupt, got: {e}"),
            Ok(_) => panic!("ledger with swapped entries opened clean"),
        }
        cleanup(&path);
    }

    #[test]
    fn tamper_truncate_tail_caught_by_anchor() {
        let path = tamper_path("truncate");
        let anchor = make_ledger(&path, 5);
        {
            let db = Database::create(&path).expect("raw open");
            delete_entry(&db, 4);
        }
        // Plain verify() CANNOT see truncation: the remaining 4 entries form
        // a valid chain. This is the honest limit of hash chains.
        let ledger = PersistentLedger::open(&path).expect("reopen after truncation");
        assert!(
            ledger.verify().is_ok(),
            "truncated chain verifies internally"
        );
        assert_eq!(ledger.len(), 4);
        // But the external anchor catches it: the head hash changed.
        assert!(ledger.verify_anchored(&anchor).is_err());
        cleanup(&path);
    }

    #[test]
    fn tamper_replay_old_segment_caught_by_anchor() {
        let path = tamper_path("replay");
        // Build a ledger with 5 entries, anchor the head.
        let anchor = make_ledger(&path, 5);
        // Attacker replaces the DB with an older valid snapshot (3 entries).
        let victim_path = tamper_path("replay_victim");
        {
            let old_ledger = PersistentLedger::open(&victim_path).expect("open victim");
            for i in 0..3 {
                old_ledger
                    .append("alice", &format!("action_{i}"))
                    .expect("append");
            }
            old_ledger.flush().expect("flush");
        }
        // Simulate the attacker copying the old snapshot over the victim's file.
        // (In practice: file replacement. Here we just test the verification.)
        let old_ledger = PersistentLedger::open(&victim_path).expect("reopen old");
        assert!(
            old_ledger.verify().is_ok(),
            "old segment is internally valid"
        );
        // The old head does not match the anchor from the 5-entry ledger.
        assert!(old_ledger.verify_anchored(&anchor).is_err());
        cleanup(&path);
        cleanup(&victim_path);
    }

    #[test]
    fn tamper_change_genesis_hash_rejected() {
        let path = tamper_path("genesis");
        make_ledger(&path, 3);
        {
            let db = Database::create(&path).expect("raw open");
            let txn = db.begin_write().expect("write txn");
            {
                let mut table = txn.open_table(META_TABLE).expect("meta");
                table
                    .insert(META_GENESIS_KEY, "FORGED_GENESIS".to_string())
                    .expect("insert");
            }
            txn.commit().expect("commit");
        }
        // Entry 0's prev_hash no longer matches the stored genesis.
        match PersistentLedger::open(&path) {
            Err(LedgerError::Corrupt { broken_index }) => assert_eq!(broken_index, 0),
            Err(e) => panic!("expected Corrupt at 0, got: {e}"),
            Ok(_) => panic!("ledger with forged genesis opened clean"),
        }
        cleanup(&path);
    }

    #[test]
    fn tamper_recomputed_chain_caught_by_anchor() {
        // The strongest attacker: edits an entry AND recomputes every
        // subsequent hash so the chain is internally valid. Plain verify()
        // cannot catch this. Only an external anchor can.
        let path = tamper_path("recompute");
        let anchor = make_ledger(&path, 5);
        {
            // Attacker builds a fresh valid chain with forged data.
            let forged_path = tamper_path("forged");
            let forged = PersistentLedger::open(&forged_path).expect("open forged");
            for i in 0..5 {
                let action = if i == 2 {
                    "FORGED_ACTION"
                } else {
                    &format!("action_{i}")
                };
                forged.append("alice", action).expect("append");
            }
            forged.flush().expect("flush");
            drop(forged); // release the file lock before raw-opening
                          // Copy the forged entries over the victim's database.
            let victim_db = Database::create(&path).expect("victim db");
            let forged_db = Database::create(&forged_path).expect("forged db");
            for seq in 0..5u64 {
                let entry = read_entry(&forged_db, seq);
                write_entry(&victim_db, seq, &entry);
            }
            drop(victim_db);
            drop(forged_db);
            cleanup(&forged_path);
        }
        let ledger = PersistentLedger::open(&path).expect("reopen");
        // The recomputed chain is internally valid...
        assert!(
            ledger.verify().is_ok(),
            "recomputed chain verifies internally"
        );
        // ...but the head hash doesn't match the external anchor.
        assert!(
            ledger.verify_anchored(&anchor).is_err(),
            "recomputed chain must fail anchor check"
        );
        cleanup(&path);
    }
}

#[cfg(test)]
mod stress_tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering};

    static STRESS_COUNTER: AtomicU64 = AtomicU64::new(2000);

    fn stress_path(name: &str) -> PathBuf {
        let id = STRESS_COUNTER.fetch_add(1, Ordering::SeqCst);
        let mut dir = std::env::temp_dir();
        dir.push(format!(
            "vault_stress_{}_{}_{}",
            name,
            std::process::id(),
            id
        ));
        std::fs::create_dir_all(&dir).expect("create test dir");
        dir.push("ledger.redb");
        dir
    }

    fn cleanup(path: &Path) {
        if let Some(parent) = path.parent() {
            let _ = std::fs::remove_dir_all(parent);
        }
    }

    /// Simple xorshift PRNG for deterministic-but-varied timing.
    /// (No external rand dependency needed in tests.)
    struct XorShift(u64);
    impl XorShift {
        fn next(&mut self) -> u64 {
            let mut x = self.0;
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            self.0 = x;
            x
        }
    }

    #[test]
    fn stress_32_threads_random_timing() {
        let path = stress_path("32t");
        let ledger = std::sync::Arc::new(PersistentLedger::open(&path).expect("open"));
        let total = std::sync::Arc::new(AtomicU64::new(0));

        let mut handles = Vec::new();
        for thread_id in 0..32 {
            let l = ledger.clone();
            let t = total.clone();
            handles.push(std::thread::spawn(move || {
                let mut rng = XorShift(0x12345678 + thread_id as u64 * 0x9e3779b9);
                // Random 10..40 appends per thread
                let n = 10 + (rng.next() % 31) as usize;
                for i in 0..n {
                    // Random 0..2ms sleep to interleave thread timing
                    let sleep_us = rng.next() % 2000;
                    if sleep_us > 500 {
                        std::thread::sleep(std::time::Duration::from_micros(sleep_us));
                    }
                    l.append(
                        &format!("thread-{thread_id}"),
                        &format!("event_{i}_{}", rng.next() % 1000),
                    )
                    .expect("append");
                    t.fetch_add(1, Ordering::SeqCst);
                }
            }));
        }
        for h in handles {
            h.join().expect("thread panicked");
        }

        let expected = total.load(Ordering::SeqCst) as usize;
        assert_eq!(ledger.len(), expected, "all appends must persist");
        assert!(ledger.verify().is_ok(), "chain must verify after stress");

        // Sequence numbers must be contiguous 0..n with no gaps or dupes.
        let mut seqs: Vec<usize> = ledger.entries().iter().map(|e| e.sequence).collect();
        seqs.sort_unstable();
        for (i, s) in seqs.iter().enumerate() {
            assert_eq!(*s, i, "sequence gap or duplicate at index {i}");
        }

        drop(ledger);
        let ledger = PersistentLedger::open(&path).expect("reopen");
        assert_eq!(ledger.len(), expected);
        assert!(ledger.verify().is_ok());
        cleanup(&path);
    }
}
