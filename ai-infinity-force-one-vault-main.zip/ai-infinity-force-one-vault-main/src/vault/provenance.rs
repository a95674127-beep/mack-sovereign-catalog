//! vault::provenance — cryptographic proof of authorship and ownership.
//!
//! Provides a signed, hash-chained attestation ledger that binds an artifact
//! (identified by its SHA-256 digest) to its author, the patent docket, and
//! every subsequent ownership event. Each attestation is Ed25519-signed by
//! the holder of the authorship key; the ledger refuses to accept an
//! attestation whose signature does not verify against the bound public key,
//! so possession of the signing key is the sole proof of authorship.
//!
//! Every attestation also chains into the ledger:
//!   att_hash[n] = SHA256(seq ‖ ts ‖ actor ‖ docket ‖ action ‖ artifact ‖ att_hash[n-1])
//! giving the same tamper-evidence as the audit log, and the signature covers
//! the attestation hash, so signing and chaining reinforce each other.

pub const GENESIS_HASH: &str = "0000000000000000000000000000000000000000000000000000000000000000";
use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use rand::RngCore;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::time::{SystemTime, UNIX_EPOCH};
use thiserror::Error;
use zeroize::Zeroizing;

pub const PROVENANCE_VERSION: &str = "1.0";

#[derive(Debug, Error)]
pub enum ProvenanceError {
    #[error("signature does not verify against the ledger's authorship key")]
    BadSignature,
    #[error("attestation chain broken at sequence {0}")]
    ChainBroken(u64),
    #[error("serialization failed: {0}")]
    Serialization(String),
    #[error("signing failed")]
    SigningFailed,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AttestationAction {
    /// Declares original authorship of the artifact.
    Authorship,
    /// Declares current ownership of the artifact.
    Ownership,
    /// Transfers ownership to the holder of a new key.
    Transfer,
    /// Records a patent filing or docket event.
    Filing,
    /// Publishes or releases the artifact under a license.
    Release,
}

/// One signed, hash-chained attestation binding an artifact to its author
/// or a subsequent custody event.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Attestation {
    pub provenance_version: String,
    pub sequence: u64,
    pub timestamp: u64,
    /// Author or custodian identity, e.g. "Allen Mack <a95674127@gmail.com>".
    pub actor: String,
    /// Patent docket reference, e.g. "MACK-STACK-01".
    pub docket: String,
    pub action: AttestationAction,
    /// SHA-256 hex digest of the artifact being attested.
    pub artifact_sha256: String,
    /// Hash of the previous attestation; genesis chains to zeros.
    pub prev_hash: String,
    /// Hash of this attestation's canonical body.
    pub attestation_hash: String,
    /// Hex-encoded Ed25519 signature over `attestation_hash`.
    pub signature: String,
}

impl Attestation {
    fn canonical_body(
        sequence: u64,
        timestamp: u64,
        actor: &str,
        docket: &str,
        action: AttestationAction,
        artifact_sha256: &str,
        prev_hash: &str,
    ) -> Vec<u8> {
        let mut hasher = Sha256::new();
        hasher.update(b"PROVENANCE-v1");
        hasher.update(sequence.to_be_bytes());
        hasher.update(timestamp.to_be_bytes());
        hasher.update(actor.as_bytes());
        hasher.update(docket.as_bytes());
        hasher.update(
            serde_json::to_vec(&action).expect("AttestationAction serialization is infallible"),
        );
        hasher.update(artifact_sha256.as_bytes());
        hasher.update(prev_hash.as_bytes());
        hasher.finalize().to_vec()
    }

    fn new(
        sequence: u64,
        actor: &str,
        docket: &str,
        action: AttestationAction,
        artifact_sha256: &str,
        prev_hash: &str,
    ) -> Self {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        let attestation_hash = hex::encode(Self::canonical_body(
            sequence,
            timestamp,
            actor,
            docket,
            action,
            artifact_sha256,
            prev_hash,
        ));
        Self {
            provenance_version: PROVENANCE_VERSION.to_string(),
            sequence,
            timestamp,
            actor: actor.to_string(),
            docket: docket.to_string(),
            action,
            artifact_sha256: artifact_sha256.to_string(),
            prev_hash: prev_hash.to_string(),
            attestation_hash,
            signature: String::new(),
        }
    }

    /// Signs the attestation hash with the given signing key.
    fn sign_with(&mut self, signing_key: &SigningKey) -> Result<(), ProvenanceError> {
        let signature = signing_key
            .sign(self.attestation_hash.as_bytes())
            .to_bytes();
        self.signature = hex::encode(signature);
        Ok(())
    }

    /// Verifies the signature against the given public key.
    fn verify_signature(&self, verifying_key: &VerifyingKey) -> Result<(), ProvenanceError> {
        let sig_bytes = hex::decode(&self.signature).map_err(|_| ProvenanceError::BadSignature)?;
        let signature =
            Signature::from_slice(&sig_bytes).map_err(|_| ProvenanceError::BadSignature)?;
        verifying_key
            .verify(self.attestation_hash.as_bytes(), &signature)
            .map_err(|_| ProvenanceError::BadSignature)
    }
}

/// Generates a fresh Ed25519 authorship keypair.
///
/// The secret key bytes are held in `Zeroizing` and wiped when the returned
/// buffer is dropped; callers that persist the key should do so only into
/// storage that is at least as protected.
pub fn generate_authorship_keypair() -> Result<(Zeroizing<[u8; 32]>, VerifyingKey), ProvenanceError>
{
    let mut secret = Zeroizing::new([0u8; 32]);
    rand::thread_rng()
        .try_fill_bytes(&mut *secret)
        .map_err(|_| ProvenanceError::SigningFailed)?;
    let signing_key = SigningKey::from_bytes(&secret);
    Ok((secret, signing_key.verifying_key()))
}

/// A tamper-evident, signature-verified chain of authorship and ownership
/// attestations bound to a single authorship public key.
pub struct ProvenanceLedger {
    verifying_key: VerifyingKey,
    attestations: Vec<Attestation>,
}

impl ProvenanceLedger {
    /// Creates an empty ledger bound to the author's public key.
    pub fn new(verifying_key: VerifyingKey) -> Self {
        Self {
            verifying_key,
            attestations: Vec::new(),
        }
    }

    /// Appends a signed attestation. The signature is verified against the
    /// ledger's authorship key before the attestation is accepted, so only
    /// the holder of the authorship signing key can extend the chain.
    pub fn attest(
        &mut self,
        actor: &str,
        docket: &str,
        action: AttestationAction,
        artifact_sha256: &str,
        signing_key: &SigningKey,
    ) -> Result<&Attestation, ProvenanceError> {
        // Refuse to extend the chain with a key that does not match the ledger.
        if signing_key.verifying_key() != self.verifying_key {
            return Err(ProvenanceError::BadSignature);
        }

        let sequence = self.attestations.len() as u64;
        let prev_hash = self
            .attestations
            .last()
            .map(|a| a.attestation_hash.clone())
            .unwrap_or_else(|| GENESIS_HASH.to_string());

        let mut attestation =
            Attestation::new(sequence, actor, docket, action, artifact_sha256, &prev_hash);
        attestation.sign_with(signing_key)?;
        attestation.verify_signature(&self.verifying_key)?;

        self.attestations.push(attestation);
        Ok(self.attestations.last().unwrap())
    }

    /// Verifies the full chain: linkage hashes and every signature.
    /// Returns Err with the sequence number of the first broken attestation.
    pub fn verify_chain(&self) -> Result<(), ProvenanceError> {
        let mut expected_prev = GENESIS_HASH.to_string();

        for attestation in &self.attestations {
            if attestation.prev_hash != expected_prev {
                return Err(ProvenanceError::ChainBroken(attestation.sequence));
            }

            // Recompute the attestation hash over its canonical body to
            // detect any field mutation, then verify the signature over it.
            let recomputed = hex::encode(Attestation::canonical_body(
                attestation.sequence,
                attestation.timestamp,
                &attestation.actor,
                &attestation.docket,
                attestation.action,
                &attestation.artifact_sha256,
                &attestation.prev_hash,
            ));
            if recomputed != attestation.attestation_hash {
                return Err(ProvenanceError::ChainBroken(attestation.sequence));
            }
            attestation
                .verify_signature(&self.verifying_key)
                .map_err(|_| ProvenanceError::ChainBroken(attestation.sequence))?;

            expected_prev = attestation.attestation_hash.clone();
        }
        Ok(())
    }

    /// The head hash: an external anchor (transparency log, notarization,
    /// patent filing receipt) can pin this value at any time.
    pub fn head_hash(&self) -> String {
        self.attestations
            .last()
            .map(|a| a.attestation_hash.clone())
            .unwrap_or_else(|| GENESIS_HASH.to_string())
    }

    /// Serializes the ledger to JSON. On load, use
    /// [`ProvenanceLedger::from_json`] with the author's public key to
    /// re-verify every attestation before trusting the ledger.
    pub fn to_json(&self) -> Result<String, ProvenanceError> {
        serde_json::to_string_pretty(&self.attestations)
            .map_err(|e| ProvenanceError::Serialization(e.to_string()))
    }

    /// Deserializes a ledger from JSON and verifies the full chain against
    /// the given public key before accepting it.
    pub fn from_json(json: &str, verifying_key: VerifyingKey) -> Result<Self, ProvenanceError> {
        let attestations: Vec<Attestation> = serde_json::from_str(json)
            .map_err(|e| ProvenanceError::Serialization(e.to_string()))?;
        let ledger = Self {
            verifying_key,
            attestations,
        };
        ledger.verify_chain()?;
        Ok(ledger)
    }

    pub fn len(&self) -> usize {
        self.attestations.len()
    }

    pub fn is_empty(&self) -> bool {
        self.attestations.is_empty()
    }

    pub fn attestations(&self) -> &[Attestation] {
        &self.attestations
    }
}
