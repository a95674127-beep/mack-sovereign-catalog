use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fmt::Write as _;
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::{SystemTime, UNIX_EPOCH};

pub const GENESIS_EVT_1041: &str = "GENESIS_EVT_1041";
pub const DEFAULT_GENESIS_HASH: &str = GENESIS_EVT_1041;

fn default_genesis() -> String {
    DEFAULT_GENESIS_HASH.to_string()
}

fn to_hex(bytes: &[u8]) -> String {
    let mut out = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        let _ = write!(out, "{:02x}", b);
    }
    out
}

/// Current UTC time as RFC 3339 with microseconds, using only the standard library.
fn now_rfc3339() -> String {
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();
    let secs = now.as_secs() as i64;
    let micros = now.subsec_micros();

    let days = secs.div_euclid(86_400);
    let rem = secs.rem_euclid(86_400);
    let hour = rem / 3600;
    let minute = (rem % 3600) / 60;
    let second = rem % 60;

    let z = days + 719_468;
    let era = z.div_euclid(146_097);
    let doe = z.rem_euclid(146_097);
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let mut year = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let day = doy - (153 * mp + 2) / 5 + 1;
    let month = if mp < 10 { mp + 3 } else { mp - 9 };
    if month <= 2 {
        year += 1;
    }

    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:06}Z",
        year, month, day, hour, minute, second, micros
    )
}

fn feed(hasher: &mut Sha256, bytes: &[u8]) {
    hasher.update((bytes.len() as u64).to_le_bytes());
    hasher.update(bytes);
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AuditEntry {
    pub sequence: usize,
    pub timestamp: String,
    pub actor: String,
    pub action: String,
    pub prev_hash: String,
    pub hash: String,
}

impl AuditEntry {
    /// Every field is length-prefixed, so ("a|b", "c") and ("a", "b|c") can never collide.
    fn compute_hash(
        sequence: usize,
        timestamp: &str,
        actor: &str,
        action: &str,
        prev_hash: &str,
    ) -> String {
        let mut hasher = Sha256::new();
        hasher.update((sequence as u64).to_le_bytes());
        feed(&mut hasher, timestamp.as_bytes());
        feed(&mut hasher, actor.as_bytes());
        feed(&mut hasher, action.as_bytes());
        feed(&mut hasher, prev_hash.as_bytes());
        let digest = hasher.finalize();
        to_hex(&digest[..])
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditLog {
    #[serde(default = "default_genesis")]
    genesis: String,
    entries: Vec<AuditEntry>,
}

impl AuditLog {
    pub fn new() -> Self {
        Self {
            genesis: default_genesis(),
            entries: Vec::new(),
        }
    }

    pub fn with_genesis(genesis: &str) -> Self {
        Self {
            genesis: genesis.to_string(),
            entries: Vec::new(),
        }
    }

    pub fn new_with_genesis(genesis: &str) -> Self {
        Self::with_genesis(genesis)
    }

    /// Removes and returns the newest entry, if any. Used to roll back an
    /// append that could not be durably persisted.
    pub fn pop_last(&mut self) -> Option<AuditEntry> {
        self.entries.pop()
    }

    /// Rebuilds a log from previously persisted entries, verifying the full
    /// chain. Returns `Err(index)` of the first broken entry instead of
    /// constructing an invalid log. Used by the persistent ledger on open.
    pub fn from_entries(genesis: String, entries: Vec<AuditEntry>) -> Result<Self, usize> {
        let log = Self { genesis, entries };
        match log.first_break(0, log.entries.len()) {
            Some(index) => Err(index),
            None => Ok(log),
        }
    }

    pub fn genesis_hash(&self) -> &str {
        &self.genesis
    }

    pub fn verify_segments(&self) -> SegmentVerificationReport {
        self.verify_segment(0, self.entries.len())
    }

    pub fn genesis(&self) -> &str {
        &self.genesis
    }

    pub fn append(&mut self, actor: &str, action: &str) -> &AuditEntry {
        let sequence = self.entries.len();
        let timestamp = now_rfc3339();
        let prev_hash = self.head_hash();
        let hash = AuditEntry::compute_hash(sequence, &timestamp, actor, action, &prev_hash);

        self.entries.push(AuditEntry {
            sequence,
            timestamp,
            actor: actor.to_string(),
            action: action.to_string(),
            prev_hash,
            hash,
        });

        &self.entries[sequence]
    }

    pub fn entries(&self) -> &[AuditEntry] {
        &self.entries
    }

    pub fn entries_mut(&mut self) -> &mut [AuditEntry] {
        &mut self.entries
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Hash of the newest entry, or the genesis hash when the log is empty.
    /// Store this value somewhere outside the log to detect truncation.
    pub fn head_hash(&self) -> String {
        self.entries
            .last()
            .map(|e| e.hash.clone())
            .unwrap_or_else(|| self.genesis.clone())
    }

    /// Finds the first broken entry in the range start..end, if any.
    fn first_break(&self, start: usize, end: usize) -> Option<usize> {
        let count = end.saturating_sub(start);
        for (index, entry) in self.entries.iter().enumerate().skip(start).take(count) {
            let expected_prev: &str = if index == 0 {
                &self.genesis
            } else {
                &self.entries[index - 1].hash
            };

            if entry.sequence != index || entry.prev_hash != expected_prev {
                return Some(index);
            }

            let expected_hash = AuditEntry::compute_hash(
                entry.sequence,
                &entry.timestamp,
                &entry.actor,
                &entry.action,
                expected_prev,
            );

            if entry.hash != expected_hash {
                return Some(index);
            }
        }
        None
    }

    pub fn verify(&self) -> Result<(), usize> {
        match self.first_break(0, self.entries.len()) {
            Some(index) => Err(index),
            None => Ok(()),
        }
    }

    /// Verifies the chain AND checks it still ends at a hash you saved earlier.
    /// Catches deleted trailing entries, which plain verify() cannot see.
    pub fn verify_anchored(&self, expected_head: &str) -> Result<(), usize> {
        self.verify()?;
        if self.head_hash() == expected_head {
            Ok(())
        } else {
            Err(self.entries.len())
        }
    }

    /// Verifies only entries start..end. Entries outside the range are not checked.
    pub fn verify_segment(&self, start: usize, end: usize) -> SegmentVerificationReport {
        let total = self.entries.len();
        let end = end.min(total);
        let start = start.min(end);

        let broken_index = self.first_break(start, end);
        let is_valid = broken_index.is_none();

        SegmentVerificationReport {
            start,
            end,
            segment_start: start,
            segment_end: end,
            ok: is_valid,
            valid: is_valid,
            broken_index,
            is_valid,
            total_entries: total,
            genesis_hash: self.genesis.clone(),
            last_hash: self.entries.last().map(|e| e.hash.clone()),
            broken_segments: broken_index.into_iter().collect(),
        }
    }

    pub fn to_jsonl(&self) -> String {
        let mut out = String::new();
        for entry in &self.entries {
            if let Ok(line) = serde_json::to_string(entry) {
                out.push_str(&line);
                out.push('\n');
            }
        }
        out
    }
}

impl Default for AuditLog {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, Default)]
pub struct ConcurrentLedger {
    inner: Arc<Mutex<AuditLog>>,
}

impl ConcurrentLedger {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(Mutex::new(AuditLog::new())),
        }
    }

    pub fn with_genesis(genesis: &str) -> Self {
        Self {
            inner: Arc::new(Mutex::new(AuditLog::with_genesis(genesis))),
        }
    }

    pub fn new_genesis(genesis: &str) -> Self {
        Self::with_genesis(genesis)
    }

    /// A panic in another thread must not take the whole ledger down with it.
    fn lock(&self) -> MutexGuard<'_, AuditLog> {
        self.inner
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    pub fn append(&self, actor: &str, action: &str) -> Option<AuditEntry> {
        let mut guard = self.lock();
        Some(guard.append(actor, action).clone())
    }

    pub fn entries(&self) -> Vec<AuditEntry> {
        self.lock().entries().to_vec()
    }

    pub fn len(&self) -> usize {
        self.lock().len()
    }

    pub fn is_empty(&self) -> bool {
        self.lock().is_empty()
    }

    pub fn head_hash(&self) -> String {
        self.lock().head_hash()
    }

    pub fn verify(&self) -> Result<(), usize> {
        self.lock().verify()
    }

    pub fn verify_segments(&self) -> SegmentVerificationReport {
        let guard = self.lock();
        let total = guard.len();
        guard.verify_segment(0, total)
    }

    pub fn to_jsonl(&self) -> String {
        self.lock().to_jsonl()
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SegmentVerificationReport {
    pub start: usize,
    pub end: usize,
    pub segment_start: usize,
    pub segment_end: usize,
    pub ok: bool,
    pub valid: bool,
    pub broken_index: Option<usize>,
    pub is_valid: bool,
    pub total_entries: usize,
    pub genesis_hash: String,
    pub last_hash: Option<String>,
    pub broken_segments: Vec<usize>,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_log(n: usize) -> AuditLog {
        let mut log = AuditLog::new();
        for i in 0..n {
            log.append("alice", &format!("action_{i}"));
        }
        log
    }

    #[test]
    fn append_creates_chained_entries() {
        let mut log = AuditLog::new();
        log.append("alice", "login");
        log.append("alice", "write");

        assert_eq!(log.len(), 2);
        assert!(log.verify().is_ok());
        assert_eq!(log.entries()[0].sequence, 0);
        assert_eq!(log.entries()[1].sequence, 1);
        assert_eq!(log.entries()[0].actor, "alice");
        assert_eq!(log.entries()[0].prev_hash, GENESIS_EVT_1041);
        assert_eq!(log.entries()[1].prev_hash, log.entries()[0].hash);
    }

    #[test]
    fn empty_log_is_valid() {
        let log = AuditLog::new();
        assert!(log.is_empty());
        assert!(log.verify().is_ok());
        assert_eq!(log.head_hash(), GENESIS_EVT_1041);
    }

    #[test]
    fn log_serializes_and_deserializes() {
        let mut log = AuditLog::new();
        log.append("alice", "login");

        let out = log.to_jsonl();
        let first: AuditEntry = serde_json::from_str(out.lines().next().unwrap()).unwrap();
        assert_eq!(first.actor, "alice");
        assert_eq!(first.sequence, 0);
        assert_eq!(first, log.entries()[0]);
    }

    #[test]
    fn timestamp_looks_like_rfc3339() {
        let log = sample_log(1);
        let ts = &log.entries()[0].timestamp;
        assert_eq!(ts.len(), 27, "unexpected timestamp: {ts}");
        assert!(ts.ends_with('Z'));
        assert_eq!(&ts[4..5], "-");
        assert_eq!(&ts[10..11], "T");
    }

    #[test]
    fn tampered_action_is_detected() {
        let mut log = sample_log(4);
        log.entries_mut()[2].action = "evil".to_string();
        assert_eq!(log.verify(), Err(2));
    }

    #[test]
    fn tampered_prev_hash_is_detected() {
        let mut log = sample_log(4);
        log.entries_mut()[1].prev_hash = "bogus".to_string();
        assert_eq!(log.verify(), Err(1));
    }

    #[test]
    fn deleted_middle_entry_is_detected() {
        let mut log = sample_log(4);
        log.entries.remove(1);
        assert!(log.verify().is_err());
    }

    #[test]
    fn separator_confusion_does_not_collide() {
        let a = AuditEntry::compute_hash(0, "t", "a|b", "c", "p");
        let b = AuditEntry::compute_hash(0, "t", "a", "b|c", "p");
        assert_ne!(a, b);
    }

    #[test]
    fn truncation_is_caught_by_anchor() {
        let mut log = sample_log(5);
        let saved_head = log.head_hash();
        assert!(log.verify_anchored(&saved_head).is_ok());

        log.entries.truncate(3);
        assert!(log.verify().is_ok());
        assert!(log.verify_anchored(&saved_head).is_err());
    }

    #[test]
    fn verify_segment_only_checks_requested_range() {
        let mut log = sample_log(5);
        log.entries_mut()[3].action = "evil".to_string();

        let clean = log.verify_segment(0, 2);
        assert!(clean.valid);
        assert_eq!(clean.broken_index, None);

        let dirty = log.verify_segment(2, 5);
        assert!(!dirty.valid);
        assert_eq!(dirty.broken_index, Some(3));
        assert_eq!(dirty.broken_segments, vec![3]);
    }

    #[test]
    fn verify_segment_clamps_out_of_range() {
        let log = sample_log(3);
        let report = log.verify_segment(0, 999);
        assert!(report.valid);
        assert_eq!(report.end, 3);
        assert_eq!(report.total_entries, 3);
    }

    #[test]
    fn custom_genesis_is_used() {
        let mut log = AuditLog::with_genesis("MY_GENESIS");
        log.append("alice", "login");
        assert_eq!(log.entries()[0].prev_hash, "MY_GENESIS");
        assert!(log.verify().is_ok());
    }

    #[test]
    fn concurrent_ledger_survives_parallel_appends() {
        let ledger = ConcurrentLedger::new();
        let mut handles = Vec::new();

        for lane in 0..12 {
            let l = ledger.clone();
            handles.push(std::thread::spawn(move || {
                for i in 0..25 {
                    l.append(&format!("MACK-{:02}", lane + 1), &format!("event_{i}"));
                }
            }));
        }
        for h in handles {
            h.join().unwrap();
        }

        assert_eq!(ledger.len(), 300);
        assert!(ledger.verify().is_ok());

        let report = ledger.verify_segments();
        assert!(report.valid);
        assert_eq!(report.total_entries, 300);
        assert!(report.broken_segments.is_empty());
    }

    #[test]
    fn concurrent_report_shows_real_broken_index() {
        let ledger = ConcurrentLedger::new();
        for i in 0..4 {
            ledger.append("alice", &format!("a{i}"));
        }
        ledger.lock().entries_mut()[2].actor = "mallory".to_string();

        let report = ledger.verify_segments();
        assert!(!report.valid);
        assert_eq!(report.broken_index, Some(2));
        assert_eq!(report.broken_segments, vec![2]);
    }
}
