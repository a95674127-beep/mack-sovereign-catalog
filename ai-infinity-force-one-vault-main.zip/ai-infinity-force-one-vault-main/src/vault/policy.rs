//! policy.rs - Zero-trust policy engine
//! AI Infinity Force One Vault
//! Defines what Actions are allowed on what Resources

use serde::{Deserialize, Serialize};

/// What can be done
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Action {
    Read,
    Write,
    Delete,
    List,
    Encrypt,
    Decrypt,
    Export,
    Admin,
}

/// Allow or Deny
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Effect {
    Allow,
    Deny,
}

/// Decision result
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Decision {
    Allow,
    Deny,
}

/// Principal - represents a user or system entity
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Hash)]
pub struct Principal(pub String);

/// Resource - represents a vault resource
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Hash)]
pub struct Resource(pub String);

/// A single access rule.
///
/// `principal` is an exact name or `"*"` (any principal). `resource`
/// is an exact name, `"*"` (any resource), or a `"prefix/*"` pattern
/// matching the prefix path itself and everything under it. The
/// pattern semantics and first-match evaluation are harvested from
/// Stealth Core's `Policy` (component authored by Allen Mack in
/// `autonomous-mack-stealth-core` `src/policy.rs`; folded into the
/// vault 2026-11-10, harvest audit row 1).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Rule {
    pub principal: Principal,
    pub resource: Resource,
    pub actions: Vec<Action>,
    pub effect: Effect,
}

/// Access policy engine — the live zero-trust engine the vault
/// facade, the pipeline, and `main` actually evaluate.
///
/// Evaluation is **first-match**: rules are consulted in the order
/// they were added, and the first rule whose principal matches,
/// whose resource matches, and whose action list contains the
/// requested action decides the outcome (Allow or Deny). A rule
/// that matches principal and resource but not the action is
/// skipped, so grants for different actions compose exactly as
/// they did under the previous any-allow-match engine. No matching
/// rule means Deny — the zero-trust default is unchanged.
///
/// Migration note (2026-11-10): before the harvest, `Rule` had no
/// effect field and evaluation was any-match over exact names only,
/// so every pre-existing rule was an exact-match allow. Under
/// first-match those rules behave identically: exact names match
/// only themselves, and the relative order of exact allow rules
/// cannot change the outcome. The deny effect and the `"*"` /
/// `"prefix/*"` patterns are new expressive power, reachable only
/// through rules that use them.
#[derive(Debug, Clone)]
pub struct AccessPolicy {
    rules: Vec<Rule>,
}

impl AccessPolicy {
    /// Create new empty policy
    pub fn new() -> Self {
        Self { rules: Vec::new() }
    }

    /// Add a rule. Rules are consulted in insertion order; see the
    /// type-level docs for the first-match semantics.
    pub fn grant(&mut self, rule: Rule) {
        self.rules.push(rule);
    }

    /// Add a deny rule (a carve-out). Equivalent to granting a
    /// [`Rule`] whose effect is [`Effect::Deny`]; placement matters:
    /// a deny added *before* an allow for the same
    /// principal/resource/action wins, and one added *after* does
    /// not — the same first-match discipline as Stealth Core.
    pub fn deny(&mut self, principal: Principal, resource: Resource, actions: Vec<Action>) {
        self.rules.push(Rule {
            principal,
            resource,
            actions,
            effect: Effect::Deny,
        });
    }

    /// Evaluate access decision
    pub fn evaluate(&self, principal: &Principal, resource: &Resource, action: Action) -> Decision {
        for rule in &self.rules {
            if !principal_matches(&rule.principal, principal) {
                continue;
            }
            if !resource_matches(&rule.resource, resource) {
                continue;
            }
            if !rule.actions.contains(&action) {
                continue;
            }
            return match rule.effect {
                Effect::Allow => Decision::Allow,
                Effect::Deny => Decision::Deny,
            };
        }
        Decision::Deny
    }
}

/// Principal matching, per Stealth Core: `"*"` matches any
/// principal; anything else is an exact match.
fn principal_matches(pattern: &Principal, principal: &Principal) -> bool {
    pattern.0 == "*" || pattern.0 == principal.0
}

/// Resource matching, per Stealth Core: `"*"` matches any resource;
/// a `"prefix/*"` pattern matches the prefix path itself and
/// everything under it; anything else is an exact match.
fn resource_matches(pattern: &Resource, resource: &Resource) -> bool {
    let pattern = pattern.0.as_str();
    let value = resource.0.as_str();
    if pattern == "*" || pattern == value {
        return true;
    }
    match pattern.strip_suffix("/*") {
        Some(prefix) => value == prefix || value.starts_with(&format!("{prefix}/")),
        None => false,
    }
}

impl Default for AccessPolicy {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Operation budgets
// ---------------------------------------------------------------------------

/// A bounded count of operations a gate will allow before it starts
/// refusing work.
///
/// Pattern harvested from Stealth Core `src/core.rs` (component
/// authored by Allen Mack in `autonomous-mack-stealth-core` as the
/// `Vault::gate` budget; folded into the vault 2026-11-10, harvest
/// audit row 5). The vault previously bounded operation *size*,
/// *time*, and *rate*, but never the *count* of operations a
/// principal could drive through a gate; the budget closes that gap.
///
/// Semantics, matching the donor: `None` (the default) is unlimited,
/// preserving pre-harvest behavior. Only operations the gate allows
/// consume budget — a policy denial never decrements the balance.
/// The gate checks exhaustion *before* evaluating policy and audits
/// the refusal.
#[derive(Debug, Clone)]
pub struct OperationBudget {
    budget: Option<usize>,
    used: usize,
}

impl OperationBudget {
    /// An unlimited budget (the default): never exhausted.
    pub fn unlimited() -> Self {
        Self {
            budget: None,
            used: 0,
        }
    }

    /// A budget of `budget` allowed operations; `None` is unlimited.
    pub fn new(budget: Option<usize>) -> Self {
        Self { budget, used: 0 }
    }

    /// Replaces the limit; the used count is preserved, so lowering
    /// the limit at or below `used` exhausts the budget immediately.
    pub fn set(&mut self, budget: Option<usize>) {
        self.budget = budget;
    }

    /// The configured limit, if any.
    pub fn limit(&self) -> Option<usize> {
        self.budget
    }

    /// Operations consumed so far (allowed operations only).
    pub fn used(&self) -> usize {
        self.used
    }

    /// Operations remaining before exhaustion; `None` when unlimited.
    pub fn remaining(&self) -> Option<usize> {
        self.budget.map(|b| b.saturating_sub(self.used))
    }

    /// Whether the gate must refuse further operations.
    pub fn is_exhausted(&self) -> bool {
        self.budget.is_some_and(|b| self.used >= b)
    }

    /// Records one allowed operation against the budget.
    pub fn record_allowed(&mut self) {
        self.used += 1;
    }
}

impl Default for OperationBudget {
    fn default() -> Self {
        Self::unlimited()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    // --- Operation budget tests (harvested pattern, 2026-11-10) ---

    #[test]
    fn budget_unlimited_never_exhausts() {
        let mut budget = OperationBudget::unlimited();
        for _ in 0..1_000 {
            budget.record_allowed();
        }
        assert!(!budget.is_exhausted());
        assert_eq!(budget.used(), 1_000);
        assert_eq!(budget.remaining(), None);
    }

    #[test]
    fn budget_counts_down_to_exhaustion() {
        let mut budget = OperationBudget::new(Some(2));
        assert!(!budget.is_exhausted());
        assert_eq!(budget.remaining(), Some(2));
        budget.record_allowed();
        assert_eq!(budget.remaining(), Some(1));
        assert!(!budget.is_exhausted());
        budget.record_allowed();
        assert_eq!(budget.remaining(), Some(0));
        assert!(budget.is_exhausted());
    }

    #[test]
    fn budget_zero_is_exhausted_immediately_and_set_preserves_used() {
        let budget = OperationBudget::new(Some(0));
        assert!(budget.is_exhausted());
        let mut budget = OperationBudget::new(Some(3));
        budget.record_allowed();
        budget.record_allowed();
        budget.set(Some(2));
        assert!(budget.is_exhausted(), "lowering the limit keeps the count");
        budget.set(None);
        assert!(!budget.is_exhausted());
    }

    // --- Merged-engine tests (harvest 2026-11-10, audit row 1) ---
    //
    // The first group is the grant-migration battery: every pattern
    // the pre-harvest engine could express (exact-match allow rules)
    // must behave identically under first-match evaluation.

    #[test]
    fn migration_exact_grants_compose_across_actions() {
        // Pre-harvest shape: separate exact grants per action, as
        // produced by granting Read and Write in two rules. Under
        // any-match both applied; under first-match the rule that
        // does not contain the action is skipped, so both still do.
        let mut policy = AccessPolicy::new();
        let alice = Principal("alice".into());
        let secret = Resource("secret1".into());
        policy.grant(Rule {
            principal: alice.clone(),
            resource: secret.clone(),
            actions: vec![Action::Read],
            effect: Effect::Allow,
        });
        policy.grant(Rule {
            principal: alice.clone(),
            resource: secret.clone(),
            actions: vec![Action::Write],
            effect: Effect::Allow,
        });
        assert_eq!(
            policy.evaluate(&alice, &secret, Action::Read),
            Decision::Allow
        );
        assert_eq!(
            policy.evaluate(&alice, &secret, Action::Write),
            Decision::Allow
        );
        assert_eq!(
            policy.evaluate(&alice, &secret, Action::Delete),
            Decision::Deny
        );
    }

    #[test]
    fn migration_rule_order_does_not_change_exact_allows() {
        // Two exact allow rules in either order give the same
        // decisions under any-match and under first-match.
        let build = |swap: bool| {
            let mut policy = AccessPolicy::new();
            let a = Rule {
                principal: Principal("alice".into()),
                resource: Resource("doc_a".into()),
                actions: vec![Action::Read],
                effect: Effect::Allow,
            };
            let b = Rule {
                principal: Principal("bob".into()),
                resource: Resource("doc_b".into()),
                actions: vec![Action::Read],
                effect: Effect::Allow,
            };
            if swap {
                policy.grant(b);
                policy.grant(a);
            } else {
                policy.grant(a);
                policy.grant(b);
            }
            policy
        };
        for policy in [build(false), build(true)] {
            assert_eq!(
                policy.evaluate(
                    &Principal("alice".into()),
                    &Resource("doc_a".into()),
                    Action::Read
                ),
                Decision::Allow
            );
            assert_eq!(
                policy.evaluate(
                    &Principal("bob".into()),
                    &Resource("doc_b".into()),
                    Action::Read
                ),
                Decision::Allow
            );
            assert_eq!(
                policy.evaluate(
                    &Principal("alice".into()),
                    &Resource("doc_b".into()),
                    Action::Read
                ),
                Decision::Deny
            );
            assert_eq!(
                policy.evaluate(
                    &Principal("carol".into()),
                    &Resource("doc_a".into()),
                    Action::Read
                ),
                Decision::Deny
            );
        }
    }

    // The remaining tests cover the NEW expressive power: deny
    // carve-outs and patterns (Stealth semantics).

    #[test]
    fn deny_carve_out_added_first_wins() {
        let mut policy = AccessPolicy::new();
        policy.deny(
            Principal("eve".into()),
            Resource("secret1".into()),
            vec![Action::Read],
        );
        policy.grant(Rule {
            principal: Principal("*".into()),
            resource: Resource("secret1".into()),
            actions: vec![Action::Read],
            effect: Effect::Allow,
        });
        assert_eq!(
            policy.evaluate(
                &Principal("eve".into()),
                &Resource("secret1".into()),
                Action::Read
            ),
            Decision::Deny,
            "the earlier deny carve-out decides for eve"
        );
        assert_eq!(
            policy.evaluate(
                &Principal("alice".into()),
                &Resource("secret1".into()),
                Action::Read
            ),
            Decision::Allow,
            "the wildcard allow still covers everyone else"
        );
    }

    #[test]
    fn deny_added_after_allow_does_not_override_it() {
        let mut policy = AccessPolicy::new();
        policy.grant(Rule {
            principal: Principal("alice".into()),
            resource: Resource("secret1".into()),
            actions: vec![Action::Read],
            effect: Effect::Allow,
        });
        policy.deny(
            Principal("alice".into()),
            Resource("secret1".into()),
            vec![Action::Read],
        );
        assert_eq!(
            policy.evaluate(
                &Principal("alice".into()),
                &Resource("secret1".into()),
                Action::Read
            ),
            Decision::Allow,
            "first match wins: the earlier allow decides"
        );
    }

    #[test]
    fn deny_for_one_action_leaves_other_actions_allowed() {
        let mut policy = AccessPolicy::new();
        policy.deny(
            Principal("alice".into()),
            Resource("secret1".into()),
            vec![Action::Delete],
        );
        policy.grant(Rule {
            principal: Principal("alice".into()),
            resource: Resource("secret1".into()),
            actions: vec![Action::Read, Action::Write, Action::Delete],
            effect: Effect::Allow,
        });
        let alice = Principal("alice".into());
        let secret = Resource("secret1".into());
        assert_eq!(
            policy.evaluate(&alice, &secret, Action::Delete),
            Decision::Deny
        );
        assert_eq!(
            policy.evaluate(&alice, &secret, Action::Read),
            Decision::Allow
        );
        assert_eq!(
            policy.evaluate(&alice, &secret, Action::Write),
            Decision::Allow
        );
    }

    #[test]
    fn wildcard_principal_and_resource_patterns() {
        let mut policy = AccessPolicy::new();
        policy.grant(Rule {
            principal: Principal("*".into()),
            resource: Resource("*".into()),
            actions: vec![Action::List],
            effect: Effect::Allow,
        });
        assert_eq!(
            policy.evaluate(
                &Principal("anyone".into()),
                &Resource("anything".into()),
                Action::List
            ),
            Decision::Allow
        );
        assert_eq!(
            policy.evaluate(
                &Principal("anyone".into()),
                &Resource("anything".into()),
                Action::Read
            ),
            Decision::Deny,
            "the wildcard rule still only covers its own actions"
        );
    }

    #[test]
    fn prefix_pattern_matches_path_and_children_only() {
        let mut policy = AccessPolicy::new();
        policy.grant(Rule {
            principal: Principal("alice".into()),
            resource: Resource("docs/*".into()),
            actions: vec![Action::Read],
            effect: Effect::Allow,
        });
        let alice = Principal("alice".into());
        assert_eq!(
            policy.evaluate(&alice, &Resource("docs".into()), Action::Read),
            Decision::Allow,
            "the prefix path itself matches (Stealth semantics)"
        );
        assert_eq!(
            policy.evaluate(&alice, &Resource("docs/report".into()), Action::Read),
            Decision::Allow
        );
        assert_eq!(
            policy.evaluate(&alice, &Resource("docs/deep/nested".into()), Action::Read),
            Decision::Allow
        );
        assert_eq!(
            policy.evaluate(&alice, &Resource("docsx/report".into()), Action::Read),
            Decision::Deny,
            "a sibling sharing the string prefix must not match"
        );
        assert_eq!(
            policy.evaluate(&alice, &Resource("other".into()), Action::Read),
            Decision::Deny
        );
    }

    #[test]
    fn test_access_policy_grant_and_evaluate() {
        let mut policy = AccessPolicy::new();
        let alice = Principal("alice".into());
        let secret = Resource("secret1".into());

        // Initially deny
        assert_eq!(
            policy.evaluate(&alice, &secret, Action::Read),
            Decision::Deny
        );

        // Grant and allow
        policy.grant(Rule {
            effect: Effect::Allow,
            principal: alice.clone(),
            resource: secret.clone(),
            actions: vec![Action::Read, Action::Write],
        });

        assert_eq!(
            policy.evaluate(&alice, &secret, Action::Read),
            Decision::Allow
        );
        assert_eq!(
            policy.evaluate(&alice, &secret, Action::Write),
            Decision::Allow
        );
        assert_eq!(
            policy.evaluate(&alice, &secret, Action::Delete),
            Decision::Deny
        );
    }
}
