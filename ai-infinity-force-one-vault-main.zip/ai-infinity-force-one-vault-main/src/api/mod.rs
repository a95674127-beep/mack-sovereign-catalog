//! REST API module for the AI Infinity Force One vault (Milestone 4).

use axum::{
    extract::{Path, State},
    http::{header, HeaderMap, Method, StatusCode},
    response::IntoResponse,
    routing::{get, post},
    Json, Router,
};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Arc, Mutex, RwLock};
use std::time::Instant;
use subtle::ConstantTimeEq;
use tower_http::cors::{AllowOrigin, CorsLayer};

use crate::pov::ProofOfVerification;
use crate::sandbox::lanes::{LaneContainmentEngine, LaneId, LaneStatus};
use crate::sandbox::pipeline::{ContainmentDecision, ContainmentPipeline};
use crate::vault::audit::ConcurrentLedger;

// No hardcoded default token. If MACK_ENGINE_TOKEN is unset, a random
// token is generated at startup and printed to the log. The old public
// default ("mack-vault-admin-secret-2026") was removed because it shipped
// in the frontend bundle and was therefore not a secret.
pub const DASHBOARD_TOKEN_HEADER: &str = "X-Dashboard-Token";

#[derive(Clone)]
pub struct AppState {
    pub lanes: Arc<LaneContainmentEngine>,
    pub ledger: Arc<ConcurrentLedger>,
    pub admin_token: Arc<String>,
    pub dashboard_token: Arc<String>,
    pub operator_stats: Arc<RwLock<HashMap<String, OperatorReputation>>>,
    pub event_buffer: Arc<RwLock<Vec<EngineEvent>>>,
    /// Detection-containment pipeline gating all payload ingress.
    pub pipeline: Arc<ContainmentPipeline>,
    /// Single-node in-memory rate limiter. Not distributed: each server
    /// instance enforces its own budget.
    pub rate_limiter: Arc<RateLimiter>,
}

/// Simple token-bucket rate limiter (single-node, in-memory).
///
/// Honest limits: this is per-process state. Behind a load balancer or with
/// multiple server instances, each instance enforces its own budget — it is
/// not a distributed rate limit. Suitable for a single-node deployment.
pub struct RateLimiter {
    state: Mutex<BucketState>,
    capacity: u64,
    refill_per_sec: u64,
}

struct BucketState {
    tokens: f64,
    last_refill: Instant,
}

impl RateLimiter {
    /// Creates a limiter allowing `capacity` burst tokens, refilling at
    /// `refill_per_sec` tokens per second.
    pub fn new(capacity: u64, refill_per_sec: u64) -> Self {
        Self {
            state: Mutex::new(BucketState {
                tokens: capacity as f64,
                last_refill: Instant::now(),
            }),
            capacity,
            refill_per_sec,
        }
    }

    /// Attempts to consume one token. Returns `true` when allowed.
    pub fn check(&self) -> bool {
        let mut state = self.state.lock().unwrap_or_else(|e| e.into_inner());
        let now = Instant::now();
        let elapsed = now.duration_since(state.last_refill);
        state.tokens = (state.tokens + elapsed.as_secs_f64() * self.refill_per_sec as f64)
            .min(self.capacity as f64);
        state.last_refill = now;
        if state.tokens >= 1.0 {
            state.tokens -= 1.0;
            true
        } else {
            false
        }
    }

    /// Tokens currently available (for observability/tests).
    pub fn available(&self) -> u64 {
        let mut state = self.state.lock().unwrap_or_else(|e| e.into_inner());
        let now = Instant::now();
        let elapsed = now.duration_since(state.last_refill);
        state.tokens = (state.tokens + elapsed.as_secs_f64() * self.refill_per_sec as f64)
            .min(self.capacity as f64);
        state.last_refill = now;
        state.tokens as u64
    }
}

/// Default ingest budget: 60 requests burst, 10/sec sustained.
impl Default for RateLimiter {
    fn default() -> Self {
        Self::new(60, 10)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct EngineEvent {
    pub timestamp: String,
    pub lane: String,
    pub event_type: String,
    pub message: String,
    pub severity: String,
}

impl AppState {
    pub fn new(lanes: Arc<LaneContainmentEngine>, ledger: Arc<ConcurrentLedger>) -> Self {
        let admin_token = std::env::var("MACK_ENGINE_TOKEN").unwrap_or_else(|_| {
            let tok = generate_secure_token();
            eprintln!("[SECURITY] MACK_ENGINE_TOKEN not set; using ephemeral admin token.");
            tok
        });
        let dashboard_token =
            std::env::var("VAULT_DASHBOARD_TOKEN").unwrap_or_else(|_| generate_secure_token());

        Self {
            lanes,
            ledger,
            admin_token: Arc::new(admin_token),
            dashboard_token: Arc::new(dashboard_token),
            operator_stats: Arc::new(RwLock::new(HashMap::new())),
            event_buffer: Arc::new(RwLock::new(Vec::new())),
            pipeline: Arc::new(ContainmentPipeline::new(1_048_576)),
            rate_limiter: Arc::new(RateLimiter::default()),
        }
    }

    pub fn with_admin_token(
        lanes: Arc<LaneContainmentEngine>,
        ledger: Arc<ConcurrentLedger>,
        admin_token: impl Into<String>,
    ) -> Self {
        Self {
            lanes,
            ledger,
            admin_token: Arc::new(admin_token.into()),
            dashboard_token: Arc::new(String::new()),
            operator_stats: Arc::new(RwLock::new(HashMap::new())),
            event_buffer: Arc::new(RwLock::new(Vec::new())),
            pipeline: Arc::new(ContainmentPipeline::new(1_048_576)),
            rate_limiter: Arc::new(RateLimiter::default()),
        }
    }

    pub fn with_dashboard_token(
        lanes: Arc<LaneContainmentEngine>,
        ledger: Arc<ConcurrentLedger>,
        dashboard_token: impl Into<String>,
    ) -> Self {
        let admin_token = std::env::var("MACK_ENGINE_TOKEN").unwrap_or_else(|_| {
            let tok = generate_secure_token();
            eprintln!("[SECURITY] MACK_ENGINE_TOKEN not set; using ephemeral admin token.");
            tok
        });

        Self {
            lanes,
            ledger,
            admin_token: Arc::new(admin_token),
            dashboard_token: Arc::new(dashboard_token.into()),
            operator_stats: Arc::new(RwLock::new(HashMap::new())),
            event_buffer: Arc::new(RwLock::new(Vec::new())),
            pipeline: Arc::new(ContainmentPipeline::new(1_048_576)),
            rate_limiter: Arc::new(RateLimiter::default()),
        }
    }

    /// Test/support constructor allowing a custom pipeline and limiter.
    pub fn with_pipeline(
        lanes: Arc<LaneContainmentEngine>,
        ledger: Arc<ConcurrentLedger>,
        dashboard_token: impl Into<String>,
        pipeline: Arc<ContainmentPipeline>,
        rate_limiter: Arc<RateLimiter>,
    ) -> Self {
        let admin_token = std::env::var("MACK_ENGINE_TOKEN").unwrap_or_else(|_| {
            let tok = generate_secure_token();
            eprintln!("[SECURITY] MACK_ENGINE_TOKEN not set; using ephemeral admin token.");
            tok
        });

        Self {
            lanes,
            ledger,
            admin_token: Arc::new(admin_token),
            dashboard_token: Arc::new(dashboard_token.into()),
            operator_stats: Arc::new(RwLock::new(HashMap::new())),
            event_buffer: Arc::new(RwLock::new(Vec::new())),
            pipeline,
            rate_limiter,
        }
    }
}

#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct HealthResponse {
    pub status: String,
    pub engine: String,
    pub version: String,
}

#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct LaneInfo {
    pub code: String,
    pub label: String,
    pub status: String,
    pub backoff_level: u8,
    pub remaining_ms: u64,
}

#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct LanesResponse {
    pub total: usize,
    pub lanes: Vec<LaneInfo>,
}

#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct ResetResponse {
    pub lane: String,
    pub status: String,
}

#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct VerificationResponse {
    pub valid: bool,
    pub entries_checked: usize,
    pub genesis_hash: String,
    pub last_hash: Option<String>,
    pub broken_segments: Vec<usize>,
    pub message: String,
}

#[derive(Debug, Serialize, Deserialize, PartialEq)]
pub struct EventTailResponse {
    pub events: Vec<EngineEvent>,
}

/// Head of the hash-chained audit ledger: sequence length and tip hash.
#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct LedgerHead {
    pub seq: usize,
    pub head_hash: String,
}

/// Unified engine snapshot for dashboards: version, ledger head, lane
/// states, and recent audit events in a single authenticated call.
#[derive(Debug, Serialize, Deserialize, PartialEq)]
pub struct SnapshotResponse {
    pub engine_version: String,
    pub timestamp: String,
    pub ledger: LedgerHead,
    pub lanes: Vec<LaneInfo>,
    pub recent_events: Vec<EngineEvent>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct TaskVerificationResult {
    pub task_id: String,
    pub operator_id: String,
    pub is_valid: bool,
    pub verification_method: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PovVerifyResponse {
    pub total_tasks: usize,
    pub passed_tasks: usize,
    pub rejected_tasks: usize,
    pub pass_rate: f64,
    pub results: Vec<TaskVerificationResult>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct OperatorReputation {
    pub operator_id: String,
    pub total_submitted: u64,
    pub verified_valid: u64,
    pub rejected: u64,
    pub reputation_score: f64,
    pub status: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct OperatorReputationResponse {
    pub total_operators: usize,
    pub operators: Vec<OperatorReputation>,
}

/// Request body for `POST /api/v1/ingest/submit`.
///
/// The payload is hex-encoded because JSON has no native byte-string type.
/// This is the network ingress path for untrusted payloads: every submission
/// is routed through the [`ContainmentPipeline`] (detect → decide → contain),
/// so the detection verdict — not the caller — determines whether and how
/// the payload executes.
#[derive(Debug, Serialize, Deserialize)]
pub struct IngestSubmitRequest {
    /// Target lane code, e.g. "MACK-04". Must be one of the 12 vault lanes.
    pub lane: String,
    /// Hex-encoded payload bytes.
    pub payload_hex: String,
}

/// Response for `POST /api/v1/ingest/submit`.
#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct IngestSubmitResponse {
    /// Containment decision: "execute_standard" | "execute_isolated" | "sealed_hold".
    pub decision: String,
    /// Triage outcome: "Clean" | "Quarantine" | "Sealed".
    pub triage_outcome: String,
    /// Threat score 0–100.
    pub threat_score: u32,
    /// Whether the payload was executed (false for sealed).
    pub executed: bool,
    /// Whether execution succeeded, when executed.
    pub execution_ok: Option<bool>,
    /// Forensic anchor ID when a sealed event was recorded to the log.
    pub sealed_event_id: Option<String>,
    pub message: String,
}

// ---------------------------------------------------------------------------
// Why /api/v1/pov/verify is NOT routed through the ContainmentPipeline:
//
// verify_pov_handler accepts structured ProofOfVerification JSON and calls
// `independently_verify()`, which performs pure hash/string comparisons —
// it never executes caller-supplied bytes as code or dispatches them to a
// lane. There is no "payload execution" to gate, so routing it through the
// pipeline would be security theater: a scan that cannot change the outcome.
// The pipeline gates paths where bytes are *executed* (ingest/submit,
// DdilDetonationCoordinator). If verify_pov_handler ever gains an execution
// path, this comment — and the handler — must be revisited.
// ---------------------------------------------------------------------------

#[derive(Debug, Deserialize)]
#[serde(untagged)]
pub enum PovVerifyPayload {
    Batch { tasks: Vec<ProofOfVerification> },
    Direct(Vec<ProofOfVerification>),
}

#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct ApiError {
    pub error: String,
    pub message: String,
}

impl ApiError {
    pub fn new(error: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            error: error.into(),
            message: message.into(),
        }
    }
}

/// Scrubs the server's own token set out of text that is about to
/// leave the process in an API response or a buffered engine event.
///
/// Defense-in-depth via the [`crate::redact::Redactor`] (component
/// authored by Allen Mack in VaultLane; harvested into the vault
/// 2026-11-10, harvest audit row 3). No current code path prints a
/// token, but several responses echo client input or lower-layer
/// error strings; if a token ever reaches one of those strings (a
/// client replaying a token as a lane code, an error message quoting
/// a header), this pass replaces it — in raw, base64, and hex form —
/// before the text is serialized or stored for later serving.
fn scrub_outbound(state: &AppState, text: &str) -> String {
    let scrubbed = crate::redact::scrub_once(
        &[state.admin_token.as_str(), state.dashboard_token.as_str()],
        text.as_bytes(),
    );
    String::from_utf8_lossy(&scrubbed).into_owned()
}

/// Generate a cryptographically secure token for dashboard authentication
fn generate_secure_token() -> String {
    use rand::Rng;
    let mut rng = rand::thread_rng();
    let bytes: Vec<u8> = (0..32).map(|_| rng.gen()).collect();
    hex::encode(bytes)
}

/// Middleware to verify dashboard token.
///
/// Token comparison uses [`subtle::ConstantTimeEq`] so that comparison time
/// does not leak how many leading bytes matched (timing side-channel
/// resistance). An empty expected token fails closed (misconfigured auth
/// is not "no auth required").
fn verify_dashboard_token(
    headers: &HeaderMap,
    expected_token: &str,
) -> Result<(), (StatusCode, Json<ApiError>)> {
    // Fail closed: an empty expected token means auth is misconfigured,
    // not "no auth required".
    if expected_token.is_empty() {
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ApiError::new(
                "unauthorized",
                "Dashboard authentication is not configured on this server.",
            )),
        ));
    }
    // Accept either the documented `Authorization: Bearer <token>` header
    // (the dashboard contract) or the legacy `X-Dashboard-Token: <token>`
    // header. Both are compared in constant time against the same expected
    // token; a request is authorized when either one matches.
    let bearer = headers
        .get(header::AUTHORIZATION)
        .and_then(|h| h.to_str().ok())
        .and_then(|v| v.strip_prefix("Bearer "))
        .map(str::trim);
    let legacy = headers
        .get(DASHBOARD_TOKEN_HEADER)
        .and_then(|h| h.to_str().ok())
        .map(str::trim);

    // Constant-time: both length and content are compared without
    // early exit, so no timing oracle on prefix matches.
    let valid = [bearer, legacy]
        .into_iter()
        .flatten()
        .any(|t| bool::from(t.as_bytes().ct_eq(expected_token.as_bytes())));

    if valid {
        Ok(())
    } else {
        Err((
            StatusCode::UNAUTHORIZED,
            Json(ApiError::new(
                "unauthorized",
                "Missing or invalid dashboard token. Expected Authorization: Bearer <token> or X-Dashboard-Token header.",
            )),
        ))
    }
}

/// Constant-time bearer-token check for the admin token.
fn verify_admin_token(headers: &HeaderMap, expected_token: &str) -> bool {
    let auth_header = headers
        .get(header::AUTHORIZATION)
        .and_then(|h| h.to_str().ok());
    match auth_header.and_then(|v| v.strip_prefix("Bearer ").map(str::trim)) {
        Some(t) => t.as_bytes().ct_eq(expected_token.as_bytes()).into(),
        None => false,
    }
}

pub fn create_router(state: AppState) -> Router {
    let cors = CorsLayer::new()
        .allow_origin(AllowOrigin::predicate(|origin, _| {
            let origin_bytes = origin.as_bytes();
            origin_bytes.starts_with(b"http://localhost:")
                || origin_bytes.starts_with(b"http://127.0.0.1:")
                || origin_bytes == b"https://ai-infinity-force-one-vault.lovable.app"
        }))
        .allow_methods([Method::GET, Method::POST, Method::OPTIONS])
        .allow_headers([
            header::AUTHORIZATION,
            header::CONTENT_TYPE,
            header::ACCEPT,
            header::ORIGIN,
            axum::http::HeaderName::from_static("x-dashboard-token"),
        ]);

    Router::new()
        .route("/api/v1/health", get(health_handler))
        .route("/api/v1/lanes", get(list_lanes_handler))
        .route("/api/v1/lanes/:code/reset", post(reset_lane_handler))
        .route("/api/v1/ledger/verify", post(verify_ledger_handler))
        .route("/api/v1/ledger/snapshot", get(ledger_snapshot_handler))
        .route("/api/v1/events/tail", get(event_tail_handler))
        .route("/api/v1/pov/verify", post(verify_pov_handler))
        .route("/api/v1/pov/reputation", get(get_pov_reputation_handler))
        .route("/api/v1/ingest/submit", post(submit_ingest_handler))
        .layer(cors)
        .with_state(state)
}

/// Enforces the ingest rate budget. Returns a 429 response when exhausted.
fn check_rate_limit(state: &AppState) -> Result<(), (StatusCode, Json<ApiError>)> {
    if state.rate_limiter.check() {
        Ok(())
    } else {
        Err((
            StatusCode::TOO_MANY_REQUESTS,
            Json(ApiError::new(
                "rate_limited",
                "Ingest rate budget exhausted. Retry after the bucket refills.",
            )),
        ))
    }
}

async fn health_handler() -> impl IntoResponse {
    Json(HealthResponse {
        status: "operational".to_string(),
        engine: "MACK-Stack-Vault-Engine".to_string(),
        version: "0.1.0".to_string(),
    })
}

/// Collects the current status of all lanes. Shared by the lanes list
/// and the unified snapshot endpoints so both report identical state.
fn collect_lane_infos(state: &AppState) -> Vec<LaneInfo> {
    let mut lane_infos = Vec::new();

    for &lane_id in &LaneId::ALL_LANES {
        let status = state.lanes.lane_status(lane_id);
        let (status_str, backoff, rem_ms) = match status {
            LaneStatus::Green => ("Green".to_string(), 0, 0),
            LaneStatus::Quarantined {
                backoff_level,
                remaining,
            } => (
                "Quarantined".to_string(),
                backoff_level,
                remaining.as_millis() as u64,
            ),
            LaneStatus::TerminalLockout => ("TerminalLockout".to_string(), 4, 0),
        };

        lane_infos.push(LaneInfo {
            code: lane_id.code().to_string(),
            label: lane_id.label().to_string(),
            status: status_str,
            backoff_level: backoff,
            remaining_ms: rem_ms,
        });
    }

    lane_infos
}

async fn list_lanes_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<impl IntoResponse, (StatusCode, Json<ApiError>)> {
    verify_dashboard_token(&headers, &state.dashboard_token)?;

    let lane_infos = collect_lane_infos(&state);

    Ok(Json(LanesResponse {
        total: lane_infos.len(),
        lanes: lane_infos,
    }))
}

/// `GET /api/v1/ledger/snapshot` — unified engine snapshot for dashboards.
///
/// Returns the engine version, a timestamp, the audit-ledger head
/// (sequence + tip hash), all lane states, and the most recent audit
/// events in a single authenticated call, so a dashboard can render the
/// live system view without fanning out to four separate endpoints.
async fn ledger_snapshot_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<impl IntoResponse, (StatusCode, Json<ApiError>)> {
    verify_dashboard_token(&headers, &state.dashboard_token)?;

    let events = state
        .event_buffer
        .read()
        .unwrap_or_else(|e| e.into_inner())
        .clone();
    let recent_events = events.into_iter().rev().take(50).collect::<Vec<_>>();

    Ok(Json(SnapshotResponse {
        engine_version: env!("CARGO_PKG_VERSION").to_string(),
        timestamp: chrono::Local::now().to_rfc3339(),
        ledger: LedgerHead {
            seq: state.ledger.len(),
            head_hash: state.ledger.head_hash(),
        },
        lanes: collect_lane_infos(&state),
        recent_events,
    }))
}

async fn reset_lane_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(code): Path<String>,
) -> Result<impl IntoResponse, (StatusCode, Json<ApiError>)> {
    verify_dashboard_token(&headers, &state.dashboard_token)?;

    if !verify_admin_token(&headers, &state.admin_token) {
        // Distinguish "no credentials presented" (401) from "bad credentials" (403).
        let has_header = headers.get(header::AUTHORIZATION).is_some();
        return Err(if has_header {
            (
                StatusCode::FORBIDDEN,
                Json(ApiError::new(
                    "forbidden",
                    "Invalid or insufficient administrative credentials.",
                )),
            )
        } else {
            (
                StatusCode::UNAUTHORIZED,
                Json(ApiError::new(
                    "unauthorized",
                    "Missing Authorization header. Expected Bearer token.",
                )),
            )
        });
    }

    if let Some(lane_id) = LaneId::from_str_lenient(&code) {
        state.lanes.clear_lane_quarantine(lane_id);

        // Log event
        let event = EngineEvent {
            timestamp: chrono::Local::now().to_rfc3339(),
            lane: lane_id.code().to_string(),
            event_type: "lane_reset".to_string(),
            message: format!("Lane {} quarantine cleared", lane_id.code()),
            severity: "info".to_string(),
        };
        state
            .event_buffer
            .write()
            .unwrap_or_else(|e| e.into_inner())
            .push(event);

        Ok(Json(ResetResponse {
            lane: lane_id.code().to_string(),
            status: "quarantine_cleared".to_string(),
        }))
    } else {
        Err((
            StatusCode::NOT_FOUND,
            Json(ApiError::new(
                "lane_not_found",
                scrub_outbound(
                    &state,
                    &format!(
                        "Unknown lane code '{}'. Must be one of the 12 vault lanes.",
                        code
                    ),
                ),
            )),
        ))
    }
}

async fn verify_ledger_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<impl IntoResponse, (StatusCode, Json<ApiError>)> {
    verify_dashboard_token(&headers, &state.dashboard_token)?;

    let report = state.ledger.verify_segments();
    Ok(Json(VerificationResponse {
        valid: report.is_valid,
        entries_checked: report.total_entries,
        genesis_hash: report.genesis_hash,
        last_hash: report.last_hash,
        broken_segments: report.broken_segments.clone(),
        message: if report.is_valid {
            "Hash-chained ledger is fully intact and verified against genesis.".to_string()
        } else {
            format!(
                "Integrity violation detected in ledger segments: {:?}",
                report.broken_segments
            )
        },
    }))
}

async fn event_tail_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<impl IntoResponse, (StatusCode, Json<ApiError>)> {
    verify_dashboard_token(&headers, &state.dashboard_token)?;

    let events = state
        .event_buffer
        .read()
        .unwrap_or_else(|e| e.into_inner())
        .clone();

    // Return the most recent 100 events
    let tail = events.into_iter().rev().take(100).collect::<Vec<_>>();

    Ok(Json(EventTailResponse { events: tail }))
}

async fn verify_pov_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(payload): Json<PovVerifyPayload>,
) -> Result<impl IntoResponse, (StatusCode, Json<ApiError>)> {
    verify_dashboard_token(&headers, &state.dashboard_token)?;
    check_rate_limit(&state)?;

    let tasks = match payload {
        PovVerifyPayload::Batch { tasks } => tasks,
        PovVerifyPayload::Direct(tasks) => tasks,
    };

    let total_tasks = tasks.len();
    let mut passed_tasks = 0;
    let mut rejected_tasks = 0;
    let mut results = Vec::new();

    let mut stats_map = state
        .operator_stats
        .write()
        .unwrap_or_else(|e| e.into_inner());

    for task in tasks {
        let is_valid = task.independently_verify();
        if is_valid {
            passed_tasks += 1;
        } else {
            rejected_tasks += 1;
        }

        results.push(TaskVerificationResult {
            task_id: task.task_id.clone(),
            operator_id: task.operator_id.clone(),
            is_valid,
            verification_method: task.verification_method.clone(),
        });

        let entry = stats_map
            .entry(task.operator_id.clone())
            .or_insert_with(|| OperatorReputation {
                operator_id: task.operator_id.clone(),
                total_submitted: 0,
                verified_valid: 0,
                rejected: 0,
                reputation_score: 1.0,
                status: "trusted".to_string(),
            });

        entry.total_submitted += 1;
        if is_valid {
            entry.verified_valid += 1;
        } else {
            entry.rejected += 1;
        }

        let score = if entry.total_submitted > 0 {
            entry.verified_valid as f64 / entry.total_submitted as f64
        } else {
            1.0
        };
        entry.reputation_score = score;
        entry.status = if score >= 0.90 {
            "trusted".to_string()
        } else if score >= 0.70 {
            "probationary".to_string()
        } else {
            "suspended".to_string()
        };
    }

    let pass_rate = if total_tasks > 0 {
        passed_tasks as f64 / total_tasks as f64
    } else {
        1.0
    };

    Ok(Json(PovVerifyResponse {
        total_tasks,
        passed_tasks,
        rejected_tasks,
        pass_rate,
        results,
    }))
}

async fn get_pov_reputation_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<impl IntoResponse, (StatusCode, Json<ApiError>)> {
    verify_dashboard_token(&headers, &state.dashboard_token)?;

    let stats_map = state
        .operator_stats
        .read()
        .unwrap_or_else(|e| e.into_inner());
    let mut operators: Vec<OperatorReputation> = stats_map.values().cloned().collect();
    operators.sort_by(|a, b| a.operator_id.cmp(&b.operator_id));

    Ok(Json(OperatorReputationResponse {
        total_operators: operators.len(),
        operators,
    }))
}

/// `POST /api/v1/ingest/submit` — network ingress for untrusted payloads.
///
/// Every submission is routed through the [`ContainmentPipeline`]:
/// the detection verdict decides whether the payload executes in the
/// standard lane, escalates to process-isolated containment, or is sealed
/// without execution. Callers cannot bypass the scan.
///
/// Rate-limited (see [`RateLimiter`]); requires the dashboard token.
async fn submit_ingest_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<IngestSubmitRequest>,
) -> Result<impl IntoResponse, (StatusCode, Json<ApiError>)> {
    verify_dashboard_token(&headers, &state.dashboard_token)?;
    check_rate_limit(&state)?;

    let lane_id = LaneId::from_str_lenient(&req.lane).ok_or_else(|| {
        (
            StatusCode::BAD_REQUEST,
            Json(ApiError::new(
                "unknown_lane",
                scrub_outbound(
                    &state,
                    &format!(
                        "Unknown lane '{}'. Must be one of the 12 vault lanes.",
                        req.lane
                    ),
                ),
            )),
        )
    })?;

    let payload = hex::decode(req.payload_hex.trim()).map_err(|_| {
        (
            StatusCode::BAD_REQUEST,
            Json(ApiError::new(
                "bad_payload",
                "payload_hex must be valid hex-encoded bytes.",
            )),
        )
    })?;

    // The pipeline is synchronous (detection + lane dispatch). Run it on a
    // blocking thread so the async runtime stays responsive.
    let pipeline = Arc::clone(&state.pipeline);
    let result = tokio::task::spawn_blocking(move || pipeline.process(lane_id, payload))
        .await
        .map_err(|_| {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(ApiError::new(
                    "pipeline_error",
                    "Containment pipeline task failed.",
                )),
            )
        })?;

    let (decision_str, executed, execution_ok) = match &result.decision {
        ContainmentDecision::ExecuteStandard { .. } => {
            let ok = result.execution.as_ref().map(|r| r.is_ok());
            ("execute_standard", true, ok)
        }
        ContainmentDecision::ExecuteIsolated { .. } => {
            let ok = result.execution.as_ref().map(|r| r.is_ok());
            ("execute_isolated", true, ok)
        }
        ContainmentDecision::SealedHold { .. } => ("sealed_hold", false, None),
    };

    // Surface a forensic-recording failure without changing the containment
    // outcome: the payload stays sealed either way.
    if let Some(err) = &result.sealed_record_error {
        let event = EngineEvent {
            timestamp: chrono::Local::now().to_rfc3339(),
            lane: lane_id.code().to_string(),
            event_type: "sealed_record_failure".to_string(),
            // Lower-layer error strings are served back out via the
            // event tail; scrub the token set before buffering.
            message: scrub_outbound(&state, err),
            severity: "warning".to_string(),
        };
        state
            .event_buffer
            .write()
            .unwrap_or_else(|e| e.into_inner())
            .push(event);
    }

    let message = match result.decision {
        ContainmentDecision::ExecuteStandard { .. } => {
            "Payload clean: executed in standard lane containment.".to_string()
        }
        ContainmentDecision::ExecuteIsolated { .. } => match result.execution {
            Some(Ok(_)) => {
                "Payload quarantined: executed in process-isolated containment.".to_string()
            }
            _ => "Payload quarantined: isolated containment unavailable, rejected fail-closed."
                .to_string(),
        },
        ContainmentDecision::SealedHold { .. } => {
            "Payload sealed: critical threat verdict, not executed. Forensic hold on MACK-12."
                .to_string()
        }
    };

    Ok(Json(IngestSubmitResponse {
        decision: decision_str.to_string(),
        triage_outcome: format!("{:?}", result.scan.triage.outcome),
        threat_score: result.scan.triage.threat_score,
        executed,
        execution_ok,
        sealed_event_id: result.sealed_event.map(|e| e.record_hash),
        message,
    }))
}
