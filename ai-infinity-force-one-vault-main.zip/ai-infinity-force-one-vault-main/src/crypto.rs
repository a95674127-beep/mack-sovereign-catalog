 use argon2::Argon2;
use chacha20poly1305::{
    aead::{Aead, KeyInit},
    Key, XChaCha20Poly1305, XNonce,
};
use std::fmt;

#[derive(Debug)]
pub enum CryptoError {
    KeyDerivationFailed,
    EncryptionFailed,
    DecryptionFailed,
    RandomGenerationFailed,
}

impl fmt::Display for CryptoError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            CryptoError::KeyDerivationFailed => write!(f, "key derivation failed"),
            CryptoError::EncryptionFailed => write!(f, "encryption failed"),
            CryptoError::DecryptionFailed => write!(f, "decryption failed"),
            CryptoError::RandomGenerationFailed => write!(f, "random generation failed"),
        }
    }
}

impl std::error::Error for CryptoError {}

const NONCE_LEN: usize = 24;
const SALT_LEN: usize = 16;

pub fn generate_salt() -> Result<[u8; SALT_LEN], CryptoError> {
    let mut salt = [0u8; SALT_LEN];
    getrandom::getrandom(&mut salt).map_err(|_| CryptoError::RandomGenerationFailed)?;
    Ok(salt)
}

fn derive_key(passphrase: &str, salt: &[u8]) -> Result<zeroize::Zeroizing<[u8; 32]>, CryptoError> {
    let mut key = zeroize::Zeroizing::new([0u8; 32]);
    Argon2::default()
        .hash_password_into(passphrase.as_bytes(), salt, &mut *key)
        .map_err(|_| CryptoError::KeyDerivationFailed)?;
    Ok(key)
}

pub fn encrypt(plaintext: &[u8], passphrase: &str, salt: &[u8]) -> Result<Vec<u8>, CryptoError> {
    let key_bytes = derive_key(passphrase, salt)?;
    let key = Key::from_slice(&*key_bytes);
    let cipher = XChaCha20Poly1305::new(key);

    let mut nonce_bytes = [0u8; NONCE_LEN];
    getrandom::getrandom(&mut nonce_bytes).map_err(|_| CryptoError::RandomGenerationFailed)?;
    let nonce = XNonce::try_from(nonce_bytes.as_slice()).map_err(|_| CryptoError::EncryptionFailed)?;

    let ciphertext = cipher
        .encrypt(&nonce, plaintext)
        .map_err(|_| CryptoError::EncryptionFailed)?;

    let mut envelope = Vec::with_capacity(NONCE_LEN + ciphertext.len());
    envelope.extend_from_slice(&nonce_bytes);
    envelope.extend_from_slice(&ciphertext);
    Ok(envelope)
}

pub fn decrypt(envelope: &[u8], passphrase: &str, salt: &[u8]) -> Result<Vec<u8>, CryptoError> {
    if envelope.len() < NONCE_LEN {
        return Err(CryptoError::DecryptionFailed);
    }
    let (nonce_bytes, ciphertext) = envelope.split_at(NONCE_LEN);
    let key_bytes = derive_key(passphrase, salt)?;
    let key = Key::from_slice(&*key_bytes);
    let cipher = XChaCha20Poly1305::new(key);

    let nonce = XNonce::try_from(nonce_bytes).map_err(|_| CryptoError::DecryptionFailed)?;

    cipher
        .decrypt(&nonce, ciphertext)
        .map_err(|_| CryptoError::DecryptionFailed)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn encrypts_and_decrypts_round_trip() {
        let salt = generate_salt().unwrap();
        let passphrase = "test-passphrase";
        let plaintext = b"hello vault";

        let envelope = encrypt(plaintext, passphrase, &salt).unwrap();
        let decrypted = decrypt(&envelope, passphrase, &salt).unwrap();

        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn decrypt_fails_with_wrong_passphrase() {
        let salt = generate_salt().unwrap();
        let plaintext = b"hello vault";

        let envelope = encrypt(plaintext, "correct-passphrase", &salt).unwrap();
        let result = decrypt(&envelope, "wrong-passphrase", &salt);

        assert!(result.is_err());
    }

    #[test]
    fn decrypt_fails_with_wrong_salt() {
        let salt = generate_salt().unwrap();
        let other_salt = generate_salt().unwrap();
        let plaintext = b"hello vault";

        let envelope = encrypt(plaintext, "passphrase", &salt).unwrap();
        let result = decrypt(&envelope, "passphrase", &other_salt);

        assert!(result.is_err());
    }

    #[test]
    fn decrypt_fails_on_truncated_envelope() {
        let salt = generate_salt().unwrap();
        let plaintext = b"hello vault";
        let envelope = encrypt(plaintext, "passphrase", &salt).unwrap();

        let truncated = &envelope[..envelope.len() - 5];
        let result = decrypt(truncated, "passphrase", &salt);

        assert!(result.is_err());
    }
}
