# Security Policy

MACK (AI Infinity Force One) is a proprietary, fail-closed Rust security
platform maintained by a single developer. Security reports are taken
seriously and read personally by the maintainer.

## Reporting a vulnerability

Report privately by email: **a95674127@gmail.com**

Please include:

- A description of the issue and the component involved (containment lanes,
  audit ledger, vault cryptography, detection / STIX export, or other).
- Steps to reproduce, or a proof of concept, if you have one.
- The version or commit you tested against, if known.

Please do **not** open a public issue or post details publicly before
contacting the maintainer.

## What to expect

- **Acknowledgment:** within 5 business days. This is a solo-maintained
  project; every report is read by the maintainer personally.
- **Triage:** confirmed issues are fixed in priority order, with the
  reporter's input on the fix where practical.
- **Disclosure:** coordinated disclosure is requested — please allow up to
  90 days for a fix before public disclosure. Reporters are credited in the
  release record with their permission.

## Safe harbor

Good-faith security research conducted under this policy is authorized.
The maintainer will not pursue or support legal action against researchers
who, in good faith:

- Test only against their own copy or instance of the software.
- Avoid privacy violations, data destruction, and service degradation.
- Give the maintainer reasonable time to respond and remediate before
  disclosing.

## Scope

**In scope:** the MACK codebase itself — the 12-lane containment engine and
its Landlock-confined workers, the tamper-evident audit ledger, vault
encryption at rest (Argon2id + XChaCha20-Poly1305), YARA-X detection, and
the STIX 2.1 export.

**Out of scope:**

- Vulnerabilities in third-party dependencies — please report those
  upstream. (One known transitive advisory, RUSTSEC-2023-0071 affecting the
  `rsa` crate via `yara-x`, is documented in the project's release record;
  MACK contains no RSA key handling or decryption in first-party code.)
- Social engineering, physical attacks, and denial-of-service testing
  against infrastructure the maintainer does not operate.
- Reports generated without a working proof of concept or manual
  verification.

## Supported versions

The signed release record is the supported baseline: release attestation
published at commit `e9e14ce8` over the `d60e82d` record (226 tests, fuzz
campaign of 2,639,356 executions, zero crashes). The public verification
record is at https://github.com/a95674127-beep/mack-verification — reports
against the signed release are always in scope; reports against newer,
unreleased work are welcome and labeled as such.

— Allen Mack, AI Infinity Force One (sole proprietor)
