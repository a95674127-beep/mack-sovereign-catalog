//! Criterion benchmarks for the tamper-evident audit ledger
//! (`ai_infinity_force_one_vault::AuditLog`).
//!
//! Measures the two operations a deployment performs constantly:
//! appending entries to the hash chain, and verifying a chain end to end.
//! Results are recorded in BENCHMARKS.md at the repository root.
//!
//! Run with: `cargo bench --bench audit_ledger`

use ai_infinity_force_one_vault::AuditLog;
use criterion::{black_box, criterion_group, criterion_main, BatchSize, Criterion};

/// Build a log holding `n` entries (setup work, outside the timed region).
fn built_log(n: usize) -> AuditLog {
    let mut log = AuditLog::new();
    for i in 0..n {
        log.append("bench_actor", &format!("bench_action_{i}"));
    }
    log
}

fn bench_append(c: &mut Criterion) {
    let mut group = c.benchmark_group("audit_append");
    for n in [1_000usize, 10_000usize] {
        group.bench_function(format!("append_{n}_entries"), |b| {
            b.iter_batched(
                AuditLog::new,
                |mut log| {
                    for i in 0..n {
                        log.append("bench_actor", &format!("bench_action_{i}"));
                    }
                    black_box(log.len());
                },
                BatchSize::SmallInput,
            );
        });
    }
    group.finish();
}

fn bench_verify(c: &mut Criterion) {
    let mut group = c.benchmark_group("audit_verify");
    for n in [1_000usize, 10_000usize] {
        let log = built_log(n);
        group.bench_function(format!("verify_{n}_entries"), |b| {
            b.iter(|| black_box(log.verify()));
        });
    }
    group.finish();
}

criterion_group!(benches, bench_append, bench_verify);
criterion_main!(benches);
