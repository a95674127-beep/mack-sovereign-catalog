# Deployment & Dashboard Setup

> Updated 2026-10-27 to match the current code. Earlier versions of this
> document described a printed dashboard token, a `0.0.0.0` bind, and a
> `VAULT_ADMIN_KEY` default — none of those exist in the current engine.

## Quick Start: Local Development

### 1. Start the Rust Engine

```bash
cargo run --bin server
```

Output:
```
[MACK-STACK] REST API Server listening on http://127.0.0.1:8080
[MACK-STACK] Dashboard Web Address: http://127.0.0.1:5173
[MACK-STACK] Admin token source: MACK_ENGINE_TOKEN env var (ephemeral random token if unset — no built-in default)
[MACK-STACK] Dashboard token source: VAULT_DASHBOARD_TOKEN env var (auto-generated if not set)
```

The engine binds **loopback only** (`127.0.0.1:8080`) and **never prints
any token**. Tokens are configured through the environment (below), not
copied out of server logs.

### 2. Configure the Dashboard

Set the dashboard token in the **engine's** environment before starting
it (or let it auto-generate one):

```bash
export VAULT_DASHBOARD_TOKEN="your-secure-dashboard-token"
```

The dashboard client holds its copy of the token **in page memory only**
(`frontend/src/api/tokenManager.ts`) and sends it as the
`X-Dashboard-Token` header. It is never stored in `localStorage` /
`sessionStorage`, and it must **never** be placed in a `VITE_*`
variable: Vite embeds those values in the public JavaScript bundle,
where anyone can read them.

The only dashboard environment variable is the engine's address, and it
is not a secret. Create `frontend/.env.local` only if the engine is not
at the default location:

```bash
VITE_API_BASE=http://127.0.0.1:8080
```

### 3. Build & Run Dashboard

```bash
cd frontend
npm install
npm run build
npm run preview
```

Visit: **http://127.0.0.1:4173**

---

## Routes Overview

All dashboard routes require authentication: either
`Authorization: Bearer <token>` or the legacy
`X-Dashboard-Token: <token>` header, compared in constant time.

| Route | Method | Purpose | Response |
|-------|--------|---------|----------|
| `/api/v1/health` | GET | Confirm engine connectivity | `HealthResponse` |
| `/api/v1/lanes` | GET | Snapshot of 12-lane status | `LanesResponse` |
| `/api/v1/lanes/{code}/reset` | POST | Reset lane from quarantine | `ResetResponse` |
| `/api/v1/ledger/verify` | POST | Verify hash-chain integrity | `VerificationResponse` |
| `/api/v1/events/tail` | GET | Fetch recent events | `EventTailResponse` |

---

## Environment Variables

### Engine (`src/bin/server.rs`, `src/api/mod.rs`)

- `MACK_ENGINE_TOKEN` — Admin token (lane reset and other privileged
  calls). **There is no built-in default.** If unset, the engine
  generates an ephemeral random token for that run and logs a
  `[SECURITY]` warning to stderr.
- `VAULT_DASHBOARD_TOKEN` — Dashboard auth token (auto-generated if
  not set).

No other credential variables are read. In particular, there is no
`VAULT_ADMIN_KEY`; older documents that mention one are stale.

### Dashboard (`frontend/`)

- `VITE_API_BASE` — Engine base URL (default: `http://127.0.0.1:8080`).
  Not a secret. There is deliberately **no** `VITE_DASHBOARD_TOKEN`:
  build-time variables are public once bundled.

---

## Dashboard Token Security

The dashboard token is a **32-byte cryptographically secure hex string**
held by the engine:

```rust
// Resolved in AppState::new()
let dashboard_token =
    std::env::var("VAULT_DASHBOARD_TOKEN").unwrap_or_else(|_| generate_secure_token());
```

**Best Practice:**
1. Set `VAULT_DASHBOARD_TOKEN` in the engine's environment (or let the
   engine generate one per run).
2. Enter the same value into the dashboard at runtime; the client keeps
   it in page memory only and clears it on reload.
3. The dashboard sends the token in the `X-Dashboard-Token` header (or
   as a Bearer token).
4. The engine validates with constant-time comparison
   (`subtle::ConstantTimeEq`) to prevent timing attacks.
5. Never commit a token to the repository, and never copy one into a
   frontend build variable or a log line.

---

## Production Deployment

### Engine

```bash
export MACK_ENGINE_TOKEN="your-secure-admin-token"
export VAULT_DASHBOARD_TOKEN="your-secure-dashboard-token"
cargo build --release
./target/release/server
```

Listens on `127.0.0.1:8080` (loopback only). For access from another
machine, put a reverse proxy with its own TLS and access control in
front of it — do not rebind the engine to a public interface directly.

### Dashboard (Standalone SPA)

```bash
cd frontend
npm run build
# dist/ contains standalone app ready for any static host
```

Deploy `frontend/dist` to:
- Vercel, Netlify, GitHub Pages
- S3 + CloudFront
- Any web server

Configure `VITE_API_BASE` at build time if needed. The dashboard token
is **not** part of the build; it is supplied at runtime as described
above.

---

## Status Indicators

### Demo Mode (Sample Data)
- ⚠️ Orange banner at top of dashboard
- No engine connected
- Sampling engine disabled

### Live Engine
- ✅ Green banner at top of dashboard
- Real-time lane status
- Event tail active
- Full ledger verification

---

## Troubleshooting

**"Missing or invalid dashboard token"**
- The token entered in the dashboard must match the engine's
  `VAULT_DASHBOARD_TOKEN` (or the value it generated this run)
- Check the `X-Dashboard-Token` / `Authorization: Bearer` header is
  being sent

**"Health check failed"**
- Engine not running? `cargo run --bin server`
- Wrong `VITE_API_BASE`? Check port 8080

**"CORS error"**
- Ensure dashboard origin is whitelisted in engine
- Edit `create_router()` `AllowOrigin::predicate`
