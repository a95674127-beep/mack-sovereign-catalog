# Cryptographic Provenance & Attribution Declaration

**Inventor / Sole Author:** Allen Mack (`a95674127@gmail.com`)  
**Docket Reference:** `MACK-STACK-01`  
**Repository:** `ai-infinity-force-one-vault`  
**Legal Notice:** Copyright (c) 2026 Allen Mack — All Rights Reserved. Patent status: no USPTO application number is on record (see `PATENT_STATUS.md`); no "patent pending" claim is made.

---

## 1. Technical Inventorship & Authorship Specification

This codebase implements the core algorithms for the **MACK Stack Containment and Vault Security Architecture**.
Every component, including:
- 12-lane sandbox containment boundary and process isolation
- Zero-trust default-deny capability policy engine
- Multi-detector threat inspection (entropy boundary analysis + SHA-256 blocklist)
- Proof-of-Value (PoV) independent work verification protocol
- Argon2id + ChaCha20-Poly1305 AEAD authenticated envelope encryption
- Zeroized secret key lifecycle and zero-downtime key rotation (`KeyRing`)
- SHA-256 hash-chained immutable audit ledger

is authored, designed, and owned by **Allen Mack**.

## 2. Human & AI Co-Development Attestation (35 U.S.C. § 101/102/103/112)

In accordance with USPTO Inventorship Guidance for AI-Assisted Inventions (89 FR 10043):
1. **Significant Human Contribution:** Allen Mack conceived the inventive concept, system architecture, threat model, state machine gates, and security requirements.
2. **AI Tool Role:** AI systems operated strictly as an assistive tool (compiler, implementer, syntax verifier, and test generator) under the direct instructions, prompts, and architectural direction of the human inventor.
3. **Sole Human Inventor:** Under United States patent law and international intellectual property conventions, Allen Mack is the sole named human inventor and proprietor.

## 3. Cryptographic Verification of Authorship

Authorship and chain of custody are mathematically enforced via the `ai_infinity_force_one_vault::provenance` module:
- **Algorithm:** Ed25519 digital signature scheme (RFC 8032)
- **Hash Chain:** Canonical serialization hashed with SHA-256, chained sequence-by-sequence to a fixed genesis anchor
- **Tamper Evidence:** Any modification to author identity, patent docket, timestamp, or artifact hash breaks the signature and chain verification
- **Zeroization:** Signing keys are held in memory-wiping `Zeroizing` containers to prevent extraction from memory dumps.
