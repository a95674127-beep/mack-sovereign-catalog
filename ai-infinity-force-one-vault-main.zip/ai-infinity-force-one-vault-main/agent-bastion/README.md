# Agent Bastion

**A containment-first runner for autonomous-agent workloads, built on the
MACK stack's Detection-Containment Pipeline.**

An autonomous agent's tool calls and payloads are only as safe as the box
they run in. Agent Bastion puts a mandatory gate in front of execution:
every payload is scanned and scored *first*, and the score — not the
caller — decides how, where, or whether it runs.

| Threat score | Route | What happens |
|---|---|---|
| 0 | Standard lane | Executes in-process on the target lane |
| 1–59 | Process-isolated lane | Executes in a separate OS process, Landlock-confined on Linux (no filesystem access) |
| 60+ | Sealed hold (MACK-12) | **Never executed.** Held for forensics; hash-anchored record when a sealed-event log is attached |

**Fail-closed by design:** if the process-isolated backend is unavailable,
a suspicious payload is *rejected* — never downgraded to standard
execution. (Covered by the pipeline's own test suite:
`quarantine_without_isolated_backend_is_rejected`.)

## Run it

```bash
cargo build --release
LANE_WORKER_PATH=$PWD/target/release/lane_worker ./target/release/server
# REST API on http://0.0.0.0:8080
```

## Submit work

```bash
curl -s -X POST http://127.0.0.1:8080/api/v1/ingest/submit \
  -H 'Content-Type: application/json' \
  -d '{"lane":"MACK-04","payload_hex":"68656c6c6f"}'
```

Response:

```json
{
  "decision": "execute_standard",
  "triage_outcome": "Clean",
  "threat_score": 0,
  "executed": true,
  "execution_ok": true,
  "sealed_event_id": null,
  "message": "..."
}
```

`decision` is one of `execute_standard` | `execute_isolated` |
`sealed_hold`. The payload is hex-encoded because JSON has no native
byte-string type. Target lanes are the 12 MACK lanes (`MACK-01` …
`MACK-12`).

## Benchmarks

Measured, not animated: see [BENCHMARKS.md](BENCHMARKS.md) for
submit→outcome latency and throughput per containment band, the
methodology, and the machine they were measured on. Reproduce them with:

```bash
LANE_WORKER_PATH=$PWD/target/release/lane_worker \
  cargo run --release --example bastion_bench
```

## What this is — and is not

Agent Bastion v0.1 is the MACK stack's existing, tested containment
pipeline presented as the runner it already is: the HTTP ingress above
has routed through `ContainmentPipeline` with API tests since the
pipeline landed. This package adds the product documentation and the
benchmark harness; it changes no pipeline behavior and weakens no
guarantee.

It is **not** a general-purpose VM or container sandbox for arbitrary
binaries, and it does not claim hypervisor-grade isolation. The
isolated band is OS-process isolation with Landlock confinement on
Linux; the standard band is in-process lane execution. Choose the band
your threat model needs — the score chooses for payloads, and 60+
never runs at all.

## Threat model, plainly

- Protects against: untrusted payloads executing without inspection;
  suspicious payloads touching the host filesystem (isolated band);
  silent downgrade when isolation is unavailable.
- Does not protect against: a compromised host or kernel; side-channel
  attacks between processes; malicious payloads that score 0 (detection
  is heuristic + signature based — YARA rules, entropy, indicator
  matching — not a proof of safety).

## License

Proprietary — © Allen Mack / AI Infinity Force One. All rights reserved.
