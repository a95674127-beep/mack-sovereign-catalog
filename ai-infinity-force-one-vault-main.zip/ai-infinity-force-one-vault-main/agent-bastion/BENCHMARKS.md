# Agent Bastion — Benchmarks

**Measured 2026-10-21.** Every number below comes from timing the real
`ContainmentPipeline::process` (detect → decide → contain → execute) in a
release build on the machine described. Nothing here is estimated,
projected, or simulated — rerun the harness and compare:
`LANE_WORKER_PATH=$PWD/target/release/lane_worker cargo run --release --example bastion_bench`
(source: `examples/bastion_bench.rs`).

## Environment

- Machine: AMD EPYC 9D25 host, **2 logical cores** visible (shared VM —
  treat absolute numbers as *this-machine* figures, not datasheet specs)
- Build: `cargo build --release`, rustc 1.99.1, local snapshot of
  `ai-infinity-force-one-vault` (GitHub main head `54a6c859`, 2026-10-17;
  the snapshot matches main in the sandbox/api modules; main's later
  commits are CI and ledger-demo housekeeping)
- Isolated containment: **available** during the run (Landlock process
  lanes live, `lane_worker` from the same build)

## Calibration — payloads chosen by the band they actually land in

| Candidate | Threat score | Decision |
|---|---|---|
| clean text (39 B, the pipeline test suite's benign payload) | 0 | ExecuteStandard |
| high-entropy blob, 512 B (test suite's quarantine construction) | 35 | ExecuteIsolated |
| C2 beacon string (46 B, test suite's known-bad pattern) | 60 | SealedHold |
| *(reference)* empty payload | 100 | SealedHold |

## Sequential latency — submit → outcome

| Class | Score | n | Mean | Median | p95 | Throughput |
|---|---|---|---|---|---|---|
| Clean → standard lane | 0 | 300 | 0.437 ms | 0.400 ms | 0.668 ms | 2,288 ops/s |
| Suspicious → isolated lane | 35 | 60 | 0.569 ms | 0.533 ms | 0.724 ms | 1,757 ops/s |
| Malicious → sealed hold | 60 | 300 | 0.399 ms | 0.398 ms | 0.435 ms | 2,504 ops/s |

## Concurrent throughput

4 threads × 150 clean submissions against **one shared pipeline**:
**2,798 ops/s aggregate** (600 ops in 0.21 s wall). Single-threaded
clean throughput is 2,288 ops/s, so concurrency adds modestly on a
2-core VM — reported as measured, not extrapolated.

## Reading these numbers honestly

- **What is timed:** the full gate — scan, triage scoring, routing, and
  the lane's execution of these small payloads (39–512 B). It is the
  cost of the *containment decision path*, the thing Agent Bastion adds
  in front of agent work. Large payloads and heavy workloads cost more;
  scan cost grows with payload size (max payload here: 1 MiB).
- **Isolation overhead:** the isolated band costs ≈ **+0.13 ms mean
  (+30%)** over the standard band for the 512 B class — the isolated
  engine keeps worker processes available rather than spawning per call.
- **Sealed is fastest** because sealed payloads are never executed:
  scan + decision only. That is the design working as intended.
- These are **latency figures for the gate**, not end-to-end agent task
  times, and not comparable to hypervisor or microVM cold-start numbers.

## Test suite (same snapshot, same day)

`cargo test --release`: **215 passed, 0 failed** across 18 test
targets — the pipeline's own containment tests included
(`quarantine_without_isolated_backend_is_rejected`,
`sealed_payload_never_executes`, `clean_payload_executes_in_standard_lane`).

## HTTP verification (same build, same day)

The packaged server (`target/release/server`, port 8080) was booted and
the three calibration payloads were submitted to
`POST /api/v1/ingest/submit`:

- clean → `200 {"decision":"execute_standard","threat_score":0,"executed":true,"execution_ok":true}`
- entropy → `200 {"decision":"execute_isolated","threat_score":35,"executed":true,"execution_ok":true}`
- C2 → `200 {"decision":"sealed_hold","threat_score":60,"executed":false}`
