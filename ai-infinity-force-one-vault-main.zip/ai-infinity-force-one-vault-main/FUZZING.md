# Infinity Force One - Cargo Fuzz Harness & Guide

This directory houses continuous differential and mutation fuzzing targets for the MACK Stack Zero-Trust Engine.

## Fuzz Targets

1. **`fuzz_pov_batch`**:
   - Fuzzes batch JSON ingestion and deserialization for Proof-of-Verification (PoV) DePIN feeds.
   - Target guarantees memory safety, crash resilience, and rejection of malformed or maliciously crafted payloads without panics.

2. **`fuzz_audit_chain`**:
   - Fuzzes SHA-256 chained audit ledger creation, hash integrity calculations, and tamper-detection invariants.
   - Asserts that untampered logs always verify and retroactive bit modifications or entry deletions fail chain verification.

3. **`fuzz_lane_transitions`**:
   - Fuzzes multi-lane containment dispatch across all 12 canonical MACK lanes (`L-01` through `L-12`).
   - Validates boundary limits, quarantine backoff triggers, and manual/automated quarantine releases.

---

## Prerequisites

Fuzzing uses LLVM's LibFuzzer via `cargo-fuzz` and requires the Rust nightly toolchain:

```bash
# Install Rust nightly
rustup toolchain install nightly

# Install cargo-fuzz
cargo install cargo-fuzz
```

---

## How to Run Fuzz Targets

### 1. Fuzzing PoV Batch Ingestion
```bash
cargo +nightly fuzz run fuzz_pov_batch
```

### 2. Fuzzing Audit Chain Integrity
```bash
cargo +nightly fuzz run fuzz_audit_chain
```

### 3. Fuzzing Lane State Transitions
```bash
cargo +nightly fuzz run fuzz_lane_transitions
```

### Options & Corpus Management
- **Set max run time**: `cargo +nightly fuzz run fuzz_pov_batch -- -max_total_time=600`
- **Parallel jobs**: `cargo +nightly fuzz run fuzz_audit_chain -- -jobs=4 -workers=4`
- **Artifacts**: Crashing inputs are automatically stored under `fuzz/artifacts/<target_name>/`.

---

## Standard CI Smoke Testing
For environments without nightly or libfuzzer, deterministic fuzz corpora and mutation smoke tests are integrated directly into standard test suites:

```bash
cargo test --test fuzz_smoke_tests
```
