# Patent Status — factual record

> This file records facts, not legal conclusions. For filing strategy and
> marking questions, consult a registered patent attorney.

## What the repository claims

- `OWNERSHIP_AND_PATENT_STAMP_2026-08-18.md` (dated 2026-08-18) marks the
  work "Patent Pending" and describes a USPTO provisional application as
  **"to be filed"** via Patent Center (SB/16). The inventor declaration in
  that file is unsigned.
- `PROVENANCE_AND_ATTRIBUTION.md` repeats the "Patent Pending" notice.

## What is verified

- **No USPTO application number is recorded anywhere in this repository.**
- No filing receipt, confirmation number, or application serial number has
  been committed as evidence of filing.
- The undersigned inventor declaration (signature line) remains blank.

## What this means

"Patent pending" is a legal marking that is only truthful **after** a patent
application has actually been filed with the USPTO. Marking a product
"patent pending" without a filed application can constitute false marking
under 35 U.S.C. § 292.

## Required actions for the owner

1. If a provisional or non-provisional application **has** been filed:
   record the application number, filing date, and confirmation number in
   this file, and keep the filing receipt with the repository's legal
   records.
2. If it has **not** yet been filed: avoid "Patent Pending" in any public
   material (including this repository, if public) until filing is complete,
   and complete the inventor declaration signature.
3. Do not rewrite git history after filing (see NOTICE).

## Log

| Date       | Event |
|------------|-------|
| 2026-08-18 | Intent to file declared in OWNERSHIP_AND_PATENT_STAMP_2026-08-18.md |
| 2026-10-08 | Status review: no application number on record; this file created to track it honestly |
| 2026-10-23 | Cleanup: "Patent Pending" removed from living documents (`MILESTONE_3.md`, `PROVENANCE_AND_ATTRIBUTION.md`); correction banner added to the 2026-08-18 stamp; status re-verified — still no application number on record |
