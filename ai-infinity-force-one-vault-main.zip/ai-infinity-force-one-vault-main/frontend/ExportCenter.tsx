 // src/components/ExportCenter.tsx
import { useState, useEffect } from 'react';

interface ExportItem {
  profile: string;
  filename: string;
  sha256: string;
  size: number;
}

export function ExportCenter() {
  const [exportsList, setExportsList] = useState<ExportItem[]>([]);
  const [selectedProfile, setSelectedProfile] = useState<string>('');
  const [status, setStatus] = useState<string>('Idle');
  const [verified, setVerified] = useState<boolean>(false);
  const [downloadBlob, setDownloadBlob] = useState<{ blob: Blob; filename: string; url: string } | null>(null);

  useEffect(() => {
    fetch('/exports/index.json')
      .then((res) => res.json())
      .then((data) => {
        setExportsList(data.exports || []);
        if (data.exports?.length > 0) setSelectedProfile(data.exports[0].profile);
      })
      .catch(() => setStatus('Failed to load export index.'));
  }, []);

  const bufferToHex = (buffer: ArrayBuffer): string => {
    return Array.from(new Uint8Array(buffer))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  };

  const handleVerifyAndDownload = async () => {
    const item = exportsList.find((e) => e.profile === selectedProfile);
    if (!item) return;

    setStatus('Downloading archive...');
    setVerified(false);
    
    // Revoke previous object URL to prevent memory leaks
    if (downloadBlob) {
      URL.revokeObjectURL(downloadBlob.url);
      setDownloadBlob(null);
    }

    try {
      const response = await fetch(`/exports/${item.filename}`);

      if (!response.ok) {
        setStatus(`Download Failed: server returned ${response.status} ${response.statusText}`);
        return;
      }

      const arrayBuffer = await response.arrayBuffer();

      setStatus('Verifying checksum...');
      const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
      const computedHash = bufferToHex(hashBuffer);

      if (computedHash !== item.sha256) {
        setStatus('Verification Failed: SHA-256 checksum mismatch.');
        return;
      }

      const blob = new Blob([arrayBuffer], { type: 'application/zip' });
      const url = URL.createObjectURL(blob);
      
      setDownloadBlob({ blob, filename: item.filename, url });
      setVerified(true);
      setStatus('Verification Successful! Ready for download.');
    } catch (err) {
      setStatus(`Error during download or verification: ${(err as Error).message}`);
    }
  };

  return (
    <div className="p-6 max-w-xl mx-auto bg-white rounded-xl shadow-md space-y-4">
      <h2 className="text-xl font-bold">Export Center</h2>
      
      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">Select Profile:</label>
        <select 
          value={selectedProfile} 
          onChange={(e) => setSelectedProfile(e.target.value)}
          className="w-full p-2 border rounded"
        >
          {exportsList.map((item) => (
            <option key={item.profile} value={item.profile}>
              {item.profile} ({Math.round(item.size / 1024)} KB)
            </option>
          ))}
        </select>
      </div>

      <button
        onClick={handleVerifyAndDownload}
        className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700"
      >
        Verify & Prepare Download
      </button>

      <div className="text-sm text-gray-600">
        <strong>Status:</strong> {status}
      </div>

      {verified && downloadBlob && (
        <a
          href={downloadBlob.url}
          download={downloadBlob.filename}
          className="block text-center bg-green-600 text-white p-2 rounded hover:bg-green-700"
        >
          Download Verified Archive ({downloadBlob.filename})
        </a>
      )}
    </div>
  );
}

