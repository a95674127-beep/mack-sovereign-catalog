# AI Infinity Force One Vault — Dashboard (Standalone SPA)

A React/TypeScript dashboard for real-time monitoring of the 12-lane containment sandbox, ledger verification, and operator reputation tracking.

## Features

- **12-Lane Containment Monitor** — Real-time lane status, quarantine levels, reset controls
- **Ledger Audit Verification** — Hash-chain integrity checking with genesis validation
- **Event Tail** — Live event stream from the Rust engine
- **Operator Reputation** — Track verification rates and operator trust scores
- **Export Center** — Archive and export verification records

## Setup

### Development

```bash
# Install dependencies
npm install

# Create .env.local with your engine token
cp .env.example .env.local
# Edit .env.local to add your dashboard token from engine startup

# Run dev server
npm run dev
```

Visit: http://localhost:5173

### Build (Standalone SPA)

```bash
npm run build
```

Output in `dist/` — ready for deployment to any static host.

### Preview Built App

```bash
npm run preview
```

Visit: http://127.0.0.1:4173

---

## Authentication

The dashboard communicates with the Rust engine via **secure token authentication**:

1. **Engine generates token** on startup:
   ```
   [MACK-STACK] Dashboard Token (save to .env): <token>
   ```

2. **Dashboard sends token** in every request:
   ```
   X-Dashboard-Token: <token>
   ```

3. **Engine validates** with constant-time comparison

**No token = 401 Unauthorized**

---

## Configuration

### Environment Variables

Create `frontend/.env.local`:

```bash
# Rust engine base URL (required)
VITE_API_BASE=http://127.0.0.1:8080

# Dashboard authentication token from engine (required)
VITE_DASHBOARD_TOKEN=your-secure-token-here
```

### API Base Fallback

If `VITE_API_BASE` is not set, defaults to `http://127.0.0.1:8080`

---

## API Routes (Engine → Dashboard)

All routes require `X-Dashboard-Token` header.

| Route | Method | Purpose |
|-------|--------|---------|
| `/api/v1/health` | GET | Engine health check |
| `/api/v1/lanes` | GET | Snapshot of lane status |
| `/api/v1/lanes/{code}/reset` | POST | Reset lane (requires admin token) |
| `/api/v1/ledger/verify` | POST | Verify hash-chain integrity |
| `/api/v1/events/tail` | GET | Fetch recent events |
| `/api/v1/pov/verify` | POST | Verify Proof-of-Verification tasks |

---

## Project Structure

```
frontend/
├── src/
│   ├── api/
│   │   ├── vaultApi.ts       — API client methods
│   │   └── tokenManager.ts   — Token storage & injection
│   ├── components/
│   │   ├── LaneStatusDashboard.tsx   — 12-lane monitor
│   │   ├── LedgerVerifier.tsx         — Ledger audit UI
│   │   └── ExportCenter.tsx           — Export/archive UI
│   ├── App.tsx              — Main layout & routing
│   └── main.tsx             — React root
├── index.html               — Entry point
├── package.json
├── tsconfig.json
├── vite.config.ts          — Build config
└── .env.example            — Config template
```

---

## Development

### Add New API Route

1. Add method to `src/api/vaultApi.ts`:
   ```typescript
   export async function fetchNewData(): Promise<NewResponse> {
     const res = await fetch(`${API_BASE}/api/v1/new-route`, {
       headers: DashboardTokenManager.injectToken(),
     });
     return res.json();
   }
   ```

2. Use in component:
   ```tsx
   import { fetchNewData } from '../api/vaultApi';
   
   useEffect(() => {
     fetchNewData().then(setData);
   }, []);
   ```

### Styling

Dashboard uses **inline CSS** for self-contained styling. All colors follow the dark theme:
- Background: `#0f172a`
- Surface: `#1e293b`
- Text: `#f8fafc`
- Accent: `#38bdf8`

---

## Deployment

### Vercel

```bash
vercel
# Auto-detects Vite build
```

Set environment variables in Vercel dashboard:
- `VITE_API_BASE`
- `VITE_DASHBOARD_TOKEN`

### GitHub Pages

```bash
npm run build
# Deploy dist/ to gh-pages branch
```

### AWS S3 + CloudFront

```bash
npm run build
aws s3 sync dist/ s3://your-bucket --delete
# Invalidate CloudFront cache
```

---

## Troubleshooting

**403 Unauthorized**
- Token mismatch between engine and dashboard
- Check `VITE_DASHBOARD_TOKEN` in .env.local

**CORS errors**
- Engine must allow dashboard origin
- Edit `create_router()` `AllowOrigin::predicate` in `src/api/mod.rs`

**No lanes loading**
- Engine not running? Start: `cargo run --bin server`
- Wrong API base? Check `VITE_API_BASE`

---

## Tech Stack

- **React 18** — UI framework
- **TypeScript** — Type safety
- **Vite 5** — Build tool
- **Lucide React** — Icons (optional)
- **Fetch API** — HTTP client

---

## License

See root repository LICENSE.
