import React, { useState, useEffect } from 'react';
import { fetchLanes, resetLane, LaneInfo } from '../api/vaultApi';

export function LaneStatusDashboard() {
  const [lanes, setLanes] = useState<LaneInfo[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [adminToken, setAdminToken] = useState('');
  // No default token: the admin token is a server-side secret and must
  // never be baked into the frontend bundle.
  const [resetMessage, setResetMessage] = useState<string | null>(null);

  const loadLanes = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchLanes();
      setLanes(data.lanes);
    } catch (err: any) {
      setError(err.message || 'Failed to load lanes');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLanes();
    const interval = setInterval(loadLanes, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleReset = async (code: string) => {
    setResetMessage(null);
    try {
      const res = await resetLane(code, adminToken);
      setResetMessage(`Reset ${res.lane}: ${res.status}`);
      loadLanes();
    } catch (err: any) {
      setResetMessage(`Reset failed: ${err.message}`);
    }
  };

  return (
    <div style={{ background: '#1e293b', padding: '1.5rem', borderRadius: '0.75rem', marginBottom: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
        <div>
          <h2 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 'bold' }}>12-Lane Containment Sandbox</h2>
          <p style={{ margin: '0.25rem 0 0 0', color: '#94a3b8', fontSize: '0.875rem' }}>
            Real-time process isolation and automated exponential quarantine backoff.
          </p>
        </div>
        <button
          onClick={loadLanes}
          disabled={loading}
          style={{ background: '#3b82f6', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '0.375rem', cursor: 'pointer' }}
        >
          {loading ? 'Refreshing...' : 'Refresh Status'}
        </button>
      </div>

      <div style={{ background: '#0f172a', padding: '0.75rem 1rem', borderRadius: '0.5rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
        <label style={{ fontSize: '0.875rem', color: '#cbd5e1' }}>Admin Authorization Key:</label>
        <input
          type="password"
          value={adminToken}
          onChange={(e) => setAdminToken(e.target.value)}
          placeholder="Bearer admin token"
          style={{ flex: 1, padding: '0.4rem 0.6rem', borderRadius: '0.25rem', border: '1px solid #475569', background: '#1e293b', color: 'white' }}
        />
      </div>

      {resetMessage && (
        <div style={{ padding: '0.5rem 1rem', borderRadius: '0.375rem', background: '#334155', color: '#38bdf8', marginBottom: '1rem', fontSize: '0.875rem' }}>
          {resetMessage}
        </div>
      )}

      {error && (
        <div style={{ padding: '0.75rem', background: '#7f1d1d', color: '#fecaca', borderRadius: '0.375rem', marginBottom: '1rem' }}>
          {error}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '1rem' }}>
        {lanes.map((lane) => {
          const isGreen = lane.status === 'Green';
          const isLockout = lane.status === 'TerminalLockout';
          const badgeBg = isGreen ? '#166534' : isLockout ? '#991b1b' : '#854d0e';
          const badgeColor = isGreen ? '#bbf7d0' : isLockout ? '#fecaca' : '#fef08a';

          return (
            <div key={lane.code} style={{ background: '#0f172a', border: '1px solid #334155', borderRadius: '0.5rem', padding: '1rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
                <span style={{ fontWeight: 'bold', fontSize: '0.95rem' }}>{lane.code}</span>
                <span style={{ fontSize: '0.75rem', padding: '0.2rem 0.5rem', borderRadius: '9999px', background: badgeBg, color: badgeColor, fontWeight: '600' }}>
                  {lane.status}
                </span>
              </div>
              <div style={{ fontSize: '0.85rem', color: '#94a3b8', marginBottom: '0.5rem' }}>{lane.label}</div>
              <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.75rem' }}>
                Backoff Level: {lane.backoff_level} {lane.remaining_ms > 0 && `(${lane.remaining_ms}ms rem)`}
              </div>
              <button
                onClick={() => handleReset(lane.code)}
                style={{ width: '100%', background: '#475569', color: 'white', border: 'none', padding: '0.4rem', borderRadius: '0.25rem', fontSize: '0.8rem', cursor: 'pointer' }}
              >
                Clear Quarantine
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
