import React, { useState } from 'react';
import { verifyLedger, VerificationResponse } from '../api/vaultApi';

export function LedgerVerifier() {
  const [report, setReport] = useState<VerificationResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleVerify = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await verifyLedger();
      setReport(res);
    } catch (err: any) {
      setError(err.message || 'Ledger verification call failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ background: '#1e293b', padding: '1.5rem', borderRadius: '0.75rem', marginBottom: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
        <div>
          <h2 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 'bold' }}>Audit Ledger Genesis & Segment Verification</h2>
          <p style={{ margin: '0.25rem 0 0 0', color: '#94a3b8', fontSize: '0.875rem' }}>
            Milestone 2 Merkle-hash chained tamper-evident audit verification.
          </p>
        </div>
        <button
          onClick={handleVerify}
          disabled={loading}
          style={{ background: '#10b981', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '0.375rem', cursor: 'pointer' }}
        >
          {loading ? 'Verifying...' : 'Run Cryptographic Audit'}
        </button>
      </div>

      {error && (
        <div style={{ padding: '0.75rem', background: '#7f1d1d', color: '#fecaca', borderRadius: '0.375rem', marginBottom: '1rem' }}>
          {error}
        </div>
      )}

      {report && (
        <div style={{ background: '#0f172a', border: `1px solid ${report.valid ? '#166534' : '#991b1b'}`, borderRadius: '0.5rem', padding: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.75rem' }}>
            <span style={{
              display: 'inline-block',
              width: '10px',
              height: '10px',
              borderRadius: '50%',
              background: report.valid ? '#22c55e' : '#ef4444'
            }} />
            <strong style={{ color: report.valid ? '#4ade80' : '#f87171' }}>
              {report.valid ? 'INTEGRITY VERIFIED: All Segments Valid' : 'TAMPER DETECTED: Segment Violation'}
            </strong>
          </div>
          <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.875rem', color: '#cbd5e1' }}>{report.message}</p>
          <div style={{ fontSize: '0.8rem', color: '#94a3b8', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.5rem' }}>
            <div>Entries Checked: <span style={{ color: 'white' }}>{report.entries_checked}</span></div>
            <div>Broken Segments: <span style={{ color: report.broken_segments.length ? '#f87171' : 'white' }}>{report.broken_segments.length}</span></div>
            <div style={{ gridColumn: '1 / -1' }}>Genesis Hash: <code style={{ color: '#38bdf8' }}>{report.genesis_hash}</code></div>
            {report.last_hash && (
              <div style={{ gridColumn: '1 / -1' }}>Tip Hash: <code style={{ color: '#a78bfa' }}>{report.last_hash}</code></div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
