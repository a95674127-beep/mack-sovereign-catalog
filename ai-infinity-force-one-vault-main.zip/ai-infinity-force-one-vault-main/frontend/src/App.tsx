import React, { useState, useEffect } from 'react';
import { LaneStatusDashboard } from './components/LaneStatusDashboard';
import { LedgerVerifier } from './components/LedgerVerifier';
import { ExportCenter } from './components/ExportCenter';
import { fetchHealth } from './api/vaultApi';

export default function App() {
  const [activeTab, setActiveTab] = useState<'lanes' | 'ledger' | 'exports'>('lanes');
  const [engineStatus, setEngineStatus] = useState<'sample' | 'live'>('sample');

  useEffect(() => {
    const checkEngine = async () => {
      try {
        const health = await fetchHealth();
        if (health.status === 'operational' && health.engine.includes('MACK-Stack')) {
          setEngineStatus('live');
        }
      } catch {
        setEngineStatus('sample');
      }
    };
    checkEngine();
  }, []);

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem 1rem' }}>
      {engineStatus === 'sample' && (
        <div
          style={{
            background: '#ea580c',
            border: '2px solid #dc2626',
            borderRadius: '0.5rem',
            padding: '1rem 1.25rem',
            marginBottom: '1.5rem',
            display: 'flex',
            alignItems: 'center',
            gap: '1rem',
            fontWeight: '600',
            color: '#fff',
          }}
        >
          <span style={{ fontSize: '1.25rem' }}>⚠️</span>
          <span>
            Front-end demo running on sample data. The real engine is the Rust code in the vault repo.
          </span>
        </div>
      )}

      {engineStatus === 'live' && (
        <div
          style={{
            background: '#10b981',
            border: '2px solid #059669',
            borderRadius: '0.5rem',
            padding: '1rem 1.25rem',
            marginBottom: '1.5rem',
            display: 'flex',
            alignItems: 'center',
            gap: '1rem',
            fontWeight: '600',
            color: '#fff',
          }}
        >
          <span style={{ fontSize: '1.25rem' }}>✅</span>
          <span>LIVE ENGINE CONNECTED — All systems operational.</span>
        </div>
      )}

      <header style={{ marginBottom: '2rem', borderBottom: '1px solid #334155', paddingBottom: '1rem' }}>
        <h1 style={{ fontSize: '1.75rem', fontWeight: 'bold', margin: '0 0 0.5rem 0', color: '#38bdf8' }}>
          AI Infinity Force One Vault
        </h1>
        <p style={{ margin: 0, color: '#94a3b8' }}>
          Mission-Critical Defense Architecture &bull; 12-Lane Containment &bull; Merkle Audit Ledger
        </p>

        <nav style={{ display: 'flex', gap: '0.5rem', marginTop: '1.25rem' }}>
          <button
            onClick={() => setActiveTab('lanes')}
            style={{
              padding: '0.5rem 1rem',
              borderRadius: '0.375rem',
              border: 'none',
              cursor: 'pointer',
              fontWeight: '500',
              background: activeTab === 'lanes' ? '#38bdf8' : '#1e293b',
              color: activeTab === 'lanes' ? '#0f172a' : '#cbd5e1',
            }}
          >
            12-Lane Containment
          </button>
          <button
            onClick={() => setActiveTab('ledger')}
            style={{
              padding: '0.5rem 1rem',
              borderRadius: '0.375rem',
              border: 'none',
              cursor: 'pointer',
              fontWeight: '500',
              background: activeTab === 'ledger' ? '#38bdf8' : '#1e293b',
              color: activeTab === 'ledger' ? '#0f172a' : '#cbd5e1',
            }}
          >
            Ledger Audit Verification
          </button>
          <button
            onClick={() => setActiveTab('exports')}
            style={{
              padding: '0.5rem 1rem',
              borderRadius: '0.375rem',
              border: 'none',
              cursor: 'pointer',
              fontWeight: '500',
              background: activeTab === 'exports' ? '#38bdf8' : '#1e293b',
              color: activeTab === 'exports' ? '#0f172a' : '#cbd5e1',
            }}
          >
            Archive Verification & Export Center
          </button>
        </nav>
      </header>

      <main>
        {activeTab === 'lanes' && <LaneStatusDashboard />}
        {activeTab === 'ledger' && <LedgerVerifier />}
        {activeTab === 'exports' && (
          <div style={{ color: '#0f172a' }}>
            <ExportCenter />
          </div>
        )}
      </main>
    </div>
  );
}
