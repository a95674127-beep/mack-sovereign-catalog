import { DashboardTokenManager } from './tokenManager';

export interface HealthResponse {
  status: string;
  engine: string;
  version: string;
}

export interface LaneInfo {
  code: string;
  label: string;
  status: 'Green' | 'Quarantined' | 'TerminalLockout' | string;
  backoff_level: number;
  remaining_ms: number;
}

export interface LanesResponse {
  total: number;
  lanes: LaneInfo[];
}

export interface ResetResponse {
  lane: string;
  status: string;
}

export interface VerificationResponse {
  valid: boolean;
  entries_checked: number;
  genesis_hash: string;
  last_hash: string | null;
  broken_segments: number[];
  message: string;
}

export interface EventTailResponse {
  events: Array<{
    timestamp: string;
    lane: string;
    event_type: string;
    message: string;
    severity: 'info' | 'warning' | 'error';
  }>;
}

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8080';

/**
 * Fetch health status — confirms engine connectivity
 */
export async function fetchHealth(): Promise<HealthResponse> {
  const res = await fetch(`${API_BASE}/api/v1/health`, {
    headers: DashboardTokenManager.injectToken(),
  });
  if (!res.ok) throw new Error(`Health check failed: ${res.statusText}`);
  return res.json();
}

/**
 * Fetch current lane status snapshot
 */
export async function fetchLanes(): Promise<LanesResponse> {
  const res = await fetch(`${API_BASE}/api/v1/lanes`, {
    headers: DashboardTokenManager.injectToken(),
  });
  if (!res.ok) throw new Error(`Fetch lanes failed: ${res.statusText}`);
  return res.json();
}

/**
 * Reset a lane from quarantine or lockout
 */
export async function resetLane(laneCode: string, adminToken: string): Promise<ResetResponse> {
  const res = await fetch(`${API_BASE}/api/v1/lanes/${laneCode}/reset`, {
    method: 'POST',
    headers: DashboardTokenManager.injectToken({
      'Authorization': `Bearer ${adminToken}`,
      'Content-Type': 'application/json',
    }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: res.statusText }));
    throw new Error(err.message || `Lane reset failed (${res.status})`);
  }
  return res.json();
}

/**
 * Verify the ledger's hash-chain integrity
 */
export async function verifyLedger(): Promise<VerificationResponse> {
  const res = await fetch(`${API_BASE}/api/v1/ledger/verify`, {
    method: 'POST',
    headers: DashboardTokenManager.injectToken(),
  });
  if (!res.ok) throw new Error(`Ledger verification failed: ${res.statusText}`);
  return res.json();
}

/**
 * Tail recent events from the engine (real-time or SSE)
 */
export async function fetchEventTail(): Promise<EventTailResponse> {
  const res = await fetch(`${API_BASE}/api/v1/events/tail`, {
    headers: DashboardTokenManager.injectToken(),
  });
  if (!res.ok) throw new Error(`Event tail fetch failed: ${res.statusText}`);
  return res.json();
}
