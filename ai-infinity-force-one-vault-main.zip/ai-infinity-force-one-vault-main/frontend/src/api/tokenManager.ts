/**
 * Holds the dashboard token in page memory only.
 *
 * Never place privileged credentials in VITE_* variables: Vite embeds those
 * values in the public JavaScript bundle. This client-side token is still
 * accessible to same-origin JavaScript, so production deployments should use
 * a server-side session/BFF with short-lived, scoped credentials.
 */
export class DashboardTokenManager {
  private static token: string | null = null;
  private static readonly TOKEN_HEADER = 'X-Dashboard-Token';

  static getToken(): string {
    return this.token ?? '';
  }

  static injectToken(headers: HeadersInit = {}): Headers {
    const result = new Headers(headers);
    const token = this.getToken();
    if (token) result.set(this.TOKEN_HEADER, token);
    else result.delete(this.TOKEN_HEADER);
    return result;
  }

  /** Clears the in-memory credential (also cleared automatically on reload). */
  static clearToken(): void {
    this.token = null;
  }

  /** Keep credentials in memory only; do not persist to localStorage/sessionStorage. */
  static setToken(token: string): void {
    this.token = token.trim() || null;
  }
}
