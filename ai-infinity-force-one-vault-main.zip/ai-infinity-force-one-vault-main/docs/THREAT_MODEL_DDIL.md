# Threat Model: Tactical Edge & D-DIL Operational Profile

## Threat Environment
- **Operational Theatre**: Tactical Field Operations, Forward Operating Bases (FOB), Radar and C2 Nodes.
- **Connectivity**: Denied, Degraded, Intermittent, Low-bandwidth (D-DIL) — no internet or cloud access.
- **Adversary Vectors**:
  - Malicious maintenance laptops and poisoned USB/firmware media.
  - Tactical spear-phishing targeting military credentials (CAC PIN, SIPR/NIPR).
  - Weaponized documents (VBA macros, PDF exploits) delivered via tactical networks.
  - C2 callbacks attempting beaconing or reverse shell exfiltration.

## Mitigation Architecture
- Offline deterministic scoring without cloud telemetries or third-party phone-home dependencies.
- Zero-knowledge encryption ensuring data at rest remains unreadable even if physical hardware is captured.
- 12 independent containment lanes preventing cross-contamination across operational systems.
