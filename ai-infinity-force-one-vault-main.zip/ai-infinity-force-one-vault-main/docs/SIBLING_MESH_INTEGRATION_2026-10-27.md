# Sibling Mesh Integration Record — 2026-10-27

This record documents the integration of the sibling-mesh ownership
model into the live repository. It supersedes the pre-integration status
described in `docs/SIBLING_MESH_DESIGN.md` and
`docs/LOCAL_VERIFICATION_SIBLING_MESH.md` (which described the standalone
package before it was wired in).

## What was integrated

- **`src/sandbox/sibling.rs`** — added unchanged from the verified
  package (in-process sibling-ring ownership: bounded leases, monotonic
  fencing tokens, idempotent lease requests, health gating, fail-closed
  commit authorization). Registered in `src/sandbox/mod.rs` and
  re-exported from the crate root.
- **Leased-execution gate in the lane engine**
  (`src/sandbox/lanes.rs`): `LaneContainmentEngine` can now carry a
  `SiblingOwnership` registry.
  - Default constructors (`new`, `new_isolated`) leave ownership
    **disabled** — existing behavior is unchanged.
  - `new_with_ownership` enables it. `execute_lane_leased` takes a
    `LeaseRequest` (ring, task, idempotency key, logical time, TTL),
    acquires a one-lane lease, executes the lane, and re-validates the
    fencing token via `authorize_commit` before releasing the result; a
    lease taken over by a sibling mid-execution makes the stale
    holder's commit fail closed.
  - `set_ring_health` / `ring_health` / `lease_for` expose ring health
    control and inspection.
  - New public types: `LeaseRequest`, `LeasedExecutionError` (re-exported
    from the crate root alongside the sibling types).

## Fixes landed in the same change

- **`src/bin/server.rs`** no longer prints the dashboard token at
  startup. Tokens come from the server environment
  (`VAULT_DASHBOARD_TOKEN`, `MACK_ENGINE_TOKEN`) and are entered into
  clients at runtime.
- **`frontend/src/api/tokenManager.ts`** replaced: the previous version
  read the dashboard token from `localStorage` and from a
  `VITE_DASHBOARD_TOKEN` build-time variable (which Vite embeds in the
  public bundle). The current version holds the token in page memory
  only — never persisted, never a build-time credential.
  `frontend/src/api/vaultApi.ts` was already identical; the frontend
  builds cleanly (`npm run build`: type-check + bundle pass).
- **`DEPLOYMENT.md`** rewritten to match the code: loopback bind,
  environment-based tokens, no `VAULT_ADMIN_KEY` (never read by the
  engine), no built-in default admin token.
- **`Cargo.lock` / `Cargo.toml`**: `ctutils` 0.4.3 → 0.4.6, clearing
  RUSTSEC-2026-0385 (the same advisory previously fixed in VaultLane
  v0.4.2). The `yara-x` pin moved `=1.21.0` → `=1.22.1`; every other
  flagged crate in the audit below arrived transitively through
  yara-x, and the bump moved `wasmtime` 45.0.3 → 48.0.7,
  `zip` 8.6.0 → 9.1.2, and `crypto-bigint` 0.5.5 → 0.7.10.

## Verification (2026-10-27, local)

- `cargo fmt --check` — clean.
- `cargo clippy --locked --all-targets -- -D warnings` — clean.
- `cargo test --locked` — **226 passed, 0 failed** (library: 138,
  including 6 sibling-model tests and 5 leased-execution engine tests;
  the remaining 88 are the pre-existing integration suites).
- `cargo audit` (cargo-audit 0.22.2) — before this change: 13
  vulnerabilities and 2 warnings, all arriving transitively through
  `yara-x` 1.21.0. After the fixes above: **1 vulnerability** —
  RUSTSEC-2023-0071 (Marvin Attack timing sidechannel) in the `rsa`
  crate, for which RustSec lists **no fixed upgrade available**; it
  remains transitive via `yara-x` and is tracked, not hidden. The 2
  warnings are informational: `bincode` unmaintained
  (RUSTSEC-2025-0141, transitive via yara-x) and a `tokio` `AsyncFd`
  soundness warning (RUSTSEC-2026-0386).

## What this is still not

The sibling mesh remains an **in-process model**: no network transport,
no persistence, no distributed failover. The remaining implementation
gates in `docs/SIBLING_MESH_DESIGN.md` (durable checkpoints, certificate
lifecycle, mTLS transport, quotas/logging, chaos testing) are unchanged
and still open.
