# NIST SP 800-53 Rev. 5 & DoD STIG Control Alignment

| NIST SP 800-53 Control | STIG Reference | Vault Architectural Implementation |
|---|---|---|
| **AC-3: Access Enforcement** | SRG-OS-000080 | Default-deny RBAC / ABAC policy engine (`src/vault/policy.rs`). |
| **SC-13: Cryptographic Protection** | SRG-OS-000033 | Argon2id key derivation + XChaCha20-Poly1305 / AES-256-GCM AEAD encryption. |
| **SC-28: Protection at Rest** | SRG-OS-000185 | Zero-knowledge sealed storage envelopes (`src/vault/crypto.rs`). |
| **AU-9: Protection of Audit Info** | SRG-OS-000057 | Hash-chained tamper-evident ledger (`src/vault/audit.rs`, `src/vault/forensics.rs`). |
| **SI-3: Malicious Code Protection** | SRG-OS-000480 | Offline Shannon entropy analysis, C2 callback detection, and weaponized doc scanner. |
| **SI-4: System Monitoring** | SRG-OS-000004 | 12-lane concurrent containment engine with automated quarantine backoff. |
