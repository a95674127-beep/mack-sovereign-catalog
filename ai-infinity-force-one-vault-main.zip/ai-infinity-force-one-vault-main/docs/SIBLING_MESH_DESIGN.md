# MACK Stack — Double-Ring Sibling Mesh Design

**Status: design contract; not implemented or production verified.** This document deliberately separates a future 12+12 topology from the currently implemented single-ring lane engine. Adding a `.proto` contract does not create a running gRPC service.

## Recommended rollout

1. **Model and test ownership rules in-process first.** Introduce ring identity (`alpha` / `beta`), a monotonically increasing process epoch, per-task idempotency keys, explicit lane states, and lease/fencing-token ownership. A worker must reject work carrying a stale fencing token.
2. **Make task recovery explicit.** Only retry tasks declared idempotent or carrying a durable checkpoint. Never promise exactly-once execution from transport retries alone. For financial side effects, use an idempotency key enforced by the downstream system and reconcile uncertain outcomes before retrying.
3. **Add bounded control-plane messages.** Validate ring IDs against a fixed allow-list; cap message sizes and requested lanes; validate timestamps/deadlines; rate-limit requests; reject unknown epochs, repeated sequence numbers, expired leases, and duplicate request IDs with inconsistent payloads.
4. **Add Tonic transport after dependency review.** Use `tonic`/`prost` with a committed lockfile and reproducible build. Prefer a Unix-domain socket with strict filesystem permissions on supported Unix hosts. If TCP loopback is used, configure TLS with client certificates and validate peer identity. Loopback alone is not authentication.
5. **Keep control and workload data separate.** Start by moving scheduling metadata only. Avoid shipping arbitrary serialized execution memory or raw financial payloads. Use validated, versioned checkpoints with integrity digests and explicit size limits.
6. **Add audit linkage.** Each ring signs or otherwise authenticates its audit-head statement. Compare sequence and hash heads; do not treat two independent hash chains as consensus or as proof that either ring is honest.
7. **Chaos-test before claiming failover.** Exercise process kill, timeout, stale messages, replay, clock skew, disk full, corrupted checkpoint, duplicate task submission, and partition/split-brain cases.

## Safety invariants

- At most one ring owns a task at a time, enforced by a monotonically increasing fencing token checked at the resource that commits side effects.
- Loss of heartbeat means **suspected failure**, not proof of failure. Do not promote a standby without a valid lease/ownership decision; on partition, fail closed for conflicting writes.
- Capacity grants are bounded leases, not bearer credentials. They specify expiry, allowed task classes, lane count, and request ID.
- No unconditional grant, fixed lane ID, demo session token, or trust decision based solely on a different `ring_id`.
- No private keys or tokens in logs, source, frontend build variables, or checked-in PEM files.
- Zeroization is best-effort hygiene for owned buffers, not a guarantee that all copies, allocator remnants, swap, crash dumps, or kernel buffers are erased.
- Two rings on one host improve process/lane resilience, not host-level availability. Host failure requires a separate host/domain and external coordination.

## Heartbeat policy (initial proposal; tune with measurements)

- Heartbeat interval: 250 ms is a candidate, not a guarantee.
- Mark peer `SUSPECT` after 3 missed heartbeats; do not immediately fail over.
- Enter `PARTITIONED` when transport is unavailable; block conflicting state-changing work until lease/fencing checks establish ownership.
- Use a bounded exponential reconnect delay with jitter (for example 100 ms to 2 s) and a circuit breaker. Reset backoff only after several authenticated, monotonic heartbeats.
- Reject replayed sequence numbers and stale process epochs; use monotonic local timers for timeout measurement and wall clock only for cross-process deadlines with skew tolerance.

## Protobuf contract

`proto/mack/sibling/v1/sibling_mesh.proto` is a schema draft. It intentionally has no field for a raw session bearer token and does not claim that a boolean `verified` field is sufficient. Signature verification must use canonical serialization and pinned/rotated peer identities, or rely on properly configured mTLS identity plus application-level authorization. Implement one model explicitly; do not mix informal assumptions.

## Implementation gates

- [x] Write unit-tested ring/lane state machine and lease/fencing rules. — Done 2026-10-27: `src/sandbox/sibling.rs` plus the opt-in leased-execution gate in the lane engine, covered by 11 new tests in the full-suite run recorded in `docs/SIBLING_MESH_INTEGRATION_2026-10-27.md`.
- [ ] Define durable checkpoint format and recovery semantics.
- [ ] Review key/certificate lifecycle and rotation; do not invent an X.509 CA from Ed25519/X25519 keypairs without a real certificate issuance/validation implementation.
- [ ] Add Tonic/prost dependencies and update `Cargo.lock` using Cargo.
- [ ] Configure client and server mTLS and test wrong CA, wrong identity, expired certificate, replay, and unauthorized method cases.
- [ ] Add payload limits, deadlines, request quotas, and structured redacted logs.
- [ ] Run unit/integration/chaos tests and document measured recovery time.
- [ ] Keep production availability claims out of marketing until demonstrated under stated failure assumptions.

## Current truth

This repository currently has a 12-lane containment subsystem. The second 12-lane sibling ring, gRPC service, ephemeral PKI, cryptographic bus, lane borrowing, and automated failover described here are **planned**, not verified features. The in-process ownership model and its leased-execution gate are implemented and tested in this tree (see `docs/SIBLING_MESH_INTEGRATION_2026-10-27.md`); everything distributed remains planned, and production availability claims stay out of marketing until demonstrated under stated failure assumptions.

## In-process reference model (added in this package)

`src/sandbox/sibling.rs` provides a dependency-free deterministic ownership model with bounded lane requests, bounded lease TTLs, idempotent repeated requests, conflict rejection for live ownership, monotonically increasing fencing tokens, health gating, and a commit-authorization check. Six unit tests specify these invariants. It is not a distributed consensus or persistence layer: a process restart resets in-memory ownership, so do not use this model alone to authorize production side effects.

**Integration update (2026-10-27):** the model is registered in the crate (`sandbox::sibling`, re-exported at the crate root) and wired into `LaneContainmentEngine` as an opt-in leased-execution gate: `new_with_ownership` enables it, `execute_lane_leased` requires a live one-lane lease before a lane runs and re-validates the fencing token before releasing the result, and `validate_commit` exposes the same fail-closed check at a commit boundary. Engines built with the existing constructors are unchanged. The gate is in-process only — the transport, persistence, and failover work in the gates below is still open. Verification for this integration is recorded in `docs/SIBLING_MESH_INTEGRATION_2026-10-27.md`.
