#!/usr/bin/env python3
# FILE: scripts/generate_m3_assets.py
# PASTE THIS WHOLE FILE - IT'S THE ONLY FILE YOU NEED

import argparse, colorsys, json
from pathlib import Path
from typing import Dict, Tuple

OUTPUT_DIR = Path("./m3_output")
SEED_COLOR = "#6750A4"

def hex_to_rgb(h: str) -> Tuple[int, int, int]:
    h = h.lstrip("#")
    if len(h) == 3: h = "".join(c*2 for c in h)
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)

def rgb_to_hex(r,g,b): return f"#{r:02X}{g:02X}{b:02X}"

def tone_from_base(base_hex, tone):
    r,g,b = hex_to_rgb(base_hex)
    h,l,s = colorsys.rgb_to_hls(r/255, g/255, b/255)
    new_l = l * (tone/40.0) if tone <= 40 else l + (1-l)*((tone-40)/60.0)
    nr,ng,nb = colorsys.hls_to_rgb(h, max(0,min(1,new_l)), s)
    return rgb_to_hex(int(nr*255), int(ng*255), int(nb*255))

def generate_tonal_palette(base_hex):
    tones = [0,4,6,10,12,17,20,22,24,30,40,50,60,70,80,87,90,92,94,95,96,98,99,100]
    return {t: tone_from_base(base_hex, t) for t in tones}

def hue_shift(c, d):
    r,g,b = hex_to_rgb(c)
    h,l,s = colorsys.rgb_to_hls(r/255, g/255, b/255)
    h = (h + d/360.0) % 1.0
    nr,ng,nb = colorsys.hls_to_rgb(h,l,s)
    return rgb_to_hex(int(nr*255), int(ng*255), int(nb*255))

def desaturate(c, a):
    r,g,b = hex_to_rgb(c)
    h,l,s = colorsys.rgb_to_hls(r/255, g/255, b/255)
    nr,ng,nb = colorsys.hls_to_rgb(h,l, max(0,s*(1-a)))
    return rgb_to_hex(int(nr*255), int(ng*255), int(nb*255))

class M3AssetGenerator:
    def __init__(self, seed_color, output_dir):
        self.seed_color = seed_color
        self.output_dir = output_dir

    def run(self):
        self.output_dir.mkdir(parents=True, exist_ok=True)
        seed = self.seed_color
        palettes = {
            "primary": generate_tonal_palette(seed),
            "secondary": generate_tonal_palette(desaturate(hue_shift(seed, 15), 0.35)),
            "tertiary": generate_tonal_palette(desaturate(hue_shift(seed, 70), 0.25)),
            "neutral": generate_tonal_palette(desaturate(seed, 0.92)),
            "neutralVariant": generate_tonal_palette(desaturate(hue_shift(seed, 8), 0.75)),
            "error": generate_tonal_palette("#BA1A1A"),
        }
        def light(p): return {
            "primary": p["primary"][40], "onPrimary": p["primary"][100], "primaryContainer": p["primary"][90], "onPrimaryContainer": p["primary"][10],
            "secondary": p["secondary"][40], "onSecondary": p["secondary"][100], "secondaryContainer": p["secondary"][90], "onSecondaryContainer": p["secondary"][10],
            "tertiary": p["tertiary"][40], "onTertiary": p["tertiary"][100], "tertiaryContainer": p["tertiary"][90], "onTertiaryContainer": p["tertiary"][10],
            "error": p["error"][40], "onError": p["error"][100], "errorContainer": p["error"][90], "onErrorContainer": p["error"][10],
            "background": p["neutral"][99], "onBackground": p["neutral"][10], "surface": p["neutral"][99], "onSurface": p["neutral"][10],
            "surfaceVariant": p["neutralVariant"][90], "onSurfaceVariant": p["neutralVariant"][30], "outline": p["neutralVariant"][50], "outlineVariant": p["neutralVariant"][80],
            "scrim": "#000000", "shadow": "#000000", "inverseSurface": p["neutral"][20], "inverseOnSurface": p["neutral"][95], "inversePrimary": p["primary"][80],
            "surfaceDim": p["neutral"][87], "surfaceBright": p["neutral"][98], "surfaceContainerLowest": p["neutral"][100], "surfaceContainerLow": p["neutral"][96],
            "surfaceContainer": p["neutral"][94], "surfaceContainerHigh": p["neutral"][92], "surfaceContainerHighest": p["neutral"][90],
        }
        def dark(p): return {
            "primary": p["primary"][80], "onPrimary": p["primary"][20], "primaryContainer": p["primary"][30], "onPrimaryContainer": p["primary"][90],
            "secondary": p["secondary"][80], "onSecondary": p["secondary"][20], "secondaryContainer": p["secondary"][30], "onSecondaryContainer": p["secondary"][90],
            "tertiary": p["tertiary"][80], "onTertiary": p["tertiary"][20], "tertiaryContainer": p["tertiary"][30], "onTertiaryContainer": p["tertiary"][90],
            "error": p["error"][80], "onError": p["error"][20], "errorContainer": p["error"][30], "onErrorContainer": p["error"][90],
            "background": p["neutral"][10], "onBackground": p["neutral"][90], "surface": p["neutral"][10], "onSurface": p["neutral"][90],
            "surfaceVariant": p["neutralVariant"][30], "onSurfaceVariant": p["neutralVariant"][80], "outline": p["neutralVariant"][60], "outlineVariant": p["neutralVariant"][30],
            "scrim": "#000000", "shadow": "#000000", "inverseSurface": p["neutral"][90], "inverseOnSurface": p["neutral"][20], "inversePrimary": p["primary"][40],
            "surfaceDim": p["neutral"][6], "surfaceBright": p["neutral"][24], "surfaceContainerLowest": p["neutral"][4], "surfaceContainerLow": p["neutral"][10],
            "surfaceContainer": p["neutral"][12], "surfaceContainerHigh": p["neutral"][17], "surfaceContainerHighest": p["neutral"][22],
        }
        tokens = {
            "source_color": seed,
            "schemes": {"light": light(palettes), "dark": dark(palettes)},
            "palettes": palettes,
            "shape": {"extraSmall": "4dp", "small": "8dp", "medium": "12dp", "large": "16dp", "extraLarge": "28dp", "full": "9999dp"},
        }
        (self.output_dir / "m3_tokens.json").write_text(json.dumps(tokens, indent=2))
        css = [":root {"]
        for k,v in tokens["schemes"]["light"].items(): css.append(f" --md-sys-color-{k}: {v};")
        css += ["}", "@media (prefers-color-scheme: dark) { :root {"]
        for k,v in tokens["schemes"]["dark"].items(): css.append(f" --md-sys-color-{k}: {v};")
        css += [" } }"]
        (self.output_dir / "m3_tokens.css").write_text("\n".join(css))
        print(f"✅ DONE! Created {self.output_dir}/m3_tokens.json")
        print(f"🚀 Seed {seed} -> Primary Light {tokens['schemes']['light']['primary']}")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seed", default="#6750A4")
    p.add_argument("--output", default="./m3_output")
    args = p.parse_args()
    M3AssetGenerator(args.seed, Path(args.output)).run()

if __name__ == "__main__":
    main()
