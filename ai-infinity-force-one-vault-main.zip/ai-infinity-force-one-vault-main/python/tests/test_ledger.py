"""pytest tests for the Python MackLedger (hash-chained audit ledger)."""
import json
import tempfile
from pathlib import Path

import pytest

from mack_stack.mack_sandbox import MackLedger


@pytest.fixture
def ledger_path(tmp_path):
    return tmp_path / "test_ledger.jsonl"


@pytest.fixture
def ledger(ledger_path):
    return MackLedger(path=ledger_path)


def test_append_and_verify(ledger):
    ledger.append("test_event", "MACK-01", {"key": "value"})
    ledger.append("test_event2", "MACK-02", {"n": 42})
    result = ledger.verify()
    assert result["valid"] is True
    assert result["count"] == 2


def test_chain_links_prev_hash(ledger, ledger_path):
    ledger.append("e1", "MACK-01", {"a": 1})
    e1_hash = ledger._last_hash
    ledger.append("e2", "MACK-01", {"a": 2})

    # Read the second entry; its prev_hash must equal the first entry's hash
    lines = ledger_path.read_text().strip().split("\n")
    e2 = json.loads(lines[1])
    assert e2["prev_hash"] == e1_hash


def test_tamper_detected(ledger, ledger_path):
    ledger.append("e1", "MACK-01", {"a": 1})
    ledger.append("e2", "MACK-01", {"a": 2})

    # Tamper: modify the first entry's payload
    lines = ledger_path.read_text().strip().split("\n")
    e1 = json.loads(lines[0])
    e1["data"]["a"] = 999
    lines[0] = json.dumps(e1)
    ledger_path.write_text("\n".join(lines) + "\n")

    # Reopen and verify: must detect tampering
    ledger2 = MackLedger(path=ledger_path)
    result = ledger2.verify()
    assert result["valid"] is False


def test_empty_ledger_verifies(ledger):
    result = ledger.verify()
    assert result["valid"] is True
    assert result["count"] == 0


def test_hmac_key_from_env_not_hardcoded():
    # The HMAC key must come from the environment, not be hardcoded.
    import mack_stack.mack_sandbox as m
    import os
    # With no env var, the key is empty (HMAC disabled, not a default secret)
    old = os.environ.pop("MACK_LEDGER_HMAC_KEY", None)
    try:
        import importlib
        importlib.reload(m)
        assert m.HMAC_KEY == b"", "HMAC key must be empty when env var is unset"
    finally:
        if old is not None:
            os.environ["MACK_LEDGER_HMAC_KEY"] = old
        importlib.reload(m)
