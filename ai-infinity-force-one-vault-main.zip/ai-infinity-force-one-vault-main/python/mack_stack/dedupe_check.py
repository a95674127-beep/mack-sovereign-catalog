import hashlib
from pathlib import Path
from collections import defaultdict

ROOT = Path(".")
SKIP = {".git", "target", "__pycache__", ".venv"}

def file_hash(p):
    h = hashlib.sha256()  # was md5; sha256 avoids bandit B324
    try:
        with open(p, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                h.update(chunk)
        return h.hexdigest()
    except (IOError, OSError) as e:
        print(f"[SKIP - {e}] {p}")
        return None

hashes = defaultdict(list)
names = defaultdict(list)

for p in ROOT.rglob("*"):
    if any(s in p.parts for s in SKIP):
        continue
    if not p.is_file():
        continue
    if p.suffix in [".pyc", ".pyo"] or p.name == ".DS_Store":
        print(f"[JUNK] {p}")
        continue
    h = file_hash(p)
    if h is None:
        continue
    hashes[h].append(p)
    names[p.name].append(p)

print("\n--- DUPLICATE CONTENT ---")
for h, files in hashes.items():
    if len(files) > 1:
        print(f"\nHash {h}:")
        for f in files:
            print(f"  {f}")

print("\n--- DUPLICATE NAMES (potential overlap) ---")
for name, files in names.items():
    if len(files) > 1 and name != "__init__.py":
        print(f"{name}: {files}")
