from mack_sandbox import get_ledger
import json

ledger = get_ledger()

events = [
    ("system_start", "MACK-01", {"note": "milestone 3 real run - startup"}),
    ("pov_ingest", "MACK-02", {"task_id": "task_0001_example", "verified": True}),
    ("pov_ingest", "MACK-03", {"task_id": "task_0002_example", "verified": False}),
]

print("=== APPEND ===")
for event_type, lane, payload in events:
    record = ledger.append(event_type, lane, payload)
    print(json.dumps(record, indent=2))

print("\n=== VERIFY ===")
result = ledger.verify()
print(json.dumps(result, indent=2))
