from cryptography.exceptions import InvalidTag


class EncryptedVaultSegmentManager:
    """Manages encrypted storage segments for the vault."""

    def __init__(self, key: bytes):
        self.key = key

    def decrypt_segment(self, segment_id: str, nonce: bytes, ciphertext: bytes, associated_data: bytes | None = None) -> bytes:
        """Decrypts a vault segment using AES-GCM."""
        try:
            # Assuming aesgcm is initialized or imported appropriately in your context
            plaintext = self.aesgcm.decrypt(nonce, ciphertext, associated_data)
            return plaintext
        except InvalidTag as e:
            raise ValueError(f"Decryption failed for segment {segment_id}: {e!s}")
          
