# Benchmarks — Audit Ledger

## What is measured

The two operations a deployment performs constantly on the tamper-evident
audit ledger (`AuditLog`, `src/vault/audit.rs`):

- **Append** — adding entries to the SHA-256 hash chain
  (`append_1000_entries`, `append_10000_entries`). Each append computes
  the entry's chain hash from its sequence, timestamp, actor, action and
  the previous entry's hash.
- **Verify** — walking a built chain end to end and recomputing every
  hash (`verify_1000_entries`, `verify_10000_entries`).

Benchmark source: `benches/audit_ledger.rs` (criterion 0.5, wired as the
`audit_ledger` bench target with `harness = false`). Append benchmarks
use `iter_batched` so chain construction is the measured work and setup
stays outside the timed region; verify benchmarks build the chain once,
outside the timed region.

## How to reproduce

```
export PATH="$HOME/.cargo/bin:$PATH"
export TMPDIR=~/workspace/tmp-cargo
export CARGO_BUILD_JOBS=2
cargo bench --bench audit_ledger
```

## Recorded run — 2026-11-06

Machine: the owner's agent workstation VM — AMD EPYC 9D25 (4 vCPUs
visible), 7.7 GB RAM, Linux 7.0.0-43-generic, rustc 1.99.1,
`CARGO_BUILD_JOBS=2`. Criterion defaults: 100 samples per benchmark.
Numbers below are criterion's reported [lower bound, **median**, upper
bound] of the mean-time confidence interval.

| Benchmark | Time [lower, median, upper] | Per entry (median) |
|---|---|---|
| append 1,000 entries | [1.7932 ms, **1.8155 ms**, 1.8409 ms] | ≈ 1.82 µs |
| append 10,000 entries | [18.138 ms, **18.343 ms**, 18.608 ms] | ≈ 1.83 µs |
| verify 1,000 entries | [989.27 µs, **990.27 µs**, 991.48 µs] | ≈ 0.99 µs |
| verify 10,000 entries | [10.038 ms, **10.116 ms**, 10.208 ms] | ≈ 1.01 µs |

Quotable form, with the machine attached: **on the recorded VM, the
ledger appends ≈ 550,000 entries/second and verifies a chain at
≈ 1,000,000 entries/second, scaling linearly from 1,000 to 10,000
entries.** These are workstation-VM figures for the in-memory
`AuditLog`; they are not dedicated-hardware numbers and are not a
latency guarantee for any other component (network, disk persistence
via `PersistentLedger`, and the detection pipeline are not measured
here).
